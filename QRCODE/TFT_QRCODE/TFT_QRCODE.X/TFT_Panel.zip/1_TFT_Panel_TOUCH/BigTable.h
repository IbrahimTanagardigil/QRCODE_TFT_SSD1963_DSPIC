#ifndef __BIGTABLE_H__
#define __BIGTABLE_H__



extern unsigned char ExBigFont[15][192];
extern unsigned char BigFont[25][192];
#endif