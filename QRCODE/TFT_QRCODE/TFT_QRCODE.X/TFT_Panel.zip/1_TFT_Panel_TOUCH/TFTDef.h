#include "p33FJ256MC710.h"

#ifndef __TFTDEF_H__
#define __TFTDEF_H__



#define CAN_111kHz		1			//Eski
//#define CAN_100kHz		1		//Yeni 28.02.2013

//��lemci sabitleri
#define DefFcy			40000000

//#define Ee_25LC320
#define Ee_25LC256

//#define TFTPAN_1
#define TFTPAN_2

#define PAGE2_5_SEKME
//#define PAGE2_4_SEKME


//Denemelerde buzzerin �tmesini istemiyorsan 0 yap.
#define DefBuzzerDurum			1

//CAN SID sabitleri
#define	DefCanInv		0x1f0			
#define	DefCanPfc		0x1e0		

//Can Emirleri
//636 ve daha b�y�k emirler iki module ayn� g�nderiliyor.Di�erleri tek tek g�nderilmek zorunda.
#define	DefEmir_GenelTest		623  	//CAN DEN GENEL TEST YAP EMR� GELD�
#define	DefEmir_Bypass			625  	//CAN DEN YUKU BYPASA AKTAR EMR� GELD�	 
#define	DefEmir_Inverter		627  	//CAN DEN Y�K� INVERTERE AKTAR EMR� GELD�
#define	DefEmir_RamToFabrika	629 	//CAN DEN AYARLARIN KOPYASINI FABR�KA B�LGES�NE YAP EMR� GELD�
#define	DefEmir_FabrikaToRam	631  	//CAN DEN AYARLARIN KOPYASINI PARAMETRE RAMINA Y�KLE EMR� GELD�
#define	DefEmir_RamToEeprom		633  	//CAN DEN T�M AYARLARI EPROMA KAYDET EMR� GELD�
#define	DefEmir_GeriBasma		667  	//CAN DEN DC BARADAK� FAZLALI�I �EBEKEYE BAS EMR� GELD�
#define	DefEmir_FaultReset		663  	//CAN DEN FAULT RESETLEME EMR� GELD�
#define	DefEmir_KisaAkuTestYap	639  	//CAN DEN KISA AK� TEST� YAP EMR� GELD�
#define	DefEmir_UzunAkuTestYap	641  	//CAN DEN UZUN AK� TEST� YAP EMR� GELD�
#define	DefEmir_AkuTestIptal	643  	//CAN DEN AK� TEST �PTAL EMR� GELD�	
#define	DefEmir_Boost			645  	//CAN DEN BOOST �ARJ BA�LAT EMR� GELD�
#define	DefEmir_CancelBoost		647  	//CAN DEN BOOST �ARJ DURDUR EMR� GELD�
#define	DefEmir_KisaDur			649  	//CAN DEN KISA S�RE DURAKLA EMR� GELD� (10 saniye)
#define	DefEmir_Jenerator		651  	//CAN DEN JENERAT�R MODUNA GEC EMR� GELD� (KALICI)
#define	DefEmir_Uyu				653  	//CAN DEN UYKU MODUNA GE� EMR� GELD�
#define	DefEmir_Uyan			655  	//CAN DEN UYKU MODUNDAN �IK EMR� GELD�
#define	DefEmir_LogOut			659  	//CAN DEN Logout emri
#define	DefEmir_LogIn			657  	//CAN DEN Login emri
#define	DefEmir_UserLogIn		661  	//CAN DEN User Login emri

#define DefEmir_AcilKapat		501		//CAN DEN Acil Kapat emri

//Can Genel sabitleri
#define DefCanHataSinir			3		//4 kere can den data gelince geriye error yazd�rs�n.
#define Def50ms					1		//Can me�gulken Uartta buffer lanan datay� tekrar 50 ms sonra g�nderir.
#define Def100ms				2		//Can me�gulken Uartta buffer lanan datay� tekrar 100 ms sonra g�nderir.

#define MinAddrKontrol			0
#define AraAddrKontrol			1
#define MaxAddrKontrol  		2


//Analog i�lemleri i�in sabitler
#define AN8			8
#define TH1			8
#define AN9			9
#define TH2			9
#define AN10		10					//Giri� DC ka�ak �l��m�
#define AN11		11					//Giri� DC ka�ak ref �l��m�
#define AN12		12					//DC besleme olcumu //02.10.2013
#define AN15		15					//Dc besleme kompanzasyonu i�in
#define AN19		19					//27.05.2015 Touch
#define AN18		18					//27.05.2015 Touch

//Eeprom Alarm kay�t (Log kay�t i�in)	
#define DefLogSil			0
#define DefLogOku			1	
#define DefLogYaz			2

#define DefLogBos			3
#define DefLogSilindi		4
#define DefLogSiliniyor		5

#define DefLogAlrGoster		1
#define DefOanAlrGoster		0
#define DefAlrGosterme		2

////Uart'tan Eeprom s�n�r adresleri
//#define DefEepromAltSinir	3072			
//#define DefEepromUstSinir	4094


//192 events
#ifdef Ee_25LC320

	#define DefLogFirstAddr		0
	#define DefLogLastAddr		3071
	#define DefMaxLogSayisi		192
	//Alarm men�s� tan�mlamalar�
	#define DefLogAltSinir		0
	#define DefLogUstSinir		191
	
	#define DefFullEeprom		4096

#endif
//512 events
#ifdef Ee_25LC256

	#define DefLogFirstAddr		4096
	#define DefLogLastAddr		12287
	#define DefMaxLogSayisi		512
	//Alarm men�s� tan�mlamalar�
	#define DefLogAltSinir		0
	#define DefLogUstSinir		511
	
	#define DefFullEeprom		12287

#endif

//16 Byte l�k 3071 - 0 + 1 = 3072 / 16 = 192 tane
#define DefLogCount			((DefLogLastAddr - DefLogFirstAddr + 1) / 16) 

//Alarm durumuna kar��l�k �ekilen r�le i�lemleri i�in
#define DefRoleSimulasyon	0
#define DefRoleAlarmaBagli	1
#define DefRoleDefault		12
	

//Uart'tan Eeprom s�n�r adresleri
#define DefEepromAltSinir	3071	
#define DefEepromUstSinir	4094
#define DefEepromTabanAdres 3302

#define DefEepromLabelAltSinir 3072
#define DefEepromLabelUstSinir 3234

//#define DefEepromDegiskenUstSinir 3476	//3468 di 	12.03.2014
#define DefEepromDegiskenUstSinir 3496		//Touch i�in eklendi

#define DefEepromBosKontrol	4092

//Megatech Protokol�
//G2
#define DefMegatech_ThreeInThreeOut	0
#define DefMegatech_ThreeInOneOut	1
#define DefMegatech_Normal			0

/* LCD'de kullanilan komutlarin tanimlamasi*/ 
#define DefSil  			1			// Ekrani temizler 
#define DefBasaDon  		2  			// Imleci sol �st k�seye getirir 
#define DefSolaYaz  		4  			// Imlecin belirttigi adres azalarak gider 
#define DefSagaYaz  		6  			// Imlecin belirttigi adres artarak gider 
#define DefImlecGizle  		12   		// G�stergeyi ac, kursor g�r�nmesin 
#define DefImlecAltta  		14   		// Yanip s�nen blok kursor 
#define DefImlecYanSon		15   		// Yanip s�nen blok kursor
#define DefImlecGeri     	16  		// Kursoru bir karakter geri kaydr 
#define DefKaydirSaga    	24  		// G�stergeyi bir karakter saa kaydr                   
#define DefKaydirSola    	28  		// G�stergeyi bir karakter sola kaydr    
#define DefEkraniKapat   	8       	// G�stergeyi kapat (veriler silinmez) 
#define DefBirinciSatir  	128  		// LCD'nin ilk satir balang� adresi        
                            			// (DDRAM adres) 
#define DefIkinciSatir  	192  		// Dkinci satirin balang� adresi 
#define DefKarakUretAdres 	64  		// Karakter �reteci adresini belirle   
                            			// (CGRAM adres) 
/* LCD'de Kullanilan Fonksiyon Se�imi */ 
#define DefCiftSatir8Bit  	56  		// 8 bit ara birim, 2 satir, 5*7 piksel 
#define DefTekSatir8Bit   	48  		// 8 bit ara birim, 1 satir, 5*7 piksel 
#define DefCiftSatir4Bit  	40  		// 4 bit ara birim, 2 satir, 5*7 piksel 
#define DefTekSatir4Bit   	32  		// 4 bit ara birim, 1 satir, 5*7 piksel 
 
//Men� tan�mlamalar�
//------------------
#define DefAnaMenu			1			//Ana men� i�erisinde ise
#define DefAlt1Menu			2			//Alt1 men� i�erisinde ise
#define DefOlcumAltMenu		4			//�l��m g�sterge men� i�erisinde ise
#define DefAyarAnaMenu		8			//Ayar i�lemlerinin se�ildi�i ana men�
#define DefAyarAltMenu		16			//Ayar i�lemlerinin yap�ld��� alt men�
#define DefAyarGrupAltMenu	32			//Ayar men�s�ndeki grup ayarlar�nda kullan�lacak.
#define DefTercihAltMenu	64			//Tercih alt men� i�erisinde ise
#define DefAraSifreMenu		128			//Uyar� ! L�tfen �ifre giriniz dedikten sonra ekranda g�z�kecek men� d�r.
#define DefEmirAltMenu		256			//Emir alt men�s� i�erisinde ise ( Alarm Ses : A��k - Kapal� se�ene�inde )
#define DefEmirRoleMenu		512			//Emir R�le test alt men�s� i�in
#define DefRoleAlarmAtama	1024		//Tercihler R�lelere alarm atama i�lemi

//Buton tan�mlamalar�
#define DefYukariButon		1
#define DefAsagiButon		2
#define DefEnterButon		4
#define DefSagButon			8
#define DefSolButon			16	

//Ana men� isimlerinin tan�mlamalar�
#define DefAnaMenuUstLimit		10
#define DefAnaMenuAltLimit		1
#define DefOlcumMenuUstLimit	6
#define DefOlcumMenuAltLimit	1


#define DefDurumMenu		1
#define DefOlcumMenu		2
#define DefAlarmMenu		3
#define DefBilgiMenu		4
#define DefTercihMenu		5
#define DefEmirMenu			6
#define DefZamanMenu		7
#define DefServisMenu		8
#define DefAyarMenu			9
#define DefAyarMenu_1		91
#define DefAyarMenu_2		92
#define DefAyarMenu_3		93
#define DefAyarMenu_4		94
#define DefKalibrasyon		10			//Touch

#define DefSifreDogru		5
#define DefSifreYanlis		6

//�l��m men�s� isimlerinin tan�mlamar�
#define DefGiris			1
#define DefBypass			2
#define DefEvirici			3
#define DefCikis			4
#define DefDc				5
#define DefGenel			6
#define DefOlcumExit		7

//Bilgi men�s� isimlerinin tan�mlamalar�
#define DefBilgiSayfa		1

//Tercih men�s� isimlerinin tan�mlamar�
#define DefLcdTercihleri			1
#define DefHaberlesmeTercihleri		2
#define DefAlarmTercihleri			3
#define DefBypassTercihleri			4
#define DefTercihExit				5

//Ayar Ana men�s� isimlerinin tan�mlamar�
#define DefGrupParametre	0
#define DefInvFabrika		1
#define DefPfcFabrika		2
#define DefPanelSecenek		3
#define DefAcGiris			4
#define DefAcBypass			5
#define DefAcCikis			6
#define DefDcAyar			7
#define DefGucSecenek		8
#define DefSystemAdj		9
#define DefAyarAnaExit		10

//Ayar Grup Parametreleri ana men�s�
#define DefGrup_2192	0
#define DefGrup_2193	1
#define DefGrup_2194	2
#define DefGrup_2185	3
#define DefGrup_2142	4
#define DefGrup_1187	5
#define DefGrup_1136	6
#define DefGrup_1181	7
#define DefGrup_2233	8
#define DefGrup_1233	9



//Tercihler men�s� tan�mlamalar�
#define DefDilAltSinir		 0
#define DefDilUstSinir		 2
#define DefBackLightUstSinir 9
#define DefBackLightAltSinir 2 
#define DefAcikSureUstSinir  30
#define DefAcikSureAltSinir  10
#define DefYarimAydinlikSureUstSinir  30
#define DefYarimAydinlikSureAltSinir  10

#define DefServisPort		0
#define DefUserPort			1

//Emirler men�s� tan�mlamalar�
#define DefUyariSesAraligiUstSinir 10
#define DefUyariSesAraligiAltSinir 5

#define DefRole_LFAlr		33				//Alarm : R02
#define DefRole_BLAlr		25				//Alarm : A26
#define DefRole_BYPAlr		18				//Alarm : A19
//Servis men�s� tan�mlamalar�
#define DefYedekBakim		0
#define DefFanBakim			1
#define DefAkuBakim			2
#define DefGenelBakim		3


//Genel
#define Enter_Exit			0

//Menu.Koordinat tan�mlamalar�
/*      Alt Menu Ad�       Ana Menu Numaras�   +    Alt Menu Numaras� * 256     Toplam      */

#define DefDurum_Ana_Menu		1 + ( 256 )										//257

#define DefOlcGirisMenu			2 + ( 1 * 256 )									//258
#define DefOlcBypMenu			2 + ( 2 * 256 )									//514
#define DefOlcInvMenu			2 + ( 3 * 256 )									//770
#define DefOlcCikisMenu			2 + ( 4 * 256 )									//1026
#define DefOlcDcMenu			2 + ( 5 * 256 )									//1282
#define DefOlcGenelMenu			2 + ( 6 * 256 )									//1538

#define DefAlrLogMenu			3 + ( 1 * 256 )									//259
#define DefAlrSilMenu			3 + ( 2 * 256 )									//515

#define DefBilgiCommMenu		4 + ( 1 * 256 )									//260		

#define DefOptEkranMenu			5 + ( 1 * 256 )									//261
#define DefOptHaberMenu			5 + ( 2 * 256 )									//517
#define DefOptAlrMenu			5 + ( 3 * 256 )									//773
#define DefOptBypassMenu		5 + ( 4 * 256 )									//1029

#define DefEmirBypInvMenu		6 + ( 1 * 256 )									//262
#define DefEmirBoostMenu		6 + ( 2 * 256 )									//518
#define DefEmirAkuTestMenu		6 + ( 3 * 256 )									//774
#define DefEmirRoleSimMenu		6 + ( 4 * 256 )									//1030
#define DefEmirModemInitMenu	6 + ( 5 * 256 )									//1286
#define DefEmirAlrSesMenu		6 + ( 6 * 256 )									//1542
#define DefEmirMimikMenu		6 + ( 7 * 256 )									//1798

#define DefZamanGosterMenu		7 + ( 1 * 256 )									//263
#define DefZamanSaatMenu		7 + ( 2 * 256 )									//519
#define DefZamanDakMenu			7 + ( 3 * 256 )									//775
#define DefZamanGunMenu			7 + ( 4 * 256 )									//1031
#define DefZamanAyMenu			7 + ( 5 * 256 )									//1287
#define DefZamanYilMenu			7 + ( 6 * 256 )									//1543
#define DefZamanKayitMenu		7 + ( 7 * 256 )									//1799

#define DefServisToplamSaatMenu 8 + ( 1 * 256 )									//264
#define DefServisMakYukMenu		8 + ( 2 * 256 )									//520
#define DefServisHataSifirMenu	8 + ( 3 * 256 )									//776
#define DefServisBakimMenu		8 + ( 4 * 256 )									//1032
#define DefServisLogoutMenu		8 + ( 5 * 256 )									//1288

#define DefAyar_Ana_Menu		9 + ( 256 )										//265
#define DefAyarKodMenu			9 + ( 1 * 256 )									//265
#define DefAyarSifreMenu		9 + ( 2 * 256 )									//521
#define DefUserKodMenu			9 + ( 3 * 256 )									//777

//Menu.TercihKoordinat
/* Tercih Alt Menu Ad�    Tercih Ana Menu Numaras�   +  Tercih Alt Menu Numaras� * 256     Toplam      */
#define DefOptDilMenu			1 + ( 1 * 256 )									//261
#define DefOptButonMenu			1 + ( 2 * 256 )									//517
#define DefOptAydinlikMenu		1 + ( 3 * 256 )									//3077
#define DefOptBeklemeMenu		1 + ( 4 * 256 )									//3333
#define DefOptKarartmaMenu		1 + ( 5 * 256 )									//3589

#define DefOptRemoteMenu		2 + ( 1 * 256 )									//773
#define DefOptCom2Menu			2 + ( 2 * 256 )									//1029
#define DefOptSNMPMenu			2 + ( 3 * 256 )									//1029
#define DefOptRole1Menu			2 + ( 4 * 256 )									//3845
#define DefOptRole2Menu			2 + ( 5 * 256 )									//4101
#define DefOptRole3Menu			2 + ( 6 * 256 )									//4357
#define DefOptRole4Menu			2 + ( 7 * 256 )									//4613
#define DefOptRole5Menu			2 + ( 8 * 256 )									//4869
#define DefOptRole6Menu			2 + ( 9 * 256 )									//5125
#define DefOptRole7Menu			2 + ( 10 * 256 )								//5381
#define DefOptRole8Menu			2 + ( 11 * 256 )								//5637
#define DefOptRole9Menu			2 + ( 12 * 256 )								//5893
#define DefOptRole10Menu		2 + ( 13 * 256 )								//6149
#define DefOptRole11Menu		2 + ( 14 * 256 )								//6405
#define DefOptRole12Menu		2 + ( 15 * 256 )								//6661
#define DefOptREPOMenu			2 + ( 16 * 256 )								//6661

#define DefOptUyariAralikMenu 	3 + ( 1 * 256 )									//2821
#define DefOptUyariKayitMenu	3 + ( 2 * 256 )									//1285
#define DefOptDurumKayitMenu	3 + ( 3 * 256 )									//1541
#define DefOptElgBaslaMenu		3 + ( 4 * 256 )									//1797

#define DefOptVatTransMenu		4 + ( 1 * 256 )									//2053
#define DefOptJenBypMenu		4 + ( 2 * 256 )									//2309
#define DefOptJenSenkMenu		4 + ( 3 * 256 )									//2565
#define DefOptModSecMenu		4 + ( 4 * 256 )									//1028



//Mimik diyagram Tan�mlamalar�
#define DefPfcPasif				0
#define DefPfcAktif				1
#define DefInvPasif				2
#define DefInvAktif				3
#define DefTrisorPasif			4
#define DefTrisorAktif			5
#define DefAnahtarPasif			6
#define DefAnahtarAktif			7
#define DefAkuBos				8
#define DefAkuDolu1				9
#define DefAkuDolu2				10
#define DefAkuDolu3				11
#define DefUyari				12

#define DefGri					0
#define DefYesil				1
#define DefSari					2
#define DefKirmizi				3

#define DefPasif				0
#define DefAktif				1



//PIN TANIMLAMALARI
//-----------------

//Eeprom Pin tan�mlamalar�
#define Ee_Cs			_LATF13								
#define EeHold			_LATD14				
#define EeWp			_LATD15	

//Rtc pin tan�mlamalar�
#define Cs_Rtc 			_LATF12	
#define Int_Cs			_LATA15					//int4

//R�le tan�mlamalar�
#define Relay1			LATDbits.LATD12
#define Relay2			LATAbits.LATA1
#define Relay3			LATDbits.LATD11
#define Relay4 			LATDbits.LATD0

//OptO3 kart� tan�mlamalar�
#define Relay5			LATGbits.LATG14			//Relay Opt1
#define Relay6 			LATEbits.LATE1			//Relay Opt2
#define Relay7			LATEbits.LATE0			//Relay Opt3
#define Relay8 			LATAbits.LATA7			//Relay Opt4
#define Relay9 			LATGbits.LATG12			//Relay Opt5
#define Relay10 		LATGbits.LATG13			//Relay Opt6
#define Relay11 		LATEbits.LATE2			//Relay Opt7
#define Relay12 		LATEbits.LATE3			//Relay Opt8
	
#define IN2_OPT			PORTGbits.RG1			//OPT03 Kart�		
#define IN3_OPT			PORTGbits.RG0			//OPT03 Kart�	

//Haberle�me ( RS430 ) kart� tan�mlamalar�
#define SnmpRelay		LATAbits.LATA6			//RS430 kart� SNMP r�lesi

//Led tan�mlamalar�
#define LEDMainOk		LATAbits.LATA3			//Main Ok Led
#define LEDRectifier	LATAbits.LATA0			//Rectifier Led
#define LEDBatt			LATAbits.LATA4			//Battery Led
#define LEDMaint		LATCbits.LATC3			//Static Bypass Led
#define LEDLoadInv		LATCbits.LATC2			//Load On Inv Led
#define LEDStaticByp	LATCbits.LATC4			//Maint. Byp Led
#define LEDOutSw		LATCbits.LATC1			//Output Switch Led

//Lcd Pin tan�mlamalar�
#define LcdPort			LATD
#define LcdE			LATDbits.LATD10
#define LcdRs			LATDbits.LATD9
#define LcdBL			LATEbits.LATE7
#define Buzzer			_LATG3			

//Buton Tan�mlamalar�
#define	Asagi			PORTBbits.RB0	
#define	Sol				PORTBbits.RB1
#define Enter			PORTBbits.RB2	
#define	Sag				PORTBbits.RB3			
#define	Yukari			PORTBbits.RB4	


	
//IDB03 Kart� tan�mlamalar�
#define	GENIN1			PORTEbits.RE9	
#define	EMCSTOP			PORTAbits.RA14	
#define	BATTSW			PORTEbits.RE8	


//TFT tan�mlamalar�

#define TFT_RS		_LATD9
#define TFT_CS		_LATD10

//#define TFT_D0		_LATE4
#define TFT_D0		_LATD1
#define TFT_D1		_LATD2
#define TFT_D2		_LATD3
#define TFT_D3		_LATD4
#define TFT_D4		_LATD5
#define TFT_D5		_LATD6
#define TFT_D6		_LATD7
#define TFT_D7		_LATD8



#define TFT_WR		_LATG2

#ifdef TFTPAN_1
	#define TFT_D8		_LATA2
#endif
#ifdef TFTPAN_2
	#define TFT_D8		_LATC2
#endif

#define TFT_BL		_LATE7
#define TFT_DISP_ON _LATE5

#ifdef TFTPAN_1
	#define TFT_RES		_LATA3
#endif
#ifdef TFTPAN_2
	#define TFT_RES		_LATA0
#endif

#define TFT_RD		_LATA4
//Background colors
#define Clear		1
#define NotClear	0
#define Gradient	1
#define NotGradient	0
#define Digital		1
#define NotDigital	0
#define White		100
#define Black		200
#define Blue		300
#define Grey		400
#define Red			500
#define Green		600
#define DarkBlue	700
//For Big Variables definations
#define ikiNokta	10					//:
#define Nokta		11					//.
//#define AltUstOk	12					//Ok					optimizasyon i�in 17.02.2014
#define YukariOk	13					//Ok
#define AsagiOk		14					//Ok
#define SolOk		15					//Ok
#define SagOk		16					//Ok
#define OrtaNokta	17					//B�y�k orta nokta
#define SagSolOK	18					//B�y�k orta nokta
//#define Unlem		19					//Unlem					optimizasyon i�in 17.02.2014
#define TouchArti	19
#define Uyari		20					//Uyari
#define ScrollDownOk 21
#define ScrollUpOk	22
//#define ScrollBar	23											optimizasyon i�in 17.02.2014


//Touch Panel tan�mlamalar�
//#define AnalogX		17			//27.05.2015 de�i�tirildi Touch
#define AnalogX		19
#define AnalogY		18
#define DriveA		_LATC1		//Yeni TFTPAN1
#define DriveB		_LATB5		//Yeni TFTPAN1

//Measure men�
#define Input		0
#define Bypass		1
#define Inverter	2
#define Output		3
#define DC			4
#define General		5
//#define Enter_Exit	6
#endif