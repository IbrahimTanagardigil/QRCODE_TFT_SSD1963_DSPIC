#ifndef __LCDEEPROM_H__
#define __LCDEEPROM_H__

extern void EeAlarmOku(struct DATE * ,int );
extern void EeAlarmYaz(struct DATE * ,int );
extern void EeByteYaz(unsigned int ,unsigned int );
extern unsigned int EeByteOku(unsigned int );
extern void EeAktif(void);
extern volatile void BekleMs(int );
extern void EeWordYaz(unsigned int ,unsigned int );
extern unsigned int EeWordOku(unsigned int );

#endif