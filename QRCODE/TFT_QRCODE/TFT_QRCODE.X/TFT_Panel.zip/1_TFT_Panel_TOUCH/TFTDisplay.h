#ifndef __TFTDISPLAY_H__
#define __TFTDISPLAY_H__

extern void TFTInit(void);
extern void DigitalText(unsigned int ,unsigned int ,const char* ,unsigned long ,unsigned int );
extern void OutVariable(unsigned int ,unsigned int ,unsigned int ,unsigned char ,unsigned char ,unsigned int ,unsigned long ,unsigned long ,unsigned int );
extern void SendVariable(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned long );
extern unsigned char BitCntrl(unsigned int ,unsigned char );
extern void SSD1963Init(void); 
extern void Write_Command (unsigned char );
extern void Write_Data (unsigned int );
extern void Komut_TekParametre(unsigned char ,unsigned char );
extern void SendPixel(unsigned long );
extern void goToAddress(unsigned int ,unsigned int );
extern void WindowSet(unsigned int ,unsigned int ,unsigned int,unsigned int);
extern void FullScreen(unsigned long );
extern void Area1963(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long );
extern void Line(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int );
extern void CaprazHat(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int );
extern void PixelPoint(unsigned int ,unsigned int ,unsigned long ,unsigned int);
extern void Circle(unsigned int ,unsigned int , unsigned int ,unsigned int ,unsigned int , unsigned long ,unsigned int);
extern void Dikdortgen(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int ,unsigned int ,unsigned int );
extern void BusSend(unsigned int );
extern void FirstState(void);
extern void Wait(unsigned int );
extern void NopWait(unsigned int );
extern void ShowPic(void);	
extern void Mouse(unsigned int ,unsigned int );
extern void ShowIcon(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned int );
extern void DegiskenFONTFonk(unsigned int ,unsigned int ,const char* ,unsigned int ,unsigned long ,unsigned long ,unsigned int,unsigned int ,unsigned int );
extern unsigned long GetPixelColor(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long );
extern void BackGround(unsigned int ,unsigned int ,unsigned long );
extern void ChangePage(unsigned int );
extern void ChangeSatir(unsigned int );
extern void ASendText(unsigned int ,unsigned int ,const char* ,unsigned int ,unsigned long ,unsigned long ,unsigned int );
extern void ASendText2(unsigned int ,unsigned int ,const char* ,unsigned int ,unsigned long ,unsigned long ,unsigned int );

extern void BufferedText(unsigned int ,unsigned int ,unsigned int ,unsigned long );
extern void ASendVariable(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned long ,unsigned int );
extern void ClearLine(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int ,unsigned int );

extern void Elipse(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int ,unsigned int );

extern void BigOutVar(unsigned int ,unsigned int ,unsigned int ,unsigned char ,unsigned char ,unsigned int ,unsigned long ,unsigned int );
extern void BigVariable(unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int );

extern void ExBigVariable(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned int );

extern void FotoSendPixel(unsigned long );


#endif