#ifndef __TOUCH_H__
#define __TOUCH_H__

extern unsigned int TouchIntWait(void);
extern unsigned int FilterY(void);
extern unsigned int Yal(void);
extern unsigned int FilterX(void);
extern unsigned int Xal(void);
extern unsigned int Average(unsigned int ,unsigned char );
extern void GetCoordinate(void);
extern void CalibrationMenu(int );

#endif