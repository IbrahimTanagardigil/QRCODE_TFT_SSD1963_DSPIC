#ifndef __TFTRTC_H__
#define __TFTRTC_H__

#include "TFTVar.h"

extern void YazRTC(volatile struct DATE *);
extern void OkuRTC(volatile struct DATE *);

#endif