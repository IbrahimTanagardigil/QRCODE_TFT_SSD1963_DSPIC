#include "p33FJ256MC710.h"

#include "TFTDef.h"
#include "TFTVar.h"
#include "TFTUart1.h"
#include "TFTRtc.h"
#include "TFTEeprom.h"
#include "TFTCanInv.h"
#include "TFTCanPfc.h"


void Uart1_Fonk( unsigned int *U1_Buf, unsigned int U1_Count)
{	
	unsigned int Uart1_i;
	unsigned int U1_ZamanCevap;
	unsigned int U1_AraIslem;
	unsigned int U1_SifreSayac = 0;
	unsigned int U1_Yetki;
	
	Uart1.Flag = 0;		
	switch(U1_Count)
	{
		case 2:
			// PC Uart program� i�in gerekli
			if(*U1_Buf == 'P')
			{
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}				
			else if(*U1_Buf == 'I')
			{
				for(Uart1_i = 0;Uart1_i < 15;Uart1_i++)
					Uart1.GonderBuf[Uart1_i] = Label.Firma[Uart1_i+1];
				for(Uart1_i = 0;Uart1_i < 10;Uart1_i++)
					Uart1.GonderBuf[Uart1_i + 15] = Label.Model[Uart1_i];
				for(Uart1_i = 0;Uart1_i < 10;Uart1_i++)
					Uart1.GonderBuf[Uart1_i + 25] = UartProtokol[Uart1_i];
				U1_Gonder("#$$$$$$$$$$$$$$$ $$$$$$$$$$ $$$$$$$$$$",Uart1.GonderBuf);
				break;
			}
			//Burada kullan�lacak emirler & Megatech komutlar� var.

				
			else if (*U1_Buf == 'T')																//CONTROL COMMAND from PC  (Test batteries) 
			{		
				if( EeKayit.Konfig.Bit.UzakErisim )
				{		
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{				
						CanGonder(DefCanInv,28,'W',DefEmir_KisaAkuTestYap,0);					// command to UPS test Start
						U1_Gonder("OK", Uart1.Dumm );
						Megatech.T.TestForTenSec = 1;
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{
					U1_Gonder("ACCDE",Uart1.Dumm );
				}
				break;
			}						
			else if (*U1_Buf == 'Q') 															// Beeper on/off
			{		
				if( EeKayit.Konfig.Bit.UzakErisim )
				{
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{																			// Response from UPS
						U1_Gonder("OK", Uart1.Dumm );											// command for beeper on / off 	
						//Yeni Bir alarma kadar buzzer sesini kapat	veya a�
						Megatech.Q.TurnBeep ^= 1;
						if( Menu.MaskeAlarmSesAcik == 0 )
							Menu.MaskeAlarmSesAcik = 1;
						else if( Menu.MaskeAlarmSesAcik == 1 )
							Menu.MaskeAlarmSesAcik = 0;
			//			Menu.EskiAlarmSesAcik = Menu.MaskeAlarmSesAcik;		
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{
					U1_Gonder("ACCDE",Uart1.Dumm );
				}
				break;
			}
			else if (*U1_Buf == 'C') 															//CONTROL COMMAND from PC  (Cancel shutdown)
			{		
				if( EeKayit.Konfig.Bit.UzakErisim )
				{
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						Timer6.ShutdownTime	= 0;
						Timer6.RestoreTime = 0;	
						Alarm.Word.Lcd2.Bit.Uyanacak = 0;
						Alarm.Word.Lcd2.Bit.Uykuyagirecek = 0;
						CanGonder(DefCanInv,28,'W',DefEmir_Uyan,0);		
						U1_Gonder("OK", Uart1.Dumm );
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{
					U1_Gonder("ACCDE",Uart1.Dumm );
				}
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 3:		
			// PC Uart program� i�in gerekli
			if( (*U1_Buf == 'W') && (*(U1_Buf + 1) == 'P') )
			{
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}
			
			
			else if( (*U1_Buf == 'L') && (*(U1_Buf + 1) == 'S') )
			{
				if( Can.FromInv.LogInDurum == 1 )
					U1_Gonder("OK", Uart1.Dumm );
				else
					U1_Gonder("LOUT", Uart1.Dumm );
				break;
			}		
			else if(*U1_Buf == 'D')
			{
				if( *(U1_Buf + 1) == '1' )
				{
					//!11111_22222_33333_44444_55555_66666_XXX_YYY<chr$13> 
					//!11111_22222_33333_44444_55555_66666_XXXX_YYYY<chr$13> oldu
					Uart1.GonderBuf[0] = Alarm.Word.Inv1.All;		//Inv Alarmlar�
					Uart1.GonderBuf[1] = Alarm.Word.Inv2.All;		//Inv Uyar�lar� 1
					Uart1.GonderBuf[2] = Alarm.Word.Inv3.All;		//Inv Uyar�lar� 2
					Uart1.GonderBuf[3] = Alarm.Word.Pfc1.All;		//Pfc Alarmlar�
					Uart1.GonderBuf[4] = Alarm.Word.Pfc2.All;		//Pfc Uyar�lar�
					Uart1.GonderBuf[5] = Alarm.Word.Lcd1.All;		//Lcd Alarmlar�	
					Uart1.GonderBuf[6] = AlarmKod.Kod.Pfc;// - 1000;	//Pfc Kod
					Uart1.GonderBuf[7] = AlarmKod.Kod.Inv;			//Inv Kod
					U1_Gonder("!� � � � � � @ @",Uart1.GonderBuf);
					break;
				}	
				else if( *(U1_Buf + 1) == '2' )
				{		
					//AAA_BBB_CCC_DDD_EEE_FFF_GGG_HHH_JJJ_KKK_LLL_MMM_RRR_SSS_TTT_NN.N_PP.P<chr13>
					Uart1.GonderBuf[0] = Can.FromPfc.VinRMS.L1;									//Rectifier Input Voltage Line L1
					Uart1.GonderBuf[1] = Can.FromPfc.VinRMS.L2;									//Rectifier Input Voltage Line L2
					Uart1.GonderBuf[2] = Can.FromPfc.VinRMS.L3;									//Rectifier Input Voltage Line L3
					Uart1.GonderBuf[3] = Can.FromPfc.VinRMS.L1L3;								//Rectifier Input Voltage Line L1 - L3
					Uart1.GonderBuf[4] = Can.FromPfc.VinRMS.L2L1;								//Rectifier Input Voltage Line L2 - L1
					Uart1.GonderBuf[5] = Can.FromPfc.VinRMS.L3L2;								//Rectifier Input Voltage Line L3 - L2
					Uart1.GonderBuf[6] = Can.FromPfc.CinRMS.L1;									//L1 phase input current in amperes
					Uart1.GonderBuf[7] =Can.FromPfc.CinRMS.L2;									//L2 phase input current in amperes
					Uart1.GonderBuf[8] =Can.FromPfc.CinRMS.L3;									//L3 phase input current in amperes
					Uart1.GonderBuf[9] = Can.FromInv.VbypRMS.L1;								//L1 phase bypass input voltage in volts -- phase to neutral
					Uart1.GonderBuf[10] = Can.FromInv.VbypRMS.L2;								//L2 phase bypass input voltage in volts -- phase to neutral
					Uart1.GonderBuf[11] = Can.FromInv.VbypRMS.L3;								//L3 phase bypass input voltage in volts -- phase to neutral
					Uart1.GonderBuf[12] = Can.FromInv.VbypRMS.L1L3;								//L1 - L3 phase bypass input voltage in volts -- phase to neutral
					Uart1.GonderBuf[13] = Can.FromInv.VbypRMS.L2L1;								//L2 - L1 phase bypass input voltage in volts -- phase to neutral
					Uart1.GonderBuf[14] = Can.FromInv.VbypRMS.L3L2;								//L3 - L2 phase bypass input voltage in volts -- phase to neutral
					Uart1.GonderBuf[15] = Can.FromPfc.RecFreq;									//Measured L1 phase rectifier input frequency (1/10 Hertz)		
					Uart1.GonderBuf[16] = Can.FromInv.BypFreq;									//Measured by-pass input frequency (1/10 Hertz)
					U1_Gonder("?% % % % % % % % % % % % % % % ^ ^",Uart1.GonderBuf);	
					break;					
				}
				else if( *(U1_Buf + 1) == '3' )
				{
					//?PPP_CCC_NNN_+BBB.B_+PPP.P_+SSS.S_RRR_TTT_UUU_KK_HHH<chr$13>
					Uart1.GonderBuf[0] = Can.FromPfc.RecDCBus.Pos + Can.FromPfc.RecDCBus.Neg;	//Total Battey Voltage in Volts
					Uart1.GonderBuf[1] = Can.FromPfc.RecDCBus.Pos;								//(+) battery group DC voltage
					Uart1.GonderBuf[2] = Can.FromPfc.RecDCBus.Neg;								//(-) battery group DC voltage
					
					if( Can.FromPfc.DisCbattC.Pos > 0 )
					{
						Uart1.GonderBuf[3] = '-';
						Uart1.GonderBuf[4] = Can.FromPfc.SonucDisCbattC.Pos;					//(+) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					else			
					{
						Uart1.GonderBuf[3] = '+';		
						Uart1.GonderBuf[4] = Can.FromPfc.CbattC.Pos;							//(+) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					if( Can.FromPfc.DisCbattC.Neg > 0 )
					{
						Uart1.GonderBuf[5] = '-';
						Uart1.GonderBuf[6] = Can.FromPfc.SonucDisCbattC.Neg;					//(-) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					else
					{				
						Uart1.GonderBuf[5] = '+';	
						Uart1.GonderBuf[6] = Can.FromPfc.CbattC.Neg;							//(-) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					if( AyarBitAnlam.InvFactOpt.Bit.TempSensor == 0 )
					{
						if( EeKayit.TermalSensor1.Olculen > 32767)
						{	
							Uart1.GonderBuf[8] = 65536 - EeKayit.TermalSensor1.Olculen;			//measured battery ambient temperature (1/10 deg C)
							Uart1.GonderBuf[7] = '-';
						}
						else if( EeKayit.TermalSensor1.Olculen == 0 )
						{
							Uart1.GonderBuf[8] = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart1.GonderBuf[7] = ' ';
						}
						else
						{
							Uart1.GonderBuf[8] = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart1.GonderBuf[7] = '+';
						}
					}
					else																		//measured battery ambient temperature (1/10 deg C)
					{							
						if( Can.FromPfc.RecTemp > 32767)
						{
							Uart1.GonderBuf[8] = 65536 - Can.FromPfc.RecTemp;	
							Uart1.GonderBuf[7] = '-';
						}
						else if( Can.FromPfc.RecTemp == 0 )
						{
							Uart1.GonderBuf[8] = Can.FromPfc.RecTemp;	
							Uart1.GonderBuf[7] = ' ';
						}
						else
						{
							Uart1.GonderBuf[8] = Can.FromPfc.RecTemp;	
							Uart1.GonderBuf[7] = '+';
						}
					}
					if(( Alarm.Word.Pfc1.Bit.SebekeKesik == 1 ) && (AkuKapasite.IlkDakikaGecti == 1))
						Uart1.GonderBuf[9] = AkuKapasite.KalanSure;
					else
						Uart1.GonderBuf[9] = EeKayit.AkuSabitKalanSure;
			//		Uart1.GonderBuf[9] = Menu.AkuKalanSure;									//estimated battery backup time
					Uart1.GonderBuf[10] = Can.FromPfc.RecDCBus.Pos;								//Measured (+)DC BUS voltage
					Uart1.GonderBuf[11] = Can.FromPfc.RecDCBus.Neg;								//Measured (-)DC BUS voltage
					Uart1.GonderBuf[12] = EeKayit.AkuKolSayisi;									//Battery groups
					Uart1.GonderBuf[13] = EeKayit.AkuAh;										//Battery A/H rating
					U1_Gonder("?% % % $� $� $� % % % ] %",Uart1.GonderBuf);
					break;
				}
				else if( *(U1_Buf + 1) == '4' )
				{		
					//?AAA_BBB_CCC_DDD_EEE_GGG_HHH_III_JJJ_FF.F_KKK_MMM_NNN<chr$13>
					Uart1.GonderBuf[0] = Can.FromInv.VinvRMS.L1;								//L1 phase AC inverter output voltage  / phase to neutral
					Uart1.GonderBuf[1] = Can.FromInv.VinvRMS.L2;								//L2 phase AC inverter output voltage  / phase to neutral
					Uart1.GonderBuf[2] = Can.FromInv.VinvRMS.L3;								//L3 phase AC inverter output voltage  / phase to neutra
					Uart1.GonderBuf[3] = Can.FromInv.VoutRMS.L1;								//L1 phase AC UPS output voltage  / phase to neutral
					Uart1.GonderBuf[4] = Can.FromInv.VoutRMS.L2;								//L2 phase AC UPS output voltage  / phase to neutral
					Uart1.GonderBuf[5] = Can.FromInv.VoutRMS.L3;								//L3 phase AC UPS output voltage  / phase to neutral
					Uart1.GonderBuf[6] = Can.FromInv.VinvRMS.L1L3;								//L1-L3 phase AC UPS output voltage / phase to phase
					Uart1.GonderBuf[7] = Can.FromInv.VinvRMS.L2L1;								//L2-L1 phase AC UPS output voltage / phase to phase
					Uart1.GonderBuf[8] = Can.FromInv.VinvRMS.L3L2;								//L3-L2 phase AC UPS output voltage / phase to phase
					Uart1.GonderBuf[9] = Can.FromInv.OutFreq;									//UPS output frequency in hertz (1/10 Hertz)
					Uart1.GonderBuf[10] = Can.FromInv.CoutRMS.L1;								//L1 phase UPS output current in amperes
					Uart1.GonderBuf[11] = Can.FromInv.CoutRMS.L2;								//L2 phase UPS output current in amperes
					Uart1.GonderBuf[12] = Can.FromInv.CoutRMS.L3;								//L3 phase UPS output current in amperes
					U1_Gonder("?% % % % % % % % % ^ % % %",Uart1.GonderBuf);	
					break;					
				}
				else if( *(U1_Buf + 1) == '5' )
				{		
					//?AAA_BBB_CCC_DDD.D_EEE.E_GGG.G_H.H_J.J_K.K_M.M_N.N_P.P<chr$13>
					Uart1.GonderBuf[0] = Can.FromInv.Load.L1;									//L1 phase load percentage 
					Uart1.GonderBuf[1] = Can.FromInv.Load.L2;									//L2 phase load percentage
					Uart1.GonderBuf[2] = Can.FromInv.Load.L3;									//L3 phase load percentage
					Uart1.GonderBuf[3] = Can.FromInv.PowerWatt.L1;								//L1 phase UPS output power in kWA 
					Uart1.GonderBuf[4] = Can.FromInv.PowerWatt.L2;								//L2 phase UPS output power in kWA 
					Uart1.GonderBuf[5] = Can.FromInv.PowerWatt.L3;								//L3 phase UPS output power in kWA 
					Uart1.GonderBuf[6] = Can.FromInv.Pf.L1 / 10;								//L1 phase output power factor
					Uart1.GonderBuf[7] = Can.FromInv.Pf.L2 / 10;								//L2 phase output power factor
					Uart1.GonderBuf[8] = Can.FromInv.Pf.L3 / 10;								//L3 phase output power factor
					Uart1.GonderBuf[9] = Can.FromInv.CrestFactor.L1;							//L1 phase load krest factor
					Uart1.GonderBuf[10] = Can.FromInv.CrestFactor.L2;							//L2 phase load krest factor
					Uart1.GonderBuf[11] = Can.FromInv.CrestFactor.L3;							//L3 phase load krest factor
					U1_Gonder("?% % % � � � | | | | | |",Uart1.GonderBuf);	
					break;					
				}
				else if( *(U1_Buf + 1) == '6' )
				{		
					//?AAA.A_BBB.B_CCC.C_FFFFF_MMMMM_GGGGG_NNNNN_DDDDDD_HH:HH_PPP<chr$13>
					Uart1.GonderBuf[0] = EeKayit.TermalSensor1.Olculen;							//TH1 temp sensor temperature  (1/10 deg C)
					Uart1.GonderBuf[1] = EeKayit.TermalSensor2.Olculen;							//TH2 temp sensor temperature  (1/10 deg C)
					Uart1.GonderBuf[2] = Can.FromPfc.RecTemp;									//TH3 temp sensor temperature   (1/10 deg C)
					Uart1.GonderBuf[3] = EeKayit.Bakim[DefFanBakim].KalanSure;					//Fan maintenance counter
					Uart1.GonderBuf[4] = EeKayit.Bakim[DefAkuBakim].KalanSure;					//Battery maintenance counter
					Uart1.GonderBuf[5] = EeKayit.Bakim[DefGenelBakim].KalanSure;				//General maintenance counter
					Uart1.GonderBuf[6] = EeKayit.Bakim[DefYedekBakim].KalanSure;				//Optional maintenance counter
					Uart1.GonderBuf[7] = Can.ToInv.Date_2.Day;
					Uart1.GonderBuf[8] = Can.ToInv.Date_2.Month;
					Uart1.GonderBuf[9] = Can.ToInv.Date_2.Year;
					Uart1.GonderBuf[10] = Can.ToInv.Date_2.Hour;
					Uart1.GonderBuf[11] = Can.ToInv.Date_2.Min;  
					Uart1.GonderBuf[12] = 0;													//Relative ambient humidity (Ba��l ortam nemi)
					U1_Gonder("?� � � � � � � ]]] ]:] %",Uart1.GonderBuf);	
					break;
				}
				else
				{
					U1_Gonder("ERROR",Uart1.Dumm );
					break;
				}
			}
			else if ( (*U1_Buf == 'F') && (*(U1_Buf + 1) == '2') )
			{
				//#III/FFF_BBB/CCC_XXX/YYY_RR/EE_BBB_GG_UMRFNU_PPPPPP_RRRRRR<chr$13>
				for(Uart1_i = 0;Uart1_i < 23;Uart1_i++)											//Nominal values
					Uart1.GonderBuf[Uart1_i] = Label.NominalVoltage[Uart1_i];
					
				Uart1.GonderBuf[23] = Uart1.NumOfPhaseIn = 3;									//Input phases (options : 1P or 3P)
				Uart1.GonderBuf[24] = Uart1.NumOfPhaseOut;										//Output phases (options : 1P or 3P)
				Uart1.GonderBuf[25] = Can.FromInv.AkuSayisi;									//Number of 12 volts batteries in 1 group
				Uart1.GonderBuf[26] = Uart1.DeviceType = 0;										//Device type �0�=UPS ,�1�=converter
				Uart1.GonderBuf[27] = Can.FromInv.CalismaModu;									//Device Operation mode														
				Uart1.GonderBuf[28] = Uart1.BypassConfig = 1;									//Bypass configuration �0�=bypass not installed ,�1�=bypass installed
				Uart1.GonderBuf[29] = Uart1.BattConfig = 2;										//Battery �0�= not installed �1�=batteries installed �2�=2 battery group
				Uart1.GonderBuf[30] = Can.FromInv.N_1MinUps;									//N+1 min�mum UPS
				Uart1.GonderBuf[31] = Can.FromInv.KGKNo;										//UPS number
				
				for(Uart1_i = 0;Uart1_i < 6;Uart1_i++)
					Uart1.GonderBuf[Uart1_i + 32] = Label.SaseNo[Uart1_i];
				for(Uart1_i = 0;Uart1_i < 6;Uart1_i++)
					Uart1.GonderBuf[Uart1_i + 38] = Label.OutputPower[Uart1_i];
					
				U1_Gonder("#$$$$$$$$$$$$$$$$$$$$$$$ [P/[P % [[[[[[ $$$$$$ $$$$$$",Uart1.GonderBuf);
				break;
			}
			
			else if( (*U1_Buf == 'T') && (*(U1_Buf + 1) == 'L') )
			{
				Megatech.TL.TestUntilBattLow = 1;
				if( EeKayit.Konfig.Bit.UzakErisim )
				{
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						CanGonder(DefCanInv,28,'W',DefEmir_UzunAkuTestYap,0);	
						U1_Gonder("OK", Uart1.Dumm );	
					}	
					else 
					{	U1_Gonder("ACCDE", Uart1.Dumm ); }			
				}
				else 
				{	U1_Gonder("ACCDE", Uart1.Dumm ); }	
				break;
			}
			else if ((*U1_Buf == 'C') && (*(U1_Buf+1) == 'T'))										//CONTROL COMMAND from PC  (Cancel battery test)		
			{				 						
				if( EeKayit.Konfig.Bit.UzakErisim )			
				{
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						CanGonder(DefCanInv,28,'W',DefEmir_AkuTestIptal,0);	
						U1_Gonder("OK", Uart1.Dumm );	
					}
					else 
					{	U1_Gonder("ACCDE", Uart1.Dumm ); }						
				}
				else 
					U1_Gonder("ACCDE",Uart1.Dumm );
				break;
			}
			
			else if(*U1_Buf == 'G')
			{
				if(*(U1_Buf + 1) == '1')
				{ 
					if( AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1 == 1 )
					{
						if( EeKayit.TermalSensor1.Olculen > 32767)
						{	
							Megatech.G1.Temperature = 65536 - EeKayit.TermalSensor1.Olculen;			//measured battery ambient temperature (1/10 deg C)
							Uart1.GonderBuf[4] = '-';
						}
						else if( EeKayit.TermalSensor1.Olculen == 0 )
						{
							Megatech.G1.Temperature = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart1.GonderBuf[4] = ' ';
						}
						else
						{
							Megatech.G1.Temperature = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart1.GonderBuf[4] = '+';
						}
					}
					else																		//measured battery ambient temperature (1/10 deg C)
					{							
						if( Can.FromPfc.RecTemp > 32767)
						{
							Megatech.G1.Temperature = 65536 - Can.FromPfc.RecTemp;	
							Uart1.GonderBuf[4] = '-';
						}
						else if( Can.FromPfc.RecTemp == 0 )
						{
							Megatech.G1.Temperature = Can.FromPfc.RecTemp;	
							Uart1.GonderBuf[4] = ' ';
						}
						else
						{
							Megatech.G1.Temperature = Can.FromPfc.RecTemp;	
							Uart1.GonderBuf[4] = '+';
						}
					}					
					
					//if( Alarm.Word.Pfc1.Bit.SebekeKesik ) DisCharge d�r			//GErekirse denenebilir.
					if( Can.FromPfc.DisCbattC.Pos > 0 )								//For Discharge mode
						Megatech.G1.BattCurrChrgDChrg = Can.FromPfc.SonucDisCbattC.Pos + Can.FromPfc.SonucDisCbattC.Neg;
					else															//For Charge mode
						Megatech.G1.BattCurrChrgDChrg = Can.FromPfc.CbattC.Pos + Can.FromPfc.CbattC.Neg;
					Megatech.G1.BattVoltg = Can.FromPfc.RecDCBus.Pos + Can.FromPfc.RecDCBus.Neg;
					
					Megatech.G1.BattCapPer = AkuKapasite.KalanAkuKap;
										
					if(( Alarm.Word.Pfc1.Bit.SebekeKesik == 1 ) && (AkuKapasite.IlkDakikaGecti == 1))
						Megatech.G1.BattTimeRem = AkuKapasite.KalanSure;
					else
						Megatech.G1.BattTimeRem = EeKayit.AkuSabitKalanSure;
						
					Megatech.G1.FreqOfBypSource = Can.FromInv.BypFreq;
					Megatech.G1.IPFreq = Can.FromPfc.RecFreq;
					Megatech.G1.OPFreq = Can.FromInv.OutFreq;
					
					Uart1.GonderBuf[0] = Megatech.G1.BattVoltg;						//Battery Voltage 								SSS		000		-	999
					Uart1.GonderBuf[1] = Megatech.G1.BattCapPer;					//Battery Capacity Percentage					PPP		000		-	100
					Uart1.GonderBuf[2] = Megatech.G1.BattTimeRem;					//Battery Time Remaining						NNNN	0000	-	9999
					Uart1.GonderBuf[3] = Megatech.G1.BattCurrChrgDChrg;				//Battery Current Charge and Discharge mode		RRR.R	000.0	-	999.9	Depends on Megatech.G2.a2
					Uart1.GonderBuf[5] = Megatech.G1.Temperature;					//Temperature									+TT.T	-99.9	-	+99.9
					Uart1.GonderBuf[6] = Megatech.G1.IPFreq;						//I / P Frequency								FF.F	00.0	-	99.9
					Uart1.GonderBuf[7] = Megatech.G1.FreqOfBypSource;				//Frequency of Bypass Source					EE.E	00.0	-	99.9
					Uart1.GonderBuf[8] = Megatech.G1.OPFreq;						//O / P Frequency 													//Output Load Percentage (zero for this version)
											
					//UPS : !SSS PPP NNNN RRR.R +TT.T FF.F EE.E QQ.Q<13>
					//UPS : !SSS PPP NNNN RRR.R -TT.T FF.F EE.E QQ.Q<13>
					U1_Gonder("!% % @ � $^ ^ ^ ^",Uart1.GonderBuf);					//Temperature difference
					break;
				}
				if(*(U1_Buf + 1) == '2')											//Logic 0						Logic 1	
				{																	//--------					-	--------------
					Megatech.G2.a7 = 0;
					Megatech.G2.a6 = Alarm.Word.Pfc1.Bit.FazCevir;
					Megatech.G2.a5 = Alarm.Word.Inv1.Bit.AkuZayifKes;
					Megatech.G2.a4 = Alarm.Word.Inv2.Bit.AkuZayif;
					Megatech.G2.a3 = 0;
					Megatech.G2.a2 = (Alarm.Word.Pfc1.Bit.SebekeKesik | Alarm.Word.Pfc1.Bit.AcGirisYuksek);
					Megatech.G2.a1 = Alarm.Word.Pfc2.Bit.BoostSarj;
					Megatech.G2.a0 = ~Alarm.Word.Pfc2.Bit.PfcDurakladi;

					Megatech.G2.b7 = 0;
					Megatech.G2.b6 = 0;
					Megatech.G2.b5 = 0;
					Megatech.G2.b4 = Alarm.Word.Inv2.Bit.BypassFrekans;
					Megatech.G2.b3 = Alarm.Word.Inv1.Bit.Bakimda;
					Megatech.G2.b2 = ~(Alarm.Word.Inv2.Bit.BypassKesik | Alarm.Word.Inv2.Bit.BypassVolt);
					Megatech.G2.b1 = ~Alarm.Word.Inv2.Bit.CikisBypassta;
					Megatech.G2.b0 = ~Alarm.Word.Inv3.Bit.InvStop;

					Megatech.G2.c7 = 0;
					Megatech.G2.c6 = Alarm.Word.Inv1.Bit.AcilKapatma;
					Megatech.G2.c5 = Alarm.Word.Inv1.Bit.AkuYuksek;
					Megatech.G2.c4 = 0;
					Megatech.G2.c3 = Alarm.Word.Inv1.Bit.AsiriYukKes;
					Megatech.G2.c2 = 0;
					Megatech.G2.c1 = Alarm.Word.Inv1.Bit.AsiriIsiKes;
					Megatech.G2.c0 = Alarm.Word.Inv1.Bit.KisaDevre;


					Uart1.GonderBuf[0] = Megatech.G2.a7;							//Not used
					Uart1.GonderBuf[1] = Megatech.G2.a6;							//Normal					-	Rectifier Rotation Err
					Uart1.GonderBuf[2] = Megatech.G2.a5;							//Normal					-	Low Battery Shutdown
					Uart1.GonderBuf[3] = Megatech.G2.a4;							//Normal					-	Low Battery
					Uart1.GonderBuf[4] = Megatech.G2.a3;							//Not used				-	Three in/out
					Uart1.GonderBuf[5] = Megatech.G2.a2;							//AC Normal					-	Back Up		
					Uart1.GonderBuf[6] = Megatech.G2.a1;							//Float Charge				-	Boost Charge
					Uart1.GonderBuf[7] = Megatech.G2.a0;							//Rectifier Stop			-	Rectifier Operating
														
					Uart1.GonderBuf[8] = Megatech.G2.b7;							//Not used
					Uart1.GonderBuf[9] = Megatech.G2.b6;							//Not used
					Uart1.GonderBuf[10] = Megatech.G2.b5;							//Not used
					Uart1.GonderBuf[11] = Megatech.G2.b4;							//Bypass Freq OK			-	Bypass Freq Fail
					Uart1.GonderBuf[12] = Megatech.G2.b3;							//Manual Byp.Breaker Open	-	Manual Byp.Breaker On
					Uart1.GonderBuf[13] = Megatech.G2.b2;							//Bypass AC Abnormal		-	Bypass AC Normal
					Uart1.GonderBuf[14] = Megatech.G2.b1;							//Static switch in byp. mode-	Static Switch in Inver
					Uart1.GonderBuf[15] = Megatech.G2.b0;							//The fault condition of Inv-	Inverter Operation

					Uart1.GonderBuf[16] = Megatech.G2.c7;							//Not Used
					Uart1.GonderBuf[17] = Megatech.G2.c6;							//Normal					-	Emergency Stop (EPO)
					Uart1.GonderBuf[18] = Megatech.G2.c5;							//Normal					-	High DC Shutdown
					Uart1.GonderBuf[19] = Megatech.G2.c4;							//Not used					-	Manual Bypass Breaker 
					Uart1.GonderBuf[20] = Megatech.G2.c3;							//Normal					-	Over load shutdown
					Uart1.GonderBuf[21] = Megatech.G2.c2;							//Not used					-	Inverter O/P Fail shut
					Uart1.GonderBuf[22] = Megatech.G2.c1;							//Normal					-	Over Temperature shutd
					Uart1.GonderBuf[23] = Megatech.G2.c0;							//Normal					-	Short Circuit Shutdown
					//UPS : !a7a6a5a4a3a2a1a0 b7b6b5b4b3b2b1b0 c7c6c5c4c3c2c1c0<13>
					U1_Gonder("![[[[[[[[ [[[[[[[[ [[[[[[[[",Uart1.GonderBuf);
					break;
				}
				if(*(U1_Buf + 1) == '3')
				{
					Uart1.GonderBuf[0] = Megatech.G3.IPVoltageR;					//I/P voltage of R Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[1] = Megatech.G3.IPVoltageS;					//I/P voltage of S Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[2] = Megatech.G3.IPVoltageT;					//I/P voltage of T Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[3] = Megatech.G3.BypVoltageR;					//Byp voltage of R Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[4] = Megatech.G3.BypVoltageS;					//Byp voltage of S Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[5] = Megatech.G3.BypVoltageT;					//Byp voltage of T Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[6] = Megatech.G3.OPVoltageR;					//O/P voltage of R Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[7] = Megatech.G3.OPVoltageS;					//O/P voltage of S Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[8] = Megatech.G3.OPVoltageT;					//O/P voltage of T Phase						NNN.N	000.0	-	999.9
					Uart1.GonderBuf[9] = Megatech.G3.LoadPercentageR;				//Load Percentage of R Phase					NNN.N	000.0	-	999.9
					Uart1.GonderBuf[10] = Megatech.G3.LoadPercentageS;				//Load Percentage of S Phase					NNN.N	000.0	-	999.9
					Uart1.GonderBuf[11] = Megatech.G3.LoadPercentageT;				//Load Percentage of T Phase					NNN.N	000.0	-	999.9
					//UPS : !NNN.N/NNN.N/NNN.N PPP.P/PPP.P/PPP.P QQQ.Q/QQQ.Q/QQQ.Q SSS.S/SSS.S/SSS.S<13>
					U1_Gonder("!�/�/� �/�/� �/�/� �/�/�",Uart1.GonderBuf);
					break;
				}
				if(*(U1_Buf + 1) == 'F')
				{
					Megatech.GF.RecVoltPToN = 220;
					Megatech.GF.RecVoltPToP	= 380;
					Megatech.GF.RecFreq = 50;						
					Megatech.GF.BypVoltPToN = 220;
					Megatech.GF.BypVoltPToP = 380;
					Megatech.GF.BypFreq = 50;	
					Megatech.GF.OPVoltPToN = 220;
					Megatech.GF.OPVoltPToP = 380;
					Megatech.GF.OPFreq = 50;	
					Megatech.GF.BattVoltage = (Can.FromInv.AkuSayisi * 12) * 2;
					Megatech.GF.PowerRate = (Label.OutputPower[0] - 48) * 10 + (Label.OutputPower[1] - 48);
					

					Uart1.GonderBuf[0] = Megatech.GF.RecVoltPToN;					//Rectifier Voltage of Ph To N					220	
					Uart1.GonderBuf[1] = Megatech.GF.RecVoltPToP;					//Rectifier Voltage of Ph To Ph					380
					Uart1.GonderBuf[2] = Megatech.GF.RecFreq;						//Rectifier Frequency							CCC	- 050
					Uart1.GonderBuf[3] = Megatech.GF.BypVoltPToN;					//Bypass Source Voltage of Ph To N				220
					Uart1.GonderBuf[4] = Megatech.GF.BypVoltPToP;					//Bypass Source Voltage of Ph To Ph				380
					Uart1.GonderBuf[5] = Megatech.GF.BypFreq;						//Bypass Source Frequency						FFF	- 050
					Uart1.GonderBuf[6] = Megatech.GF.OPVoltPToN;					//O/P Voltage of Ph To N						220
//					Uart1.GonderBuf[7] = Megatech.GF.OPVoltPToP;					//O/P Voltage of Ph To Ph						380
					Uart1.GonderBuf[7] = Megatech.GF.OPFreq;						//O/P Frequency									QQQ
					Uart1.GonderBuf[8] = Megatech.GF.BattVoltage;					//Battery Voltage								SSS
					Uart1.GonderBuf[9] = Megatech.GF.PowerRate;						//Power Rating									xxxxxxxxxx (10 characters)
					//UPS : !220V/380V 3P4W 060 220V/380V 3P4W 061 220V/3P3W      060 396 150KVA    <13>
					U1_Gonder("!%V/%V 3P4W % %V/%V 3P4W % %V/3P3W      % % %KVA    ",Uart1.GonderBuf);
					break;
				}
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 4:							
			if ((*U1_Buf == 'T') && (*(U1_Buf + 1) == 'I') && (*(U1_Buf + 2)== 'M'))
			{
				OkuRTC(&Date4);
				Uart1.GonderBuf[0] = Date4.Day;
				Uart1.GonderBuf[1] = Date4.Month;
				Uart1.GonderBuf[2] = Date4.Year;
				Uart1.GonderBuf[3] = Date4.Hour;
				Uart1.GonderBuf[4] = Date4.Min;
				
				U1_Gonder("]]] ]:]",Uart1.GonderBuf);
				break;
			}		
			else if ((*U1_Buf == 'C') && (*(U1_Buf + 1) == 'H') && (*(U1_Buf + 2)== 'K'))
			{
				Uart1.ChkSorgusuGeldi = 1;
				U1_Gonder("�", &Uart1.CheckSum );
				Uart1.ChkSorgusuGeldi = 0;
				break;
			}		
			//Sxx<13> gelecek uart tan ve xx dakika i�eriside uyu yani shutdown emri g�nderilecek.
			else if ((*U1_Buf == 'S'))			
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{		
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{		
						if( *(U1_Buf + 1) != '.' )			
						{				
							Timer6.ShutdownTime = ((*(U1_Buf + 1) - 48) * 10 + (*(U1_Buf + 2) - 48)) * 60;
							if( Timer6.ShutdownTime == 0 )
								CanGonder(DefCanInv,28,'W',DefEmir_Uyu,0);
						}
						else if( *(U1_Buf + 1) == '.' )		
							Timer6.ShutdownTime = ( 6 * (*(U1_Buf + 2) - 48) );
							
						Timer6.RestoreTime = 0;	
						U1_Gonder( "OK", Uart1.Dumm );
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{
					U1_Gonder( "ACCDE",Uart1.Dumm );
				}
				break;
			}
			//Txx<13> gelecek uart tan fakat buradan sadece k�sa test emri gidecek.
			else if ((*U1_Buf == 'T'))			
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						if((*(U1_Buf + 1) > 47) && (*(U1_Buf + 1) < 58))
						{
							if((*(U1_Buf + 2) > 47) && (*(U1_Buf + 2) < 58))
							{									
								CanGonder(DefCanInv,28,'W',DefEmir_KisaAkuTestYap,0);					// command to UPS test Start
								U1_Gonder("OK", Uart1.Dumm );
								Megatech.T.TestForTenSec = 1;
							}
							else
							{
								U1_Gonder("ERROR",Uart1.Dumm );
								break;
							}
						}
						else
						{
							U1_Gonder("ERROR",Uart1.Dumm );
							break;
						}
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
						break;
					}
				}
				else 
				{
					U1_Gonder("ACCDE",Uart1.Dumm );
					break;
				}
			}
			else if ((*U1_Buf == 'K') && (*(U1_Buf + 1) == 'O') && (*(U1_Buf + 2) == 'D'))			
			{
				if( Can.FromInv.LogInDurum == 0 )
				{
					if( Uart1.PassWordHataliGeriSayac == 0 )
					{
						if( Uart1.KodIslemiGeriSayac == 0 )
						{
							//Yeni kod �ret ve �ifre de�i�tir.
							SifreAl();
							//Yeni servis kodlar�n� g�nder
							Uart1.GonderBuf[0] = Menu.ServisKodH;
							Uart1.GonderBuf[1] = Menu.ServisKodL;
							//3 sn lik saya� ba�lat
							Uart1.KodIslemiGeriSayac = 60;
							//Kod i�lemi yap�ld�.Ancak Password do�ru gelirse s�f�rlan�r.	
							Uart1.KodIslemiYapildi = 1;
							U1_Gonder("@@",Uart1.GonderBuf);
						}
						else
							U1_Gonder("WAIT",Uart1.Dumm);
					}
					else
						U1_Gonder("WAIT",Uart1.Dumm);	
				}
				else
					U1_Gonder("LOGIN",Uart1.Dumm);
					
				break;
			}
			//Servis eleman�n�n i�i bitti.
			else if ((*U1_Buf == 'O') && (*(U1_Buf + 1) == 'U') && (*(U1_Buf + 2) == 'T'))							
			{
				//Yazma vb. i�lemler serbest de�il
			//	Can.FromInv.LogInDurum = 0;
				Genel.UserPassDogru15dklikIzin = 0;
				Genel.UserPassGeriSayac = 0;
				Uart1.KodIslemiGeriSayac = 0;
			//	Alarm.Word.Lcd1.Bit.ServisLoginOk = 0; Inv2 bitlerinden kendi kalkacak
				CanGonder(DefCanInv,28,'W',DefEmir_LogOut,0);
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}
			else if ((*U1_Buf == 'C') && (*(U1_Buf + 1) == 'L') && (*(U1_Buf + 2) == 'K'))
			{
				OkuRTC(&Date4);
				Uart1.GonderBuf[0] = Date4.Hour;
				Uart1.GonderBuf[1] = Date4.Min;
				
				U1_Gonder("#]:]",Uart1.GonderBuf);
				break;
			}
			else if ((*U1_Buf == 'D') && (*(U1_Buf + 1) == 'A') && (*(U1_Buf + 2) == 'T'))
			{
				OkuRTC(&Date4);
				Uart1.GonderBuf[0] = Date4.Day;
				Uart1.GonderBuf[1] = Date4.Month;
				Uart1.GonderBuf[2] = Date4.Year;
				
				U1_Gonder("D]]]",Uart1.GonderBuf);
				break;
			}
			else if ((*U1_Buf == 'F') && (*(U1_Buf + 1) == 'I') && (*(U1_Buf + 2)== 'R'))
			{					
				//Variable length string according to firmware version			
				U1_Gonder("$$$$$",Protokol);
				break;
			}
			//----------------KOMUTLAR-----------------------
			//Komut	Inverter e ge� emri		
			else if ((*U1_Buf == 'I') && (*(U1_Buf + 1) == 'N') && (*(U1_Buf + 2) == 'V'))	
			{									
				if( EeKayit.Konfig.Bit.UzakErisim )
				{		
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{	
						//Commands.YUKU_AKTAR = 0;	
						CanGonder(DefCanInv,28,'W',DefEmir_Inverter,0);	
						U1_Gonder("OK", Uart1.Dumm );
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{	U1_Gonder("ACCDE", Uart1.Dumm );	}
				break;
			}	
			//Komut Bypass a ge� emri
			else if ((*U1_Buf == 'B') && (*(U1_Buf + 1) == 'Y') && (*(U1_Buf + 2) == 'P'))
			{										
				if( EeKayit.Konfig.Bit.UzakErisim )
				{			
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						CanGonder(DefCanInv,28,'W',DefEmir_Bypass,0);
						U1_Gonder("OK", Uart1.Dumm );
					}
					else 
					{	U1_Gonder("ACCDE", Uart1.Dumm );	}
				}
				else 
				{	U1_Gonder("ACCDE", Uart1.Dumm );	}
				break;
			}
			//Komut (start/stop boost charge mode)
			else if ((*U1_Buf == 'B') && (*(U1_Buf + 1) == 'S') && (*(U1_Buf + 2) == 'T'))
			{									
				if( EeKayit.Konfig.Bit.UzakErisim )								
				{			
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{						
						Menu.EnterStopBoost ^= 1;
						if( Menu.EnterStopBoost == 1 )	
							CanGonder(DefCanInv,28,'W',DefEmir_Boost,0);
						if( Menu.EnterStopBoost == 0)
							CanGonder(DefCanInv,28,'W',DefEmir_CancelBoost,0);
							
						U1_Gonder("OK", Uart1.Dumm );
					}
					else 
					{	U1_Gonder("ACCDE", Uart1.Dumm );	}
				}									
				else 
				{	U1_Gonder("ACCDE", Uart1.Dumm );	}
				break;
			}
			//Komut Inverter e ge� emri
			else if ((*U1_Buf == 'P') && (*(U1_Buf + 1) == 'O') && (*(U1_Buf + 2) == 'N'))
			{	
				if( Can.FromInv.LogInDurum == 1 )									
				{							
					CanGonder(DefCanInv,28,'W',DefEmir_Inverter,0);
					U1_Gonder("OK", Uart1.Dumm );
				}																					
				else 
					U1_Gonder("ACCDE", Uart1.Dumm );
				break;
			}	

			else if ( (*U1_Buf == 'L') && (*(U1_Buf + 2) == 'X') )
			{	
				if( Can.FromInv.LogInDurum )
				{	
					if(*(U1_Buf + 1) == '1')
					{
						if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )) || ( Can.ToInv.Gonderildi.Bit.U1_W == 1 ))
						{
							YedekCanGonder(DefCanInv,28,'W',1,0);
							CanGonder(DefCanInv,28,'W',1,0);
							Can.ToInv.Gonderildi.Bit.U1_W = 1;
							break;
							//��lemler var
						}
					}
					if(*(U1_Buf + 1) == '2')
					{
						if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )) || ( Can.ToPfc.Gonderildi.Bit.U1_W == 1 ))
						{
							YedekCanGonder(DefCanPfc,55,'W',1,0);
							CanGonder(DefCanPfc,55,'W',1,0);
							Can.ToPfc.Gonderildi.Bit.U1_W = 1;
							break;
							//��lemler var
						}
					}
				}
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 5:		
			if ((*U1_Buf == 'C') && (*(U1_Buf + 1) == 'R') && (*(U1_Buf + 2)== 'S') && (*(U1_Buf + 3)== 'T'))
			{
				Uart1.CheckSum = 0;
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}
			else if ((*U1_Buf == 'L') && (*(U1_Buf + 1) == 'A') && (*(U1_Buf + 2)== 'M') && (*(U1_Buf + 3)== 'P'))
			{
			//	Menu.MimikSayac = 6;
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}
			else if ((*U1_Buf == 'W') && (*(U1_Buf + 1) == 'I') && (*(U1_Buf + 2)== 'N') && (*(U1_Buf + 3)== 'I'))
			{
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}			
			//A�a��daki Lcd i�in Tft i�in ayr� yap�lacak.
			else if ((*U1_Buf == 'M') && (*(U1_Buf + 1) == 'E') && (*(U1_Buf + 2)== 'N') && (*(U1_Buf + 3)== 'U'))
			{
				Uart1.GonderBuf[0] = Menu.AnaSekme;
				Uart1.GonderBuf[1] = Menu.Alt1Sekme;
				Uart1.GonderBuf[2] = Menu.OlcumAltSekme;
				Uart1.GonderBuf[3] = Can.AyarMenuDizisi[0];	
				Uart1.GonderBuf[4] = 0;
					
				//Ana men�	
				if( Menu.Sekme.All == DefAnaMenu )
				{
					Uart1.GonderBuf[0] = Menu.AnaSekme;
					Uart1.GonderBuf[1] = 0;
				}					
				//Alt men�
				if( Menu.Sekme.All == DefAlt1Menu )
				{
					Uart1.GonderBuf[1] = Menu.Alt1Sekme;
					Uart1.GonderBuf[2] = 0;		
					Uart1.GonderBuf[3] = 0;		
					Uart1.GonderBuf[4] = 0;						
				}			
				//Ayar Alt men�s�	
				if( Menu.Sekme.All == DefAyarAltMenu )
					Uart1.GonderBuf[3] = Can.AyarMenuDizisi[0];	
				else
				{
					Uart1.GonderBuf[2] = 0;	
					Uart1.GonderBuf[3] = 0;	
					Uart1.GonderBuf[4] = 0;
				}
				//Alt Alt men�
				if( Menu.Sekme.All == DefOlcumAltMenu )	
					Uart1.GonderBuf[2] = Menu.OlcumAltSekme;
				else if( Menu.Sekme.All == DefTercihAltMenu )	
					Uart1.GonderBuf[2] = Menu.TercihAltSekme;
				else if( Menu.Sekme.All == DefAyarAnaMenu )
				{
					Uart1.GonderBuf[1] = 1;
					Uart1.GonderBuf[2] = Menu.AyarAnaSekme;
				}	
				
				if( Menu.Sekme.All == DefAyarAltMenu )
				{
					Uart1.GonderBuf[1] = 1;
					Uart1.GonderBuf[2] = Menu.AyarAnaSekme;
					if(( Can.AyarMenuDizisi[0] == 1171 ) || ( Can.AyarMenuDizisi[0] == 2160 ) || ( Can.AyarMenuDizisi[0] == 3415 ))
					{
						if( Can.AyarMenuDizisi[0] == 3415 )
						{
							if( Menu.AyarEtiket == 0 )
								Uart1.GonderBuf[4] = 9;
							if( Menu.AyarEtiket == 2 )
								Uart1.GonderBuf[4] = 6;
							if( Menu.AyarEtiket == 6 )
								Uart1.GonderBuf[4] = 7;
							if( Menu.AyarEtiket == 1 )
								Uart1.GonderBuf[4] = 10;
						}
						else
						{
							if( Can.AyarMenuDizisi[0] == 1171 )
							{
								if( Menu.AyarEtiket > 8 )
								{
									if( Menu.AyarEtiket == 9 )
										Uart1.GonderBuf[4] = 12;
									if( Menu.AyarEtiket == 10 )
										Uart1.GonderBuf[4] = 13;
									if( Menu.AyarEtiket == 11 )
										Uart1.GonderBuf[4] = 15;
									if( Menu.AyarEtiket == 12 )
										Uart1.GonderBuf[4] = 16;
								}
								else
									Uart1.GonderBuf[4] = Menu.AyarEtiket + 1;
							}
							if( Can.AyarMenuDizisi[0] == 2160 )
							{
								if( Menu.AyarEtiket > 4 )
								{
									if( Menu.AyarEtiket == 5 )
										Uart1.GonderBuf[4] = 7;
									if( Menu.AyarEtiket == 6 )
										Uart1.GonderBuf[4] = 8;
									if( Menu.AyarEtiket == 7 )
										Uart1.GonderBuf[4] = 9;
									if( Menu.AyarEtiket == 8 )
										Uart1.GonderBuf[4] = 10;
									if( Menu.AyarEtiket == 9 )
										Uart1.GonderBuf[4] = 11;
									if( Menu.AyarEtiket == 10 )
										Uart1.GonderBuf[4] = 12;
									if( Menu.AyarEtiket == 11 )
										Uart1.GonderBuf[4] = 14;
								}
								else
									Uart1.GonderBuf[4] = Menu.AyarEtiket + 1;
							}
						}
							
						if( Uart1.GonderBuf[4] < 10 )
							U1_Gonder("002_]_]_]>R@-[",Uart1.GonderBuf);				//Ba��ndaki 3 hane versiyon pc yard�m i�lemi i�in men� tft olursa falan de�i�sin diye
						else
							U1_Gonder("002_].].]>R@-]",Uart1.GonderBuf);
						break;
					}
					else
					{
						Uart1.GonderBuf[4] = 0;
						U1_Gonder("002_]_]_]>R@",Uart1.GonderBuf);
						break;
					}
				}
				else if( Menu.Sekme.All == DefAyarGrupAltMenu )
				{
					Uart1.GonderBuf[1] = 1;
					Uart1.GonderBuf[2] = Menu.AyarAnaSekme;
					
					if( Menu.AyarEtiket == 0 )
						Uart1.GonderBuf[3] = 2192;	
					if( Menu.AyarEtiket == 1 )
						Uart1.GonderBuf[3] = 2193;	
					if( Menu.AyarEtiket == 2 )
						Uart1.GonderBuf[3] = 2194;
					if( Menu.AyarEtiket == 3 )
						Uart1.GonderBuf[3] = 2185;	
					if( Menu.AyarEtiket == 4 )
						Uart1.GonderBuf[3] = 2142;	
					if( Menu.AyarEtiket == 5 )
						Uart1.GonderBuf[3] = 1187;
					if( Menu.AyarEtiket == 6 )
						Uart1.GonderBuf[3] = 1136;	
					if( Menu.AyarEtiket == 7 )
						Uart1.GonderBuf[3] = 1181;			
					
					Uart1.GonderBuf[4] = Can.AyarMenuDizisi[0];
					U1_Gonder("002_]_]_]>R@ - R@",Uart1.GonderBuf);
					
				}
				else
				{
					Uart1.GonderBuf[4] = 0;
					U1_Gonder("002_]_]_]>R@",Uart1.GonderBuf);
					break;
				}
				
			}
			else if((*U1_Buf == 'M') && (*(U1_Buf + 1) == 'F') && (*(U1_Buf + 2)== 'I') && (*(U1_Buf + 3)== 'R'))
			{
				Uart1.GonderBuf[0] = Can.FromInv.InvVersiyon;
				Uart1.GonderBuf[1] = Can.FromPfc.PfcVersiyon;
				Uart1.GonderBuf[2] = TftVersiyon;
				
				U1_Gonder("%_%_%",Uart1.GonderBuf);
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}		
		break;
		case 6:
			if(*U1_Buf == 'R')
			{
				Uart1.SonSorulanEmir = 'R';
				
				//Inverter e R1xxx sorgusu
				if(*(U1_Buf + 1) - 48 == 1)
				{
					if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToInv.Gonderildi.Bit.U1_R == 1 ))
					{
						Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48));
						YedekCanGonder(DefCanInv,28,'R',0,Uart1.AraIslemDeger[0] );
						CanGonder(DefCanInv,28,'R',0,Uart1.AraIslemDeger[0] );
						Can.ToInv.Gonderildi.Bit.U1_R = 1;
						
						Can.FromInv.R_HataSayaci.Adres = 0;
						Can.FromInv.R_HataSayaci.Paket = 0;
						Can.FromInv.R_HataSayaci.Gorev = 0;
						Uart1.Tekrar = 19;
						break;
					}
				}
				//Pfc ye R2xxx sorgusu
				if(*(U1_Buf + 1) - 48 == 2)
				{
					if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToPfc.Gonderildi.Bit.U1_R == 1 ))
					{
						Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48));
						YedekCanGonder(DefCanPfc,55,'R',0,Uart1.AraIslemDeger[0] );
						CanGonder(DefCanPfc,55,'R',0,Uart1.AraIslemDeger[0] );
						Can.ToPfc.Gonderildi.Bit.U1_R = 1;
						
						Can.FromPfc.R_HataSayaci.Adres = 0;
						Can.FromPfc.R_HataSayaci.Paket = 0;
						Can.FromPfc.R_HataSayaci.Gorev = 0;
						Uart1.Tekrar = 19;
						break;
					}	
				}
				if(*(U1_Buf + 1) - 48 == 3)
				{
					Uart1.R_Adres = ( ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48)) << 1 ) + 2560;
					//Saat ayar� ram den okunmuyor cevap i�lendikten sonra gidiyor
					if( (Uart1.R_Adres == 3246) || (Uart1.R_Adres == 3248) || (Uart1.R_Adres == 3250) ) 
					{
						OkuRTC(&Uart1.Date_3);
						if(Uart1.R_Adres == 3246)
							U1_ZamanCevap = (Uart1.Date_3.Hour * 100) + Uart1.Date_3.Min;
						if(Uart1.R_Adres == 3248)
							U1_ZamanCevap = (Uart1.Date_3.Day * 100) + Uart1.Date_3.Month;
						if(Uart1.R_Adres == 3250)
							U1_ZamanCevap = Uart1.Date_3.Year + 2000;
							
						U1_Gonder("�",&U1_ZamanCevap);
					}
					else
						U1_Gonder("�",Uart1.R_Adres);
					break;
				}
			}
//			//User login i�in
			else if((*U1_Buf == 'U'))
			{
				if( Genel.UserPassDogru15dklikIzin == 1 )
				{
					U1_Gonder("USER LOGIN",Uart1.Dumm);
					break;
				}
				Menu.UserGolgeSifre[0] = *(U1_Buf + 1);
				Menu.UserGolgeSifre[1] = *(U1_Buf + 2);
				Menu.UserGolgeSifre[2] = *(U1_Buf + 3);
				Menu.UserGolgeSifre[3] = *(U1_Buf + 4);
				Uart1.Dumm[0] = UserSifreDogrula();
				if( Uart1.Dumm[0] == 1 )
				{
					Genel.UserPassDogru15dklikIzin = 1;
					Genel.LoginWaitButon = 0;
					//15 dk l�k geri saya� kuruldu.
					Genel.UserPassGeriSayac = 450;
					CanGonder(DefCanInv,28,'W',DefEmir_UserLogIn,0);
					U1_Gonder("OK", Uart1.Dumm );
					break;
				}
				else
				{
					U1_Gonder("ERROR", Uart1.Dumm );
					break;
				}
				
			}
			//�zel Eepromdan direk adresinden 1 byte l�k data al�r.
			else if (*U1_Buf == 'E')
			{	
				Uart1.AraIslemDeger[0] = (*(U1_Buf + 1) - 48) * 1000 + (*(U1_Buf + 2) - 48) * 100 + ((*(U1_Buf + 3)-48) * 10) + (*(U1_Buf + 4) - 48);	
				Uart1.GonderBuf[0] = EeByteOku(Uart1.AraIslemDeger[0]);
				U1_Gonder("�",Uart1.GonderBuf);
				break;
			} 
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 7:			
			if(*U1_Buf == 'L')					//Adresten okuma
			{
				if((*(U1_Buf + 1) > 47) && (*(U1_Buf + 1) < 58))
				{
					if((*(U1_Buf + 2) > 47) && (*(U1_Buf + 2) < 58))
					{
						//Inverter e L1xxxx sorgusu
						if(*(U1_Buf + 1) - 48 == 1)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToInv.Gonderildi.Bit.U1_L == 1 ))
							{
								Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 1000 + (*(U1_Buf + 3) - 48) * 100 + (*(U1_Buf + 4) - 48) * 10 +  + (*(U1_Buf + 5) - 48) );
								YedekCanGonder(DefCanInv,28,'L',0,Uart1.AraIslemDeger[0] );
								CanGonder(DefCanInv,28,'L',0,Uart1.AraIslemDeger[0] );
								Can.ToInv.Gonderildi.Bit.U1_L = 1;
								
								Can.FromInv.L_HataSayaci.Adres = 0;
								Can.FromInv.L_HataSayaci.Paket = 0;
								Can.FromInv.L_HataSayaci.Gorev = 0;
								Uart1.Tekrar = 19;
								break;
							}
						}
						//Pfc ye L2xxxx sorgusu
						if(*(U1_Buf + 1) - 48 == 2)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToPfc.Gonderildi.Bit.U1_L == 1 ))
							{
								Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 1000 + (*(U1_Buf + 3) - 48) * 100 + (*(U1_Buf + 4) - 48) * 10 +  + (*(U1_Buf + 5) - 48) );
								YedekCanGonder(DefCanPfc,55,'L',0,Uart1.AraIslemDeger[0] );
								CanGonder(DefCanPfc,55,'L',0,Uart1.AraIslemDeger[0] );
								Can.ToPfc.Gonderildi.Bit.U1_L = 1;
								
								Can.FromPfc.L_HataSayaci.Adres = 0;
								Can.FromPfc.L_HataSayaci.Paket = 0;
								Can.FromPfc.L_HataSayaci.Gorev = 0;
								Uart1.Tekrar = 19;
								break;
							}	
						}
					}
					else
					{
						U1_Gonder("ERROR",Uart1.Dumm );
						break;
					}
				}
				else
				{
					U1_Gonder("ERROR",Uart1.Dumm );
					break;
				}
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;		
		case 8:
			//R�le simiulasyon. 
			//FORMAT.........:RELAYxx<13>
			if((*U1_Buf == 'R') && (*(U1_Buf + 1) == 'E') && (*(U1_Buf + 2) == 'L') && (*(U1_Buf + 3) == 'A') && (*(U1_Buf + 4) == 'Y'))
			{
				// 2 x 2s = 4s alarma ba�l� role �ekmesin 
				Menu.RoleTestSayac = 2;
				Uart1.AraIslemDeger[0] = (*(U1_Buf + 5)-48) * 10 + (*(U1_Buf + 6)-48);
				if(Uart1.AraIslemDeger[0] == 0)
				{
					for(Uart1_i = 0;Uart1_i < 12;Uart1_i++)
						RoleIslem(Uart1_i,0);
					U1_Gonder("R�LELER RESETLEND�.",Uart1.Dumm);
					break;
				}
				else
				{
					RoleIslem((Uart1.AraIslemDeger[0] - 1),1);
					U1_Gonder("R�LE ] SET ED�LD�.",Uart1.AraIslemDeger);
					break;
				}
			}
			else if( (*U1_Buf == 'L') && (*(U1_Buf + 1) == 'O') && (*(U1_Buf + 2) == 'G') )
			{			
				// 2 x 50 ms = 100 ms log kayd� yap�lmas�n
				Genel.LogSorulduSayac = 2;														
				Uart1.AraIslemDeger[0] = (((*(U1_Buf + 3) - 48) * 1000) + ((*(U1_Buf + 4) - 48) * 100) + ((*(U1_Buf + 5) - 48) * 10) + ((*(U1_Buf + 6) - 48)));
			//	if( Uart1.AraIslemDeger[0] > ((DefLogLastAddr+1) / 16) )
				if( Uart1.AraIslemDeger[0] > (DefMaxLogSayisi-1) )
				{
					U1_Gonder("INVALID LOG ADDRESS",Uart1.Dumm);
					break;
				}
				else	
				{
					//En son kaydedilen Log0000 adresinde olmal�d�r.
			//		Uart1.AraIslemDeger[0] = ( (EeKayit.LogSayac - 1) - Uart1.AraIslemDeger[0] ) * 16;
			//		Uart1.AraIslemDeger[1] = EeWordOku(Uart1.AraIslemDeger[0]);
//					if(Uart1.AraIslemDeger[0] <= (EeKayit.LogSayac - 1))
//						Uart1.AraIslemDeger[3] = ((( EeKayit.LogSayac - 1 ) - Uart1.AraIslemDeger[0] ) * 16 ) + DefLogFirstAddr;	
//					else
//						Uart1.AraIslemDeger[3] = (((( DefLogLastAddr + 1 ) / 16) + ( EeKayit.LogSayac - 1 ) - Uart1.AraIslemDeger[0] ) * 16) + DefLogFirstAddr;
			
					
					if(Uart1.AraIslemDeger[0] > (EeKayit.LogSayac - 1))
					//	Uart1.AraIslemDeger[3] = (((( DefLogLastAddr + 1 ) / 16) + ( EeKayit.LogSayac - 1 ) - Uart1.AraIslemDeger[0] ) * 16) + DefLogFirstAddr;	
						Uart1.AraIslemDeger[3] = ((DefLogCount + ( EeKayit.LogSayac - 1 ) - Uart1.AraIslemDeger[0] ) * 16) + DefLogFirstAddr;	
					else
						Uart1.AraIslemDeger[3] = ((( EeKayit.LogSayac - 1 ) - Uart1.AraIslemDeger[0] ) * 16 ) + DefLogFirstAddr;
			
			
					Uart1.AraIslemDeger[1] = EeWordOku(Uart1.AraIslemDeger[3]);
					
					if( Uart1.AraIslemDeger[1] == 65535 )
					{
						U1_Gonder("LOG ADDRESS EMPTY",Uart1.Dumm);
						break;
					}
					else
					{
			//			EeAlarmOku(&Date,Uart1.AraIslemDeger[0]); 
						EeAlarmOku(&Date,Uart1.AraIslemDeger[3]); 
						if( Uart1.AraIslemDeger[1] == 65534 )
						{
							Uart1.GonderBuf[0] = Date.Day;
							Uart1.GonderBuf[1] = Date.Month;
							Uart1.GonderBuf[2] = Date.Year;
							Uart1.GonderBuf[3] = Date.Hour;
							Uart1.GonderBuf[4] = Date.Min;
							Uart1.GonderBuf[5] = Date.Sec;
							U1_Gonder("LOGS EVENTS CLEARED ]]] ]:]:]",Uart1.GonderBuf);
							break;
						}
						else
						{
							Uart1.GonderBuf[0] = LogAlarmKod.Kod.Inv;
							Uart1.GonderBuf[1] = LogAlarmKod.Kod.Pfc;
							Uart1.GonderBuf[2] = LogAlarm.Word.Lcd1.All;
							Uart1.GonderBuf[3] = LogAlarm.Word.Inv1.All;
							Uart1.GonderBuf[4] = LogAlarm.Word.Inv2.All;
							Uart1.GonderBuf[5] = LogAlarm.Word.Inv3.All; //23.12.2014 - 02.01.2014 eklendi �nceden 0 d�.
							Uart1.GonderBuf[6] = LogAlarm.Word.Pfc1.All;
							Uart1.GonderBuf[7] = LogAlarm.Word.Pfc2.All;
							Uart1.GonderBuf[8] = Date.Day;
							Uart1.GonderBuf[9] = Date.Month;
							Uart1.GonderBuf[10] = Date.Year;
							Uart1.GonderBuf[11] = Date.Hour;
							Uart1.GonderBuf[12] = Date.Min;
							Uart1.GonderBuf[13] = Date.Sec;
							U1_Gonder("� � � � � � � � ]]] ]:]:]",Uart1.GonderBuf);
							break;
						}
					}	
				}
			}	
			else if((*U1_Buf == 'T') && (*(U1_Buf + 1) == 'F') && (*(U1_Buf + 2) == 'T'))
			{
				Uart1.R_Adres = ((*(U1_Buf + 3) - 48) * 1000 + (*(U1_Buf + 4) - 48) * 100 + (*(U1_Buf + 5) - 48) * 10 + (*(U1_Buf + 6) - 48));
				U1_Gonder("�",Uart1.R_Adres);
				break;
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 9:
			//RS232 den Eeproma direk yazma i�lemi LAbel lar i�in
			//FORMAT.........:Wpaaavvv<13>  
			// p -> page (sayfa) , aaa -> adres , vvv -> de�er	
			if(*U1_Buf == 'W')
			{	
				if( Can.FromInv.LogInDurum )
				{	
					if( EeKayit.Konfig.Bit.UzakErisim )	
					{
						//Numerik kontrol yap�l�yor.
						for(Uart1_i = 1;Uart1_i < 8;Uart1_i++)								
						{
							if( (*(U1_Buf + Uart1_i) > 57) || (*(U1_Buf + Uart1_i) < 48) )
							{		
									U1_Gonder("BE MUST NUMERIC",Uart1.Dumm);
									break;
							}		
						}
						//Sayfa
						Uart1.AraIslemDeger[0] = (*(U1_Buf + 1) - 48);	
						//Adres
						Uart1.AraIslemDeger[1] = ((*(U1_Buf + 2)-48)*100) + ((*(U1_Buf + 3)-48) * 10) + *(U1_Buf + 4) - 48;
						//Eeprom datas�
						Uart1.AraIslemDeger[2] = ((*(U1_Buf + 5)-48)*100) + ((*(U1_Buf + 6)-48) * 10) + *(U1_Buf + 7) - 48;
						Uart1.R_Deger = Uart1.AraIslemDeger[2] & 0x00ff;
						//Eeprom adresi
						Uart1.R_Adres = (Uart1.AraIslemDeger[0] * 1024) + Uart1.AraIslemDeger[1] * 2;
						//Eeprom Label i�in girilen adres kontrol� yapar.
						if( (Uart1.R_Adres < DefEepromLabelAltSinir) || (Uart1.R_Adres > DefEepromLabelUstSinir) )
						{
							U1_Gonder("WRONG LABEL ADRES",Uart1.Dumm);
							break;
						}	
						else
						{
							*Uart1.R_Adres = Uart1.R_Deger;	
							EeWordYaz(Uart1.R_Adres, Uart1.R_Deger);	
							U1_Gonder("OK", Uart1.Dumm );
							break;
						}												
					}
					else 												
						U1_Gonder("ACCDE",Uart1.Dumm);	
				}
				else
					U1_Gonder("ACCDE",Uart1.Dumm);
				break;	
			}									

			else if((*U1_Buf == 'A') && (*(U1_Buf + 1) == 'C') && (*(U1_Buf + 2) == 'L'))		//RS232 YE SAAT CEVABI
			{
				Date.Hour = (((*(U1_Buf + 3) - 48) * 10) + (*(U1_Buf + 4) - 48));
				Date.Min = (((*(U1_Buf + 6) - 48) * 10) + (*(U1_Buf + 7) - 48));
				YazRTC(&Date);
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}
			else if((*U1_Buf == 'A') && (*(U1_Buf + 1) == 'D'))									//RS232 YE TAR�H CEVABI
			{
				Date.Day = (((*(U1_Buf + 2) - 48) * 10) + (*(U1_Buf + 3) - 48));
				Date.Month = (((*(U1_Buf + 4) - 48) * 10) + (*(U1_Buf + 5) - 48));
				Date.Year = (((*(U1_Buf + 6)-48) * 10) + (*(U1_Buf + 7) - 48));
				YazRTC(&Date);
				U1_Gonder("OK", Uart1.Dumm );	
				break;
			}
						
			//SxxRyyyy<13> gelecek uart tan ve xx dakika i�eriside uyu (shutdown) yyyy dakika sonra uyan (Restore) emri g�nderilecek.
			else if ((*U1_Buf == 'S') && (*(U1_Buf + 3) == 'R'))			
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{			
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{	
						if( *(U1_Buf + 1) != '.' )							
							Timer6.ShutdownTime = ((*(U1_Buf + 1) - 48) * 10 + (*(U1_Buf + 2) - 48)) * 60;
						else if( *(U1_Buf + 1) == '.' )		
							Timer6.ShutdownTime = ( 6 * (*(U1_Buf + 2) - 48) );
							
						Timer6.RestoreTime = ( ((*(U1_Buf + 4) - 48) * 1000) + ((*(U1_Buf + 5) - 48) * 100) + ((*(U1_Buf + 6) - 48) * 10) + (*(U1_Buf + 7) - 48) ) * 60;						
						U1_Gonder("OK", Uart1.Dumm );
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{
					U1_Gonder("ACCDE",Uart1.Dumm );
				}
				break;
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 10:

			//Gelen P12345678<13>
			if(*U1_Buf == 'P')	
			{	
				//Merkezi kod �ifresi ge�erli yani Kod Gen 1. sat�rda yaz�lacak
				if( Can.FromInv.SifreSistemi == 1 )
				{
					if( Uart1.KodIslemiYapildi == 1 )
					{
						//S�ras�yla	Hi word, alttaki Low word
						Uart1.AraIslemDeger[0] = ( ((*(U1_Buf + 1) - 48) * 1000) + ((*(U1_Buf + 2) - 48) * 100) + ((*(U1_Buf + 3) - 48) * 10) + (*(U1_Buf + 4) - 48) );
						Uart1.AraIslemDeger[1] = ( ((*(U1_Buf + 5) - 48) * 1000) + ((*(U1_Buf + 6) - 48) * 100) + ((*(U1_Buf + 7) - 48) * 10) + (*(U1_Buf + 8) - 48) );
						if(( Menu.SifreH == Uart1.AraIslemDeger[0] ) && ( Menu.SifreL == Uart1.AraIslemDeger[1]))
						{
							if( Can.FromInv.LogInDurum == 0 )
							{
								CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
								//Servis kodlar�n� yenile
								SifreAl();
							}
							//Bir dahakinde kod istenmeden �ifre yaz�lmas�n diye s�f�rlan�r.
							Uart1.KodIslemiYapildi = 0;	
							U1_Gonder("OK", Uart1.Dumm );
							break;
						}
						else
						{
							//7,5 saniye geriye sayacak.
							Uart1.PassWordHataliGeriSayac = 150;
							U1_Gonder("ERROR", Uart1.Dumm );
							break;
						}
					}
					else
					{	
						U1_Gonder("ERROR", Uart1.Dumm );
						break;
					}		
				}
				//Basit kod �ifresi ge�erli kod Gen 1. Sat�rda de�il onun yerine password yaz�l�.
				else if( Can.FromInv.SifreSistemi == 2 )
				{
					U1_SifreSayac = 0;
					for(Uart1_i = 0;Uart1_i < 8;Uart1_i++)
					{
						if( EeKayit.BasitPassword[Uart1_i] == ( *(U1_Buf + Uart1_i + 1)))
							U1_SifreSayac++;
					}
					if(U1_SifreSayac > 7)
					{
						U1_SifreSayac = 0;
						if( Can.FromInv.LogInDurum == 0 )
						{
							CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
						}
						//Bir dahakinde kod istenmeden �ifre yaz�lmas�n diye s�f�rlan�r.
						Uart1.KodIslemiYapildi = 0;	
						U1_Gonder("OK", Uart1.Dumm );
						break;
					}
					else
					{
						//7,5 saniye geriye sayacak.
						Uart1.PassWordHataliGeriSayac = 150;
						U1_Gonder("ERROR", Uart1.Dumm );
						break;
					}	
				}
				else
				{	
					U1_Gonder("SifreSistemi Hatas�", Uart1.Dumm );
					break;
				}
			}		
			//Denemelerde Sadece Ram'e istenilen de�eri verebilmek i�in geli�tirildi.
			else if((*U1_Buf == 'L'))												
			{
				Uart1.R_Adres = (((*(U1_Buf + 1) - 48) * 100 + (*(U1_Buf + 2) - 48) * 10 + ((*(U1_Buf + 3) - 48))) * 2) + 2560;		
				Uart1.R_Deger = (*(U1_Buf + 4) - 48) * 10000 + (*(U1_Buf + 5) - 48) * 1000 + (*(U1_Buf + 6) - 48) * 100 + (*(U1_Buf + 7) - 48) * 10 + (*(U1_Buf + 8) - 48);
				*Uart1.R_Adres = Uart1.R_Deger;	
				U1_Gonder("OK", Uart1.Dumm );
				break;
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 11:
			//Adrese yazma
			if((*U1_Buf == 'W') || (*U1_Buf == 'B'))				
			{	
				if(*U1_Buf == 'W')
					Uart1.W_B = 0;
				if(*U1_Buf == 'B')
					Uart1.W_B = 1;
					
				if( EeKayit.Konfig.Bit.UzakErisim )	
				{
					if(*U1_Buf == 'W')
						Uart1.SonSorulanEmir = 'W';	
					if(*U1_Buf == 'B')
						Uart1.SonSorulanEmir = 'B';					
					Uart1.CheckSum = Uart1.CheckSum + ( (*(U1_Buf + 5) - 48) * 10000 + (*(U1_Buf + 6) - 48) * 1000 + (*(U1_Buf + 7) - 48) * 100 + (*(U1_Buf + 8) - 48) * 10 + (*(U1_Buf + 9) - 48) );
	
					//Yanl�� komut olup olmad���na bakmak i�in
					Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48));
					Uart1.AraIslemDeger[1] = ( (*(U1_Buf + 5) - 48) * 10000 + (*(U1_Buf + 6) - 48) * 1000 + (*(U1_Buf + 7) - 48) * 100 + (*(U1_Buf + 8) - 48) * 10 + (*(U1_Buf + 9) - 48) );
					if( (Uart1.AraIslemDeger[0] == 0) && ((Uart1.AraIslemDeger[1] & 1) == 1) )	
					{
						//Wrong command
						U1_Gonder("WRCM", Uart1.Dumm );							
						break;
					}
					
					if(*(U1_Buf + 1) - 48 == 1)
					{
						if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))
						{
							Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48));
							Uart1.AraIslemDeger[1] = ( (*(U1_Buf + 5) - 48) * 10000 + (*(U1_Buf + 6) - 48) * 1000 + (*(U1_Buf + 7) - 48) * 100 + (*(U1_Buf + 8) - 48) * 10 + (*(U1_Buf + 9) - 48) );
							
							if(( Uart1.AraIslemDeger[0] == 46 ) || ( Uart1.AraIslemDeger[0] == 0 ))			//W1046 - Inverter Options  , W1000 - Emir se
							{
								//Adres 0 ise emirdir.
								if( Uart1.AraIslemDeger[0] == 0 )
								{	
									//Kay�tl� listeden hangilerine yazma i�lemi yapabilir onun kontrol�
									U1_Yetki = 0;
									for( Uart1_i = 0;Uart1_i < 7;Uart1_i++ )
									{
										if( Uart1.AraIslemDeger[1] == YazmaYetkileri_Emir[Uart1_i] )
											U1_Yetki++;
									}	
									if( U1_Yetki > 0 )	
									{
										U1_Yetki = 0;								
										//Kullan�c� �ifresi do�ru girilmeli.
										if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
										{
											//Adres 0 ise gelen i�lem emir i�lemidir.
											if( Uart1.AraIslemDeger[0] == 0 )
												Uart1.EmirGonderildi = 1;
											else							
												Uart1.EmirGonderildi = 0;
												
											if( Uart1.W_B == 0 )
											{
												YedekCanGonder(DefCanInv,28,'W',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
												CanGonder(DefCanInv,28,'W',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
											}
											else
											{
												YedekCanGonder(DefCanInv,28,'B',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
												CanGonder(DefCanInv,28,'B',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
											}
											Can.ToInv.Gonderildi.Bit.U1_W = 1;
											Uart1.Tekrar = 19;
											break;
										}
										else
										{	U1_Gonder("ACCDE", Uart1.Dumm ); }
									}	
									else
									{	U1_Gonder("ACCDE", Uart1.Dumm ); }					
								}
								//Emir haricindekilerdir.
								else
								{											
									//Kullan�c� �ifresi do�ru girilmeli.
									if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
									{
										if( Uart1.W_B == 0 )
										{
											YedekCanGonder(DefCanInv,28,'W',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
											CanGonder(DefCanInv,28,'W',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
										}
										else
										{
											YedekCanGonder(DefCanInv,28,'B',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
											CanGonder(DefCanInv,28,'B',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
										}
										Can.ToInv.Gonderildi.Bit.U1_W = 1;
										Uart1.Tekrar = 19;
										break;
									}
									else
									{	U1_Gonder("ACCDE", Uart1.Dumm ); }	
								}
							}
							else
							{	U1_Gonder("ACCDE", Uart1.Dumm ); }	
						}
					}
					if(*(U1_Buf + 1) - 48 == 2)
					{	U1_Gonder("ACCDE", Uart1.Dumm ); }	
					//�uan Pfc ye data g�nderilmeye izin verilmiyor.
	//				if(*(U1_Buf + 1) - 48 == 2)
	//				{
	//					if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))
	//					{
	//						Uart1.AraIslemDeger[0] = ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48));
	//						Uart1.AraIslemDeger[1] = ( (*(U1_Buf + 5) - 48) * 10000 + (*(U1_Buf + 6) - 48) * 1000 + (*(U1_Buf + 7) - 48) * 100 + (*(U1_Buf + 8) - 48) * 10 + (*(U1_Buf + 9) - 48) );
	//						YedekCanGonder(DefCanPfc,55,'W',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
	//						CanGonder(DefCanPfc,55,'W',Uart1.AraIslemDeger[1],Uart1.AraIslemDeger[0]);
	//						Can.ToPfc.Gonderildi.Bit.U1_W = 1;
	//						Uart1.Tekrar = 19;
	//						break;
	//					}
	//				}
					if(*(U1_Buf + 1) - 48 == 3)
					{
						Uart1.R_Adres = ( ((*(U1_Buf + 2) - 48) * 100 + (*(U1_Buf + 3) - 48) * 10 + (*(U1_Buf + 4) - 48)) << 1 ) + 2560;
						Uart1.R_Deger = ( (*(U1_Buf + 5) - 48) * 10000 + (*(U1_Buf + 6) - 48) * 1000 + (*(U1_Buf + 7) - 48) * 100 + (*(U1_Buf + 8) - 48) * 10 + (*(U1_Buf + 9) - 48) );
						Uart1.RamLimitli_mi = Uart1.R_Deger;
						
						//Kay�tl� listeden hangilerine yazma i�lemi yapabilir onun kontrol�
						U1_Yetki = 0;
						for( Uart1_i = 1;Uart1_i < 7;Uart1_i++ )
						{
							if( Uart1.R_Adres == YazmaYetkileri_Comm1[Uart1_i][0] )
								U1_Yetki++;
						}
						
						if( U1_Yetki > 0)
						{	
							U1_Yetki = 0;
							//Kullan�c� �ifresi do�ru girilmeli.
							if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
							{
								//Label lar haricindeki eeprom de�erleri min - max limitlerden ge�er.
								if((Uart1.R_Adres > 3300) && (Uart1.R_Adres < DefEepromDegiskenUstSinir))								
								{
									U1_AraIslem = Uart1.R_Adres;
									U1_AraIslem = (U1_AraIslem-3302)/2;
									if( Uart1.R_Deger > MinMax[U1_AraIslem][MaxAddrKontrol] )
										Uart1.R_Deger = MinMax[U1_AraIslem][MaxAddrKontrol];
										
									if( ( Uart1.R_Deger > MinMax[U1_AraIslem][MinAddrKontrol] ) && ( Uart1.R_Deger< MinMax[U1_AraIslem][AraAddrKontrol] ) )
										Uart1.R_Deger = MinMax[U1_AraIslem][MinAddrKontrol];
										
									if( Uart1.R_Deger < MinMax[U1_AraIslem][MinAddrKontrol] )
										Uart1.R_Deger = MinMax[U1_AraIslem][MinAddrKontrol];
								}							
								*Uart1.R_Adres = Uart1.R_Deger;
								EeWordYaz( Uart1.R_Adres , Uart1.R_Deger );	
								
								//07.05.2014
								if( (Label.NominalVoltage[16] == '1') && ( (Label.NominalVoltage[17] == '1') || (Label.NominalVoltage[17] == '2') ) )
									UPS_I_O_Options = 1;
								else
									UPS_I_O_Options = 0;
								//02.10.2013---
								if( (Uart1.R_Adres == 3396) || (Uart1.R_Adres == 3404) )
								{
									Basla[9] = Genel.Besleme = AdcOku(AN12);
									EeKayit.BeslemeIlk = Genel.Besleme;
									EeWordYaz( &EeKayit.BeslemeIlk , EeKayit.BeslemeIlk );								
								}							
								//------------						
								//Dil adresinde bir �ey yaz�l�yorsa ekran� yenile
								if( Uart1.R_Adres == 3372 )
									Menu.YenileGeriSayac = 5;
									
								if( Uart1.RamLimitli_mi == Uart1.R_Deger )	
									U1_Gonder("OK", Uart1.Dumm );
								else
									U1_Gonder("LIMITED", Uart1.Dumm );
							}
							else
							{	U1_Gonder("ACCDE", Uart1.Dumm ); }	
						}
						else
						{	U1_Gonder("ACCDE", Uart1.Dumm ); }	
					}	
				}
				else
				{	U1_Gonder("ACCDE", Uart1.Dumm ); }
			}
			else if((*U1_Buf == 'R') && (*(U1_Buf + 1) == 'E') && (*(U1_Buf + 2) == 'S') && (*(U1_Buf + 3) == 'E') && (*(U1_Buf + 4) == 'T') && (*(U1_Buf + 5) == ' ') && (*(U1_Buf + 6) == 'P') && (*(U1_Buf + 7) == 'A') && (*(U1_Buf + 8) == 'S') && (*(U1_Buf + 9) == 'S'))
			{
				for( Uart1_i = 0; Uart1_i < 8; Uart1_i++ )
				{
					EeKayit.BasitPassword[0] = 48; EeKayit.BasitPassword[1] = 56; EeKayit.BasitPassword[2] = 51;
					EeKayit.BasitPassword[3] = 51; EeKayit.BasitPassword[4] = 51; EeKayit.BasitPassword[5] = 54;
					EeKayit.BasitPassword[6] = 48; EeKayit.BasitPassword[7] = 48;
					EeWordYaz( &EeKayit.BasitPassword[Uart1_i] , EeKayit.BasitPassword[Uart1_i] );
				}
				U1_Gonder("OK",Uart1.Dumm );
				break;
			}
			//Asm Reset i�lemi
			else if((*U1_Buf == 'R') && (*(U1_Buf + 1) == 'E') && (*(U1_Buf + 2) == 'S') && (*(U1_Buf + 3) == 'E') && (*(U1_Buf + 4) == 'T') && (*(U1_Buf + 5) == 'P') && (*(U1_Buf + 6) == 'A') && (*(U1_Buf + 7) == 'N') && (*(U1_Buf + 8) == 'E') && (*(U1_Buf + 9) == 'L'))
			{	asm("RESET");}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		case 15:		
			if((*U1_Buf == 'A') && (*(U1_Buf + 1) == 'T'))									//RS232 YE TAR�H CEVABI
			{	
				if( EeKayit.Konfig.Bit.UzakErisim )
				{
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						Date.Day = (((*(U1_Buf + 2) - 48) * 10) + (*(U1_Buf + 3) - 48));
						Date.Month = (((*(U1_Buf + 4) - 48) * 10) + (*(U1_Buf + 5) - 48));
						Date.Year = (((*(U1_Buf + 6)-48) * 10) + (*(U1_Buf + 7) - 48));
						Date.Hour = (((*(U1_Buf + 9) - 48) * 10) + (*(U1_Buf + 10) - 48));
						Date.Min = (((*(U1_Buf + 12) - 48) * 10) + (*(U1_Buf + 13) - 48));
						YazRTC(&Date);
						U1_Gonder("OK", Uart1.Dumm );	
						break;
					}
					else 
					{
						U1_Gonder("ACCDE",Uart1.Dumm );
					}
				}
				else 
				{
					U1_Gonder("ACCDE",Uart1.Dumm );
				}
			}
			else
			{
				U1_Gonder("ERROR",Uart1.Dumm );
			}
		break;
		default:
//			BekleMs(1);
			U1_Gonder("OK", Uart1.Dumm );
		break;
	}	
}	






void U1_Gonder(char *U1_str,unsigned int *U1_Var)									
{
	unsigned int U1_x1 , U1_x2 , U1_x3;
	unsigned int Uart1_z;
	
	U1_x1 = 0;	U1_x2 = 0;	U1_x3 = 0;	
	
	if( (Uart1.SonSorulanEmir=='R') || (Uart1.SonSorulanEmir == 'W') )
	{
		if( Uart1.ChkSorgusuGeldi == 0 )
		{
			Uart1.CheckSum = Uart1.CheckSum + *U1_Var;
		}
	}
	Uart1.SonSorulanEmir = 0;
	
	while(*(U1_str+U1_x2))									//Sonland�rma simgesi
	{	
		if(*(U1_str+U1_x2) == '[')							//tek karakter
		{
			U1tx(U1_Var+U1_x1,1,U1_x3,0);
			U1_x1++;
		}
		else if(*(U1_str+U1_x2) == ']')						//iki karakter
		{
			U1tx(U1_Var+U1_x1,2,U1_x3,0);
			U1_x1++;
			U1_x3=U1_x3+1;
		}
		else if(*(U1_str+U1_x2) == '|')						//1.3
		{
			U1tx(U1_Var+U1_x1,2,U1_x3,1);
			U1_x1++;
			U1_x3=U1_x3+2;
		}
		else if(*(U1_str+U1_x2) == '%')						//�� karakter yazd�r
		{
			U1tx(U1_Var+U1_x1,3,U1_x3,0);
			U1_x1++;
			U1_x3=U1_x3+2;
		}
		else if(*(U1_str+U1_x2) == '^')						//50.1 gibi noktal� de�erleri yazd�rmak
		{
			U1tx(U1_Var+U1_x1,3,U1_x3,1);
			U1_x1++;
			U1_x3=U1_x3+3;		
		}
		else if(*(U1_str+U1_x2) == '@')						//4 karakter yazd�rmak
		{
			U1tx(U1_Var+U1_x1,4,U1_x3,0);
			U1_x1++;
			U1_x3=U1_x3+3;		
		}
		else if(*(U1_str+U1_x2) == '�')						//4 ve noktal� toplam 5 karakter yazd�rmak
		{													//�rn. 123.1 gibi.
			U1tx(U1_Var+U1_x1,4,U1_x3,1);
			U1_x1++;
			U1_x3=U1_x3+4;		
		}
		else if(*(U1_str+U1_x2) == '�')						//5 karakter yazd�rmak
		{
			U1tx(U1_Var+U1_x1,5,U1_x3,0);
			U1_x1++;
			U1_x3=U1_x3+4;		
		}
		else if(*(U1_str+U1_x2) == '~')						//Alarmlar� yazd�rmak i�in
		{
			Nop();
		}
		else if(*(U1_str+U1_x2)=='$')						//Dizi i�erisindeki elemanlar� �eker.
		{		
			U1TxDmaBuf[U1_x3] = *(U1_Var+U1_x1);	
			U1_x1++;
		}
		else
		{		
			U1TxDmaBuf[U1_x3] = *(U1_str+U1_x2);	
		}
		U1_x3++;
		U1_x2++;
	}
	Uart1.LokalSayac = 0;
	//Kelime sonlar� i�in <Chr13>
	U1TxDmaBuf[U1_x3] = 13;										

	DMA7CNT = U1_x3;
	DMA7STA = __builtin_dmaoffset(&U1TxDmaBuf);
	DMA7CONbits.CHEN = 1;								
	DMA7REQbits.FORCE = 1;					
}

void U1tx(unsigned int *U1_Deger,unsigned int U1_Hane,unsigned int U1_HaneBuf,unsigned int U1_Nokta)
{		
	switch(U1_Hane)
	{
		case 5:
			U1TxDmaBuf[U1_HaneBuf] = (*U1_Deger / 10000) + 48;
		case 4:
			U1TxDmaBuf[U1_HaneBuf+U1_Hane-4] = ((*U1_Deger % 10000) / 1000) + 48;
		case 3:
			U1TxDmaBuf[U1_HaneBuf+U1_Hane-3] = (((*U1_Deger % 10000) % 1000) / 100) + 48;
		case 2:
			U1TxDmaBuf[U1_HaneBuf+U1_Hane-2] = ((((*U1_Deger % 10000) % 1000) % 100) / 10)+ 48;
			if(U1_Nokta == 1)
				U1TxDmaBuf[U1_HaneBuf+U1_Hane-1] = '.';
		case 1:
			U1TxDmaBuf[U1_HaneBuf+U1_Hane-1+U1_Nokta] = ((((*U1_Deger % 10000) % 1000) % 100) % 10) + 48;
			break;
		default:
			break;
	}
}
