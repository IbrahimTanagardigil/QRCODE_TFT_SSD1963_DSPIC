#include "p33FJ256MC710.h"

#include "TFTCanPfc.h"
#include "TFTDef.h"
#include "TFTVar.h"
#include "TFTTablo.h"


void CanPfcIslemFonk(unsigned int *CanPfc_Buf)
{
	unsigned int PfcID;
	
	Can.FromPfc.PfcGeldi = 0;
	PfcID = *CanPfc_Buf & 0x00ff;
	
	switch( PfcID )
	{
		//Adjust men� i�in Can trafi�i
		case 54:
			/*
				Gelen Paket[0] --> Paket no
				Gelen Paket[1] --> Set sat�r�ndaki de�er
				Gelen Paket[2] --> Sonu�
				Gelen Paket[3] --> [0] + [1] + [2]
			*/
			//Paket CRC
			if( *(CanPfc_Buf + 3) == ( *CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
			{		
				//Yeni bir de�i�kene bak�l�nca eski sorgulanan adres can de kal�yor o y�zden ilk gelen data de�il ikinci data i�lensin.
				if(++Can.FromPfc.DogruDataGosterSayac > 1)
				{
					Can.FromPfc.DogruDataGosterSayac = 2;
					//Gelen Set de�eri g�nderilenden farkl�ysa bir seferli�ine g�ster
					if( Can.ToPfc.AyarGonderilenData != *(CanPfc_Buf + 1 ) )
						Can.FromPfc.GonderilendenFarkliDataGeldi = 1;
						
					//Pfc factory option da bit i�lemleri i�in
					if(( Ayar_PfcFactOpt[Menu.AyarEtiket][2] == 2160 ))
					{
						AyarBitAnlam.PfcFactOpt.All = *(CanPfc_Buf + 1 );
						Can.FromPfc.BitIslemDatasiGeldi = 1;
					}
					//Ayar Sekmesindeyse ayar i�lemi s�ras�nda Set de�eri de�i�mesin	
					if( Menu.Sekme.All == DefAyarGrupAltMenu )
					{
						if((Menu.AyarGrupAltSekme != 1) || ( Can.FromPfc.GonderilendenFarkliDataGeldi == 1 ))
						{
							Can.ToPfc.AyarGonderilenData = *(CanPfc_Buf + 1 );
							Can.FromPfc.GonderilendenFarkliDataGeldi = 0;	
							Menu.AyarAyar = *(CanPfc_Buf + 1 );
						}
					}
					else
					{								
						if(( Menu.AyarAltSekme != 1 ) || ( Can.FromPfc.GonderilendenFarkliDataGeldi == 1 ))
						{
							Can.ToPfc.AyarGonderilenData = *(CanPfc_Buf + 1 );
							Can.FromPfc.GonderilendenFarkliDataGeldi = 0;	
							Menu.AyarAyar = *(CanPfc_Buf + 1 );
						}
					}
					Menu.AyarSonuc = *(CanPfc_Buf + 2 );
					if( Menu.EnterExit == 0 )
						Menu.Yenile = 1;
					//Gelmeme durumunda ekran� s�f�rlar.
					Can.FromPfc.AyarDatasiGelmediSayac = 4;
				}
			}
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 	
		break;
		//Uart'tan g�nderilen Can den sorgular�n cevaplar�
		case 55:
			//Gelen Paket
			/*
				Gelen Paket[0] (*CanPfc_Buf) 	 --> (( 'R' << 8 ) & 0xff00) | 28
				Gelen Paket[1] (*(CanPfc_Buf+1)) --> Adres
				Gelen Paket[2] (*(CanPfc_Buf+2)) --> Adres teki de�er
				Gelen Paket[3] (*(CanPfc_Buf+3)) --> Gelen Paket[0] + Gelen Paket[1] + Gelen Paket[2]
			*/
			
			if( (Can.ToPfc.Gonderildi.Bit.U1_R == 1) || ( Can.ToPfc.Gonderildi.Bit.U2_R == 1 ) ) 
			{
				//G�rev CRC
				if((( ( *CanPfc_Buf ) >> 8) & 0x00ff) == 'R')
				{
					//Paket CRC
					if( *(CanPfc_Buf + 3) == ( *CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
					{
						//Adres CRC
						if( *(CanPfc_Buf + 1) == Can.ToPfc.TekrarIcinBuff[4] )
						{
							//Hata olmu�sa s�f�rla
							Can.FromPfc.R_HataSayaci.Adres = 0;
							Can.FromPfc.R_HataSayaci.Paket = 0;
							Can.FromPfc.R_HataSayaci.Gorev = 0;
							
							if( Can.ToPfc.Gonderildi.Bit.U1_R )
							{
								Can.ToPfc.Gonderildi.Bit.U1_R = 0; 
								U1_Gonder("�",( CanPfc_Buf+2 ));
								break;
							}
							else if( Can.ToPfc.Gonderildi.Bit.U2_R )
							{
								Can.ToPfc.Gonderildi.Bit.U2_R = 0;
								U2_Gonder("�",( CanPfc_Buf+2 ));
								break;
							}
						}
						else
						{
							if( ++Can.FromPfc.R_HataSayaci.Adres > DefCanHataSinir )
							{
								Can.FromPfc.R_HataSayaci.Adres = 0;
								if( Can.ToPfc.Gonderildi.Bit.U1_R )
								{
									Can.ToPfc.Gonderildi.Bit.U1_R = 0; 
									U1_Gonder("R-ERR",Uart1.Dumm);
									break;
								}
								else if( Can.ToPfc.Gonderildi.Bit.U2_R )
								{
									Can.ToPfc.Gonderildi.Bit.U2_R = 0;
									U2_Gonder("R-ERR",Uart2.Dumm);
									break;
								}
							}
						}
					}					
					else
					{
						if( ++Can.FromPfc.R_HataSayaci.Paket > DefCanHataSinir )
						{
							Can.FromPfc.R_HataSayaci.Paket = 0;
							if( Can.ToPfc.Gonderildi.Bit.U1_R )
							{
								Can.ToPfc.Gonderildi.Bit.U1_R = 0; 
								U1_Gonder("R-ERR",Uart1.Dumm);
								break;
							}
							else if( Can.ToPfc.Gonderildi.Bit.U2_R )
							{
								Can.ToPfc.Gonderildi.Bit.U2_R = 0;
								U2_Gonder("R-ERR",Uart2.Dumm);
								break;
							}
						}
					}
				}					
				else
				{
					if( ++Can.FromPfc.R_HataSayaci.Gorev > DefCanHataSinir )
					{
						Can.FromPfc.R_HataSayaci.Gorev = 0;
						if( Can.ToPfc.Gonderildi.Bit.U1_R )
						{
							Can.ToPfc.Gonderildi.Bit.U1_R = 0; 
							U1_Gonder("R-ERR",Uart1.Dumm);
							break;
						}
						else if( Can.ToPfc.Gonderildi.Bit.U2_R )
						{
							Can.ToPfc.Gonderildi.Bit.U2_R = 0;
							U2_Gonder("R-ERR",Uart2.Dumm);
							break;
						}
					}
				}
			}
			else if( (Can.ToPfc.Gonderildi.Bit.U1_L == 1) || ( Can.ToPfc.Gonderildi.Bit.U2_L == 1 ) ) 
			{
				//G�rev CRC
				if((( ( *CanPfc_Buf ) >> 8) & 0x00ff) == 'L')
				{
					//Paket CRC
					if( *(CanPfc_Buf + 3) == ( *CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
					{
						//Adres CRC
						if( *(CanPfc_Buf + 1) == Can.ToPfc.TekrarIcinBuff[4] )
						{
							//Hata olmu�sa s�f�rla
							Can.FromPfc.L_HataSayaci.Adres = 0;
							Can.FromPfc.L_HataSayaci.Paket = 0;
							Can.FromPfc.L_HataSayaci.Gorev = 0;
							
							if( Can.ToPfc.Gonderildi.Bit.U1_L )
							{
								Can.ToPfc.Gonderildi.Bit.U1_L = 0; 
								U1_Gonder("�",( CanPfc_Buf+2 ));
								break;
							}
							else if( Can.ToPfc.Gonderildi.Bit.U2_L )
							{
								Can.ToPfc.Gonderildi.Bit.U2_L = 0;
								U2_Gonder("�",( CanPfc_Buf+2 ));
								break;
							}
						}
						else
						{
							if( ++Can.FromPfc.L_HataSayaci.Adres > DefCanHataSinir )
							{
								Can.FromPfc.L_HataSayaci.Adres = 0;
								if( Can.ToPfc.Gonderildi.Bit.U1_L )
								{
									Can.ToPfc.Gonderildi.Bit.U1_L = 0; 
									U1_Gonder("R-ERR",Uart1.Dumm);
									break;
								}
								if( Can.ToPfc.Gonderildi.Bit.U2_L )
								{
									Can.ToPfc.Gonderildi.Bit.U2_L = 0;
									U2_Gonder("R-ERR",Uart2.Dumm);
									break;
								}
							}
						}
					}					
					else
					{
						if( ++Can.FromPfc.L_HataSayaci.Paket > DefCanHataSinir )
						{
							Can.FromPfc.L_HataSayaci.Paket = 0;
							if( Can.ToPfc.Gonderildi.Bit.U1_L )
							{
								Can.ToPfc.Gonderildi.Bit.U1_L = 0; 
								U1_Gonder("R-ERR",Uart1.Dumm);
								break;
							}
							else if( Can.ToPfc.Gonderildi.Bit.U2_L )
							{
								Can.ToPfc.Gonderildi.Bit.U2_L = 0;
								U2_Gonder("R-ERR",Uart2.Dumm);
								break;
							}
						}
					}
				}					
				else
				{
					if( ++Can.FromPfc.L_HataSayaci.Gorev > DefCanHataSinir )
					{
						Can.FromPfc.L_HataSayaci.Gorev = 0;
						if( Can.ToPfc.Gonderildi.Bit.U1_L )
						{
							Can.ToPfc.Gonderildi.Bit.U1_L = 0; 
							U1_Gonder("R-ERR",Uart1.Dumm);
							break;
						}
						else if( Can.ToPfc.Gonderildi.Bit.U2_L )
						{
							Can.ToPfc.Gonderildi.Bit.U2_L = 0;
							U2_Gonder("R-ERR",Uart2.Dumm);
							break;
						}
					}
				}
			}			
			else if( (Can.ToPfc.Gonderildi.Bit.U1_W == 1) || ( Can.ToPfc.Gonderildi.Bit.U2_W == 1 ) ) 
			{
				//G�rev CRC
				if(((( ( *CanPfc_Buf ) >> 8) & 0x00ff) == 'W') || ((( ( *CanPfc_Buf ) >> 8) & 0x00ff) == 'B'))
				{
					//Paket CRC
					if( *(CanPfc_Buf + 3) == ( *CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
					{
						//Adres CRC
						if( *(CanPfc_Buf + 1) == Can.ToPfc.TekrarIcinBuff[4] )
						{		
							//De�er CRC	
							if( *(CanPfc_Buf + 2) == Can.ToPfc.TekrarIcinBuff[3] )
							{							
								if( Can.ToPfc.Gonderildi.Bit.U1_W )
								{
									Uart1.Tekrar = 0;
									Can.ToPfc.Gonderildi.Bit.U1_W = 0; 
									U1_Gonder("OK",Uart1.Dumm);
									break;
								}
								else if( Can.ToPfc.Gonderildi.Bit.U2_W )
								{
									Uart2.Tekrar = 0;
									Can.ToPfc.Gonderildi.Bit.U2_W = 0;
									U2_Gonder("OK",Uart2.Dumm);
									break;
								}
							}
							else
							{
								if( Can.ToPfc.Gonderildi.Bit.U1_W )
								{
									Can.ToPfc.Gonderildi.Bit.U1_W = 0; 
									U1_Gonder("LIMITED",Uart1.Dumm);
									break;
								}
								if( Can.ToPfc.Gonderildi.Bit.U2_W )
								{
									Can.ToPfc.Gonderildi.Bit.U2_W = 0;
									U2_Gonder("LIMITED",Uart2.Dumm);
									break;
								}
							}
						}				
						else
						{
							if( Can.ToPfc.Gonderildi.Bit.U1_W )
							{
								Can.ToPfc.Gonderildi.Bit.U1_W = 0; 
								U1_Gonder("R-ERR",Uart1.Dumm);
								break;
							}
							else if( Can.ToPfc.Gonderildi.Bit.U2_W )
							{
								Can.ToPfc.Gonderildi.Bit.U2_W = 0;
								U2_Gonder("R-ERR",Uart2.Dumm);
								break;
							}
						}
					}					
					else
					{
						if( Can.ToPfc.Gonderildi.Bit.U1_W )
						{
							Can.ToPfc.Gonderildi.Bit.U1_W = 0; 
							U1_Gonder("R-ERR",Uart1.Dumm);
							break;
						}
						else if( Can.ToPfc.Gonderildi.Bit.U2_W )
						{
							Can.ToPfc.Gonderildi.Bit.U2_W = 0;
							U2_Gonder("R-ERR",Uart2.Dumm);
							break;
						}
					}	
				}					
				else
				{
					if( Can.ToPfc.Gonderildi.Bit.U1_W )
					{
						Can.ToPfc.Gonderildi.Bit.U1_W = 0; 
						U1_Gonder("R-ERR",Uart1.Dumm);
						break;
					}
					else if( Can.ToPfc.Gonderildi.Bit.U2_W )
					{
						Can.ToPfc.Gonderildi.Bit.U2_W = 0;
						U2_Gonder("R-ERR",Uart2.Dumm);
						break;
					}
				}
			}
			//Ram den 0.65 sn bir istenen adreslerin cevaplar�
			//Paket CRC
//			if( *(CanPfc_Buf + 3) == ( *CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
//			{
//				//G�rev CRC
//				if((( ( *CanPfc_Buf ) >> 8) & 0x00ff) == 'R')
//				{
//					if( *(CanPfc_Buf+1) == 222 )
//						Basla[2] = *(CanPfc_Buf+2);
//					if( *(CanPfc_Buf+1) == 521 )
//						Basla[3] = *(CanPfc_Buf+2);
//				}
//			}
			//D�nen adres s�rekli ram den sorgulanan adresse birbirine e�itle
			//E�er men�.koordinat istenilen yerdeyse ekran� yenile.	
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0038:
			if(*(CanPfc_Buf + 3) == (*CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
			{
				Can.ToPfc.Zaman[0] = Can.ToPfc.Date_2.Day;
				Can.ToPfc.Zaman[1] = Can.ToPfc.Date_2.Month;
				Can.ToPfc.Zaman[2] = Can.ToPfc.Date_2.Year;
				Can.ToPfc.Zaman[3] = Can.ToPfc.Date_2.Sec;
				Can.ToPfc.Zaman[4] = Can.ToPfc.Date_2.Min;
				Can.ToPfc.Zaman[5] = Can.ToPfc.Date_2.Hour;												
				Can.ToPfc.Zaman[6] = ((Can.ToPfc.Zaman[0] & 0x1f)<<11)|((Can.ToPfc.Zaman[1] & 0x0f)<<7)|(Can.ToPfc.Zaman[2] & 0x7f);
				Can.ToPfc.Zaman[7] = ((Can.ToPfc.Zaman[3] & 0x3e)<<10)|((Can.ToPfc.Zaman[4] & 0x3f)<<5)|(Can.ToPfc.Zaman[5] & 0x1f);
				//Gelen ID nin ayn�s�yla s�k��t�r�lan zaman� g�nder.
				CanGonder(DefCanPfc,PfcID,'T',Can.ToPfc.Zaman[7],Can.ToPfc.Zaman[6]);
			}
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0039:
			if(*(CanPfc_Buf + 3) == (*CanPfc_Buf + *(CanPfc_Buf + 1) + *(CanPfc_Buf + 2)))
			{
				//'T' nin bir �nemi yok. De�er Can.GonderPaket[2] in de gidecek.
				//CanGonder(DefCanPfc,PfcID,'T',EeKayit.TermalSensor1.Olculen,2);
	//			CanGonder(DefCanPfc,PfcID,'T',EeKayit.TermalSensor1.Olculen,Genel.GirisDCKacakAlr);		//Basla[5] = giri� dc ka�ak logic 1 ise ka�ak var 0 ise ka�ak yok.
				//Yukar�daki sat�r yerine geldi.Servis login bilgisini PFC de alm�� bulunuyor.GirisDCKacakAlr ve 1.biti Can.FromInv.LogInDurum oldu 
				CanGonder(DefCanPfc,PfcID,'T',EeKayit.TermalSensor1.Olculen,(Genel.GirisDCKacakAlr+(Can.FromInv.LogInDurum*2)));		//Basla[5] = giri� dc ka�ak logic 1 ise ka�ak var 0 ise ka�ak yok.
			}
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
//-------------------------------------------------------------------------------------------
//Periyodik pfc den gelenler
		case 0x0070:
			Can.FromPfc.VinRMS.L1 = *(CanPfc_Buf + 1);
			Can.FromPfc.VinRMS.L2 = *(CanPfc_Buf + 2);
			Can.FromPfc.VinRMS.L3 = *(CanPfc_Buf + 3);			
			Megatech.G3.IPVoltageR = Can.FromPfc.VinRMS.L1 * 10;
			Megatech.G3.IPVoltageS = Can.FromPfc.VinRMS.L2 * 10;
			Megatech.G3.IPVoltageT = Can.FromPfc.VinRMS.L3 * 10;
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0071:
			Can.FromPfc.VinRMS.L1L3 = *(CanPfc_Buf + 1);
			Can.FromPfc.VinRMS.L2L1 = *(CanPfc_Buf + 2);
			Can.FromPfc.VinRMS.L3L2 = *(CanPfc_Buf + 3);
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0072:
			Can.FromPfc.CinRMS.L1 = *(CanPfc_Buf + 1);
			Can.FromPfc.CinRMS.L2 = *(CanPfc_Buf + 2);
			Can.FromPfc.CinRMS.L3 = *(CanPfc_Buf + 3);
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0073:
			Can.FromPfc.RecDCBus.Pos = *(CanPfc_Buf + 1);
			Can.FromPfc.RecDCBus.Neg = *(CanPfc_Buf + 2);
			Can.FromPfc.RecTemp = *(CanPfc_Buf + 3);
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0074:
			Can.FromPfc.VBatt.Pos =  *(CanPfc_Buf + 1);
			Can.FromPfc.VBatt.Neg =  *(CanPfc_Buf + 2);
			Can.FromPfc.RecFreq = (long)(780500 / *(CanPfc_Buf + 3));
		
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0075:
			Can.FromPfc.DisCbattC.Pos = *(CanPfc_Buf + 1);
			Can.FromPfc.DisCbattC.Neg = *(CanPfc_Buf + 2);
			
			Can.FromPfc.DisCbattC.Pos *= 10;
			Can.FromPfc.DisCbattC.Neg *= 10;
			 //Paket 3 bo�		
			if( Can.FromPfc.DisCbattC.Pos > 100 )
				Can.FromPfc.SonucDisCbattC.Pos = Can.FromPfc.DisCbattC.Pos;// * 10;
			else
				Can.FromPfc.SonucDisCbattC.Pos = Can.FromPfc.HassasDisCbattC.Pos;
			if( Can.FromPfc.DisCbattC.Neg > 100 )
				Can.FromPfc.SonucDisCbattC.Neg = Can.FromPfc.DisCbattC.Neg;// * 10;
			else
				Can.FromPfc.SonucDisCbattC.Neg = Can.FromPfc.HassasDisCbattC.Neg;
				
			if( Alarm.Word.Pfc1.Bit.SebekeKesik == 0  )				//14.07.14
			{
				Can.FromPfc.SonucDisCbattC.Neg = 0;
				Can.FromPfc.SonucDisCbattC.Pos = 0;
			}
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0076:
			Can.FromPfc.HassasDisCbattC.Pos = *(CanPfc_Buf + 1);
			Can.FromPfc.HassasDisCbattC.Neg = *(CanPfc_Buf + 2);
			 //Paket 3 bo�			
			if( Can.FromPfc.DisCbattC.Pos > 100 )
				Can.FromPfc.SonucDisCbattC.Pos = Can.FromPfc.DisCbattC.Pos;// * 10;
			else
				Can.FromPfc.SonucDisCbattC.Pos = Can.FromPfc.HassasDisCbattC.Pos;
			if( Can.FromPfc.DisCbattC.Neg > 100 )
				Can.FromPfc.SonucDisCbattC.Neg = Can.FromPfc.DisCbattC.Neg;// * 10;
			else
				Can.FromPfc.SonucDisCbattC.Neg = Can.FromPfc.HassasDisCbattC.Neg;
				
			if( Alarm.Word.Pfc1.Bit.SebekeKesik == 0  )				//14.07.14
			{
				Can.FromPfc.SonucDisCbattC.Neg = 0;
				Can.FromPfc.SonucDisCbattC.Pos = 0;
			}
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x0077:
			Can.FromPfc.CbattC.Pos = *(CanPfc_Buf + 1);
			Can.FromPfc.CbattC.Neg = *(CanPfc_Buf + 2);
			 //Paket 3 bo�
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		//Aradaki label lar kullan�labilir.
		case 0x007C:
			Can.FromPfc.ChkBuffer[0] = *(CanPfc_Buf + 1);			//Alarm.Word.Pfc1.All
			Can.FromPfc.ChkBuffer[1] = *(CanPfc_Buf + 2);			//Alarm.Word.Pfc2.All
			 //Paket 3 bo�
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		case 0x007D:
			Can.FromPfc.ChkBuffer[2] = *(CanPfc_Buf + 1);			//AlarmKod.Kod.Pfc
			Can.FromPfc.ChkBuffer[3] = *(CanPfc_Buf + 2);			//Can.FromPfc.PfcVersiyon
			Can.FromPfc.ChkBuffer[4] = *(CanPfc_Buf + 3);			//check sum
			Can.FromPfc.ChkBuffer[5] = Can.FromPfc.ChkBuffer[0] + Can.FromPfc.ChkBuffer[1] + Can.FromPfc.ChkBuffer[2] + Can.FromPfc.ChkBuffer[3] + 0x007C + 0x007D;
			if( Can.FromPfc.ChkBuffer[4] == Can.FromPfc.ChkBuffer[5] )
			{
				Alarm.Word.Pfc1.All = Can.FromPfc.ChkBuffer[0];
				Alarm.Word.Pfc2.All = Can.FromPfc.ChkBuffer[1];
				AlarmKod.Kod.Pfc = ( Can.FromPfc.ChkBuffer[2] & 1023 ) + 1000;
				Can.FromPfc.PfcVersiyon = Can.FromPfc.ChkBuffer[3];
				
				if( Alarm.Word.Pfc2.Bit.PfcDurakladi )
					Alarm.Word.Pfc2.Bit.GirisKontaktorAcik = 0;
					
				//A�a��dakinin ayn�s�ndan Alarm g�sterme fonksiyonunda da var.
				//Fault kod mu Status Kod mu o ayr��t�r�l�r.Yanl��l�klara �nlem al�r.		
				if( Alarm.Word.Pfc1.Bit.PfcFaultKod )
				{						
					Alarm.Word.Lcd1.Bit.PfcDurumKod = 0;
					//Can �zerinden yanl�� bir �ekilde kod = 0 ve fault var g�r�nmesin diye
					if( AlarmKod.Kod.Pfc == 1000 )
						Alarm.Word.Pfc1.Bit.PfcFaultKod = 0;
				}
				else
				{
					if( AlarmKod.Kod.Pfc == 1000 )
						Alarm.Word.Lcd1.Bit.PfcDurumKod = 0;
					else
						Alarm.Word.Lcd1.Bit.PfcDurumKod = 1;							
				}
				MaskedAlarm.Word.Lcd1.All = Alarm.Word.Lcd1.All & EeKayit.LcdLogMaske;	
				MaskedAlarm.Word.Pfc2.All = Alarm.Word.Pfc2.All & EeKayit.PfcLogMaske;	
				
				
				
				//K�sa Devre Durumunda fault reset durumuna g�re ekranda g�sterme
				if( Alarm.Word.Pfc1.Bit.PfcFaultKod )
				{
					if( (AlarmKod.Kod.Pfc == 189) || (AlarmKod.Kod.Pfc == 289) || (AlarmKod.Kod.Pfc == 389) )
					{
						if( Genel.FaultResetSagTusSayac == 0 )
						{
							Genel.EkranUyariMesajiVar_AlarmGosterme = 2;
							Menu.YenileGeriSayac = 10;
						}
					}
				}							
			}
			if( Genel.IlkAcilisAlrSayac < 5 )
				Genel.IlkAcilisAlrSayac++;
			 //Paket 3 bo�
			//30 x 100 ms = 3 sn
			Can.FromPfc.DataGelmediSayac = 30; 
		break;
		default:
		break;
	}
}





