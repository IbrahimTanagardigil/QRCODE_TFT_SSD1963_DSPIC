#ifndef __TFTMENU_H__
#define __TFTMENU_H__

extern void TouchMenu(int );
extern void MenuYenile(void);
extern void ButonKontrol(unsigned int );
extern void BuzzerKontrol(void);
extern void MeasureMenu(unsigned int ,unsigned int );
extern unsigned char dec2bcd(unsigned char );
extern void RtcToScreen(unsigned int );
extern void FonkAraSifreMenu( unsigned int ,unsigned int  );
extern void MenuGraphic(unsigned int );

extern void ZamanaBagliIsler(void);
extern void FonkOlcumAnaMenu(unsigned int ,unsigned int ,unsigned int );
extern void FonkTercihAltMenu(unsigned int ,unsigned int ,unsigned int ,unsigned int );
extern void FonkRoleAlarmAtama( int , int , int  );
extern void LogIslem(unsigned int );
extern void AlarmGoster(unsigned int );
//extern void FonkAlarmMenu(int ,unsigned int );
extern void InfoMenu(unsigned int ,unsigned int );
extern void FonkTercihAnaMenu(unsigned int ,unsigned int );
extern void FonkEmirAltMenu(unsigned int ,unsigned int ,unsigned int ,unsigned int );
extern void FonkAyaOnMenu_1(unsigned int ,unsigned int ,unsigned int );
extern void FonkAyaOnMenu_2(unsigned int ,unsigned int ,unsigned int );
extern void FonkAyaOnMenu_3(unsigned int ,unsigned int ,unsigned int );
extern void FonkAyaOnMenu_4(unsigned int ,unsigned int ,unsigned int );
extern void FonkAyarAnaMenu(unsigned int ,unsigned int );
extern void FonkAyarAltMenuFonk(unsigned int ,unsigned int ,unsigned int );
extern void FonkAyarGrupAltMenu(unsigned int ,unsigned int ,unsigned int );
extern void BakimAlarmKontrol(unsigned int );
extern void AkuFonk(void);
extern void MimikFonk(unsigned int );

extern void RoleIslem(unsigned int ,unsigned int );
extern unsigned int UserSifreDogrula(void);
extern unsigned int SifreDogrula(void);		
extern unsigned int BasitSifreDogrula(void);
extern unsigned int HaneSifirSor(unsigned int ,unsigned int );
extern void SifreAl(void);
extern void AyarAltMenuCanSorgu(unsigned int *);

extern void InPinsTara(void);
extern void DefaultDegerler(void);
extern void FonkUstKelime( unsigned char *,unsigned char * ,unsigned int );

extern void FonkYatayCizgi(unsigned int );
extern void FonkDikeyCizgi(unsigned int );
extern void FonkNokta( unsigned int );
extern void FonkSembol( unsigned int );
extern void UPS_Durdu_Fonk(void);

extern unsigned int UPS_IO_OPTIONS(unsigned char ,unsigned int );
#endif
