#include "p33FJ256MC710.h"

#include "TFTVar.h"
#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTCanPfc.h"
#include "TFTCanInv.h"
#include "TFTEeprom.h"
#include "TFTUart1.h"
#include "TFTRtc.h"
#include "BigTable.h"
#include "TFTTablo.h"
#include "TFTFonk.h"
#include "TFTTouch.h"

unsigned int Average(unsigned int Count,unsigned char Ch)
{
	unsigned long Sum = 0;
	unsigned int AdcValue = 0,Result = 0;
	int i;
	
	for(i = 0;i < Count;i++)
	{
		AdcValue = AdcOku(Ch);
		Sum = Sum + AdcValue;
	}
	Result = Sum / Count;
	return Result;
}

unsigned int MovingAverage1(unsigned char Channel)
{
	unsigned static int h2,Toplam2,MovAvg2[8];
	unsigned int k2,i2;
	for(i2 = 0;i2<8;i2++)
	{
		if(h2 > 7)
		{
			h2 = 0;
		}
		else
		{
			MovAvg2[h2] = AdcOku(Channel);
			h2++;
		}	
		Wait(25);	
	}
	Toplam2 = 0;
	for(k2=0;k2<8;k2++)
	{
		Toplam2 = MovAvg2[k2] + Toplam2;
	}
	Toplam2 = Toplam2 >> 3;
	return Toplam2;
}
unsigned int MovingAverage2(unsigned char Channel)
{
	unsigned static int h1,Toplam1,MovAvg1[8];
	unsigned int k1,i1;
	for(i1 = 0;i1<8;i1++)
	{
		if(h1 > 7)
		{
			h1 = 0;
		}
		else
		{
			MovAvg1[h1] = AdcOku(Channel);
			h1++;
		}	
		Wait(25);	
	}
	Toplam1 = 0;
	for(k1=0;k1<8;k1++)
	{
		Toplam1 = MovAvg1[k1] + Toplam1;
	}	
	Toplam1 = Toplam1 >> 3;
	return Toplam1;
}
void GetCoordinate(void)
{	
	unsigned long Gerilim;
	Gerilim = (long)Xal()*3300;
	Gerilim = Gerilim / 1023;
	AbsisX = ((3110 - Gerilim)*480)/2760;
	
	AbsisX = AbsisX + EeKayit.TouchOfsetX;
	if(AbsisX > 480)
		AbsisX = 480;
	if(AbsisX < 0)
		AbsisX = 0;
	
	Gerilim = (long)Yal()*3300;
	Gerilim = Gerilim / 1023;
	OrdinatY = ((3010 - Gerilim)*272)/2370;
		
	OrdinatY = OrdinatY + EeKayit.TouchOfsetY;
	
	if(OrdinatY > 272)
		OrdinatY = 272;
	if(OrdinatY < 0)
		OrdinatY = 0;
	
}
unsigned int Xal(void)
{
	unsigned int ResultX;
	_LATC3 = 0;
	TRISCbits.TRISC3 = 0;													//AnalogY ��k�� yap�ld�.
	_LATC3 = 0;
//	Wait(100);																//5 ms	
	DriveA = 1;																//Y+ y�ksek empedans
	DriveB = 0;																//X+ +5V
	Wait(200);																//5 ms	
	ResultX = FilterX();
	
	
	
//	ResultX = MovingAverage1(AnalogX);
//	_LATC3 = 0;
	TRISCbits.TRISC3 = 1;													//AnalogY giri� yap�ld�.
//	_LATC3 = 0;
	return ResultX;	
}
unsigned int FilterX(void)
{
	unsigned int AraSonucX,z;
	static unsigned int zOld = 0;

	PressCounterX++;
	if(z > 7)z = 0;
	AraSonucX = MovingAverage1(AnalogX);
	xSave[z] = AraSonucX;
	if(z > 0)
		zOld = z - 1;
	else
		zOld = 7;
	if(xSave[z] > xSave[zOld] + 10)
	{
		if(PressCounterX < 2)
		{
			xSave[zOld] = xSave[z];
		}
		else
		{
			xSave[z] = xSave[zOld];
			PressCounterX = 0;
		}
	}
	if(xSave[z] < xSave[zOld] - 10)
	{
		if(PressCounterX < 2)
		{
			xSave[z] = xSave[zOld];
		}
		else
		{
			xSave[zOld] = xSave[z];
			PressCounterX = 0;
		}
	}
	z++;
	return xSave[z-1];
}
unsigned int Yal(void)
{
	unsigned int ResultY;
	_LATC4 = 0;
	TRISCbits.TRISC4 = 0;													//AnalogY ��k�� yap�ld�.
	_LATC4 = 0;
//	Wait(100);																//5 ms	
	DriveA = 0;																//Y+ +5V
	DriveB = 1;																//X+ y�ksek empedans
	Wait(200);																//5 ms	
	ResultY = FilterY();
//	ResultY = MovingAverage2(AnalogY);
//	_LATC4 = 0;
	TRISCbits.TRISC4 = 1;													//AnalogY giri� yap�ld�.
//	_LATC4 = 0;
	return ResultY;	
}
unsigned int FilterY(void)
{
	unsigned int AraSonucY,h;
	static unsigned int hOld = 0;

	PressCounterY++;
	if(h > 7)h = 0;
	AraSonucY = MovingAverage2(AnalogY);
	ySave[h] = AraSonucY;
	if(h > 0)
		hOld = h - 1;
	else
		hOld = 7;
	if(ySave[h] > ySave[hOld]+10)
	{
		if(PressCounterY < 2)
		{
			ySave[hOld] = ySave[h];
		}
		else
		{
			ySave[h] = ySave[hOld];
			PressCounterY = 0;
		}
	}
	if(ySave[h] < ySave[hOld]-10)
	{
		if(PressCounterY < 2)
		{
			ySave[h] = ySave[hOld];
		}
		else
		{
			ySave[hOld] = ySave[h];
			PressCounterY = 0;
		}
	}
	h++;
	return ySave[h-1];
}


unsigned int TouchIntWait(void)
{
	unsigned int AdcEsik = 750;//1010;												//950 <- 750
	unsigned int Sonuc,Adc;

//	_LATC4 = 0;
//	_LATC3 = 0;
	TRISCbits.TRISC3=1;														//Analog Pinler Giri� yap�ld�.
	TRISCbits.TRISC4=1;														//AnalogX
//	_LATC4 = 0;
//	_LATC3 = 0;

	
	
	DriveA = 0;																//Y+  +5V
	DriveB = 1;																//X+ y�ksek empedans
	Adc = Average(16,AnalogY);//MovingAverage0(AnalogY);											//Y koordinat�n� al.
	if(Adc > AdcEsik)
	{
		if(Adc > AdcEsik)	
			Sonuc = 1;
		else
			Sonuc = 0;
	}
	else
		Sonuc = 0;
			
    if( EeKayit.Konfig.Bit.TouchScreenOffOn == 1 )
        return Sonuc;
    else
        return 0;       //Touch screen kullan?lm?yor.
}

void Mouse(unsigned int Absis,unsigned int Oordinat)
{
//	SendText(5,35,"X",2,0x000000,0xffffff);
//	OutVariable(20,35,Absis,5,0,2,0x000000,0xffffff);						//variable  g�ndermek i�in kullan�l�r.
//
//	SendText(5,50,"Y",3,0x000000,0xffffff);
//	OutVariable(20,50,Ordinat,5,0,3,0x000000,0xffffff);						//variable  g�ndermek i�in kullan�l�r.
//
//	Dikdortgen(Absis,Absis+5,Oordinat,Oordinat+5,0xff0000,1);			
//	if(PressCounterX > 2 || PressCounterY > 2)								//birinci bas��ta i�lem yapmas�n diye	
//	{
//	}
}




//A�a��daki fonksiyonlar a��rl�kla global de�i�kenler �zerinden �al��maktad�r.
void TouchMenu(int MenuSekme)
{	
	int _y,_p;
	//Son bulunulan men�y� siler.
	switch(Menu.ExAnaSekme)
	{
		case 1:
			MimikFonk(1);
		break;
		case 2:
			FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,1);
			Menu.OlcumMenuIci = 0;
		break;
		case 3:
			Menu.LogSayac = 0;
			FonkAlarmMenu(Menu.LogSayac,1);
		break;
		case 4:
			Menu.Alt1Sekme = 0;
			InfoMenu(Menu.Alt1Sekme,1);
		break;
		case 5:
			if( Menu.Sekme.All == DefTercihAltMenu )
			{
                Menu.TercihAltMenuIci = 1;
				FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
                Menu.TercihAltMenuIci = 0;
				FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
			}
			else if(Menu.Sekme.All == DefRoleAlarmAtama)	
			{
				for(_y = 0;_y < 12;_y++)
					EeWordYaz(&EeKayit.Role[_y],EeKayit.Role[_y]);
				FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,1 );
			}
			else
			{
				Menu.TercihAnaSekme = 0;
				FonkTercihAnaMenu(Menu.TercihAnaSekme,1);
			}
		break;
		case 6:
			 if( Menu.Sekme.All == DefEmirRoleMenu )
			 {
				Genel.RoleSimulasyonToggle = 0;
				FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,1);
				Menu.RoleSimulasyonu = 0;
				
				Genel.RoleSimulasyonToggle = 0;
				for( _p = 0;_p < 12;_p++ )
					RoleIslem(_p,Genel.RoleSimulasyonToggle);
				//Simulasyon kapal� iken 4sn sonra alarmlara bakmaya ba�lar.
				Menu.RoleTestSayac = 30;
			 }
			 else
			 {				 
				Menu.EmirAnaSekme = 0;
				FonkEmirAnaMenu(Menu.EmirAnaSekme,1);
			 }
		break;
		case 7:
			TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,1);
		break;
		case 8:
			FonkServisAnaMenu(Menu.ServisAnaSekme,1);
		break;
		case 9:
			ASendText(15,222+272,GenelTablo[17][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
			if( Menu.Sekme.All == DefAyarAnaMenu )
				FonkAyarAnaMenu(Menu.AyarAnaSekme,1);
			else if( Menu.Sekme.All == DefAyarAltMenu )
				FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,1);
			else if( Menu.Sekme.All == DefAyarGrupAltMenu )
				FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,1);
			else
			{
				Menu.AyarMenulerIlkGiris = 1;
				Menu.AyarPssswordIci = 0; Menu.AyarOnSekme = 0;
				//Merkezi kod �ifresi 
				if( Can.FromInv.SifreSistemi == 1 )
				{
					//User Password kullan�ld�ysa
					if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
						FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
					else
						FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
				}
				//Basit kod �ifresi 
				if( Can.FromInv.SifreSistemi == 2 )
				{
					//User Password kullan�ld�ysa
					if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
						FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
					else
						FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
				}
			}
		break;
		case DefKalibrasyon:
				CalibrationMenu(1);
		break;
		default:
		break;
	}							
												
	Menu.Sekme.All = DefAnaMenu;                                                //Onemli 24.06.2015 tarihinde eklendi
	//Yeni dokunulan men�y� yazar					
	switch(MenuSekme)
	{
		case 1:
			MimikFonk(0);
		break;
		case 2:
			Menu.OlcumAltSekme = 0;
			Menu.OlcumMenuIci = 0;
			FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
		break;
		case 3:
			Menu.LogSayac = 0;
			TFT.LogSayfaToggle = 0;
			FonkAlarmMenu(Menu.LogSayac,0);
		break;
		case 4:
			Menu.Alt1Sekme = 0;
			InfoMenu(Menu.Alt1Sekme,0);
		break;
		case 5:
			Menu.TercihAnaSekme = 0;
			FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
		break;
		case 6:
			Menu.EmirAnaSekme = 0;
			FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
		break;
		case 7:
			Menu.ZamanAyarIci = 0;
			TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
		break;
		case 8:
			Menu.ServisAnaSekme = 0;
			FonkServisAnaMenu(Menu.ServisAnaSekme,0);
		break;
		case 9:
			Menu.AyarMenulerIlkGiris = 1;		//Ana Men�deyken login se bile girmesin herhangi bir tu�a bas�nca girsin
			Menu.ServisAnaSekme = 0;
			Menu.AyarPssswordIci = 0; Menu.AyarOnSekme = 0;
			//Merkezi kod �ifresi 
			if( Can.FromInv.SifreSistemi == 1 )
			{
				//User Password kullan�ld�ysa
				if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
					FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
				else
					FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
			}
			//Basit kod �ifresi 
			if( Can.FromInv.SifreSistemi == 2 )
			{
				//User Password kullan�ld�ysa
				if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
					FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
				else
					FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
			}
		break;
		case DefKalibrasyon:
			CalibrationMenu(0);
		break;
		default:
		break;
	}

	Menu.AnaSekme = MenuSekme;
	MenuGraphic(Menu.AnaSekme);
	Menu.ExAnaSekme = Menu.AnaSekme;
}

void TouchMenuControl(void)
{
	static int _z,Ex_MenuButonBasmaSure = 0,TouchMenuOpenCounter = 0;
	
	if( TouchIntWait() == 0 )
	{
		_TouchCount = 1;
		PressCounterX = 0;PressCounterY = 0;
		//	AbsisX = 0;  //	OrdinatY = 0;
		TouchMenuOpenCounter = 0;
	}
	else
	{	
		//Herhangi bir butona bas�l�nca Backlight tam parlak olsun ve dim i�lemleri yenilensin.
		EeKayit.LcdBacklight = Menu.OldLcdBacklight;
		Menu.AcikSureGeriSayac = EeKayit.AcikSure * 10;	
		Menu.YarimAydinlikSureGeriSayac = EeKayit.YarimAydinlikSure * 10;
		//Ekran Backlight' � economic mode dan ��kart�r. Ekran ayd�nl��� artar.
		TftInitBackCounter = 0;
		Genel.TFTRESET = 400;
			
		if(_TouchCount < 5)
			GetCoordinate();
			
		if(_TouchCount == 4)
		{
            
			//Alarm varsa buton buzzeri �tmesin.
			if( Menu.MaskeAlarmSesAcik == 0 ) // if( Menu.AlarmSesAcik == 0 )
			{
				if( DefBuzzerDurum == 1 )
                {
					Buzzer = EeKayit.Konfig.Bit.ButonTik; 
                    BuzzerGeriSayac = 80;
                }
			}
            
			TouchSekmeControl();	
			if( Menu.Sekme.All == DefAnaMenu )
			{
				switch(Menu.AnaSekme)
				{
					case DefDurumMenu:
					break;
					case DefOlcumMenu:
											if( (OrdinatY > 89) && (OrdinatY < 183) )
											{
												if( (AbsisX > 55) && (AbsisX < 417) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}	
											}
					case DefAlarmMenu:
											if( (OrdinatY > 74) && (OrdinatY < 113) )
											{
												if( (AbsisX > 406) && (AbsisX < 465) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}	
												if( (AbsisX > 18) && (AbsisX < 68) )
												{
													Menu.Buton.Bit.bYukari = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}	
											}
					break;
					case DefBilgiMenu:
											if( (AbsisX > 409) && (AbsisX < 460) )
											{
												if( (OrdinatY > 80) && (OrdinatY < 115) )
												{
													Menu.Buton.Bit.bYukari = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 142) && (OrdinatY < 189) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
											}
					break;
					case DefTercihMenu:
											if( (AbsisX > 407) && (AbsisX < 454) )
											{
												if( (OrdinatY > 69) && (OrdinatY < 95) )
												{
													Menu.Buton.Bit.bYukari = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 112) && (OrdinatY < 155) )
												{
													Menu.Buton.Bit.bEnter = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 171) && (OrdinatY < 206) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
											}
					break;
					case DefEmirMenu:
											if( (AbsisX > 407) && (AbsisX < 454) )
											{
												if( (OrdinatY > 69) && (OrdinatY < 95) )
												{
													Menu.Buton.Bit.bYukari = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 112) && (OrdinatY < 155) )
												{
													Menu.Buton.Bit.bEnter = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 171) && (OrdinatY < 206) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
											}
					break;
					case DefZamanMenu:
											if( Menu.ZamanAyarIci == 1 )
											{
												if( (AbsisX > 57) && (AbsisX < 89) && (OrdinatY > 65) && (OrdinatY < 97) )
												{
													Menu.Buton.Bit.bYukari = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (AbsisX > 10) && (AbsisX < 37) && (OrdinatY > 109) && (OrdinatY < 137) )
												{
													Menu.Buton.Bit.bSol = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (AbsisX > 57) && (AbsisX < 89) && (OrdinatY > 155) && (OrdinatY < 188) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (AbsisX > 112) && (AbsisX < 142) && (OrdinatY > 109) && (OrdinatY < 137) )
												{
													Menu.Buton.Bit.bSag = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
											}	
											if( (AbsisX > 65) && (AbsisX < 87) && (OrdinatY > 114) && (OrdinatY < 136) )
											{
												Menu.Buton.Bit.bEnter = 1;
												ButonKontrol(1);
												Menu.Buton.All = 0;
											}
									
					break;
					case DefServisMenu:
											if( (AbsisX > 407) && (AbsisX < 454) )
											{
												if( (OrdinatY > 69) && (OrdinatY < 95) )
												{
													Menu.Buton.Bit.bYukari = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 112) && (OrdinatY < 155) )
												{
													Menu.Buton.Bit.bEnter = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (OrdinatY > 171) && (OrdinatY < 206) )
												{
													Menu.Buton.Bit.bAsagi = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
											}
					break;
					case DefAyarMenu:
											if( Menu.AyarPssswordIci == 1 )
											{
												if( (AbsisX > 286) && (AbsisX < 330) && (OrdinatY > 120) && (OrdinatY < 150) )
												{
													Menu.Buton.Bit.bSol = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
												if( (AbsisX > 402) && (AbsisX < 428) && (OrdinatY > 120) && (OrdinatY < 150) )
												{
													Menu.Buton.Bit.bSag = 1;
													ButonKontrol(1);
													Menu.Buton.All = 0;
												}
											}	
											if( (AbsisX > 350) && (AbsisX < 375) && (OrdinatY > 71) && (OrdinatY < 110) )
											{
												Menu.Buton.Bit.bYukari = 1;
												ButonKontrol(1);
												Menu.Buton.All = 0;
											}
											if( (AbsisX > 350) && (AbsisX < 375) && (OrdinatY > 163) && (OrdinatY < 195) )
											{
												Menu.Buton.Bit.bAsagi = 1;
												ButonKontrol(1);
												Menu.Buton.All = 0;
											}
											if( (AbsisX > 350) && (AbsisX < 375) && (OrdinatY > 120) && (OrdinatY < 150) )
											{
												Menu.Buton.Bit.bEnter = 1;
												ButonKontrol(1);
												Menu.Buton.All = 0;
											}
					break;
					case DefKalibrasyon:
											CalibrationMenu(2);
					break;
					default:
					break;
				}
			}
			else if( Menu.Sekme.All == DefOlcumAltMenu )
			{
				if( (AbsisX > 116) && (AbsisX < 163) )
				{
					if( (OrdinatY > 46) && (OrdinatY < 90) )
					{
						Menu.Buton.Bit.bYukari = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 173) && (OrdinatY < 211) )
					{
						Menu.Buton.Bit.bAsagi = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 113) && (OrdinatY < 153) )
					{
						if( Menu.OlcumAltSekme == 3 )
						{
							Menu.Buton.Bit.bSag = 1;
							ButonKontrol(1);
							Menu.Buton.All = 0;
						}
						//EnterExit
						if( Menu.OlcumAltSekme == 6 )
						{
							Menu.Buton.Bit.bEnter = 1;
							ButonKontrol(1);
							Menu.Buton.All = 0;
						}	
					}
				}
			}
			else if( (Menu.Sekme.All == DefTercihAltMenu) || (Menu.Sekme.All == DefRoleAlarmAtama) ) 
			{
				if( (AbsisX > 407) && (AbsisX < 454) )
				{
					if( (OrdinatY > 69) && (OrdinatY < 95) )
					{
						Menu.Buton.Bit.bYukari = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 112) && (OrdinatY < 155) )
					{
						Menu.Buton.Bit.bEnter = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 171) && (OrdinatY < 206) )
					{
						Menu.Buton.Bit.bAsagi = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
				}
				if( Menu.Sekme.All == DefRoleAlarmAtama )
				{
					if( (AbsisX > 366) && (AbsisX < 395) )
					{
						Menu.Buton.Bit.bSag = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}	
					if( (AbsisX > 93) && (AbsisX < 119) )
					{
						Menu.Buton.Bit.bSol = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}	
				}
			}
			else if( Menu.Sekme.All == DefRoleAlarmAtama )
			{
			}
			else if( Menu.Sekme.All == DefEmirAltMenu )
			{
			}
			else if( Menu.Sekme.All == DefEmirRoleMenu )
			{
				//4 role simulasyonu
				if( EeKayit.Konfig.Bit.Opt03Secim == 0 )
				{
					//1. , 2. , 3. roleler
					if( (AbsisX > 38) && (AbsisX < 83) )
					{
						// 30 x 2s = 60s alarma ba�l� role �ekmesin 
						if( Menu.RoleTestSayac == 0 )
							Genel.RoleSimulasyonToggle = 0;
						Menu.RoleTestSayac = 30;
						
						
						if( (OrdinatY > 67) && (OrdinatY < 97) )
						{
							Menu.RoleSimulasyonu = 1;
							Genel.RoleSimulasyonToggle ^= 1;
							FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
						}
						if( (OrdinatY > 118) && (OrdinatY < 146) )
						{
							Menu.RoleSimulasyonu = 2;
							Genel.RoleSimulasyonToggle ^= 1;
							FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
						}
						if( (OrdinatY > 173) && (OrdinatY < 205) )
						{
							Menu.RoleSimulasyonu = 3;
							Genel.RoleSimulasyonToggle ^= 1;
							FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
						}
					}
					//4.Role
					if( (AbsisX > 135) && (AbsisX < 222) && (OrdinatY > 67) && (OrdinatY < 97) )
					{
						// 30 x 2s = 60s alarma ba�l� role �ekmesin 
						if( Menu.RoleTestSayac == 0 )
							Genel.RoleSimulasyonToggle = 0;
						Menu.RoleTestSayac = 30;
						
						Menu.RoleSimulasyonu = 4;
						Genel.RoleSimulasyonToggle ^= 1;
						FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
					}
				}
				//12 role simulasyonu
				else
				{
					if( (OrdinatY > 67) && (OrdinatY < 97) )
					{
						// 30 x 2s = 60s alarma ba�l� role �ekmesin 
						if( Menu.RoleTestSayac == 0 )
							Genel.RoleSimulasyonToggle = 0;
						Menu.RoleTestSayac = 30;
						
						if( (AbsisX > 38) && (AbsisX < 83) )
							Menu.RoleSimulasyonu = 1;
						if( (AbsisX > 135) && (AbsisX < 202) )
							Menu.RoleSimulasyonu = 4;
						if( (AbsisX > 232) && (AbsisX < 276) )
							Menu.RoleSimulasyonu = 7;
						if( (AbsisX > 322) && (AbsisX < 370) )
							Menu.RoleSimulasyonu = 10;
							
						Genel.RoleSimulasyonToggle ^= 1;
						FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
						
					}
					if( (OrdinatY > 118) && (OrdinatY < 146) )
					{
						// 30 x 2s = 60s alarma ba�l� role �ekmesin 
						if( Menu.RoleTestSayac == 0 )
							Genel.RoleSimulasyonToggle = 0;
						Menu.RoleTestSayac = 30;
						
						if( (AbsisX > 38) && (AbsisX < 83) )
							Menu.RoleSimulasyonu = 2;
						if( (AbsisX > 135) && (AbsisX < 202) )
							Menu.RoleSimulasyonu = 5;
						if( (AbsisX > 232) && (AbsisX < 276) )
							Menu.RoleSimulasyonu = 8;
						if( (AbsisX > 322) && (AbsisX < 370) )
							Menu.RoleSimulasyonu = 11;
						
							
						Genel.RoleSimulasyonToggle ^= 1;
						FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
					}
					if( (OrdinatY > 173) && (OrdinatY < 205) )
					{
						// 30 x 2s = 60s alarma ba�l� role �ekmesin 
						if( Menu.RoleTestSayac == 0 )
							Genel.RoleSimulasyonToggle = 0;
						Menu.RoleTestSayac = 30;
						
						if( (AbsisX > 38) && (AbsisX < 83) )
							Menu.RoleSimulasyonu = 3;
						if( (AbsisX > 135) && (AbsisX < 202) )
							Menu.RoleSimulasyonu = 6;
						if( (AbsisX > 232) && (AbsisX < 276) )
							Menu.RoleSimulasyonu = 9;
						if( (AbsisX > 322) && (AbsisX < 370) )
							Menu.RoleSimulasyonu = 12;
							
							
						Genel.RoleSimulasyonToggle ^= 1;
						FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
					}
				}
				//EXIT
				if( (AbsisX > 410) && (AbsisX < 453) && (OrdinatY > 85) && (OrdinatY < 192) )
				{
					Genel.RoleSimulasyonToggle = 0;
					FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,1);
					Menu.RoleSimulasyonu = 0;
					FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
					
					Genel.RoleSimulasyonToggle = 0;
					for( _z = 0;_z < 12;_z++ )
						RoleIslem(_z,Genel.RoleSimulasyonToggle);
					//Simulasyon kapal� iken 4sn sonra alarmlara bakmaya ba�lar.
					Menu.RoleTestSayac = 30;
				}	
			}
			else if( Menu.Sekme.All == DefAyarAnaMenu )
			{
				if( (AbsisX > 407) && (AbsisX < 454) )
				{
					if( (OrdinatY > 69) && (OrdinatY < 95) )
					{
						Menu.Buton.Bit.bYukari = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 112) && (OrdinatY < 155) )
					{
						Menu.Buton.Bit.bEnter = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 171) && (OrdinatY < 206) )
					{
						Menu.Buton.Bit.bAsagi = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
				}
			}
			else if(( Menu.Sekme.All == DefAyarAltMenu ) || ( Menu.Sekme.All == DefAyarGrupAltMenu ) )
			{
				if( (AbsisX > 407) && (AbsisX < 454) )
				{
					if( (OrdinatY > 69) && (OrdinatY < 95) )
					{
						Menu.Buton.Bit.bYukari = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 112) && (OrdinatY < 155) )
					{
						Menu.Buton.Bit.bEnter = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
					if( (OrdinatY > 171) && (OrdinatY < 206) )
					{
						Menu.Buton.Bit.bAsagi = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
				}
				//MenuSekmelerine girmesin diye.
				if(OrdinatY > 68)
				{
					if( (AbsisX > 32) && (AbsisX < 52) )
					{
						Menu.Buton.Bit.bSol = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}	
					if( (AbsisX > 313) && (AbsisX < 331) )
					{
						Menu.Buton.Bit.bSag = 1;
						ButonKontrol(1);
						Menu.Buton.All = 0;
					}
				}
			}
//			else if( Menu.Sekme.All == DefAyarGrupAltMenu )
//			{
//			
//			}
		}	
		if(_TouchCount == 100)
		{
			if( (OrdinatY > 219) && (OrdinatY < 237) )
			{	
				TouchVoiceMuteControl();
			}
		}
		if( ++_TouchCount > 110)
		{
			_TouchCount = 110;
			
			if(( Menu.Sekme.All == DefAyarAltMenu ) || ( Menu.Sekme.All == DefAyarGrupAltMenu ) )
			{
				if( (Menu.ButonBasmaSure - Ex_MenuButonBasmaSure) > 1 )
				{
					Ex_MenuButonBasmaSure = Menu.ButonBasmaSure;
					//Herhangi bir men�de 20 saniye bas�l�rsa ekrana kalibrasyon ekran�na d�ner.
					TouchMenuOpenCounter++;
					if( TouchMenuOpenCounter > 30 )
					{
						TouchMenuOpenCounter = 0;
						
						EeKayit.TouchOfsetX = 0; EeKayit.TouchOfsetY = 0;
						EeWordYaz( &EeKayit.TouchOfsetX ,EeKayit.TouchOfsetX );
						EeWordYaz( &EeKayit.TouchOfsetY ,EeKayit.TouchOfsetY );
						TouchMenu(10);
					}
					
					
					if(OrdinatY > 68)
					{
						if( (AbsisX > 32) && (AbsisX < 52) )
						{
							Menu.Buton.Bit.bSol = 1;
							ButonKontrol( Menu.ButonArtim );
							Menu.Buton.All = 0;
						}	
						if( (AbsisX > 313) && (AbsisX < 331) )
						{
							Menu.Buton.Bit.bSag = 1;
							ButonKontrol( Menu.ButonArtim );
							Menu.Buton.All = 0;
						}
					}
				}
			}
			if( (Menu.ButonBasmaSure - Ex_MenuButonBasmaSure) > 1 )
			{
				Ex_MenuButonBasmaSure = Menu.ButonBasmaSure;
				//Herhangi bir men�de 12 saniye bas�l�rsa ekrana kalibrasyon ekran�na d�ner.
				TouchMenuOpenCounter++;
				if( TouchMenuOpenCounter > 18 )
				{
					TouchMenuOpenCounter = 0;
					
					EeKayit.TouchOfsetX = 0; EeKayit.TouchOfsetY = 0;
					EeWordYaz( &EeKayit.TouchOfsetX ,EeKayit.TouchOfsetX );
					EeWordYaz( &EeKayit.TouchOfsetY ,EeKayit.TouchOfsetY );
					TouchMenu(10);
				}
			}	
		}
		
			
	}
}
void TouchSekmeControl(void)
{
	static int _TouchMenu = 0,_OldTouchMenu = 0;
	
	
	if( (OrdinatY > 0) && (OrdinatY < 50) )
	{
		if( (AbsisX > 7) && (AbsisX < 82) )
		{
			if( GlobalSayfa == 0 )
			{
				if(Menu.AnaSekme == 1)
					_TouchMenu = 10;
				else
					_TouchMenu = 1;
			}
			else
			{
				if(Menu.AnaSekme == 6)
					_TouchMenu = 5;
				else
					_TouchMenu = 6;
			}
		}
		else if( (AbsisX > 104) && (AbsisX < 173) )
		{
			if( GlobalSayfa == 0 )
				_TouchMenu = 2;
			else
				_TouchMenu = 7;
		}
		else if( (AbsisX > 203) && (AbsisX < 268) )
		{
			if( GlobalSayfa == 0 )
				_TouchMenu = 3;
			else
				_TouchMenu = 8;
		}
		else if( (AbsisX > 299) && (AbsisX < 361) )
		{
			if( GlobalSayfa == 0 )
				_TouchMenu = 4;
			else
				_TouchMenu = 9;
		}
		else if( (AbsisX > 396) && (AbsisX < 463) )
		{
			if( GlobalSayfa == 0 )
			{
				if(Menu.AnaSekme == 5)
					_TouchMenu = 6;
				else
					_TouchMenu = 5;
			}
			else
			{
				if(Menu.AnaSekme == 10)
					_TouchMenu = 1;
				else
					_TouchMenu = 10;
			}
		}
		
		//Sadece farkl� bir men� sekmesine dokunudu�unda fonksiyon �a��r�l�p i�lem yapt�r�l�r.
		if(_OldTouchMenu != _TouchMenu)
		{
			TouchMenu(_TouchMenu);
		}
		_OldTouchMenu = _TouchMenu;
	}
}
void TouchVoiceMuteControl(void)
{
	if( (AbsisX > 430) && (AbsisX < 459) )
	{
		Menu.EnteraBasmaSayac = 0;
		Menu.MaskeAlarmSesAcik = 0;
		//Hoparl�r a��k kapal�
		ExBigVariable(430,243+(GlobalSayfa*272),4,3,14-Menu.MaskeAlarmSesAcik,0xffff00,0);			//Sembol 1
		//Ses kesildi i�areti konulabilir.
		//1500 ms sonra ekran� yenile
		Menu.YenileGeriSayac = 30;	
	}
}

void CalibrationMenu(int sil)
{
	static int Plus = 0;
	int _sil = 0;
	const int CountOfPlus = 4;
	static int Calibration_X = 0,Calibration_Y = 0;
	int _AbsisX,_OrdinatY;
	
	if(sil > 1 )
		_sil = 0;
	else
		_sil = sil;
		
	if(sil == 0 )
	{
		Plus = 0;
	}
		
	if( sil == 1 )
		Plus = CountOfPlus+1;
		
    if( EeKayit.Konfig.Bit.TouchScreenOffOn == 1 )
    {
        if(Plus == CountOfPlus)
        {
            ASendText(40,222+272,TouchTablo[1][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,_sil);

        }	
        else	
            ASendText(40,222+272,TouchTablo[0][EeKayit.Dil],1,0xffff00,NOTGRADIENTCOLOR,_sil);
	}
    else
        ASendText(40,222+272,TouchTablo[2][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,_sil);
    
	BigOutVar(225,125+272,0,TouchArti,0,0,0xffff00,1);
	BigOutVar(380,70+272,0,TouchArti,0,0,0xffff00,1);
	BigOutVar(40,85+272,0,TouchArti,0,0,0xffff00,1);
	BigOutVar(85,170+272,0,TouchArti,0,0,0xffff00,1);
	
	_AbsisX = AbsisX-EeKayit.TouchOfsetX;
	_OrdinatY = OrdinatY-EeKayit.TouchOfsetY;
	if(Plus == 0)
	{
		BigOutVar(225,125+272,0,TouchArti,0,0,0xffff00,_sil);
		Calibration_X = 0;Calibration_Y = 0;
	}	
	if(Plus == 1)
	{
		Calibration_X = 238-_AbsisX-EeKayit.TouchOfsetX;
		Calibration_Y = 131-_OrdinatY-EeKayit.TouchOfsetY;
		BigOutVar(380,70+272,0,TouchArti,0,0,0xffff00,_sil);
	}	
	if(Plus == 2)
	{
		Calibration_X = Calibration_X + (395-_AbsisX);
		Calibration_Y = Calibration_Y + (81-_OrdinatY);
		BigOutVar(40,85+272,0,TouchArti,0,0,0xffff00,_sil);
	}	
	if(Plus == 3)
	{
		Calibration_X = Calibration_X + (53-_AbsisX);
		Calibration_Y = Calibration_Y + (93-_OrdinatY);
		BigOutVar(85,170+272,0,TouchArti,0,0,0xffff00,_sil);
	}	
	//istenirse plus say�s� artt�rl�p ortalama al�nd���nda daha do�ru sonu� al�nabilir.
	if(Plus == CountOfPlus)
	{
		Calibration_X = Calibration_X + (94-_AbsisX);
		Calibration_Y = Calibration_Y + (175-_OrdinatY);
		
		
		EeKayit.TouchOfsetX = Calibration_X / CountOfPlus;
		EeKayit.TouchOfsetY = Calibration_Y / CountOfPlus;
		
		EeWordYaz( &EeKayit.TouchOfsetX ,EeKayit.TouchOfsetX );
		EeWordYaz( &EeKayit.TouchOfsetY ,EeKayit.TouchOfsetY );
	}
		
	if( sil == 2 )
		Plus++;
	if(Plus > CountOfPlus )
		Plus = 0;
}