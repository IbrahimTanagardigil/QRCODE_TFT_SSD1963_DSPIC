
#ifndef __TFTVAR_H__
#define __TFTVAR_H__

//Genel De�i�kenler
//------------------
extern volatile unsigned int LogSayisiToInv;
extern volatile unsigned int Basla[10];
extern volatile unsigned int GlobalSayfa;
extern volatile unsigned int *RamAdres;					//�lk a��l��ta eepromdaki verileri ram e aktarmak i�in kullan�lacak.



//Timer De�i�kenleri
//------------------
//Timer 6 Bit i�lemleri
typedef struct T
{
	unsigned Sn0_05		:1;	
	unsigned Sn0_05__1	:1;	
	unsigned Sn0_05__2	:1;			
	unsigned Sn0_1		:1;	
	unsigned Sn0_25		:1;	
	unsigned Sn0_35		:1;					
	unsigned Sn0_5		:1;					
	unsigned Sn0_5__2	:1;	
	unsigned Sn0_65		:1;							
	unsigned Sn1		:1;	
	unsigned Sn1__2		:1;
	unsigned Sn1__3		:1;
	unsigned Sn1__4		:1;
	unsigned Sn1_25		:1;	
	unsigned Sn1_5		:1;			
	unsigned Sn2		:1;			
	unsigned Sn2_5		:1;			
	unsigned Sn3		:1;		
	unsigned Dk15		:1;	
};
typedef union AA
{
	unsigned int All;
	volatile struct T Bit;		
};
extern volatile union AA Timer;

//Timer 6 int de�i�kenler
typedef struct Time
{
	unsigned int Ms50;
	unsigned int Ms50_0;					//BuzzerKontrol i�in
	unsigned int Ms50_1;					//Timer i�in
	unsigned int Ms50_2;
	unsigned int Ms50_3;
	unsigned int Ms50_4;
	unsigned int Ms50_5;
	unsigned int Ms50_6;
	unsigned int Ms50_7;
	unsigned int Ms50_8;
	unsigned int Ms50_9;
	unsigned int Ms50_10;
	unsigned int BuzzerOnSayac;				//50 ms lik Buzzer on sayac
	unsigned int BuzzerOffSayac;			//50 ms lik Buzzer off sayac

	unsigned int ShutdownTime;				//Uart tan gelen emirler i�in zamanlamalar
	unsigned int RestoreTime;				//Uart tan gelen emirler i�in zamanlamalar
	unsigned int DummyTime;					//Uart tan gelen emirler i�in zamanlamalar
	
	unsigned int Ilk_15sn_Sayac;			//�lk a��l��tan 15 dk i�erisinde belli alarmlar� belli �ekilde g�stermeye yarar.
};
extern volatile struct Time Timer6;

//Menu De�i�kenleri
//------------------
//Tercih men�s�
extern volatile unsigned int TftVersiyon;			//Sabit de�erlerdir.Ba�lang��ta y�klenir.
extern volatile unsigned int RoleAtama[66];         //Genel alarm i�in 66 yap?ld? buffer ve 70 eklendi.
//Analog olarak kullan�lacak kanallar�n listesi
extern volatile unsigned int AnalogKanallar[10];	
extern volatile unsigned int AnalogKanalSayisi;
//Ayar men�s�
extern volatile unsigned char SifreAnahtari[128];
//S�n�r de�erler
extern volatile unsigned int MinMax[120][3];
//Buton kontrol�
typedef	struct Opcon11			
{
	unsigned bYukari		:1;				//1
	unsigned bAsagi			:1;				//2
	unsigned bEnter			:1;				//4
	unsigned bSag			:1;				//8
	unsigned bSol			:1;				//16
};
typedef union Opcon10						
{
	unsigned int All;
	volatile struct Opcon11 Bit;
}; 
//Sekme kontrol�
typedef	struct Opcon8
{
	unsigned Ana			:1;				//1
	unsigned Alt1			:1;				//2
	unsigned Olcum			:1;				//4
	unsigned AdjAna			:1;				//8
	unsigned AdjAlt			:1;				//16
	unsigned AdjGrupAlt		:1;				//32
	unsigned TercihAlt		:1;				//64
	unsigned AraSifre		:1;				//128
	unsigned EmirAlt		:1;				//256
	unsigned EmirRole		:1;				//512 
	unsigned RoleAlarmAtama :1;				//1024
};
typedef union Opcon7						
{
	unsigned int All;
	volatile struct Opcon8 Bit;
}; 
//Ana Kontrol
//------------
//Bu structure Genel men� ve Can men� de�i�kenlerinden �a�r�l�r.
typedef	struct Opcon18
{
	unsigned int L1;
	unsigned int L2;
	unsigned int L3;
	
	unsigned int L1L3;
	unsigned int L2L1;
	unsigned int L3L2;
};

typedef struct Opcon6				
{
	//Genel Men� De�i�kenleri
	unsigned int aDummy;					//Dummy de�er
	int ExAnaSekme;							//Ana men�n�n neresi
	int AnaSekme;							//Ana men�n�n neresi
	int Alt1Sekme;							//Bir Alt men�n�n neresi
	int AyarOnSekme;
	int AyarAnaSekme;						//Ayar men�s� se�melerinde kullan�l�r.
	int AyarAltSekme;						//Ayar alt men�s� i�lemlerinde kullan�l�r.
	int AyarGrupAltSekme;					//Ayar alt mens�ndeki Grup parametrelerin alt men�s�nde kullan�l�r.
	int OlcumAltSekme;						//�l��mlerin g�sterildi�i men�de kullan�l�r.
	int TercihAltSekme;						//Tercihlerin g�sterildi�i alt men�de kullan�l�r.
	int TercihAnaSekme;						//Tercihlerin g�sterildi�i ana men�de kullan�l�r.
	int EmirAnaSekme;						//Emirlerin g�sterildi�i ana men�de kullan�l�r.
	int EmirAltSekme;						//Emirlerin g�sterildi�i alt men�de kullan�l�r.
	int EmirAltMenuIci;						//Emirlerin g�sterildi�i popup men�de kullan�l�r.
	int ServisAnaSekme;						//Servis ana men�
	unsigned int Koordinat;					//Anasekme ve Alt1sekme birle�imi
	unsigned int AyarKoordinat;				//Ayar Men�s�nde AyarAltSekme ve AyarAnaSekme birle�mesi
	unsigned int TercihKoordinat;			//Tercih Men�s�nde TercihAltSekme ve TercihAnaSekme birle�mesi
//int OlcumSekme;							//�ki Alt men�n�n neresi.
	volatile union Opcon7 Sekme;						//Hangi men�de oldu�unu g�sterir.
	volatile union Opcon10 Buton;					//Hangi butona bas�ld���n� g�sterir.
	unsigned ButonBayrak	:1;				//Butona bas�ld���nda bayrak kalkar.
	unsigned int ButonBasmaSure;			//Butona bas�l� tutma s�resini tutar.Bu da ButonArt�m miktar�n� belirler ve butona bas�l� tutma s�resini tutar. Butona bas�l�ysa 350 ms de bir artar.
	unsigned int EnteraBasmaSayac;			//Status men�de enter a 3 saniye bas�nca yap�lacak i�lemler var onlar i�in
	unsigned int ButonArtim;				//Butona bas�l� tutunca de�erlerdeki art�m.
	int BuzzerGeriSayac;					//Buton buzeri i�in geri saya�
	unsigned EnterExit		:1;				//Enter exit men�s�ne gelice 1 olur.
	int AltLimit;
	int UstLimit;	
	int GrupAltLimit;
	int GrupUstLimit;	
	unsigned Yenile			:1;				//Men� yenilemek i�in logic 1 yap�l�r.
	unsigned int YenileGeriSayac;			//Belli bir s�re sonra yenile i�lemi yapmas� i�in
	unsigned int Satir4GosterIzin;			//�lk 5 sn alarm g�sterme ve log kay�t i�lemleri yap�lmas�n diye saya�
//unsigned Login			:1;				//�ifre Uart,Can,Lcd �zerinden do�ru girildi�inde 1logic 1 olur.
	unsigned int BastanOnDkLikSayac;		//�lk a��l��tan ba�layarak 10 dk bir artar kaydedilmez. Denemeler i�in kullan�l�r.
	//�l��m Men� De�i�kenleri
	unsigned int Olcum[20];					//Lcd De�i�kenleri i�in diziler
	unsigned int AkuKalanSure;				//Benim Hesaplad���m Ak� kalan s�resi
	//AlarmMen�s� De�i�kenleri
	unsigned int Alr[7];					//Lcd De�i�kenleri i�in diziler
	int LogSayac;							//Butonla Artt�r�lan log de�eri
	int IslemSonucuLog;						//��lemler sonucu Okunacak Log Ba�lang�� adresi.
	unsigned int Log_AlarmGoster;			//Anl�k alarmlar�,Log Alarmlar�n�,ya da hi� biri i�in de�erler al�r.
	//Information Men� De�i�kenleri			
	unsigned int Info[15];					//Lcd De�i�kenleri i�in diziler
	//Tercihler Men� De�i�kenleri			//Men� elemanlar�n�n bir �o�u kay�t edildi�i i�in EeKayit structure n�n alt�ntad�r.
	unsigned int Tercih[15];				//Lcd De�i�ikenleri i�in diziler
	unsigned AcikSureAktif		    	:1;	//Backlight bekleme s�resi a��k ise logic 1 yap�l�r.
	unsigned YarimAydinlikSureAktif 	:1;	//Backlight karartma s�resi a��k ise logic 1 yap�l�r.
	unsigned int AcikSureGeriSayac;			//EeKayit.AcikSure nin geri sayac olarak kullan�lan�.
	unsigned int EskiAcikSureGeriSayac;		//EeKayit.AcikSure nin geri sayac olarak kullan�lan�.
	unsigned int YarimAydinlikSureGeriSayac;//EeKayit.YarimAydinlikSure nin geri sayac olarak kullan�lan�.
	unsigned int EskiYarimAydinlikSureGeriSayac;//EeKayit.YarimAydinlikSure nin geri sayac olarak kullan�lan�.
	unsigned int OldLcdBacklight;			//Ayarlanan Backlight �n bir �nceki de�erini g�stermek i�in
	unsigned int RoleSinir;					//�zel r�le atamalar�nda kullan�lmak i�in
	int RoleAtamaDeger[12];					//R�le atamalar�nda kullan�lmak i�in
	int OldRoleAtamaDeger[12];				//R�le atamalar�nda kullan�lmak i�in
	//Emirler Menu De�i�kenleri
	unsigned int Emir[15];					//Lcd De�i�kenleri i�in diziler
	unsigned int EnterBypOrInv;	//Inverter e ge� (Logic 1) ya da Bypass a ge� (Logic 0) emri.
	unsigned int EnterStopBoost; //Boost yap (Logic 1) , Boost u durdur (Logic 0) Uart lardan BST komutunda da i�lem yap�l�r.
	unsigned int EnterBattTest; //Ak� test yap (Logic 1) , Stop ak� test (Logic 0)
	unsigned int AlarmSesAcik; //Logic 1 ise A��k Logic 0 ise kapal� (Yeni alarm gelinceye kadar susturmaya yarar.)
	unsigned int ModemInitEt; //Modemi init etmek i�in 1 yap�l�r.
	unsigned int MaskeAlarmSesAcik;
	unsigned int EskiAlarmSesAcik;
	unsigned RoleCekBirak				:1;	//R�le simulasyonu s�ras�nda enter a bas�l�nca �nceden atanan r�leyi �ekip b�rak�r.
	int RoleSimulasyonu;					//R�le simulasyonu i�in kullan�lan de�i�ken
	int GolgeRoleSimulasyonu;				//R�le simulasyonu i�in kullan�lan de�i�imi alg�lamak i�in kullan�l�r.
	unsigned int AkuTestKalanSure;			//Tahminim d��ar�dan gelecek Bir sonraki ak� test e ne kadar dakika kald���n� bana g�nderir.
	//Time Men� De�i�kenleri
	unsigned int Zaman[10];					//Lcd De�i�kenleri i�in diziler
	unsigned ZamanUpdate				:1;	//Zaman men�s�nde logic 1 yap�nca zaman� RTC ye kaydederi g�sterir.
	//Servis Men� De�i�kenleri
	unsigned int Servis[4];					//Lcd De�i�kenleri i�in diziler
	volatile struct Opcon18 MaxYuk;
unsigned MaxYukReset					:1;	//Max y�k izlerken belli s�re Enter a bas�nca Logic 1 olur ve de�erleri s�f�rlar.
	unsigned EnterFaultReset			:1;	//Can �zerinden FaultReset g�nderir (Logic 1 olunca)
	unsigned int FanBakimAktif;				//Bak�mlar s�releri 0 ise pasif oldu�unu g�stermek (CANCEL) �PTAL yazmak i�in , 1 de normal zaman , 2 de ise - de�er yazmak i�in
	unsigned int AkuBakimAktif;				//Bak�mlar s�releri 0 ise pasif oldu�unu g�stermek (CANCEL) �PTAL yazmak i�in , 1 de normal zaman , 2 de ise - de�er yazmak i�in
	unsigned int GenelBakimAktif;			//Bak�mlar s�releri 0 ise pasif oldu�unu g�stermek (CANCEL) �PTAL yazmak i�in , 1 de normal zaman , 2 de ise - de�er yazmak i�in
	unsigned int YedekBakimAktif;			//Bak�mlar s�releri 0 ise pasif oldu�unu g�stermek (CANCEL) �PTAL yazmak i�in , 1 de normal zaman , 2 de ise - de�er yazmak i�in
	unsigned LogOutAktif				:1;	//Logout Durumundaysa logic 1 olur ve ekranda OK g�r�n�r.
	//Ayar Men�s� �n� (�ifre)
	unsigned int Ayar[10];					//Lcd De�i�kenleri i�in diziler
	unsigned int SifreToplam;				//�ifre ��zme i�lemleri
	unsigned int ServisKodH;				//Code Generator sonucundaki de�er.
	unsigned int ServisKodL;				//Code Generator sonucundaki de�er.
	unsigned int SifreH;					//��frenin ilk d�rt hanesi
	unsigned int SifreL;					//��frenin son d�rt hanesi
	int Sifre[8];							//��frelerin hanelerini tutar.
	int GolgeSifre[8];						//��frelerin hanelerini men�de de�i�tirdi�imiz dizi.
	int UserGolgeSifre[8];					//��frelerin hanelerini men�de de�i�tirdi�imiz dizi.
	int HaneDegistir;						//�ifre girerken hanelerin aras�nda de�i�iklik yapmak i�in kullan�l�r.
	unsigned int SifreSayac;				//Blink i�leminin 0.5 sn de bir olmas� i�in kullan�l�r.
	unsigned SifreToggle				:1;	//Password hanelerinin yan�p s�nmesini sa�lar.
	unsigned SifreDogru					:1;	//�ifre do�ruysa Logic 1 olur.
	unsigned int SifreDurum;				//Ekranda g�sterilecekler bununla g�sterilir.
	//Ayar Alt Men�s�
	unsigned int AyarAlt[20];				//Lcd De�i�kenleri i�in diziler
	unsigned int AyarAyar;					//Ayar Alt men�s�nde Ayarlanan de�eri 2.Sat�rda g�sterir.
	unsigned int AyarSonuc;					//Ayar Alt men�s�nde Sonucu 3. sat�rda g�sterir. Can �zerinden gelen buna e�itlenecek.
	unsigned int AyarEskiSonuc;				//Ayar Alt men�s�nde Sonucunun eski hali  Can �zerinden gelen buna e�itlenecek.
	int AyarEtiket;							//Ayar Alt men�s�nde Etiketler aras�nda dola�may� sa�lar.
	int AyarGrupEtiket;						//Ayar Alt men�s�nde Etiketler aras�nda dola�may� sa�lar.
	int AyarUstLimit;
	int AyarAltLimit;
	int AyarAnaUstLimit;
	int AyarAnaAltLimit;
	int AyarAlt_1_UstLimit;
	int AyarAlt_1_AltLimit;
	int AyarAlt_2_UstLimit;
	int AyarAlt_2_AltLimit;
	int AyarGrupUstLimit;
	int AyarGrupAltLimit;
	int AyarPssswordIci;
	int AyarAnaMenuSayfa;
	int AyarMenulerIlkGiris;
	int TimeUpdate;
//	int AyarAnaMenuIci;
	int OlcumAltLimit;
	int OlcumAra1Limit;
	int OlcumAra2Limit;
	int OlcumUstLimit;
	int OlcumMenuIci;
	int TercihAltLimit;
	int TercihAra1Limit;
	int TercihAra2Limit;
	int TercihUstLimit;
	int TercihAltAltLimit;
	int TercihAltUstLimit;
	int TercihAltMenuIci;
	int TercihPopUpAltLimit;
	int TercihPopUpUstLimit;
	int EmirAltAltLimit;
	int EmirAltUstLimit;
	int EmirAltLimit;
	int EmirUstLimit;
	int EmirPopUpIci;						//Popup i�i
	int EmirPopUpAltLimit;
	int EmirPopUpUstLimit;
	int ServisAltLimit;
	int ServisUstLimit;
	int RoleAlrAltLimit;
	int RoleAlrUstLimit;
	int AlrRoleAltLimit;
	int AlrRoleUstLimit;
	int RoleAlrSec;
	int RoleAlrRoleSec;
	int RoleAlr;
	unsigned ZamanAyarIci				:1;	//Zaman ayar i�in enter a bas�l�nca logic 1 olur.
	unsigned BitIslemDatasiGeldi		:1;	//Ayar alt men�s� Panel ayarlamalar�nda yazma i�leminden sonra kullan�lan bir bit
	//Mimik i�lemleri
	unsigned MimikToggle				:1;	//Mimik ledlerinin tan�p s�nmesi i�in
	unsigned int MimikSayac;				//�lk a��l��ta ve mimik test te kullan�lacak
	
	//In pinlerinin de�i�kenleri
	unsigned int GenInSayac;				//Jenerator modu i�in kullan�lan debounce geri sayac�
	unsigned int EmcStopSayac;				//Emc stop i�in kullan�lan debounce geri sayac�
	unsigned int BattSwSayac;				//Batt sw i�in kullan�lan debounce geri sayac�
	unsigned int In2OptSayac;				//In4 Opt i�in kullan�lan debounce geri sayac�
	unsigned int In3OptSayac;				//In3 Opt i�in kullan�lan debounce geri sayac�
	
	//R�le testi yap�l�rken Alarma ba�l� r�le �ekmesin
	unsigned int RoleTestSayac;
	
	//Emirler men�s�
	unsigned BypInvEmriGonderiliyor		:1;	//Emirlerin g�nderildi�ine dair ekranda yaz� yazacak
	unsigned BoostEmriGonderiliyor		:1;	//Emirlerin g�nderildi�ine dair ekranda yaz� yazacak
	unsigned AkuTestEmriGonderiliyor	:1;	//Emirlerin g�nderildi�ine dair ekranda yaz� yazacak
		
	unsigned int RecDcBusEski;				//Emirler men�s�nde 1. sayfada ak� testinin yan�ndaki RecDcBus de�eri yenilenme durumu i�in
	
	unsigned int EnSonKalinanMenuAna;		//AraSifreMenuFonk() kullan�l�rken geri d�nmek istenilen en son yere d�ner.
	unsigned int EnSonKalinanMenuAlt;		//AraSifreMenuFonk() kullan�l�rken geri d�nmek istenilen en son yere d�ner.
	unsigned int EnSonKalinanSekme;			//AraSifreMenuFonk() kullan�l�rken geri d�nmek istenilen en son yere d�ner.
	
};
extern volatile struct Opcon6 Menu;
extern volatile unsigned int Protokol[10];
extern volatile unsigned int UartProtokol[10];
	
//Time men�
typedef struct DATE
{
	int Sec;
	int Min;
	int Hour;
	int Day;
	int Month;
	int Year;
};
extern volatile struct DATE Date;
extern volatile struct DATE Date4;
extern volatile struct DATE Date5;
extern volatile struct DATE Date6;
//Uart De�i�kenleri
//------------------
typedef struct Comm			
{
	unsigned Flag			:1;
	
	unsigned int LokalSayac;
	unsigned int GlobalSayac;
	
	unsigned int DataBuf[20];
	unsigned int ClrBuf[20];
	unsigned int GonderBuf[40];
	unsigned int AraIslemDeger[8];				//Uart Tan gelen datalarla i�lem yapmada kullan�l�r.
	unsigned int TekrarBuff[8];					//Can den data beklenirken bir daha uart sorusunu bu buffer da tutar ve tekrar sormaya yarar.
	unsigned int Tekrar;						//Can den data beklenirken bir daha uart sorusunu buffer da tutar ve tekrar bu de�i�kenle belirlenen zaman sonra sormaya yarar.
	
	unsigned int *R_Adres;
	unsigned int R_Deger;
	unsigned int Dumm[2];
	
	unsigned int ErrSayac;						//Uart taki error durumlar�na bakar.
	unsigned int AktifSayac;					//Uartlar�n aktif olup olmad�klar�na bakar.
	unsigned Aktif			:1;					//Uart aktif se lojik 1 olur.
	unsigned EskiAktif		:1;					//De�i�imi alg�lamak i�in bir �nceki durumu da tutar.
	
	//Kod ve Password i�lemleri i�in
	unsigned int KodIslemiGeriSayac;			//Kod i�lemi arka arkaya yap�lmas�n diye
	unsigned int PassWordHataliGeriSayac;		//Password hatal� girildi�inde arka arkaya s�k bir �ekilde geri sayamas�n diye 30 snlik geri sayac
	unsigned KodIslemiYapildi	:1;				//Kod isteme i�lemi yap�ld� password i�lemi bekleniyor
	
	unsigned int BaudRateKontrolSayac;			//Baud Rate denemeleri esnas�nda LokalSayac � s�f�rlamak i�in kullan�l�yor.
	unsigned int RamLimitli_mi;					//Ram e ve eeprom a yaz�lan de�er limitli ise cevap limited kontrol�nde kullan�l�yor.
	
	
	//�uan i�in bir yere yerle�tirilemeyen de�i�kenler
	unsigned int BypPhaseBalance;
	unsigned int BypInvSyncDiff;
	unsigned int EstBattBackUpTime;
	unsigned int NumOfPhaseIn;
	unsigned int NumOfPhaseOut;
	unsigned int NumOfBatt;
	unsigned int DeviceType;
	unsigned int OptionMode;
	unsigned int BypassConfig;
	unsigned int BattConfig;
	
	//Zaman cevab� olarak	
	volatile struct DATE Date_3;
	//Yeni eklendi Uart check sum � i�in
	unsigned int CheckSum;						//De�erlerin topland��� de�i�kendir.
	unsigned ChkSorgusuGeldi			:1;		//CHK sorusunun cevab�nda de�er kendinle toplanarak 2 kat�na ��kmas�n diye kullan�l�yor.
	unsigned int SonSorulanEmir;				//CHK sorusunun cevab�nda de�erlerin toplanmamas� gereken yerlede kullan�l�r. 'R' veya 'W' i�lemlerini tutacak
	unsigned int TekrarGondermeSayacInv;		//Uart haberle�mesinde tekrar g�nderme i�leminin sayac�;
	unsigned int TekrarGondermeSayacPfc;		//Uart haberle�mesinde tekrar g�nderme i�leminin sayac�;
	unsigned EmirGonderildi				:1;		//Uart tan emir g�nderme i�leminin yap�ld���n� onun i�in panelden periyodik okuma i�leminin �telenmesini sa�lar.
	unsigned W_B						:1;		//E�er uart tan gelen W yazma i�lemi yerine B gelirse yap�lan i�lemler i�in kullan�lan bittir.
};
extern volatile struct Comm Uart1;
extern volatile struct Comm Uart2;
extern volatile unsigned int U1TxDmaBuf[128]	 __attribute__((space(dma)));
extern volatile unsigned int U2TxDmaBuf[128]	 __attribute__((space(dma)));



//Megatek Protokol�								//2400 Baud Rate

struct Command1
{
	unsigned int BattVoltg;						//Battery Voltage 								SSS		000		-	999
	unsigned int BattCapPer;					//Battery Capacity Percentage					PPP		000		-	100
	unsigned int BattTimeRem;					//Battery Time Remaining						NNNN	0000	-	9999
	unsigned int BattCurrChrgDChrg;				//Battery Current Charge and Discharge mode		RRR.R	000.0	-	999.9	Depends on Megatech.G2.a2
	int Temperature;							//Temperature									+TT.T	-99.9	-	+99.9
	unsigned int IPFreq;						//I / P Frequency								FF.F	00.0	-	99.9
	unsigned int FreqOfBypSource;				//Frequency of Bypass Source					EE.E	00.0	-	99.9
	unsigned int OPFreq;						//O / P Frequency 								QQ.Q	00.0	-	99.9
};
struct Command2									//Logic 0						Logic 1
{												//--------					-	--------------
	unsigned a7 	:1;							//Not used
	unsigned a6 	:1;							//Normal					-	Rectifier Rotation Error
	unsigned a5 	:1;			 				//Normal					-	Low Battery Shutdown
	unsigned a4 	:1;			 				//Normal					-	Low Battery
	unsigned a3 	:1;			 				//Three in/out				-	Three in/out
	unsigned a2 	:1;			 				//AC Normal					-	Back Up		
	unsigned a1 	:1;						 	//Float Charge				-	Boost Charge
	unsigned a0 	:1;						 	//Rectifier Stop			-	Rectifier Operating

	unsigned b7 	:1;					 		//Not used
	unsigned b6 	:1;					 		//Not used
	unsigned b5 	:1;					 		//Not used
	unsigned b4 	:1;					 		//Bypass Freq OK			-	Bypass Freq Fail
	unsigned b3 	:1;					 		//Manual Byp.Breaker Open	-	Manual Byp.Breaker On
	unsigned b2 	:1;					 		//Bypass AC Abnormal		-	Bypass AC Normal
	unsigned b1 	:1;					 		//Static switch in byp. mode-	Static Switch in Inverter mode
	unsigned b0 	:1;					 		//The fault condition of Inv-	Inverter Operation
	
	unsigned c7 	:1;					 		//Not Used
	unsigned c6 	:1;					 		//Normal					-	Emergency Stop (EPO)
	unsigned c5 	:1;					 		//Normal					-	High DC Shutdown
	unsigned c4 	:1;					 		//Normal					-	Manual Bypass Breaker on Shutdown
	unsigned c3 	:1;					 		//Normal					-	Over load shutdown
	unsigned c2 	:1;					 		//Normal					-	Inverter O/P Fail shutdown
	unsigned c1 	:1;					 		//Normal					-	Over Temperature shutdown
	unsigned c0 	:1;					 		//Normal					-	Short Circuit Shutdown
};
struct Command3
{
	unsigned int IPVoltageR;				 	//I/P voltage of R Phase						NNN.N	000.0	-	999.9
	unsigned int IPVoltageS;				 	//I/P voltage of S Phase						NNN.N	000.0	-	999.9
	unsigned int IPVoltageT;				 	//I/P voltage of T Phase						NNN.N	000.0	-	999.9
	
	unsigned int BypVoltageR;				 	//Byp voltage of R Phase						NNN.N	000.0	-	999.9
	unsigned int BypVoltageS;				 	//Byp voltage of S Phase						NNN.N	000.0	-	999.9
	unsigned int BypVoltageT;				 	//Byp voltage of T Phase						NNN.N	000.0	-	999.9

	unsigned int OPVoltageR;				 	//O/P voltage of R Phase						NNN.N	000.0	-	999.9
	unsigned int OPVoltageS;				 	//O/P voltage of S Phase						NNN.N	000.0	-	999.9
	unsigned int OPVoltageT;				 	//O/P voltage of T Phase						NNN.N	000.0	-	999.9

	unsigned int LoadPercentageR;			 	//Load Percentage of R Phase					NNN.N	000.0	-	999.9
	unsigned int LoadPercentageS;			 	//Load Percentage of S Phase					NNN.N	000.0	-	999.9
	unsigned int LoadPercentageT;			 	//Load Percentage of T Phase					NNN.N	000.0	-	999.9
};
struct Command4
{
	unsigned int RecVoltPToN;				 	//Rectifier Voltage of Ph To N					220
	unsigned int RecVoltPToP;				 	//Rectifier Voltage of Ph To Ph					380
	unsigned int RecFreq;					 	//Rectifier Frequency							CCC	- 050
	unsigned int BypVoltPToN;				 	//Bypass Source Voltage of Ph To N				220
	unsigned int BypVoltPToP;				 	//Bypass Source Voltage of Ph To Ph				380
	unsigned int BypFreq;					 	//Bypass Source Frequency						FFF	- 050
	unsigned int OPVoltPToN;				 	//O/P Voltage of Ph To N						220
	unsigned int OPVoltPToP;				 	//O/P Voltage of Ph To Ph						380
	unsigned int OPFreq;					 	//O/P Frequency									QQQ
	unsigned int BattVoltage;				 	//Battery Voltage								SSS
	unsigned int PowerRate;					 	//Power Rating									xxxxxxxxxx (10 characters)
};
struct Command5
{
	unsigned TestForTenSec		:1;			 	//Test for 10 seconds and return to main power
};
struct Command6
{
	unsigned TestUntilBattLow	:1;				 //Test until battery low and return to main power
};
struct Command7
{
	unsigned TestForTime		:1;				 //Test for specified time period (Minutes)T<n><13>
};
struct Command8
{
	unsigned TurnBeep			:1;			 	//Toggle the UPS beeper
};
struct Command9
{
	unsigned ShutDown			:1;				 //Shut UPS output off in <n> minutes
};								   			 	 //<n> .2,.3,...,01,02,.... up to 10	
struct Command10
{
	unsigned ShutDownRestore	:1;				 //Shut UPS Output off in <n> minutes and wait <m> minutes and turn on UPS output again 	S<n>R<m><13>
};								   			 	 //<n> .2,.3,...,01,02,.... up to 10 and <m> 0001 to 9999
struct Command11
{
	unsigned Cancel				:1;				 //Cancel the S<n><cr> and S<n><m><13>
};
struct Command12
{
	unsigned CancelAllTest		:1;			 	 //Cancel all test activities and connect to main power to output immediately
};
extern volatile struct Protokol Megatech;
typedef struct Protokol
{
	volatile struct Command1 G1;
	volatile struct Command2 G2;
	volatile struct Command3 G3;
	volatile struct Command4 GF;
	volatile struct Command5 T;
	volatile struct Command6 TL;
	volatile struct Command7 Tnr;
	volatile struct Command8 Q;
	volatile struct Command9 Snr;
	volatile struct Command10 Snm;
	volatile struct Command11 C;
	volatile struct Command12 CT;
};

//Alarm De�i�kenleri
//------------------

//Inv Alarmlar�
typedef struct AlarmInv
{
	unsigned AsiriAkim		:1;		//0.bit
	unsigned AsiriIsiKes	:1;		//1.bit
	unsigned AkuYuksek		:1;		//2.bit
	unsigned CikisDusuk		:1;		//3.bit
	unsigned CikisYuksek	:1;		//4.bit
	unsigned AsiriYukKes	:1;		//5.bit
	unsigned KisaDevre		:1;		//6.bit
	unsigned Bakimda		:1;		//7.bit
	unsigned ElleBypass		:1;		//8.bit
	unsigned AkuZayifKes	:1;		//9.bit
	unsigned AcilKapatma	:1;		//10.bit
	unsigned DcDengeKotu	:1;		//11.bit
	unsigned TepeVoltYuksek	:1;		//12.bit
	unsigned InvBaslayamadi	:1;		//13.bit
	unsigned OncekiHata		:1;		//14.bit
	unsigned InvFaultKod	:1;		//15.bit
};	
typedef union A
{
	unsigned int All;
	volatile struct AlarmInv Bit;
};

//Inv Uyar�lar�
typedef struct UyariInv
{
	unsigned BypassKesik	:1;		//0.bit
	unsigned BypassVolt		:1;		//1.bit
	unsigned BypassFrekans	:1;		//2.bit
	unsigned AsiriYuk		:1;		//3.bit
	unsigned AsiriIsi		:1;		//4.bit
	unsigned CikisKesik		:1;		//5.bit
	unsigned CikisBypassta	:1;		//6.bit
	unsigned TersAkim		:1;		//7.bit
	unsigned InvReset		:1;		//8.bit
	unsigned AkuZayif		:1;		//9.bit
	unsigned JeneratorModu	:1;		//10.bit
	unsigned FazKaybi		:1;		//11.bit
	unsigned SenkronYok		:1;		//12.bit
	unsigned KisaDevre		:1;		//13.bit			//Ayn�s�ndan AlarmInv de de mevcut
	unsigned CikisSalteri	:1;		//14.bit
	unsigned ServisLogin	:1;		//15.bit
};	
typedef union B
{
	unsigned int All;
	volatile struct UyariInv Bit;
};

//Pfc Alarmlar�
typedef struct AlarmPfc
{
	unsigned AcGirisYuksek	:1;		//0.bit		
	unsigned SebekeKesik	:1;		//1.bit
	unsigned DcYuksek		:1;		//2.bit
	unsigned DcBusDusuk		:1;		//3.bit
	unsigned FrekansTol		:1;		//4.bit
	unsigned AsiriIsi		:1;		//5.bit
	unsigned BlackOut		:1;		//6.bit
	unsigned IGBTHatasi		:1;		//7.bit
	unsigned FazCevir		:1;		//8.bit
	unsigned Nu9			:1;		//9.bit
	unsigned Nu10			:1;		//10.bit
	unsigned Nu11			:1;		//11.bit
	unsigned Nu12			:1;		//12.bit
	unsigned PfcManualStop	:1;		//13.bit
	unsigned DcDusuk		:1;		//14.bit
	unsigned PfcFaultKod	:1;		//15.bit
};	
typedef union C
{
	unsigned int All;
	volatile struct AlarmPfc Bit;
};

//Pfc Uyar�lar�
typedef struct UyariPfc
{
	unsigned AkuTesti		:1;		//0.bit
	unsigned BoostSarj		:1;		//1.bit
	unsigned AcHigh			:1;		//2.bit
	unsigned GirisKontaktorAcik	:1;	//3.bit
	unsigned PfcDurakladi	:1;		//4.bit
	unsigned PozSarjLimit	:1;		//5.bit
	unsigned NegSarjLimit	:1;		//6.bit
	unsigned DcBaraBekleme	:1;		//7.bit
	unsigned AkuArizasi		:1;		//8.bit
	unsigned AkuIsiSensoru	:1;		//9.bit
	unsigned AkuIsiYuksek	:1;		//10.bit
	unsigned FazKaybi		:1;		//11.bit
	unsigned PfcReset		:1;		//12.bit
	unsigned BaslaGecikmesi :1;		//13.bit
	unsigned PfcStrtg		:1;		//14.bit
	unsigned Nu4			:1;		//15.bit
};	
typedef union D
{
	unsigned int All;
	volatile struct UyariPfc Bit;
};

//Lcd Alarmlar�1
typedef struct AlarmLcd1
{
	unsigned TermalSensor1IsiYuksek			:1;//0.bit
	unsigned TermalSensor2IsiYuksek			:1;//1.bit
	unsigned TermalSensor1IsiDusuk			:1;//2.bit
	unsigned TermalSensor2IsiDusuk			:1;//3.bit
	unsigned FanBakimZamani		:1;	//4.bit
	unsigned AkuBakimZamani		:1;	//5.bit
	unsigned GENEL_ALARM		:1;	//6.bit		06.07.2015 genel alarm eklendi
//	unsigned OpsiyonBakimZamani	:1;	//6.bit		06.07.2015 genel alarm eklendi
	unsigned TermalSensor1Ariza	:1;	//7.bit
	unsigned TermalSensor2Ariza	:1;	//8.bit
	unsigned HataResetle		:1;	//9.bit
	unsigned AkuKontaktorAcik	:1;	//10.bit
	unsigned GenelBakimZamani	:1;	//11.bit
	unsigned PfcCommErr			:1;	//12.bit
	unsigned InvCommErr			:1;	//13.bit
	unsigned InvDurumKod		:1;	//14.bit
	unsigned PfcDurumKod		:1;	//15.bit
};	
typedef union E
{
	unsigned int All;
	volatile struct AlarmLcd1 Bit;
};

//Inv Uyar�lar�2
typedef struct UyariInv2
{
	unsigned TestModu	 :1;		//0.bit
	unsigned BypFazCevir :1;		//1.bit
	unsigned InvStop	 :1;		//2.bit
	unsigned InvDcDusuk	 :1;		//3.bit
	unsigned AcAkimLimit :1;		//4.bit
	unsigned SigortaAtik :1;		//5.bit
	unsigned Nu6		 :1;		//6.bit
	unsigned InvStrtg	 :1;		//7.bit
	unsigned UykuModu    :1;		//8.bit
	unsigned Nu9		 :1;		//9.bit
	unsigned UserLogin	 :1;		//10.bit
	unsigned Nu11		 :1;		//11.bit
	unsigned ServisPassw :1;		//12.bit
	unsigned Nu13		 :1;		//13.bits
	unsigned MasterUPS   :1;		//14.bit			//23.12.2014
	unsigned AdimModu	 :1;		//15.bit
};	
typedef union F
{
	unsigned int All;
	volatile struct UyariInv2 Bit;
};
//Lcd Alarmlar�2
typedef struct AlarmLcd2
{
	unsigned Uykuyagirecek	:1;//0.bit
	unsigned Uyanacak		:1;//1.bit
	unsigned nu2			:1;//2.bit
	unsigned nu3			:1;//3.bit
	unsigned nu4			:1;	//4.bit
	unsigned nu5			:1;	//5.bit
	unsigned nu6			:1;	//6.bit
	unsigned nu7			:1;	//7.bit
	unsigned nu8			:1;	//8.bit
	unsigned nu9			:1;	//9.bit
	unsigned nu10			:1;	//10.bit
	unsigned nu11			:1;	//11.bit
	unsigned nu12			:1;	//12.bit
	unsigned nu13			:1;	//13.bit
	unsigned nu14			:1;	//14.bit
	unsigned Paralel_Durum	:1;	//15.bit
};	
typedef union G
{
	unsigned int All;
	volatile struct AlarmLcd2 Bit;
};
//Ana Kontrol

typedef struct Opcon24
{
	volatile union A	Inv1;
	volatile union B Inv2;
	volatile union C Pfc1;
	volatile union D Pfc2;
	volatile union E Lcd1;
	volatile union F Inv3;
	volatile union G Lcd2;
	//Yedek Alarmlar kullan�lm�yor.
	volatile union F YedekAlr2;
}; 
typedef union Opcon9
{
	unsigned long long Half[2];
	volatile struct Opcon24 Word;
}; 
extern volatile union Opcon9 Alarm;
extern volatile union Opcon9 GosterAlarm;
extern volatile union Opcon9 OldAlarm;
extern volatile union Opcon9 OldKontrolAlarm;
extern volatile union Opcon9 LogAlarm;
extern volatile union Opcon9 MaskedAlarm;					
extern volatile union Opcon9 RoleAlarmCek;				//12.03.2014

//Alarm kodlar�n� burada tutar.
typedef struct Opcon25
{
	unsigned int Inv;
	unsigned int Pfc;
}; 
typedef union Opcon21
{
	unsigned long All;
	volatile struct Opcon25 Kod;
};
extern volatile union Opcon21 AlarmKod;
extern volatile union Opcon21 OldAlarmKod;
extern volatile union Opcon21 LogAlarmKod;

//EepromHaritas�
//--------------

//Etiketler
typedef struct Eeprom1
{
	unsigned int Firma[16];
	unsigned int Model[11];
	unsigned int NominalVoltage[24];
	unsigned int OutputPower[7];
	unsigned int SaseNo[7];
	unsigned int Name[17];
};
extern volatile struct Eeprom1 Label;
//Di�er de�i�kenler
//-----------------
//Bak�m de�i�kenleri
typedef	struct Katagori				
{
	int KalanSure;
	unsigned int GecenSure;
	unsigned int AyarlananSure;
	unsigned int ServisSay;
	unsigned int Iptal;
};
//16 bit Konfigurasyon1
typedef struct Opcon12				
{
	unsigned BLRole					:1;	//0.bit
	unsigned UzakErisim				:1;	//1.bit Tercihler men�s�
	unsigned Nc2					:1;	//2.bit 
	unsigned Nc3					:1;	//3.bit 
	unsigned ButonTik				:1;	//4.bit Tercihler men�s�
	unsigned TermalSensor1			:1;	//5.bit Ayar men�s�
	unsigned TermalSensor2			:1;	//6.bit Ayar men�s�
	unsigned Comm2Secim				:1;	//7.bit Tercihler men�s�
	unsigned Opt03Secim				:1;	//8.bit Ayar Men�s�
	unsigned UserPassKullanilsin	:1;	//9.bit
	unsigned SNMP_OnOff				:1;	//10.bit Tercihler men�s�
	unsigned Bos11					:1;	//11.bit Tercihler men�s�					//12.03.2014 repo adresi degiti
	unsigned BypassVarYok			:1;	//12.bit		//0 ise bypass yok ol�umler men�s�nde bas�nca men�ye girmemesine yar�yor. 21.07.14 
	unsigned TouchScreenOffOn		:1;	//13.bit            //24.06.2015 Touch ile 
	unsigned EpoVarYok				:1;	//14.bit			//22.07.14
	unsigned JeneratorVarYok		:1;	//15.bit			//22.07.14
};	
typedef union Opcon2
{
	unsigned int All;
	volatile struct Opcon12 Bit;
};
//16 bit Konfigurasyon2
typedef struct Opcon36				
{
	unsigned Na0					:1;	//0.bit
	unsigned Na1					:1;	//1.bit 
	unsigned UyariLog				:1;	//2.bit Tercihler men�s�
	unsigned DurumLog				:1;	//3.bit Tercihler men�s�
	unsigned Na4					:1;	//4.bit 
	unsigned Na5					:1;	//5.bit 
	unsigned Na6					:1;	//6.bit 
	unsigned Na7					:1;	//7.bit 
	unsigned Na8					:1;	//8.bit 
	unsigned Na9					:1;	//9.bit
	unsigned Na10					:1;	//10.bit
	unsigned Na11					:1;	//11.bit
	unsigned Na12					:1;	//12.bit
	unsigned Na13					:1;	//13.bit
	unsigned Na14					:1;	//14.bit
	unsigned Na15					:1;	//15.bit
};	
typedef union Opcon37
{
	unsigned int All;
	volatile struct Opcon36 Bit;
};
//Termal sens�r de�i�kenleri
typedef	struct Opcon5				
{
	unsigned int Kalibrator;
	unsigned int Olculen;
	unsigned int AlrYuksek;
	unsigned int AlrDusuk;
};

//Ak� kalan kapasitesi hesap de�i�kenleri
extern volatile unsigned int AkuBuffer[20];			//Denemeler i�in
extern volatile unsigned int AkuYuzdeKapasite[2][151];
extern volatile unsigned int Peukert[420];
extern volatile unsigned int AkuKolDizi[5];

//Yetki de�i�kenleri
extern volatile unsigned int YazmaYetkileri_Comm2[12][2];
extern volatile unsigned int YazmaYetkileri_Comm1[7][2];
extern volatile unsigned int YazmaYetkileri_Panel[12][2];
extern volatile unsigned int YazmaYetkileri_Emir[7];

typedef struct Opcon34
{
	unsigned Kesik		:1;
	unsigned BirSn		:1;

	unsigned int OrnSay;
	unsigned int IlkKesik;
	unsigned int I_AkuTop;
	unsigned long I_AkuTopOrt;
	unsigned int AkuVolt;
	unsigned int KalanSure;
	unsigned int KalanTopEnerji;
	unsigned int x;

	unsigned int I_SonDakika;
	unsigned int Sure_SonDakika;
	unsigned int YuzdeI_SonDakika;
	unsigned int KalanAkuKap;		//% cinsinden	
	
	unsigned int HarcananTopEnerji;
	unsigned int OldTopEnerji;
	unsigned int TopEnerji;
	
	unsigned IlkDakikaGecti		:1;
};
extern volatile struct Opcon34 AkuKapasite;


//B�t�n De�i�kenleri tutar
extern volatile unsigned int EepromBosKontrol;
typedef struct Eeprom2				
{
	volatile struct Katagori Bakim[4];		//YedekBakim,FanBakim,Ak�Bakim,GenelBakim
	int Role[12];					//Tercihler men�s�
	unsigned int SaatDakika;
	unsigned int GunAy;
	unsigned int SnYil;
	int Dil;
	unsigned int LcdBacklight;		//Tercihler men�s�
	int AcikSure;					//Tercihler men�s�
	int YarimAydinlikSure;			//Tercihler men�s�
	unsigned int UyariSesAraligi;
	unsigned int InvLogMaske;
	unsigned int PfcLogMaske;
	unsigned int LcdLogMaske;
	int YeniTFT;				//***BU ADRES DE�ISTIRILECEK. BU ADRES EEPROM A VOLTAJ KAYITLARI ���N KULLANILACAK.	//23.12.2014 - 29.12.2014	eklendi. unsigned int BeslemeIlk;		//02.10.2013 
	volatile union Opcon2 Konfig;
	volatile union Opcon37 Konfig2;			//Bilgisayardan sadece bu bitlere de�i�tirme i�lmemi yap�labilir i�in. yeni eklendi.
	unsigned int LogCounterPage;
	volatile struct Opcon5 TermalSensor1;
	volatile struct Opcon5 TermalSensor2;
	unsigned int AkuKolSayisi;
	unsigned int AkuAh;
	unsigned int AkuSabitKalanSure;
	unsigned int LogSayac;
	unsigned int OnDakika;
	unsigned int ToplamSaat;
	
	unsigned int UserPassword[8];
	unsigned int InvUyari_1_BuzzerMaskesi;
	unsigned int InvUyari_2_BuzzerMaskesi;
	unsigned int PfcUyari_1_BuzzerMaskesi;
	unsigned int LcdUyari_1_BuzzerMaskesi;
	unsigned int BeslemeIlk;		//Buraya 23.12.2014 - 29.12.2014 te kondu.	//02.10.2013 unsigned int BOS_4;						//Dokumanda Lcd versiyon yaz�yor kontrol et.
	unsigned int MaxLogKapasitesi;
	unsigned int BasitPassword[8];
	int Role_NoNc;					//12.03.2014
	int REPO_OnOff;					//12.03.2014
	int EPO_NoNc;					//12.03.2014
	int GENIN_NoNc;					//12.03.2014
	int TouchOfsetX;
	int TouchOfsetY;
	int TouchButonSecim;
	int BOS_2;
	int BOS_3;
	int BOS_4;
	int BOS_5;
	int BOS_6;
	int BOS_7;
	int BOS_8;
};
extern struct Eeprom2 EeKayit;
//Kay�t haritas�
extern volatile unsigned int EepromMap[100][4];




//Can De�i�kenleri
//-----------------

//�l��m men�s� i�in
typedef struct Opcon20
{
	unsigned int Pos;
	unsigned int Neg;
};


//Inverter den gelenler
//Inv den gelen bit lik de�i�kenleri
typedef	struct Opcon4				
{
	unsigned Alf			:1;		//0.bit
	unsigned Vat			:1;		//1.bit
	unsigned Bos1			:1;		//2.bit
	unsigned JenBypass		:1;		//3.bit
	unsigned JenSenkron		:1;		//4.bit
	unsigned Bos2			:1;		//5.bit
	unsigned Bos3			:1;		//6.bit
	unsigned Bos4			:1;		//7.bit
	unsigned Bos5			:1;		//8.bit
	unsigned Bos6			:1;		//9.bit
	unsigned Bos7			:1;		//10.bit
	unsigned Bos8			:1;		//11.bit
	unsigned Bos9			:1;		//12.bit
	unsigned Bos10			:1;		//13.bit
	unsigned Bos11			:1;		//14.bit
	unsigned Bos12			:1;		//15.bit
};
typedef union Opcon3
{
	unsigned int All;
	volatile struct Opcon4 Bit;
}; 
//Inv den gelen bit lik de�i�kenlerin g�lgeleri
typedef union Opcon13
{
	unsigned int All;
	volatile struct Opcon4 Bit;
}; 
//Inv den gelen bit lik de�i�kenlerin eski de�eri
typedef union Opcon14
{
	unsigned int All;
	volatile struct Opcon4 Bit;
}; 
//Inv den gelen Bypass durumunun faz bitleri
typedef	struct Opcon23			
{
	unsigned R			:1;
	unsigned S			:1;
	unsigned T			:1;
};
typedef union Opcon22
{
	unsigned int All;
	volatile struct Opcon23 Bit;
}; 
typedef struct Opcon28
{
	unsigned int Gorev;
	unsigned int Paket;
	unsigned int Adres;
};
typedef struct Opcon16				
{
	//Bilgi Men�s�nde G�steriliyor.
	unsigned int InvVersiyon;

	//Tercihler Men�s�nde G�steriliyor.
	volatile union Opcon3 KonfigInv;					//Inv den gelen bit anlaml� veriler
	volatile union Opcon13 GolgeKonfigInv;			//KonfigInv nin �zerinde de�i�iklik yap�lan de�i�keni
	volatile union Opcon14 EskiKonfigInv;			//Inv den gelen eski de�er
	
	//Servis Men�s�nde
	unsigned LogInDurum					:1;	//Inverter den login i�leminin durumunu al�r. Login se logic 1
	unsigned EskiLogInDurum				:1;	//Bir �nce Inverter den logout i�leminin durumunu g�sterir.
	
	//Can i�lemlerinde kullan�lacak
	unsigned InvGeldi					:1;
	unsigned int InvBuff[4];				//�lk kesmede al�nan buffer lar.Ba�ka yerde kullan�lmaz.
	unsigned int InvAraBuff[5];				//Can i�lem yap�lan yerde gelen paketlerle i�lem yap�lan yerde kullan�l�r.
	//Rs232 - CantoInv - InvtoCan gelen data durumlar�
	volatile struct Opcon28 R_HataSayaci;
	volatile struct Opcon28 L_HataSayaci;
	volatile struct Opcon28 W_HataSayaci;
	//�l��m men�s�nde kullan�lacak
	volatile struct Opcon18 VoutRMS;
	volatile struct Opcon18 VinvRMS;
	volatile struct Opcon18 VbypRMS;
	volatile struct Opcon20 InvDCBus;
	volatile struct Opcon18 Load;
	volatile struct Opcon18 CoutRMS;
	unsigned int Digit;
//	unsigned int BypStatus;
	volatile union Opcon22 BypStatus;
	
	unsigned int InvFreq;
	unsigned int OutFreq;
	unsigned int BypFreq;
	volatile struct Opcon18 CrestFactor;
	volatile struct Opcon18 PowerWatt;
	volatile struct Opcon18 PowerVa;
	volatile struct Opcon18 Pf;

	unsigned int DataGelmediSayac;
	unsigned int AyarDatasiGelmediSayac;
	unsigned int DogruDataGosterSayac;
	unsigned GonderilendenFarkliDataGeldi			:1;
	unsigned BitIslemDatasiGeldi					:1;
	unsigned InvKodGeldi							:1;
	
	//Emirler ve Tercihler men�s�nde kullan�l�r.
	unsigned UserLogInDurum							:1;	//Inverter den kullan�c� login i�leminin durumunu al�r. Login se logic 1 
	unsigned int ChkBuffer[10];							//Datalar gelince ara bir buffer da tutulur.Alarmlar ve faultlar i�in
	
	//Yeni ekleniyor
	unsigned int N_1MinUps;								//Periyodik datalar�n i�erisine konuluyor. ( F2 nin cevab� )
	unsigned int AkuSayisi;								//�nceden Eeproma kayitl�yd� �imdi inv den al�n�yor.
	unsigned int CalismaModu;							//Uart protokollerinde kullan�l�r.
	unsigned int GolgeCalismaModu;						//26.09.12 12:00 Bypass tercihlerinde ayar i�in kullan�lacak.
	unsigned int EskiCalismaModu;						//26.09.12 12:00 Bypass tercihlerinde ayar i�in kullan�lacak.
	unsigned int KGKNo;									//Periyodik datalar�n i�erisine konuluyor. ( F2 nin cevab� )

	unsigned int SifreSistemi;							//1 gelirse Merkezi kod �ifresi ile i�lem yap�lacak. 2 gelirse Basit kod �ifresi ile i�lem yap�lacak. Ayar ana men�s�nde dinamik men� yap�s� olu�turdu.
	unsigned int CalismaModuSayac;						//Paralel mod falan bilgisi
	unsigned int OutputPhaseCount;						//14.07.14
}; 
//Pfc den gelenler
typedef struct Opcon17				
{
	//Bilgi Men�s�nde G�steriliyor.
	unsigned int PfcVersiyon;
	
	//Can i�lemlerinde kullan�lacak
	unsigned int PfcBuff[4];
	unsigned PfcGeldi					:1;
	//Rs232 - CantoPfc - PfctoCan gelen data durumlar�
	volatile struct Opcon28 R_HataSayaci;
	volatile struct Opcon28 L_HataSayaci;
	volatile struct Opcon28 W_HataSayaci;
	//�l��m men�s�nde kullan�lacak
	volatile struct Opcon18 VinRMS;
	volatile struct Opcon18 CinRMS;
	volatile struct Opcon20 CbattC;
	unsigned int RecTemp;
	volatile struct Opcon20 RecDCBus;
	volatile struct Opcon20 VBatt;
	unsigned int RecFreq;
	volatile struct Opcon20 DisCbattC;
	volatile struct Opcon20 HassasDisCbattC;
	volatile struct Opcon20 SonucDisCbattC;
	
	unsigned int DataGelmediSayac;
	unsigned int AyarDatasiGelmediSayac;
	unsigned int DogruDataGosterSayac;
	unsigned GonderilendenFarkliDataGeldi			:1;
	unsigned BitIslemDatasiGeldi					:1;
	unsigned PfcKodGeldi							:1;
	
	unsigned int ChkBuffer[10];							//Datalar gelince ara bir buffer da tutulur.Alarmlar ve faultlar i�in
};

//Inv ve Pfc ye gidenler
typedef	struct Opcon27				
{
	unsigned U1_R						:1;
	unsigned U1_L						:1;
	unsigned U1_W						:1;
	
	unsigned U2_R						:1;
	unsigned U2_L						:1;
	unsigned U2_W						:1;	
};
typedef union Opcon26
{
	unsigned int All;
	volatile struct Opcon27 Bit;
};	
typedef struct Opcon19
{
	unsigned int Zaman[8];							//Sadece Inv i�in
	unsigned int BasitSifreGonder[8];				//Sadece Inv ye Basit �ifrenin kay�t de�erini geriye 0x0012 paketine g�nderecek.
	unsigned int TekrarIcinBuff[5];					//Can den data do�ru gelmeyince Ara bir buffer a konur tekrar g�ndermek i�in.
	unsigned int AyarGonderilenData;				//Ayar men�s�nde set data kontrol� i�in
	volatile union Opcon26 Gonderildi;						//Can den sorgulanan Rmaaa -> R + Modul + Adres vb.
	volatile struct DATE Date_2;
};
typedef struct Opcon15				
{
	volatile struct Opcon16 FromInv;
	volatile struct Opcon17 FromPfc;
	volatile struct Opcon19 ToInv;
	volatile struct Opcon19 ToPfc;
	unsigned int GonderPaket[4];					//Hem Inv hem de Pfc i�in
	unsigned int AyarMenuDizisi[5];					//Ayar men�s�ndeyken g�nderilecek de�erler burada tutulur.
};
extern volatile struct Opcon15 Can;

//Gelen Can Paketleri
typedef unsigned int ECANMSGBUF [4][8];
extern volatile ECANMSGBUF ecanmsgbuf __attribute__((space(dma)));
extern volatile unsigned int *CanInvRamAdres;
extern volatile unsigned int CanInvGeriAdres;
extern volatile unsigned int CanInvData;


//Ayar men�s� De�i�kenleri - R1171 in bit cevaplar�
typedef	struct Opcon31				
{
	unsigned O_P_Switch		 :1;		//0
	unsigned TempSensor		 :1;		//1
	unsigned O_P_CBSense  	 :1;		//2
	unsigned ScrFault		 :1;		//3
	unsigned InvEeFault		 :1;		//4
	unsigned O_P_ModulType	 :1;		//5
	unsigned PfcSystem		 :1;		//6
	unsigned DcBalanceFault	 :1;		//7
	unsigned BypassSekron	 :1;		//8
	unsigned Null_9			 :1;		//9
	unsigned Null_10		 :1;		//10
	unsigned ShortCircuitPh	 :1;		//11
	unsigned BypShortCircuit :1;		//12
	unsigned Null_13		 :1;		//13
	unsigned BypLkgCurr		 :1;		//14
	unsigned BypCurrTrf		 :1;		//15
};				
typedef union Opcon30
{
	unsigned int All;
	volatile struct Opcon31 Bit;
};	
//R2160 in bit cevaplar�
typedef	struct Opcon33				
{
	unsigned I_P_ModulType	 :1;		//0
	unsigned BtTempKomp		 :1;		//1
	unsigned PfcEeFault		 :1;		//2
	unsigned BoostCharge	 :1;		//3
	unsigned I_P_CurrProtect :1;		//4
	unsigned Null_5			 :1;		//5
	unsigned I_P_CBSense	 :1;		//6
	unsigned I_P_CurTransAlr :1;		//7
	unsigned AcInputTest	 :1;		//8
	unsigned PfcTermalProtect  :1;		//9
	unsigned I_P_RegenSystem   :1;		//10
	unsigned AutomaticBattTest :1;		//11
	unsigned Null_12		 :1;		//12		//Varm�� ama bende kay�tl� de�il.
	unsigned UseSensorTH3_1	 :1;		//13
	unsigned PfcDcLeakage	 :1;		//14		//Yeni ayar giri� dc ka�ak
	unsigned Null_15		 :1;		//15
};
typedef union Opcon32
{
	unsigned int All;
	volatile struct Opcon33 Bit;
};	
typedef struct Opcon29
{
	volatile union Opcon30 InvFactOpt;						//Can den gelen Inv factory options men�s�n�n bit anlaml� i�lemleri i�in
	volatile union Opcon32 PfcFactOpt;						//Can den gelen Pfc factory options men�s�n�n bit anlaml� i�lemleri i�in
};
extern volatile struct Opcon29 AyarBitAnlam;



typedef struct Opcon35
{
	unsigned int Th1Adc[25];
	unsigned int Th2Adc[25];
	unsigned long Th1AdcValue;
	unsigned long Th2AdcValue;
	unsigned int ThSayac;
	unsigned int Th1Sayac;
	unsigned int Th2Sayac;
	//A�a��dakiler sonradan eklenen de�i�kenlerdir.
	unsigned int CanFreqAraDeger;
	unsigned AyarMenuSerPaswAyariAktif	:1;		//Men�n�n �zerindeyken enter a bas�l�nca 1 olur bir daha bas�l�nca 0 olur.
	unsigned AyarMenuUserPaswAyariAktif	:1;		//Men�n�n �zerindeyken enter a bas�l�nca 1 olur bir daha bas�l�nca 0 olur.
	unsigned UserPassDogru15dklikIzin	:1;		//User Password do�ruysa 15 dk boyunca tercihler ve emirler men�s�ndeki i�lemler yap�labilir.
	unsigned int UserPassGeriSayac;				//15 dk l�k geri saya�t�r. 15 dk sonra Genel.UserPassDogru15dklikIzin = 0 yapar.
	
	unsigned AlarmGosterilmesinBiti		:1;		//Bu bit logic olarak 1 olursa alarm 4.sat�rda g�r�nmesin.
	volatile union Opcon2 YedekKonfig;
	unsigned int GolgeUyariSesAraligi;			//Tercihler men�s�nde UyariSesAraligi ayar� n�n ekrandaki update i i�in
	unsigned int GolgeLcdBacklight;				//Tercihler men�s�nde LcdBacklight ayar� n�n ekrandaki update i i�in
	unsigned int GolgeAcikSure;					//Tercihler men�s�nde AcikSure ayar� n�n ekrandaki update i i�in
	unsigned int GolgeYarimAydinlikSure;		//Tercihler men�s�nde YarimAydinlikSure ayar� n�n ekrandaki update i i�in

	unsigned int LcdToInvPeriyodikSira;			//Lcd nin Inv ye sordu�u periyodik sorgu s�ras�
	unsigned int Th1AraDeger;					//Ekranda eksi de�erleri yazabilmek i�in konuldu.
	unsigned int Th2AraDeger;					//Ekranda eksi de�erleri yazabilmek i�in konuldu.
	unsigned int Th3AraDeger;					//Ekranda eksi de�erleri yazabilmek i�in konuldu.
	
	unsigned int MaskelenmisUyarilar_Inv1;		//  = EeKayit.InvUyari_1_BuzzerMaskesi & Alarm.Word.Inv2.All Yani Uyar�lardaki buzzer �tmelerini engellemek i�in maske
	unsigned int MaskelenmisUyarilar_Inv2;		//Uyar�lardaki buzzer �tmelerini engellemek i�in maske
	unsigned int MaskelenmisUyarilar_Pfc1;		//Uyar�lardaki buzzer �tmelerini engellemek i�in maske
	unsigned int MaskelenmisUyarilar_Lcd1;		//Uyar�lardaki buzzer �tmelerini engellemek i�in maske
	unsigned int MaskelenmisUyarilar_Lcd2;		//Uyar�lardaki buzzer �tmelerini engellemek i�in maske

	unsigned RoleSimulasyonToggle		:1;		//R�le �ek b�rak i�lemi.
	unsigned int LogSorulduSayac;				//Log lar uart tan al�n�rken yeni alarm kay�d� yapma.
	
	unsigned EkranUyariMesajiVar_AlarmGosterme	:1;	//Ekranda uyar� mesaj� ��kmas� i�in kullan�lacak. 1 ise �ifrenizi giriniz uyar� mesaj� ��kacak 2 ise ekranda biraz olsun mesajlar g�r�ns�n 0 ise alt1menufonk() vb. �a�r�lacak
	unsigned HemenEkranYenilemesin		:1;			//Ekranda uyari haricindeki mesajlardan birini yazd�r�rken ekran yenilenmesi yapmas�n diye.	

	//Status men� i�in buffer
	unsigned int Durum[10];						//Lcd De�i�kenleri i�in diziler (Menu.Durum i�erisine s��mad� adres �ak�smas� oldu�u i�in)
	unsigned LogOutveFaultReset			:1;
	unsigned EnterAlgilamaFault			:1;
	
	unsigned int FaultResetSagTusSayac;			//K�sa devre oldu�unda y�klkeri kontrol edin mesa�� gelir ve enter ile fault reset yep�l�r sa� tu�la istenirse resetlenmez ama bu sayac 0 olunca (sag tu�la de�er y�klenir) alarm varsa yine gelir.
	unsigned long DcGirisKacak_L;				//Giri� DC ka�ak gerilimi �l��l�r
	unsigned int GirisDCKacakAlr;				//Giri� DC ka�ak gerilimi �l��l�r duruma g�re alarm �retilir. Timer3 kesmesinde i�lemler yap�l�yor.
	unsigned int GirisDCKacakADC;				//Giri� DC ka�ak gerilimi �l��l�r
	unsigned long GirisDcKacakVref_L;			//Giri� DC ka�ak Vref toplam
	unsigned int GirisDcKacakVrefADC;			//Giri� DC ka�ak Vref adc
	unsigned int GirisDcKacakVref;				//Giri� DC ka�ak Vref Sonuc
	int GirisDcKacak;							//Giri� DC ka�ak Sonu�
		
	//Eeprom silme zaman payla��m� i�in
	unsigned int Log_m;
	unsigned LogSilEmri					:1;
	unsigned LogSilmeSonu				:1;
	unsigned int EeSildenSonraAlrKayitSayac;	
	unsigned int IlkAcilisAlrSayac;
	
	unsigned int EepromKilitSayac;
	
	unsigned int ParalelAlr[22];
	unsigned int MaxYukL1;
	unsigned int MaxYukL2;
	unsigned int MaxYukL3;
	
	unsigned int EskiMenu;
	unsigned int EskiSekme;
	unsigned int AraSifre_Hangisi;
	unsigned AraSifreMenuIci			:2;
	unsigned int LoginWaitButon;
	
	
	unsigned int BattSwSayac;				//Batt sw i�in kullan�lan debounce geri sayac�
	unsigned int EmcStopSayac;				//Emc stop i�in kullan�lan debounce geri sayac�
	unsigned int In2OptSayac;				//In4 Opt i�in kullan�lan debounce geri sayac�
	unsigned int In3OptSayac;				//In3 Opt i�in kullan�lan debounce geri sayac�
	unsigned int GenInSayac;				//Jenerator modu i�in kullan�lan debounce geri sayac�
	
	unsigned int UPSKapaliGeriSayac;		//23.11.2012 de eklendi.
	unsigned int UpsKapaliButonIlkBas;		//2.12.12 de eklendi.
	unsigned int AdcKilit;					//30.11.2012 de eklendi.
	
	unsigned int Besleme;					//02.10.2013
	unsigned int IlkBesleme;				//02.10.2013
	int BeslemeFark;						//02.10.2013
	unsigned int BattSwSayac2;				//Batt sw i�in kullan�lan debounce geri sayac�
	unsigned int TFTRESET;					//05.02.2015
	unsigned TFTRESETFLAG			:1;		//05.02.2015
};
//Sonradan eklenenler.
extern volatile struct Opcon35 Genel;

//Yeni eklendi.23.07.2012
//Paralel Konfigurasyon
typedef struct Opcon38				
{
	unsigned Bit0					:1;
	unsigned Bit1					:1;
	unsigned Bit2					:1;
	unsigned Bit3					:1;
	unsigned Bit4					:1;
	unsigned Bit5					:1;
	unsigned Bit6					:1;
	unsigned Bit7					:1;
	unsigned Bit8					:1;
	unsigned Bit9					:1;
	unsigned Bit10					:1;
	unsigned Bit11					:1;
	unsigned Bit12					:1;
	unsigned Bit13					:1;
	unsigned Bit14					:1;
	unsigned Bit15					:1;
};	
typedef union Opcon39
{
	unsigned int All;
	volatile struct Opcon38 Bit;
};
extern volatile union Opcon39 Paralel;
extern volatile union Opcon39 EskiParalel;
extern volatile union Opcon39 CalismaDurumu;
extern volatile union Opcon39 EskiCalismaDurumu;
//TFT de�i�kenleri
typedef struct Opcon100
{
	unsigned int TftTimer;
	unsigned int XAbsis;
	unsigned int YOordinat;
	unsigned int OldXAbsis;
	unsigned int OldYOordinat;
	unsigned int Radius;
	
	//Foto�raf De�i�kenleri
	unsigned int X1_Foto;
	unsigned int X2_Foto;
	unsigned int Y1_Foto;
	unsigned int Y2_Foto;
	unsigned long Foto_Renk;
	unsigned FotoDurum					:1;		//Lojik 1 ise pencere a��ld� piksel ler yaz�lmaya haz�r.
	
	int AlarmBuff[128]; 
	int AlarmSay;
	int AlarmSayfaSayisi;
	int LogSayfaToggle;
};
extern volatile struct Opcon100 TFT;
extern volatile unsigned char *BuffIci;

extern volatile unsigned long Buton[20];
extern volatile unsigned long name[20]; 
extern volatile unsigned char FONT[110][5];
extern volatile unsigned int FONT3[5][10];
extern volatile unsigned char DegiskenFont[100][5];
extern volatile unsigned long TextColor;
extern volatile unsigned long PixelColor;

extern volatile unsigned int GRADIENT;
extern volatile unsigned int GRADIENTCOLOR;
extern volatile unsigned long NOTGRADIENTCOLOR;
extern volatile unsigned int DIGITALTEXT;
extern volatile unsigned long TEXTCOLOR;
extern volatile unsigned long CLEARTEXTBACKCOLOR;
extern volatile unsigned long GRADIENTSTART;
extern volatile unsigned long TRANSPARIENT;
extern volatile unsigned int DIGITAL;
extern volatile unsigned int LINEREPEAT;


extern volatile unsigned int Xstart;
extern volatile unsigned int Ystart;
extern volatile unsigned int Xend;
extern volatile unsigned int Yend;
extern volatile unsigned int Sekme1;
extern volatile unsigned int Sekme2;
extern volatile unsigned int Sekme3;
extern volatile unsigned int Sekme4;
extern volatile unsigned int Sekme5;
extern volatile unsigned int SekmeHeight;
extern volatile unsigned int NameY;
extern volatile unsigned int NameEk;

extern volatile unsigned int TftTimer;
extern volatile unsigned int TextBuffer[50];
extern volatile unsigned long TextBufferLong[10];
extern volatile unsigned int klm;
extern volatile unsigned int klm2;
extern volatile unsigned int PfVar;


extern volatile unsigned int Sifir;
extern volatile unsigned int EmirMenuOrg[10][2];
extern volatile unsigned int ServisMenuOrg[10][2];


typedef struct MimikNesne
{
	//Low word
	unsigned Nesne_1		:2;				//Renk
	unsigned Nesne_2		:2;				//Renk
	unsigned Nesne_3		:2;				//Renk
	unsigned Nesne_4		:2;				//Renk
	unsigned Nesne_5		:2;				//Renk
	unsigned Nesne_6		:2;				//Renk
	unsigned Nesne_7		:2;				//Renk
	unsigned Nesne_8		:2;				//Renk
	//High word
	unsigned Nesne_9		:2;				//Renk
	unsigned Nesne_10		:2;				//Renk
	unsigned Nesne_11		:2;				//Renk
	unsigned Nesne_12		:2;				//Renk
	unsigned Nesne_13		:2;				//Renk
	unsigned Nesne_14		:2;				//Renk
	unsigned Nesne_15		:2;				//Renk
	unsigned Nesne_16		:2;				//Renk
	
	//Low word 
	unsigned Nesne_17		:2;				//Sembol durum
	unsigned Nesne_18		:2;				//Sembol durum
	unsigned Nesne_19		:2;				//Sembol durum
	unsigned Nesne_20		:2;				//Sembol durum
	unsigned Nesne_21		:2;				//Sembol durum
	unsigned Nesne_22		:2;				//Sembol durum
	unsigned Nesne_23		:2;				//Sembol durum
	unsigned Nesne_24		:2;				//Sembol durum
	//High word 
	unsigned Nesne_25		:2;				//Sembol durum
	unsigned Nesne_26		:2;				//Sembol durum
	unsigned Nesne_27		:2;				//Sembol durum
	unsigned Nesne_28		:2;				//Sembol durum
	unsigned Nesne_29		:2;				//Sembol durum
	unsigned Nesne_30		:2;				//Sembol durum
	unsigned Nesne_31		:2;				//Sembol durum
	unsigned Nesne_32		:2;				//Sembol durum
};	
//Yatay Yollar
typedef union YatayCizgi
{
	unsigned long long All;
	volatile struct MimikNesne Bit;
};
//Dikey Yollar
typedef union DikeyCizgi
{
	unsigned long long All;
	volatile struct MimikNesne Bit;
};
//Noktalar
typedef union Noktalar
{
	unsigned long long All;
	volatile struct MimikNesne Bit;
};
//Sembol
typedef union Semboller
{
	unsigned long long All;
	volatile struct MimikNesne Bit;
};


typedef	struct Mimik			
{
	volatile union YatayCizgi Yatay;
	volatile union DikeyCizgi Dikey;
	volatile union Noktalar Bag;
	volatile union Semboller Sembol;	
	
	unsigned int MimikUpdate;
	unsigned int MimikUpdateSayac;
};
extern volatile struct Mimik MimikDurum;

extern volatile unsigned int TftInitBackCounter;
extern volatile unsigned int TftInitButonSayac;
extern volatile unsigned int TftInitFlag;


extern volatile unsigned int UPS_I_O_Options;
extern volatile unsigned int GucAraHesap;


/**************Touch Screen**************/
extern volatile int AbsisX;
extern volatile int OrdinatY;
extern volatile unsigned int PressCounterX;
extern volatile unsigned int PressCounterY;
//Filter
extern volatile unsigned int xSave[10];
extern volatile unsigned int ySave[10];

extern volatile unsigned int Probe[10];
extern volatile unsigned int NavigasyonuSil;
extern volatile unsigned int _TouchCount;
extern volatile unsigned int BekleCounter;
extern volatile unsigned int BuzzerGeriSayac;
extern volatile unsigned int BakimHesaplaFlag;


#endif
