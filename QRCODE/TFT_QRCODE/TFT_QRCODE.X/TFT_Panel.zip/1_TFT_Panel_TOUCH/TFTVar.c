#include "p33FJ256MC710.h"

#include "TFTVar.h"
#include "TFTDef.h"


//Genel De�i�kenler
//------------------
volatile unsigned int LogSayisiToInv			__attribute__((address(3000)));
volatile unsigned int Basla[10]				__attribute__((address(3004)));		//R3221
volatile unsigned int GlobalSayfa;
volatile unsigned int *RamAdres;					//�lk a��l��ta eepromdaki verileri ram e aktarmak i�in kullan�lacak.
volatile struct Opcon35 Genel				__attribute__((far));	


//Timer De�i�kenleri
//------------------
volatile struct Time Timer6;	
volatile union AA Timer;

//Menu De�i�kenleri
//------------------
volatile struct Opcon6 Menu					__attribute__((address(4810)));	
volatile unsigned int Protokol[10] = {'D','3','3','-','1',' ',' ',' ',' ',' '};		//Information men�s�nde kullan�l�r.	Sabittir.							
volatile unsigned int UartProtokol[10] = {'T','X','3','0','1',' ',' ',' ',' ',' '}; 	//TX301 protokol�nde I n�n cevab�d�r.
//Tercih men�s�
volatile unsigned int RoleAtama[66] 	__attribute__((far)) =      //Genel alarm i�in 66 yap?ld? buffer ve 70 eklendi.
{
	//Atanan Alarm s?ralar?
	0 ,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 ,
	10,11,12,13,14,15,16,17,18,19,
	20,21,22,23,24,25,26,27,28,29,
	30,31,32,33,34,35,36,37,38,39,
	40,41,42,43,44,45,46,47,48,49,
	50,51,52,53,54,55,56,57,58,59,
	60,61,62,63,70,74
};	
//Ayar Men�s�
volatile unsigned char SifreAnahtari[128] =
{
	8,					//0
	0,2,3,5,4,7,9,1,6,3,//10
	2,4,6,8,9,0,5,1,7,1,//20
	5,8,0,9,2,3,6,7,4,9,//30
	1,8,2,7,3,6,4,5,0,5,//40
	7,6,1,2,8,9,4,0,3,4,//50
	6,9,0,2,1,7,3,8,5,0,//60
	9,3,1,5,8,7,2,4,6,7,//70
	5,3,0,9,6,2,4,8,1,2,//80
	5,8,6,3,1,4,7,0,9,6,//90
	4,1,2,0,5,3,9,7,8,8,//100
	0,2,3,5,4,7,9,1,6,3,//110
	9,1,5,0,6,8,2,4,7,8,//120
	5,7,2,9,6,1,0,		//127											
};	
//S�n�r de�erler
volatile unsigned int MinMax[120][3]		__attribute__((far)) =
{
	{0,0,65535},			//R3371	Yedek Bak�m Kalan				//14.07.14 9999->65535 yap�ld�.
	{0,0,65535},			//R3372	Yedek Bak�m Ge�en
	{0,0,65535},			//R3373 Yedek Bak�m Ayarlanan			
	{0,0,65535},			//R3374	Yedek Bak�m Servis Say�s�		
	{0,0,65535},			//R3375	Yedek Bak�m Iptal	

	{0,0,65535},			//R3376	Fan Bak�m Kalan
	{0,0,65535},			//R3377	Fan Bak�m Ge�en
	{0,0,65535},			//R3378 Fan Bak�m Ayarlanan			
	{0,0,65535},			//R3379	Fan Bak�m Servis Say�s�		
	{0,0,65535},			//R3380	Fan Bak�m Iptal	

	{0,0,65535},			//R3381	Ak� Bak�m Kalan
	{0,0,65535},			//R3382	Ak� Bak�m Ge�en
	{0,0,65535},			//R3383 Ak� Bak�m Ayarlanan			
	{0,0,65535},			//R3384	Ak� Bak�m Servis Say�s�		
	{0,0,65535},			//R3385	Ak� Bak�m Iptal	
	
	{0,0,65535},			//R3386	Genel Bak�m Kalan
	{0,0,65535},			//R3387	Genel Bak�m Ge�en
	{0,0,65535},			//R3388 Genel Bak�m Ayarlanan			
	{0,0,65535},			//R3389	Genel Bak�m Servis Say�s�		
	{0,0,65535},			//R3390	Genel Bak�m Iptal

	{0,0,65},			//R3391	R�le1
	{0,0,64},			//R3392	R�le2
	{0,0,64},			//R3393	R�le3
	{0,0,64},			//R3394	R�le4
	{0,0,64},			//R3395	R�le5
	{0,0,64},			//R3396	R�le6
	{0,0,64},			//R3397	R�le7
	{0,0,64},			//R3398	R�le8
	{0,0,64},			//R3399	R�le9
	{0,0,64},			//R3400	R�le10
	{0,0,64},			//R3401	R�le11
	{0,0,64},			//R3402	R�le12
	
	{0,0,2359},			//R3403	Saat � Dakika
	{0,0,3112},			//R3404	G�n � ay
	{0,0,9999},			//R3405	Sn � Y�l
	
	{0,0,4},			//R3406 Dil
	
	{2,2,9},			//R3407 LcdBacklight
	{0,10,30},			//R3408 A��k kalma s�resi
	{0,10,30},			//R3409 Yar�m ayd�nl�k s�resi
	
	{5,5,10},			//R3410 Uyar� ses aral���
	
	{0,0,65535},		//R3411 Inv Uyar� log kay�t
	{0,0,65535},		//R3412 Pfc Uyar� log kay�t
	{0,0,65535},		//R3413 Lcd Uyar� log kay�t
	
	{0,0,1},			//R3414 YeniTFT 0 ise eski 1 ise yeni //23.12.2014 - 29.12.2014	eklendi.
	{0,0,65535},		//R3415 Konfig
	{0,0,65535},		//R3416 Konfig2
	{0,0,65535},		//R3417 Bo�
//Ayarlanacak	
	{0,0,65535},		//R3418 Th1 kalibrat�r
	{0,0,65535},		//R3419 Th1 Olculen
	{0,0,65535},		//R3420 Th1 Y�ksek alarm seviyesi
	{0,0,65535},		//R3421 Th1 D���k alarm seviyesi
	
	{0,0,65535},		//R3422 Th2 kalibrat�r
	{0,0,65535},		//R3423 Th2 Olculen
	{0,0,65535},		//R3424 Th2 Y�ksek alarm seviyesi
	{0,0,65535},		//R3425 Th2 D���k alarm seviyesi
	
	{1,1,4},			//R3426 Ak� kol say�s�
	{0,0,300},			//R3427 Ak� Ah
	{0,0,10000},		//R3428 Aku Sabit Kalan Sure
	
	{0,0,65535},		//R3429 Log Counter
	{0,0,65535},		//R3430 Ondakika
	{0,0,65535},		//R3431 Toplam Zaman	
	
	{48,48,57},			//R3432 UserPassword[0]  �uan 4 adet kullan�l�yor.
	{48,48,57},			//R3433 UserPassword[1]
	{48,48,57},			//R3434 UserPassword[2]
	{48,48,57},			//R3435 UserPassword[3]  Buraya kadar.
	{48,48,57},			//R3436 UserPassword[4]
	{48,48,57},			//R3437 UserPassword[5]
	{48,48,57},			//R3438 UserPassword[6]
	{48,48,57},			//R3439 UserPassword[7]
	
	{0,0,65535},		//R3440 Inv Uyari 1 Buzzer maskesi
	{0,0,65535},		//R3441 Inv Uyari 2 Buzzer maskesi
	{0,0,65535},		//R3442 Pfc Uyari 1 Buzzer maskesi
	{0,0,65535},		//R3443 Lcd Uyari 1 Buzzer maskesi
	{0,0,65535},		//R3444 Bo�
	{0,0,192},			//R3445 Maksimum log kapasitesi
	
	{48,48,57},			//R3446 BasitPassword[0]  
	{48,48,57},			//R3447 BasitPassword[1]
	{48,48,57},			//R3448 BasitPassword[2]
	{48,48,57},			//R3449 BasitPassword[3]
	{48,48,57},			//R3450 BasitPassword[4]
	{48,48,57},			//R3451 BasitPassword[5]
	{48,48,57},			//R3452 BasitPassword[6]
	{48,48,57},			//R3453 BasitPassword[7]
	{0,0,65535},		//R3454 BOS
	{0,0,1},			//R3455 Repo On __ Off
	{0,0,1},			//R3456 Epo No _ Nc
	{0,0,1},			//R3457 GENin No _ Nc
	
	{0,0,65535},		//R3458 Touch ofset x		//Touch ile birlikte
	{0,0,65535},		//R3459 Touch ofset y		//Touch ile birlikte
	
	{0,0,65535},		//R3460 BOS					//Touch ile birlikte
	{0,0,65535},		//R3461 BOS					//Touch ile birlikte
	{0,0,65535},		//R3462 BOS					//Touch ile birlikte
	{0,0,65535},		//R3463 BOS					//Touch ile birlikte
	{0,0,65535},		//R3464 BOS					//Touch ile birlikte
	{0,0,65535},		//R3465 BOS					//Touch ile birlikte
	{0,0,65535},		//R3466 BOS					//Touch ile birlikte
	{0,0,65535}			//R3467 BOS					//Touch ile birlikte
};
//Analog olarak kullan�lacak kanallar�n listesi
volatile unsigned int AnalogKanallar[10];	
volatile unsigned int AnalogKanalSayisi;
//Time men�
volatile struct DATE Date;
volatile struct DATE Date4;
volatile struct DATE Date5;
volatile struct DATE Date6;

//Uart De�i�kenleri
//------------------
volatile struct Comm Uart1;
volatile struct Comm Uart2;
volatile unsigned int U1TxDmaBuf[128] 	__attribute__((space(dma)));
volatile unsigned int U2TxDmaBuf[128]	__attribute__((space(dma)));

//Megatek Protokol�														//2400 Baud Rate
volatile struct Protokol Megatech;

//Alarm De�i�kenlerleri
//---------------------
volatile union Opcon9 Alarm				__attribute__((address(2560)));			//R3000
volatile union Opcon9 GosterAlarm;
volatile union Opcon9 OldAlarm;
volatile union Opcon9 OldKontrolAlarm;
volatile union Opcon9 LogAlarm;
volatile union Opcon9 MaskedAlarm;
volatile union Opcon9 RoleAlarmCek;					//12.03.2014
volatile union Opcon21 AlarmKod;
volatile union Opcon21 OldAlarmKod;
volatile union Opcon21 LogAlarmKod;

//Can De�i�kenleri
//----------------
volatile struct Opcon15 Can 			__attribute__((address(4300)));
volatile ECANMSGBUF ecanmsgbuf __attribute__((space(dma),aligned(4*16)));
volatile unsigned int *CanInvRamAdres;
volatile unsigned int CanInvGeriAdres;
volatile unsigned int CanInvData;

//Ayar men�s� De�i�kenleri
volatile struct Opcon29 AyarBitAnlam;

//Ak� kalan s�re hesap de�i�kenleri
volatile struct Opcon34 AkuKapasite;
volatile unsigned int AkuBuffer[20]	__attribute__((address(4160)));			//Denemeler i�in
volatile unsigned int AkuKolDizi[5] = {90,90,40,24,17};
volatile unsigned int Peukert[420]	__attribute__((far)) = 
{
	2047,2047,2047,1938,1384,1066,861,719,615,536,
	474 , 424, 382,	348, 319, 294,273,254,238,223,
	210 , 198, 188,	178, 170, 162,154,148,142,136,
	131 , 126, 121, 117, 113, 109,105,102, 99, 96,
	93  ,  90,  88,  86,  83,  81, 79, 77, 75, 73,
	72  ,  70,  68,  67,  65,  64, 63, 61, 60, 59,
	58	,  57,  56,  55,  54,  53, 52, 51, 50, 49,
	48  ,  47,	47,  46,  45,  44, 44, 43, 42, 42,
	41  ,  41,	40,  39,  39,  38, 38, 37, 37, 36,
	36  ,  35,	35,  34,  34,  34, 33, 33, 32, 32,
	32  ,  31, 	31,  30,  30,  30, 29, 29, 29, 28,
	28  ,  28,	28,  27,  27,  27, 26, 26, 26, 26,
	25  ,  25,	25,  25,  24,  24, 24, 24, 24, 23,
	23	,  23,	23,  22,  22,  22, 22, 22, 21, 21,
	21  ,  21,	21,  21,  20,  20, 20, 20, 20, 20,
	19  ,  19, 	19,  19,  19,  19, 19, 18, 18, 18,
	18  ,  18,	18,  18,  17,  17, 17, 17, 17, 17,
	17  ,  17,	16,  16,  16,  16, 16, 16, 16, 16,
	16  ,  16,  15,  15,  15,  15, 15, 15, 15, 15,
	15  ,  15,	14,  14,  14,  14, 14, 14, 14, 14,
	14  ,  14,  14,  13,  13,  13, 13, 13, 13, 13,
	13  ,  13,	13,  13,  13,  13, 13, 12, 12, 12,
	12	,  12,	12,  12,  12,  12, 12, 12, 12, 12,
	12  ,  12,  11,  11,  11,  11, 11, 11, 11, 11,
	11  ,  11,	11,  11,  11,  11, 11, 11, 11, 11,
	10  ,  10,	10,  10,  10,  10, 10, 10, 10, 10,
	10  ,  10,	10,  10,  10,  10, 10, 10, 10, 10,
	10  ,   9,   9,   9,   9,   9,  9,	9,	9,	9,
	9   ,	9, 	 9,   9,   9,	9,	9,	9,	9,	9,
	9   ,   9,	 9,   9,   9,	9,	9,	8,	8,	8,
	8	,   8,   8,   8,   8,   8,  8,  8,  8,  8,
	8   ,   8,   8,   8,   8,   8,  8,  8,  8,  8,
	8   ,   8,   8,   8,   8,   8,  8,  8,  7,  7,
	7	,   7,   7,   7,   7,   7,  7,  7,  7,  7,
	7   ,   7,   7,   7,   7,   7,  7,  7,  7,  7,
	7   ,   7,   7,   7,   7,   7,  7,  7,  7,  7,
	7   ,   7,   7,   7,   7,   7,  7,  7,  6,  6,
	6   ,   6,   6,   6,   6,   6,  6,  6,	6,	6,
	6   ,	6,   6,   6,   6,	6,	6,	6,	6,	6,
	6	,   6,	 6,	  6,   6,   6,  6,  6,  6,	6,
	6	,   6, 	 6,   6,   6,	6,	6,	6,	6,	6,
	6	,   6, 	 6,   6,   6,   6,  6,  6,  6
};
volatile unsigned int AkuYuzdeKapasite[2][151] 	__attribute__((far))= 			//Y�zde kapasite / 10  yap�lacak
{{																		//[0][x] --> 26 ak�l� y�zdeler
 	0  , 10, 12, 14, 16, 18, 20, 25, 30, 35,							//[1][x] --> 30 ak�l� y�zdeler
	40 , 50, 56, 60, 62, 64, 66, 68, 70, 75,
	80 , 82, 85, 88, 90, 95,100,105,110,115,
	130,150,160,170,180,183,187,190,195,200,
	205,210,220,225,230,240,300,320,330,360,
	390,410,480,490,500,520,590,620,680,760,
	790,800,803,808,810,812,814,815,816,818,
	820,822,824,825,826,827,828,829,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830
},
{
	0  , 10, 10, 10, 10, 10, 20, 20, 20, 30,
	30 , 40, 50, 50, 60, 60, 60, 60, 60, 60,
	70 , 70, 70, 80, 80, 80, 80, 90, 90, 90,
	100,100,110,110,130,150,160,160,170,180,
	180,180,190,190,190,200,200,210,220,220,
	230,240,270,300,320,330,360,390,410,450,
	480,490,500,520,590,620,680,750,760,790,
	800,800,800,800,810,810,810,810,810,810,
	820,820,820,820,820,820,820,820,820,820,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830,830,830,830,830,830,830,830,830,830,
	830
}};

//Yetki de�i�kenleri
volatile unsigned int YazmaYetkileri_Panel[12][2] = 
{
//Yetki : 0 --> Serbest , 1 --> Kullan�c� �ifresi , 2 --> Servis �ifresi 
//   Adres Yetki
	{ 2032 , 2 },		//Pfc Mod�l Se�enekleri
	{ 1046 , 1 },		//Inverter Mod�l Se�enekleri
	{ 1043 , 2 },		//Inv Fabrika Se�enekleri
	{ 1100 , 2 },		//�al��ma Modu
	{ 1101 , 2 },		//KGK nosu
	{ 1102 , 2 },		//N + 1 Minimum KGK
	{ 3406 , 0 },		//�n Panel Lisan�
	{ 3416 , 1 },		//Uyar� Kay�t , Durum Log Kay�t
	{ 3407 , 0 },		//Lcd Ayd�nl�k
	{ 3410 , 0 },		//Uyar� Ses Aral���
	{ 3408 , 0 },		//Parlak Kalma S�resi
	{ 3409 , 0 }		//Yar� Ayd�nl�k S�resi
};
volatile unsigned int YazmaYetkileri_Comm1[7][2] = 
{
//Yetki : 0 --> Serbest , 1 --> Kullan�c� �ifresi , 2 --> Servis �ifresi 
//   Adres Yetki
	{ 1046 , 1 },		//Inverter Mod�l Se�enekleri
	{ 3372 , 1 },		//�n Panel Lisan�					W3406
	{ 3392 , 1 },		//Uyar� Kay�t , Durum Log Kay�t		W3416
	{ 3374 , 1 },		//Lcd Ayd�nl�k						W3407
	{ 3380 , 1 },		//Uyar� Ses Aral���					W3410
	{ 3376 , 1 },		//Parlak Kalma S�resi				W3408
	{ 3378 , 1 }		//Yar� Ayd�nl�k S�resi				W3409
};

volatile unsigned int YazmaYetkileri_Comm2[12][2] = 
{
//Yetki : 0 --> Serbest , 1 --> Kullan�c� �ifresi , 2 --> Servis �ifresi 
//   Adres Yetki
	{ 2032 , 2 },		//Pfc Mod�l Se�enekleri
	{ 1046 , 1 },		//Inverter Mod�l Se�enekleri
	{ 1043 , 2 },		//Inv Fabrika Se�enekleri
	{ 1100 , 2 },		//�al��ma Modu
	{ 1101 , 2 },		//KGK nosu
	{ 1102 , 2 },		//N + 1 Minimum KGK
	{ 3372 , 1 },		//�n Panel Lisan�					W3406
	{ 3392 , 1 },		//Uyar� Kay�t , Durum Log Kay�t		W3416
	{ 3374 , 1 },		//Lcd Ayd�nl�k						W3407
	{ 3380 , 1 },		//Uyar� Ses Aral���					W3410
	{ 3376 , 1 },		//Parlak Kalma S�resi				W3408
	{ 3378 , 1 }		//Yar� Ayd�nl�k S�resi				W3409
};

volatile unsigned int YazmaYetkileri_Emir[7] =
{
	654,				//C - Shutdown �ptal
	638,				//T , T%% - K�sa Ak� Testi
	640,				//TL - Uzun Ak� Testi
	642,				//CT - Ak� Test �ptal
	626,				//INV - Y�k Inv de
	624,				//BYP - Y�k Byp de
	644					//BST - Boost �arja Ba�la
}; 


//EepromHaritas�
//--------------

//Labels
volatile struct Eeprom1 Label 			__attribute__((address(3072)));			//R3256
struct Eeprom2 EeKayit			__attribute__((address(3302)));			//R3371
volatile unsigned int EepromBosKontrol;

volatile unsigned int TftVersiyon			__attribute__((address(2600)));		//R3020	//Sabit de�erlerdir.Ba�lang��ta y�klenir.

//TFT de�i�kenleri
volatile struct Opcon100 TFT;
volatile unsigned char *BuffIci;

/*****************Picture****************/


//Degi�tirilebilen font �eklindedir.�stenilen pixel say�s�nda(8x8 , 5x8 ,vb.) yap�l�r.DegiskenFONTFonk() ile �al��t�r�l�r.
volatile unsigned char DegiskenFont[100][5] = 
    				    {{0x00, 0x00, 0x00, 0x00, 0x00}, // SPACE
                         {0x00, 0x00, 0x5F, 0x00, 0x00}, // !
                         {0x00, 0x03, 0x00, 0x03, 0x00}, // "
                         {0x14, 0x3E, 0x14, 0x3E, 0x14}, // #
                         {0x24, 0x2A, 0x7F, 0x2A, 0x12}, // $
                         {0x43, 0x33, 0x08, 0x66, 0x61}, // %
                         {0x36, 0x49, 0x55, 0x22, 0x50}, // &
                         {0x00, 0x05, 0x03, 0x00, 0x00}, // '
                         {0x00, 0x1C, 0x22, 0x41, 0x00}, // (
                         {0x00, 0x41, 0x22, 0x1C, 0x00}, // )
                         {0x14, 0x08, 0x3E, 0x08, 0x14}, // *
                         {0x08, 0x08, 0x3E, 0x08, 0x08}, // +
                         {0x00, 0x50, 0x30, 0x00, 0x00}, // ,
                         {0x08, 0x08, 0x08, 0x08, 0x08}, // -
                         {0x00, 0x60, 0x60, 0x00, 0x00}, // .
                         {0x20, 0x10, 0x08, 0x04, 0x02}, // /
                         {0x3E, 0x51, 0x49, 0x45, 0x3E}, // 0
                         {0x00, 0x04, 0x02, 0x7F, 0x00}, // 1
                         {0x42, 0x61, 0x51, 0x49, 0x46}, // 2
                         {0x22, 0x41, 0x49, 0x49, 0x36}, // 3
                         {0x18, 0x14, 0x12, 0x7F, 0x10}, // 4
                         {0x27, 0x45, 0x45, 0x45, 0x39}, // 5
                         {0x3E, 0x49, 0x49, 0x49, 0x32}, // 6
                         {0x01, 0x01, 0x71, 0x09, 0x07}, // 7
                         {0x36, 0x49, 0x49, 0x49, 0x36}, // 8
                         {0x26, 0x49, 0x49, 0x49, 0x3E}, // 9
                         {0x00, 0x36, 0x36, 0x00, 0x00}, // :
                         {0x00, 0x56, 0x36, 0x00, 0x00}, // ;
                         {0x08, 0x14, 0x22, 0x41, 0x00}, // <
                         {0x14, 0x14, 0x14, 0x14, 0x14}, // =
                         {0x00, 0x41, 0x22, 0x14, 0x08}, // >
                         {0x02, 0x01, 0x51, 0x09, 0x06}, // ?
                         {0x3E, 0x41, 0x59, 0x55, 0x5E}, // @
                         {0x7E, 0x09, 0x09, 0x09, 0x7E}, // A
                         {0x7F, 0x49, 0x49, 0x49, 0x36}, // B
                         {0x3E, 0x41, 0x41, 0x41, 0x22}, // C
                         {0x7F, 0x41, 0x41, 0x41, 0x3E}, // D
                         {0x7F, 0x49, 0x49, 0x49, 0x41}, // E
                         {0x7F, 0x09, 0x09, 0x09, 0x01}, // F
                         {0x3E, 0x41, 0x41, 0x49, 0x3A}, // G
                         {0x7F, 0x08, 0x08, 0x08, 0x7F}, // H
                         {0x00, 0x41, 0x7F, 0x41, 0x00}, // I
                         {0x30, 0x40, 0x40, 0x40, 0x3F}, // J
                         {0x7F, 0x08, 0x14, 0x22, 0x41}, // K
                         {0x7F, 0x40, 0x40, 0x40, 0x40}, // L
                         {0x7F, 0x02, 0x0C, 0x02, 0x7F}, // M
                         {0x7F, 0x02, 0x04, 0x08, 0x7F}, // N
                         {0x3E, 0x41, 0x41, 0x41, 0x3E}, // O
                         {0x7F, 0x09, 0x09, 0x09, 0x06}, // P
                         {0x1E, 0x21, 0x21, 0x21, 0x5E}, // Q
                         {0x7F, 0x09, 0x09, 0x09, 0x76}, // R
						 {0x26, 0x49, 0x49, 0x49, 0x32}, // S
                         {0x01, 0x01, 0x7F, 0x01, 0x01}, // T
                         {0x3F, 0x40, 0x40, 0x40, 0x3F}, // U
                         {0x1F, 0x20, 0x40, 0x20, 0x1F}, // V
                         {0x7F, 0x20, 0x10, 0x20, 0x7F}, // W
                         {0x41, 0x22, 0x1C, 0x22, 0x41}, // X
                         {0x07, 0x08, 0x70, 0x08, 0x07}, // Y
                         {0x61, 0x51, 0x49, 0x45, 0x43}, // Z
                         {0x00, 0x7F, 0x41, 0x00, 0x00}, // [
                         {0x02, 0x04, 0x08, 0x10, 0x20}, // \
                         {0x00, 0x00, 0x41, 0x7F, 0x00}, // ]
                         {0x04, 0x02, 0x01, 0x02, 0x04}, // ^
                         {0x40, 0x40, 0x40, 0x40, 0x40}, // _
                         {0x00, 0x01, 0x02, 0x04, 0x00}, // `
                         {0x00, 0x00, 0x00, 0x00, 0x00}, //Bo�
                         {0x20, 0x54, 0x54, 0x54, 0x78}, // a
                         {0x7F, 0x44, 0x44, 0x44, 0x38}, // b
                         {0x38, 0x44, 0x44, 0x44, 0x44}, // c
                         {0x38, 0x44, 0x44, 0x44, 0x7F}, // d
                         {0x38, 0x54, 0x54, 0x54, 0x18}, // e
                         {0x04, 0x04, 0x7E, 0x05, 0x05}, // f
                         {0x08, 0x54, 0x54, 0x54, 0x3C}, // g
                         {0x7F, 0x08, 0x04, 0x04, 0x78}, // h
                         {0x00, 0x44, 0x7D, 0x40, 0x00}, // i
                         {0x20, 0x40, 0x44, 0x3D, 0x00}, // j
                         {0x7F, 0x10, 0x28, 0x44, 0x00}, // k
                         {0x00, 0x41, 0x7F, 0x40, 0x00}, // l
                         {0x7C, 0x04, 0x78, 0x04, 0x78}, // m
                         {0x7C, 0x08, 0x04, 0x04, 0x78}, // n
                         {0x38, 0x44, 0x44, 0x44, 0x38}, // o
                         {0x7C, 0x14, 0x14, 0x14, 0x08}, // p
                         {0x08, 0x14, 0x14, 0x14, 0x7C}, // q
                         {0x00, 0x7C, 0x08, 0x04, 0x04}, // r
                         {0x48, 0x54, 0x54, 0x54, 0x20}, // s
                         {0x04, 0x04, 0x3F, 0x44, 0x44}, // t
                         {0x3C, 0x40, 0x40, 0x20, 0x7C}, // u
                         {0x1C, 0x20, 0x40, 0x20, 0x1C}, // v
                         {0x3C, 0x40, 0x30, 0x40, 0x3C}, // w
                         {0x44, 0x28, 0x10, 0x28, 0x44}, // x
                         {0x0C, 0x50, 0x50, 0x50, 0x3C}, // y
                         {0x44, 0x64, 0x54, 0x4C, 0x44}, // z
                         {0x00, 0x08, 0x36, 0x41, 0x41}, // {
                         {0x00, 0x00, 0x7F, 0x00, 0x00}, // |
                         {0x41, 0x41, 0x36, 0x08, 0x00}, // }
                         {0x02, 0x01, 0x02, 0x04, 0x02}, // ~
  						 {0x00, 0x44, 0x7d, 0x44, 0x00}, // � 		95
  						 {0x38, 0x45, 0x45, 0x55, 0x30}, // �		96
						 {0x06, 0x09, 0x09, 0x06, 0x00}, //Derece	97
  						 {0x38, 0x45, 0x44, 0x45, 0x38}, // �		98
  						 {0x38, 0x41, 0x40, 0x40, 0x3C}  // �		99
						 };

volatile unsigned char FONT[110][5] = 
    				    {{0x00, 0x00, 0x00, 0x00, 0x00}, // SPACE
                         {0x00, 0x00, 0x5F, 0x00, 0x00}, // !
                         {0x00, 0x03, 0x00, 0x03, 0x00}, // "
                         {0x14, 0x3E, 0x14, 0x3E, 0x14}, // #
                         {0x24, 0x2A, 0x7F, 0x2A, 0x12}, // $
                         {0x43, 0x33, 0x08, 0x66, 0x61}, // %
                         {0x36, 0x49, 0x55, 0x22, 0x50}, // &
                         {0x00, 0x05, 0x03, 0x00, 0x00}, // '
                         {0x00, 0x1C, 0x22, 0x41, 0x00}, // (
                         {0x00, 0x41, 0x22, 0x1C, 0x00}, // )
                         {0x14, 0x08, 0x3E, 0x08, 0x14}, // *
                         {0x08, 0x08, 0x3E, 0x08, 0x08}, // +
                         {0x00, 0x50, 0x30, 0x00, 0x00}, // ,
                         {0x08, 0x08, 0x08, 0x08, 0x08}, // -
                         {0x00, 0x60, 0x60, 0x00, 0x00}, // .
                         {0x20, 0x10, 0x08, 0x04, 0x02}, // /
                         {0x3E, 0x51, 0x49, 0x45, 0x3E}, // 0
                         {0x00, 0x04, 0x02, 0x7F, 0x00}, // 1
                         {0x42, 0x61, 0x51, 0x49, 0x46}, // 2
                         {0x22, 0x41, 0x49, 0x49, 0x36}, // 3
                         {0x18, 0x14, 0x12, 0x7F, 0x10}, // 4
                         {0x27, 0x45, 0x45, 0x45, 0x39}, // 5
                         {0x3E, 0x49, 0x49, 0x49, 0x32}, // 6
                         {0x01, 0x01, 0x71, 0x09, 0x07}, // 7
                         {0x36, 0x49, 0x49, 0x49, 0x36}, // 8
                         {0x26, 0x49, 0x49, 0x49, 0x3E}, // 9
                         {0x00, 0x36, 0x36, 0x00, 0x00}, // :
                         {0x00, 0x56, 0x36, 0x00, 0x00}, // ;
                         {0x08, 0x14, 0x22, 0x41, 0x00}, // <
                         {0x14, 0x14, 0x14, 0x14, 0x14}, // =
                         {0x00, 0x41, 0x22, 0x14, 0x08}, // >
                         {0x02, 0x01, 0x51, 0x09, 0x06}, // ?
                         {0x3E, 0x41, 0x59, 0x55, 0x5E}, // @
                         {0x7E, 0x09, 0x09, 0x09, 0x7E}, // A
                         {0x7F, 0x49, 0x49, 0x49, 0x36}, // B
                         {0x3E, 0x41, 0x41, 0x41, 0x22}, // C
                         {0x7F, 0x41, 0x41, 0x41, 0x3E}, // D
                         {0x7F, 0x49, 0x49, 0x49, 0x41}, // E
                         {0x7F, 0x09, 0x09, 0x09, 0x01}, // F
                         {0x3E, 0x41, 0x41, 0x49, 0x3A}, // G
                         {0x7F, 0x08, 0x08, 0x08, 0x7F}, // H
                         {0x00, 0x41, 0x7F, 0x41, 0x00}, // I
                         {0x30, 0x40, 0x40, 0x40, 0x3F}, // J
                         {0x7F, 0x08, 0x14, 0x22, 0x41}, // K
                         {0x7F, 0x40, 0x40, 0x40, 0x40}, // L
                         {0x7F, 0x02, 0x0C, 0x02, 0x7F}, // M
                         {0x7F, 0x02, 0x04, 0x08, 0x7F}, // N
                         {0x3E, 0x41, 0x41, 0x41, 0x3E}, // O
                         {0x7F, 0x09, 0x09, 0x09, 0x06}, // P
                         {0x1E, 0x21, 0x21, 0x21, 0x5E}, // Q
                         {0x7F, 0x09, 0x09, 0x09, 0x76}, // R
						 {0x26, 0x49, 0x49, 0x49, 0x32}, // S
                         {0x01, 0x01, 0x7F, 0x01, 0x01}, // T
                         {0x3F, 0x40, 0x40, 0x40, 0x3F}, // U
                         {0x1F, 0x20, 0x40, 0x20, 0x1F}, // V
                         {0x7F, 0x20, 0x10, 0x20, 0x7F}, // W
                         {0x41, 0x22, 0x1C, 0x22, 0x41}, // X
                         {0x07, 0x08, 0x70, 0x08, 0x07}, // Y
                         {0x61, 0x51, 0x49, 0x45, 0x43}, // Z
                         {0x00, 0x7F, 0x41, 0x00, 0x00}, // [
                         {0x02, 0x04, 0x08, 0x10, 0x20}, // \
                         {0x00, 0x00, 0x41, 0x7F, 0x00}, // ]
                         {0x04, 0x02, 0x01, 0x02, 0x04}, // ^
                         {0x40, 0x40, 0x40, 0x40, 0x40}, // _
                         {0x00, 0x01, 0x02, 0x04, 0x00}, // `
                         {0x00, 0x00, 0x00, 0x00, 0x00}, //Bo�
                         {0x20, 0x54, 0x54, 0x54, 0x78}, // a
                         {0x7F, 0x44, 0x44, 0x44, 0x38}, // b
                         {0x38, 0x44, 0x44, 0x44, 0x44}, // c
                         {0x38, 0x44, 0x44, 0x44, 0x7F}, // d
                         {0x38, 0x54, 0x54, 0x54, 0x18}, // e
                         {0x04, 0x04, 0x7E, 0x05, 0x05}, // f
                         {0x08, 0x54, 0x54, 0x54, 0x3C}, // g
                         {0x7F, 0x08, 0x04, 0x04, 0x78}, // h
                         {0x00, 0x44, 0x7D, 0x40, 0x00}, // i
                         {0x20, 0x40, 0x44, 0x3D, 0x00}, // j
                         {0x7F, 0x10, 0x28, 0x44, 0x00}, // k
                         {0x00, 0x41, 0x7F, 0x40, 0x00}, // l
                         {0x7C, 0x04, 0x78, 0x04, 0x78}, // m
                         {0x7C, 0x08, 0x04, 0x04, 0x78}, // n
                         {0x38, 0x44, 0x44, 0x44, 0x38}, // o
                         {0x7C, 0x14, 0x14, 0x14, 0x08}, // p
                         {0x08, 0x14, 0x14, 0x14, 0x7C}, // q
                         {0x00, 0x7C, 0x08, 0x04, 0x04}, // r
                         {0x48, 0x54, 0x54, 0x54, 0x20}, // s
                         {0x04, 0x04, 0x3F, 0x44, 0x44}, // t
                         {0x3C, 0x40, 0x40, 0x20, 0x7C}, // u
                         {0x1C, 0x20, 0x40, 0x20, 0x1C}, // v
                         {0x3C, 0x40, 0x30, 0x40, 0x3C}, // w
                         {0x44, 0x28, 0x10, 0x28, 0x44}, // x
                         {0x0C, 0x50, 0x50, 0x50, 0x3C}, // y
                         {0x44, 0x64, 0x54, 0x4C, 0x44}, // z
                         {0x00, 0x08, 0x36, 0x41, 0x41}, // {
                         {0x00, 0x00, 0x7F, 0x00, 0x00}, // |
                         {0x41, 0x41, 0x36, 0x08, 0x00}, // }
                         {0x02, 0x01, 0x02, 0x04, 0x02}, // ~
  						 {0x00, 0x44, 0x7d, 0x44, 0x00}, // � 		95
  						 {0x38, 0x45, 0x45, 0x55, 0x30}, // �		96
						 {0x06, 0x09, 0x09, 0x06, 0x00}, //Derece	97
  						 {0x38, 0x45, 0x44, 0x45, 0x38}, // �		98
  						 {0x3C, 0x41, 0x40, 0x41, 0x3C}, // �		99
  						 {0x3E, 0x41, 0xC1, 0x41, 0x22}, // �		100
  						 {0x26, 0x49, 0xC9, 0x49, 0x32}  // �		101
  						 };

volatile unsigned long name[] = 
{
	0xFBFEFF,0xFDFDFF,0xFFFEFF,0xFFFEFF,0xFDFFFF,0xFBFFFF,0xFDFFFF,0xFDFFFF,
	0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF
};

volatile unsigned long Buton[] = 
{
	0xFFFFFF,0xFEFEFE,0xFFFFFF,0xFDFDFD,0xFFFFFF,0xFBFBFB,0xFFFFFF,0xFDFDFD,
	0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFFFFFF,0xFEFEFE,0xFFFFFF,0xFFFFFF,0xFEFEFE
};
 
volatile unsigned long TextColor;
volatile unsigned long PixelColor;

volatile unsigned int GRADIENT;
volatile unsigned int GRADIENTCOLOR;
volatile unsigned long NOTGRADIENTCOLOR;
volatile unsigned int DIGITALTEXT;
volatile unsigned long TEXTCOLOR;
volatile unsigned long CLEARTEXTBACKCOLOR;
volatile unsigned long GRADIENTSTART;
volatile unsigned long TRANSPARIENT;
volatile unsigned int DIGITAL;
volatile unsigned int LINEREPEAT;

volatile unsigned int Xstart = 5;
volatile unsigned int Ystart = 30;
volatile unsigned int Xend = 475;
volatile unsigned int Yend = 265;
volatile unsigned int Sekme1 = 94;
volatile unsigned int Sekme2 = 188;
volatile unsigned int Sekme3 = 282;
volatile unsigned int Sekme4 = 376;
volatile unsigned int Sekme5 = 470;
volatile unsigned int SekmeHeight = 50;
volatile unsigned int NameY = 45;
volatile unsigned int NameEk = 10;


volatile unsigned int TftTimer;
volatile unsigned int TextBuffer[50];
volatile unsigned long TextBufferLong[10];
volatile unsigned int klm;//			__attribute__((address(3002)));	
volatile unsigned int klm2;//			__attribute__((address(3002)));	
volatile unsigned int PfVar;



volatile unsigned int Sifir = 0;
volatile unsigned int EmirMenuOrg[10][2]		__attribute__((far)) =
{
	// 0 + Menu.EnterBypOrInv = EmirMenu[0][5] ya da EmirMenu[1][5]
	{0,&Menu.EnterBypOrInv},	
	{2,&Menu.EnterStopBoost},
	{4,&Menu.EnterBattTest},
	{6,&Menu.RoleSimulasyonu},	
	{8,&Menu.ModemInitEt},	
	{10,&Menu.MaskeAlarmSesAcik}	
};
volatile unsigned int ServisMenuOrg[10][2]		__attribute__((far)) =
{
	// 0 + Menu.EnterBypOrInv = EmirMenu[0][5] ya da EmirMenu[1][5]
	{0,&Sifir},	
	{1,&Sifir},	
	{2,&Sifir},	
	{3,&Menu.FanBakimAktif},	
	{6,&Menu.AkuBakimAktif},
	{9,&Menu.GenelBakimAktif},
	{12,&Sifir}
};

volatile struct Mimik MimikDurum;

//Yeni eklendi.23.07.2012
volatile union Opcon39 Paralel;
//Yeni eklendi.06.09.2012
volatile union Opcon39 EskiParalel;
//Yeni eklendi.09.10.2012
volatile union Opcon39 CalismaDurumu;
volatile union Opcon39 EskiCalismaDurumu;

volatile unsigned int TftInitBackCounter;
volatile unsigned int TftInitButonSayac;
volatile unsigned int TftInitFlag;


//07.05.2014
volatile unsigned int UPS_I_O_Options					__attribute__((address(2604)));
//14.07.14
volatile unsigned int GucAraHesap;




/**************Touch Screen**************/
volatile int AbsisX;
volatile int OrdinatY;
volatile unsigned int PressCounterX = 0;
volatile unsigned int PressCounterY = 0;
//Filter
volatile unsigned int xSave[10];
volatile unsigned int ySave[10];
volatile unsigned int Probe[10];

volatile unsigned int NavigasyonuSil;
volatile unsigned int _TouchCount;
volatile unsigned int BekleCounter;
volatile unsigned int BuzzerGeriSayac;
volatile unsigned int BakimHesaplaFlag;

