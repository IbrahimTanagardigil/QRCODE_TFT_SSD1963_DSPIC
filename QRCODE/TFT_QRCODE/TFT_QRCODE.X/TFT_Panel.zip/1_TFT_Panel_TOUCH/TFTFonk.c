#include "p33FJ256MC710.h"

#include "TFTVar.h"
#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTCanPfc.h"
#include "TFTCanInv.h"
#include "TFTEeprom.h"
#include "TFTUart1.h"
#include "TFTRtc.h"
#include "BigTable.h"
#include "TFTTablo.h"
#include "TFTFonk.h"


void Loading(unsigned int L_x,unsigned int L_y,unsigned int L_x2,unsigned int L_r,unsigned long CerceveRenk,unsigned long BarRenk,unsigned long Renk_Art,unsigned int LoadingSifir)
{
	unsigned int L_i,L_Ara,L_yKare,L_y2,L_x3;
	unsigned long L_z;
	unsigned int Loop;
	
	//O b�lgeyi temizle
	if( LoadingSifir == 1 )
	{
		for( Loop = 0;Loop < (2*L_r);Loop++ )
			Line(L_x-1-L_r,L_x2+1+L_r,L_y-L_r+Loop,L_y-L_r+Loop,0xffffff,1);
	}
	else
	{
		Circle(L_x,L_y,L_r,0,13,CerceveRenk,0);
		Circle(L_x2,L_y,L_r,0,24,CerceveRenk,0);
		LINEREPEAT = 1;
		Line(L_x-1,L_x2+1,L_y-L_r,L_y-L_r,CerceveRenk,0);
		Line(L_x-1,L_x2+1,L_y+L_r,L_y+L_r,CerceveRenk,0);
		L_z = BarRenk;
		for(L_x3=1;L_x3<L_r;L_x3++)
		{
			L_Ara = (L_x3)*(L_r+L_r-L_x3);
			L_yKare = 0;L_y2 = 0;
			while(L_Ara > L_yKare)
			{
				L_y2++;
				L_yKare = L_y2 * L_y2; 
			}
	//		L_z += Renk_Art;
			//Renk s�n�rlar�
			if( L_z > 0xfffffe )
				L_z = 0xfffffe;
			Line(L_x+L_x3-L_r,L_x+L_x3-L_r,L_y-L_y2+1,L_y+L_y2-1,L_z,0);
			Circle(L_x,L_y,L_r,0,13,CerceveRenk,0);
			Wait(2000);
			asm("CLRWDT");
		}	
		for(L_i=0;L_i<(L_x2-L_x);L_i++)
		{
			Line(L_x+L_i,L_x+L_i,L_y-L_r+1,L_y+L_r-1,L_z,0);	
			Wait(2000);
			//Yar�s�na gelince koyudan a���a gelen bar a��ktan koyuya gider.
	//		if( L_i < (L_x2-L_x)/2)
	//			L_z += Renk_Art;
	//		else
	//			L_z -= Renk_Art;
			//Renk s�n�rlar�
	//		if( L_z > 0xfffffe )
	//			L_z = 0xfffffe;
	//		if( L_z < 1 )
	//			L_z = 1;
			asm("CLRWDT");
		}
		for(L_x3=0;L_x3<L_r;L_x3++)
		{
			L_Ara = (L_r-L_x3)*(L_r+L_x3);
			L_yKare = 0;L_y2 = 0;
			while(L_Ara > L_yKare)
			{
				L_y2++;
				L_yKare = L_y2 * L_y2; 
			}
	//		L_z -= Renk_Art;
			//Renk s�n�rlar�
	//		if( L_z < 1 )
	//			L_z = 1;
			Line(L_x2+L_x3,L_x2+L_x3,L_y-L_y2+1,L_y+L_y2-1,L_z,0);
			Circle(L_x2,L_y,L_r,0,24,CerceveRenk,0);
			Wait(2000);
			asm("CLRWDT");
		}
		LINEREPEAT = 2;
	}
}
////�uan Top var ekranda dola�an
//void EkranKoruyucu(void)
//{	
//	static int Yon_x = 1,Yon_y = 2;
//	
////	Circle(TFT.XAbsis,TFT.YOordinat,TFT.Radius,0,50,0xffffff,1);
//	ASendText(TFT.XAbsis,TFT.YOordinat,"TESCOM",2,0xffffff,NOTGRADIENTCOLOR,Clear);
//	//Sag
//	if( Yon_x == 1 )
//	{
//		TFT.XAbsis++;
//		//Yukari
//		if( Yon_y == 1 )
//			TFT.YOordinat--;
//		//Asagi
//		if( Yon_y == 2 )
//			TFT.YOordinat++;
//	}
//	//Sol
//	if( Yon_x == 2 )
//	{
//		TFT.XAbsis--;
//		//Yukari
//		if( Yon_y == 1 )
//			TFT.YOordinat--;
//		//Asagi
//		if( Yon_y == 2 )
//			TFT.YOordinat++;
//	}
//	if(TFT.XAbsis>458)
//		Yon_x = 2;
//	if(TFT.XAbsis<22)
//		Yon_x = 1;
//	if(TFT.YOordinat>250)
//		Yon_y = 1;
//	if(TFT.YOordinat<22)
//		Yon_y = 2;
////	Circle(TFT.XAbsis,TFT.YOordinat,TFT.Radius,0,50,0xffffff,0);
//	ASendText(TFT.XAbsis,TFT.YOordinat,"TESCOM",2,0xffffff,NOTGRADIENTCOLOR,NotClear);
//}

//�uan Top var ekranda dola�an
void EkranKoruyucu(void)
{	
	/* optimizasyon i�in
	static int Yon_x = 1,Yon_y = 2,Mode = 1;
	
//	Circle(TFT.XAbsis,TFT.YOordinat,TFT.Radius,0,50,0xffffff,1);
	//Sag

//	Circle(TFT.XAbsis,TFT.YOordinat,TFT.Radius,0,50,0xffffff,0);
	switch(Mode)
	{
		case 1:	
			TFT.OldYOordinat = TFT.YOordinat; TFT.OldXAbsis = TFT.XAbsis;
			if( Yon_x == 1 )
			{
				TFT.XAbsis++;
				//Yukari
				if( Yon_y == 1 )
					TFT.YOordinat-=2;
				//Asagi
				if( Yon_y == 2 )
					TFT.YOordinat+=2;
			}
			//Sol
			if( Yon_x == 2 )
			{
				TFT.XAbsis--;
				//Yukari
				if( Yon_y == 1 )
					TFT.YOordinat-=2;
				//Asagi
				if( Yon_y == 2 )
					TFT.YOordinat+=2;
			}
			if(TFT.XAbsis>458)
				Yon_x = 2;
			if(TFT.XAbsis<22)
				Yon_x = 1;
			if(TFT.YOordinat>250)
				Yon_y = 1;
			if(TFT.YOordinat<22)
				Yon_y = 2;	
		break;
		case 2:
			ASendText(TFT.OldXAbsis,TFT.OldYOordinat,"T",2,0xffffff,NOTGRADIENTCOLOR,Clear);
			ASendText(TFT.XAbsis,TFT.YOordinat,"T",2,0xffffff,NOTGRADIENTCOLOR,NotClear);	
		break;
		case 3:
			ASendText(TFT.OldXAbsis,TFT.OldYOordinat,"~E",2,0xffffff,NOTGRADIENTCOLOR,Clear);
			ASendText(TFT.XAbsis,TFT.YOordinat,"~E",2,0xffffff,NOTGRADIENTCOLOR,NotClear);	
		break;
		case 4:
			ASendText(TFT.OldXAbsis,TFT.OldYOordinat,"~~S",2,0xffffff,NOTGRADIENTCOLOR,Clear);
			ASendText(TFT.XAbsis,TFT.YOordinat,"~~S",2,0xffffff,NOTGRADIENTCOLOR,NotClear);	
		break;
		case 5:
			ASendText(TFT.OldXAbsis,TFT.OldYOordinat,"~~~C",2,0xffffff,NOTGRADIENTCOLOR,Clear);
			ASendText(TFT.XAbsis,TFT.YOordinat,"~~~C",2,0xffffff,NOTGRADIENTCOLOR,NotClear);
		break;
		case 6:
			ASendText(TFT.OldXAbsis,TFT.OldYOordinat,"~~~~O",2,0xffffff,NOTGRADIENTCOLOR,Clear);
			ASendText(TFT.XAbsis,TFT.YOordinat,"~~~~O",2,0xffffff,NOTGRADIENTCOLOR,NotClear);
		break;
		case 7:
			ASendText(TFT.OldXAbsis,TFT.OldYOordinat,"~~~~~M",2,0xffffff,NOTGRADIENTCOLOR,Clear);
			ASendText(TFT.XAbsis,TFT.YOordinat,"~~~~~M",2,0xffffff,NOTGRADIENTCOLOR,NotClear);	
			Mode = 0;
		break;
		default:
		break;
	}
	Mode++;
	*/
}



unsigned int AdcOku(unsigned int KANAL)
{
	unsigned int Sonuc;
	
	//SSRC bit = 111 implies 
	AD1CON1 = 0x00E0;										
	AD1CHS0 = KANAL;
	AD1CON2 = 0;

	AD1CON1bits.ADON = 1;
	AD1CON1bits.SAMP = 1;
	Genel.AdcKilit = 10;
	while(!AD1CON1bits.DONE)					//30.11.2012 de eklendi.
	{
		if( Genel.AdcKilit == 0 )				//30.11.2012 de eklendi.
			break;								//30.11.2012 de eklendi.
	};
	Sonuc = ADC1BUF0;

	return(Sonuc);
}
//-----------------------------------------------------------------Optimizasyon i�in
//12345  basamak s�ralamas� b�yle
unsigned int Dig(unsigned int _var,int _which)
{
	unsigned int cevap;
	
	switch(_which)
	{
		case 1:
				cevap = (_var / 10000) + 48;		
		break;
		case 2:
				cevap = ((_var % 10000) / 1000) + 48;
		break;
		case 3:
				cevap = (((_var % 10000) % 1000) / 100) + 48;
		break;
		case 4:
				cevap = ((((_var % 10000) % 1000) % 100) / 10) + 48;
		break;
		case 5:
				cevap = ((((_var % 10000) % 1000) % 100) % 10) + 48;
		break;
		default:
		break;
	}	
	return(cevap);
}

//-----------------------------------------------------------------Optimizasyon i�in
void AyarSecenekOK(unsigned int xx,unsigned int sil)
{			
//	LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
	ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,sil);
			
//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(90+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(90+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
	switch(xx)
	{
		case 0:
		//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(320,(90+272),">",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(40,(90+272),"<",2,0xffffff,NOTGRADIENTCOLOR,sil);
		break;
		case 1:
		//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
			ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,sil);
		break;
		case 2:
		//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,sil);
		break;
		case 3:
			ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,sil);
			ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,sil);
			Menu.EnterExit = 1;
		break;
		default:
		break;
	}	
}	

//-----------------------------------------------------------------Optimizasyon i�in
void AyarSecenekOK2(unsigned int xx2,unsigned int Sil2)
{
//		OkGoster(1,LokalAyarGrupAltMenu);
//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
	ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,Sil2);
//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
					
//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
	ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
	switch(xx2)
	{
		case 0:
	//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
			ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
			ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
		break;
		case 1:
		//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
			ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
		break;
		case 2:
		//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
			ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,Sil2);
			ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,Sil2);
			Menu.EnterExit = 1;
		break;
		default:
		break;
	}	
}

void OptimizasyonFonk1(unsigned int NameY_NameEk,unsigned int startbuff,unsigned int ClearNotClear)
{
	const unsigned int Buff[5] = {30,104,202,292,395};
	int uu;
	
	for(uu=0;uu<5;uu++)
		ASendText(Buff[uu],NameY_NameEk,AnaMenu[EeKayit.Dil][startbuff+uu],1,0xffffff,NOTGRADIENTCOLOR,ClearNotClear);
//	ASendText(30,NameY_NameEk,AnaMenu[EeKayit.Dil][startbuff],1,0xffffff,NOTGRADIENTCOLOR,ClearNotClear);
//	ASendText(104,NameY_NameEk,AnaMenu[EeKayit.Dil][startbuff+1],1,0xffffff,NOTGRADIENTCOLOR,ClearNotClear);
//	ASendText(202,NameY_NameEk,AnaMenu[EeKayit.Dil][startbuff+2],1,0xffffff,NOTGRADIENTCOLOR,ClearNotClear);
//	ASendText(292,NameY_NameEk,AnaMenu[EeKayit.Dil][startbuff+3],1,0xffffff,NOTGRADIENTCOLOR,ClearNotClear);
//	ASendText(395,NameY_NameEk,AnaMenu[EeKayit.Dil][startbuff+4],1,0xffffff,NOTGRADIENTCOLOR,ClearNotClear);
}		

void OptimizasyonFonk2(unsigned long Renk,unsigned int Clear_Not_Clear)
{
	ASendText(320,250,"-@-",2,Renk,NOTGRADIENTCOLOR,Clear_Not_Clear);
	ASendText(320,250+272,"-@-",2,Renk,NOTGRADIENTCOLOR,Clear_Not_Clear);
}

void OptimizasyonFonk3(unsigned long RENK,unsigned int Sil_)
{
	ASendText(425,272+100,"E",2,RENK,NOTGRADIENTCOLOR,Sil_);
	ASendText(425,272+130,"X",2,RENK,NOTGRADIENTCOLOR,Sil_);
	ASendText(425,272+160,"I",2,RENK,NOTGRADIENTCOLOR,Sil_);
	ASendText(425,272+190,"T",2,RENK,NOTGRADIENTCOLOR,Sil_);
}
void OptimizasyonFonk4(unsigned int Sill)
{
	BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,Sill);
	BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,Sill);
	BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,Sill);
}

void BakimHesapla(void)
{	
    unsigned int T4T5_i;
	
	Menu.BastanOnDkLikSayac++;
	EeKayit.OnDakika++;
	EeWordYaz(&EeKayit.OnDakika,EeKayit.OnDakika);
	if( EeKayit.OnDakika > 5 )
	{
		EeKayit.OnDakika = 0;
		EeKayit.ToplamSaat++;
		EeWordYaz(&EeKayit.OnDakika,EeKayit.OnDakika);
		EeWordYaz(&EeKayit.ToplamSaat,EeKayit.ToplamSaat);
		
		for(T4T5_i = 0;T4T5_i < 4;T4T5_i++)
		{
			//Bakim Alarmlar� geri sayac� ba�lamas�n diye 0 verilmi� de�er
//			if( EeKayit.Bakim[T4T5_i].AyarlananSure == 0 )
//			{
//				EeKayit.Bakim[T4T5_i].KalanSure = 0;
//				EeKayit.Bakim[T4T5_i].GecenSure = 0;
//				EeKayit.Bakim[T4T5_i].Iptal = 1;
//				//De�er s�f�r y�klendi�i an alarmlar susar.
//				//if( T4T5_i == DefYedekBakim )
//				//	Alarm.Word.Lcd1.Bit.OpsiyonBakimZamani = 0;
//				if( T4T5_i == DefFanBakim )
//					Alarm.Word.Lcd1.Bit.FanBakimZamani = 0;
//				if( T4T5_i == DefAkuBakim )
//					Alarm.Word.Lcd1.Bit.AkuBakimZamani = 0;
//				if( T4T5_i == DefGenelBakim )
//					Alarm.Word.Lcd1.Bit.GenelBakimZamani = 0;
//			}
			//Bakim Alarmlar� geri sayac� ba�lamas� i�in 0 dan b�y�k de�er verilmi�
//			else if( EeKayit.Bakim[T4T5_i].AyarlananSure > 0 )
			if( EeKayit.Bakim[T4T5_i].AyarlananSure > 0 )
			{
				EeKayit.Bakim[T4T5_i].Iptal = 0;
				EeKayit.Bakim[T4T5_i].GecenSure++;
				
				EeWordYaz( &EeKayit.Bakim[T4T5_i].Iptal , EeKayit.Bakim[T4T5_i].Iptal );
				EeWordYaz( &EeKayit.Bakim[T4T5_i].GecenSure , EeKayit.Bakim[T4T5_i].GecenSure );
				BakimAlarmKontrol(T4T5_i);
			}
		}
	}
			
//	TftInitBackCounter--;												//09.07.2013
//	if( TftInitBackCounter == 0 )										//09.07.2013
//	{		
//		PDC4 = 0 * 4500;			
//		InitTFT();
//		Menu.Yenile = 1;
//		PDC4 = EeKayit.LcdBacklight * 4500;		
//		TftInitBackCounter = 4;											//09.07.2013 TFT yeniden ba�latma i�in ar�za durumunda kullan�lacak.
//	}
//			
}