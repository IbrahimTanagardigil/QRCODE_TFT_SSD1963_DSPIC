#include "p33FJ256MC710.h"

#include "TFTDef.h"
#include "TFTVar.h"
#include "TFTUart2.h"
#include "TFTEeprom.h"
#include "TFTCanInv.h"
#include "TFTCanPfc.h"


void Uart2_Fonk( unsigned int *U2_Buf, unsigned int U2_Count)
{	
	unsigned int Uart2_i;
	unsigned int U2_ZamanCevap;
	unsigned int U2_AraIslem;
	unsigned int U2_SifreSayac = 0;
	unsigned int U2_Yetki;
	
	
	Uart2.Flag = 0;
	switch(U2_Count)
	{	
		case 2:
			// PC Uart program� i�in gerekli
			if(*U2_Buf == 'P')
			{
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}				
			else if(*U2_Buf == 'I')
			{
				//#CCCCCCCCCCCCCCC_MMMMMMMMMM_TX301SSSSS<chr13>
				for(Uart2_i = 0;Uart2_i < 15;Uart2_i++)
					Uart2.GonderBuf[Uart2_i] = Label.Firma[Uart2_i+1];
				for(Uart2_i = 0;Uart2_i < 10;Uart2_i++)
					Uart2.GonderBuf[Uart2_i + 15] = Label.Model[Uart2_i];
				for(Uart2_i = 0;Uart2_i < 10;Uart2_i++)
					Uart2.GonderBuf[Uart2_i + 25] = UartProtokol[Uart2_i];
				U2_Gonder("#$$$$$$$$$$$$$$$ $$$$$$$$$$ $$$$$$$$$$",Uart2.GonderBuf);
				break;
			}				
			else if (*U2_Buf == 'T')																//CONTROL COMMAND from PC  (Test batteries) 
			{		
				if( EeKayit.Konfig.Bit.UzakErisim )
				{			
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{					
						CanGonder(DefCanInv,28,'W',DefEmir_KisaAkuTestYap,0);					// command to UPS test Start
						U2_Gonder("OK", Uart2.Dumm );
						Megatech.T.TestForTenSec = 1;
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
				break;
			}					
			else if (*U2_Buf == 'Q') 															// Beeper on/off
			{		
				if( EeKayit.Konfig.Bit.UzakErisim )
				{			
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{																			// Response from UPS
						U2_Gonder("OK", Uart2.Dumm );											// command for beeper on / off 	
						//Yeni Bir alarma kadar buzzer sesini kapat	veya a�
						Megatech.Q.TurnBeep ^= 1;
						if( Menu.MaskeAlarmSesAcik == 0 )
							Menu.MaskeAlarmSesAcik = 1;
						else if( Menu.MaskeAlarmSesAcik == 1 )
							Menu.MaskeAlarmSesAcik = 0;
					//	Menu.EskiAlarmSesAcik = Menu.MaskeAlarmSesAcik;	
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
				break;
			}
			else if (*U2_Buf == 'C') 															//CONTROL COMMAND from PC  (Cancel shutdown)
			{		
				if( EeKayit.Konfig.Bit.UzakErisim )
				{				
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{	
						Timer6.ShutdownTime	= 0;
						Timer6.RestoreTime = 0;	
						Alarm.Word.Lcd2.Bit.Uyanacak = 0;
						Alarm.Word.Lcd2.Bit.Uykuyagirecek = 0;
						CanGonder(DefCanInv,28,'W',DefEmir_Uyan,0);		
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
				break;
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 3:	
		
			// PC Uart program� i�in gerekli
			if( (*U2_Buf == 'W') && (*(U2_Buf + 1) == 'P') )
			{
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}			
			else if( (*U2_Buf == 'L') && (*(U2_Buf + 1) == 'S') )
			{
				if( Can.FromInv.LogInDurum == 1 )
					U2_Gonder("OK", Uart2.Dumm );
				else
					U2_Gonder("LOUT", Uart2.Dumm );
				break;
			}	
			else if(*U2_Buf == 'D')
			{
				if( *(U2_Buf + 1) == '1' )
				{
					//!11111_22222_33333_44444_55555_66666_XXX_YYY<chr$13> 
					//!11111_22222_33333_44444_55555_66666_XXXX_YYYY<chr$13>  oldu
					Uart2.GonderBuf[0] = Alarm.Word.Inv1.All;		//Inv Alarmlar�
					Uart2.GonderBuf[1] = Alarm.Word.Inv2.All;		//Inv Uyar�lar� 1
					Uart2.GonderBuf[2] = Alarm.Word.Inv3.All;		//Inv Uyar�lar� 2
					Uart2.GonderBuf[3] = Alarm.Word.Pfc1.All;		//Pfc Alarmlar�
					Uart2.GonderBuf[4] = Alarm.Word.Pfc2.All;		//Pfc Uyar�lar�
					Uart2.GonderBuf[5] = Alarm.Word.Lcd1.All;		//Lcd Alarmlar�	
					Uart2.GonderBuf[6] = AlarmKod.Kod.Pfc;// - 1000;	//Pfc Kod
					Uart2.GonderBuf[7] = AlarmKod.Kod.Inv;			//Inv Kod
					U2_Gonder("!� � � � � � @ @",Uart2.GonderBuf);
					break;
				}	
				else if( *(U2_Buf + 1) == '2' )
				{		
					//AAA_BBB_CCC_DDD_EEE_FFF_GGG_HHH_JJJ_KKK_LLL_MMM_RRR_SSS_TTT_NN.N_PP.P<chr13>
					Uart2.GonderBuf[0] = Can.FromPfc.VinRMS.L1;									//Rectifier Input Voltage Line L1
					Uart2.GonderBuf[1] = Can.FromPfc.VinRMS.L2;									//Rectifier Input Voltage Line L2
					Uart2.GonderBuf[2] = Can.FromPfc.VinRMS.L3;									//Rectifier Input Voltage Line L3
					Uart2.GonderBuf[3] = Can.FromPfc.VinRMS.L1L3;								//Rectifier Input Voltage Line L1 - L3
					Uart2.GonderBuf[4] = Can.FromPfc.VinRMS.L2L1;								//Rectifier Input Voltage Line L2 - L1
					Uart2.GonderBuf[5] = Can.FromPfc.VinRMS.L3L2;								//Rectifier Input Voltage Line L3 - L2
					Uart2.GonderBuf[6] = Can.FromPfc.CinRMS.L1;									//L1 phase input current in amperes
					Uart2.GonderBuf[7] =Can.FromPfc.CinRMS.L2;									//L2 phase input current in amperes
					Uart2.GonderBuf[8] =Can.FromPfc.CinRMS.L3;									//L3 phase input current in amperes
					Uart2.GonderBuf[9] = Can.FromInv.VbypRMS.L1;								//L1 phase bypass input voltage in volts -- phase to neutral
					Uart2.GonderBuf[10] = Can.FromInv.VbypRMS.L2;								//L2 phase bypass input voltage in volts -- phase to neutral
					Uart2.GonderBuf[11] = Can.FromInv.VbypRMS.L3;								//L3 phase bypass input voltage in volts -- phase to neutral
					Uart2.GonderBuf[12] = Can.FromInv.VbypRMS.L1L3;								//L1 - L3 phase bypass input voltage in volts -- phase to neutral
					Uart2.GonderBuf[13] = Can.FromInv.VbypRMS.L2L1;								//L2 - L1 phase bypass input voltage in volts -- phase to neutral
					Uart2.GonderBuf[14] = Can.FromInv.VbypRMS.L3L2;								//L3 - L2 phase bypass input voltage in volts -- phase to neutral
					Uart2.GonderBuf[15] = Can.FromPfc.RecFreq;									//Measured L1 phase rectifier input frequency (1/10 Hertz)		
					Uart2.GonderBuf[16] = Can.FromInv.BypFreq;									//Measured by-pass input frequency (1/10 Hertz)
					U2_Gonder("?% % % % % % % % % % % % % % % ^ ^",Uart2.GonderBuf);
						
					break;					
				}
				else if( *(U2_Buf + 1) == '3' )
				{
					//?PPP_CCC_NNN_+BBB.B_+PPP.P_+SSS.S_RRR_TTT_UUU_KK_HHH<chr$13>
					Uart2.GonderBuf[0] = Can.FromPfc.RecDCBus.Pos + Can.FromPfc.RecDCBus.Neg;	//Total Battey Voltage in Volts
					Uart2.GonderBuf[1] = Can.FromPfc.RecDCBus.Pos;								//(+) battery group DC voltage
					Uart2.GonderBuf[2] = Can.FromPfc.RecDCBus.Neg;								//(-) battery group DC voltage
					
					if( Can.FromPfc.DisCbattC.Pos > 0 )
					{
						Uart2.GonderBuf[3] = '-';
						Uart2.GonderBuf[4] = Can.FromPfc.SonucDisCbattC.Pos;					//(+) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					else			
					{
						Uart2.GonderBuf[3] = '+';		
						Uart2.GonderBuf[4] = Can.FromPfc.CbattC.Pos;							//(+) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					if( Can.FromPfc.DisCbattC.Neg > 0 )
					{
						Uart2.GonderBuf[5] = '-';
						Uart2.GonderBuf[6] = Can.FromPfc.SonucDisCbattC.Neg;					//(-) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					else
					{				
						Uart2.GonderBuf[5] = '+';	
						Uart2.GonderBuf[6] = Can.FromPfc.CbattC.Neg;							//(-) battery current in amperes (+charge � discharge) (1/10 amps)
					}
					if( AyarBitAnlam.InvFactOpt.Bit.TempSensor == 0 )
					{
						if( EeKayit.TermalSensor1.Olculen > 32767)
						{	
							Uart2.GonderBuf[8] = 65536 - EeKayit.TermalSensor1.Olculen;			//measured battery ambient temperature (1/10 deg C)
							Uart2.GonderBuf[7] = '-';
						}
						else if( EeKayit.TermalSensor1.Olculen == 0 )
						{
							Uart2.GonderBuf[8] = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart2.GonderBuf[7] = ' ' - 48 ;
						}
						else
						{
							Uart2.GonderBuf[8] = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart2.GonderBuf[7] = '+';
						}
					}
					else																		//measured battery ambient temperature (1/10 deg C)
					{							
						if( Can.FromPfc.RecTemp > 32767)
						{
							Uart2.GonderBuf[8] = 65536 - Can.FromPfc.RecTemp;	
							Uart2.GonderBuf[7] = '-';
						}
						else if( Can.FromPfc.RecTemp == 0 )
						{
							Uart2.GonderBuf[8] = Can.FromPfc.RecTemp;	
							Uart2.GonderBuf[7] = ' ';
						}
						else
						{
							Uart2.GonderBuf[8] = Can.FromPfc.RecTemp;	
							Uart2.GonderBuf[7] = '+';
						}
					}
					if(( Alarm.Word.Pfc1.Bit.SebekeKesik == 1 ) && (AkuKapasite.IlkDakikaGecti == 1))
						Uart2.GonderBuf[9] = AkuKapasite.KalanSure;
					else
						Uart2.GonderBuf[9] = EeKayit.AkuSabitKalanSure;
				//	Uart2.GonderBuf[9] = Menu.AkuKalanSure;										//estimated battery backup time
					Uart2.GonderBuf[10] = Can.FromPfc.RecDCBus.Pos;								//Measured (+)DC BUS voltage
					Uart2.GonderBuf[11] = Can.FromPfc.RecDCBus.Neg;								//Measured (-)DC BUS voltage
					Uart2.GonderBuf[12] = EeKayit.AkuKolSayisi;									//Battery groups
					Uart2.GonderBuf[13] = EeKayit.AkuAh;										//Battery A/H rating
					U2_Gonder("?% % % $� $� $� % % % ] %",Uart2.GonderBuf);
					break;
				}
				else if( *(U2_Buf + 1) == '4' )
				{		
					//?AAA_BBB_CCC_DDD_EEE_GGG_HHH_III_JJJ_FF.F_KKK_MMM_NNN<chr$13>
					Uart2.GonderBuf[0] = Can.FromInv.VinvRMS.L1;								//L1 phase AC inverter output voltage  / phase to neutral
					Uart2.GonderBuf[1] = Can.FromInv.VinvRMS.L2;								//L2 phase AC inverter output voltage  / phase to neutral
					Uart2.GonderBuf[2] = Can.FromInv.VinvRMS.L3;								//L3 phase AC inverter output voltage  / phase to neutra
					Uart2.GonderBuf[3] = Can.FromInv.VoutRMS.L1;								//L1 phase AC UPS output voltage  / phase to neutral
					Uart2.GonderBuf[4] = Can.FromInv.VoutRMS.L2;								//L2 phase AC UPS output voltage  / phase to neutral
					Uart2.GonderBuf[5] = Can.FromInv.VoutRMS.L3;								//L3 phase AC UPS output voltage  / phase to neutral
					Uart2.GonderBuf[6] = Can.FromInv.VinvRMS.L1L3;								//L1-L3 phase AC UPS output voltage / phase to phase
					Uart2.GonderBuf[7] = Can.FromInv.VinvRMS.L2L1;								//L2-L1 phase AC UPS output voltage / phase to phase
					Uart2.GonderBuf[8] = Can.FromInv.VinvRMS.L3L2;								//L3-L2 phase AC UPS output voltage / phase to phase
					Uart2.GonderBuf[9] = Can.FromInv.OutFreq;									//UPS output frequency in hertz (1/10 Hertz)
					Uart2.GonderBuf[10] = Can.FromInv.CoutRMS.L1;								//L1 phase UPS output current in amperes
					Uart2.GonderBuf[11] = Can.FromInv.CoutRMS.L2;								//L2 phase UPS output current in amperes
					Uart2.GonderBuf[12] = Can.FromInv.CoutRMS.L3;								//L3 phase UPS output current in amperes
					U2_Gonder("?% % % % % % % % % ^ % % %",Uart2.GonderBuf);	
					break;					
				}
				else if( *(U2_Buf + 1) == '5' )
				{						
					//?AAA_BBB_CCC_DDD.D_EEE.E_GGG.G_H.H_J.J_K.K_M.M_N.N_P.P<chr$13>
					Uart2.GonderBuf[0] = Can.FromInv.Load.L1;									//L1 phase load percentage 
					Uart2.GonderBuf[1] = Can.FromInv.Load.L2;									//L2 phase load percentage
					Uart2.GonderBuf[2] = Can.FromInv.Load.L3;									//L3 phase load percentage
					Uart2.GonderBuf[3] = Can.FromInv.PowerWatt.L1;								//L1 phase UPS output power in kWA 
					Uart2.GonderBuf[4] = Can.FromInv.PowerWatt.L2;								//L2 phase UPS output power in kWA 
					Uart2.GonderBuf[5] = Can.FromInv.PowerWatt.L3;								//L3 phase UPS output power in kWA 
					Uart2.GonderBuf[6] = Can.FromInv.Pf.L1 / 10;								//L1 phase output power factor
					Uart2.GonderBuf[7] = Can.FromInv.Pf.L2 / 10;								//L2 phase output power factor
					Uart2.GonderBuf[8] = Can.FromInv.Pf.L3 / 10;								//L3 phase output power factor
					Uart2.GonderBuf[9] = Can.FromInv.CrestFactor.L1;							//L1 phase load krest factor
					Uart2.GonderBuf[10] = Can.FromInv.CrestFactor.L2;							//L2 phase load krest factor
					Uart2.GonderBuf[11] = Can.FromInv.CrestFactor.L3;							//L3 phase load krest factor
					U2_Gonder("?% % % � � � | | | | | |",Uart2.GonderBuf);	
					break;					
				}
				else if( *(U2_Buf + 1) == '6' )
				{		
					//?AAA.A_BBB.B_CCC.C_FFFFF_MMMMM_GGGGG_NNNNN_DDDDDD_HH:HH_PPP<chr$13>
					Uart2.GonderBuf[0] = EeKayit.TermalSensor1.Olculen;							//TH1 temp sensor temperature  (1/10 deg C)
					Uart2.GonderBuf[1] = EeKayit.TermalSensor2.Olculen;							//TH2 temp sensor temperature  (1/10 deg C)
					Uart2.GonderBuf[2] = Can.FromPfc.RecTemp;									//TH3 temp sensor temperature   (1/10 deg C)
					Uart2.GonderBuf[3] = EeKayit.Bakim[DefFanBakim].KalanSure;					//Fan maintenance counter
					Uart2.GonderBuf[4] = EeKayit.Bakim[DefAkuBakim].KalanSure;					//Battery maintenance counter
					Uart2.GonderBuf[5] = EeKayit.Bakim[DefGenelBakim].KalanSure;				//General maintenance counter
					Uart2.GonderBuf[6] = EeKayit.Bakim[DefYedekBakim].KalanSure;				//Optional maintenance counter
					Uart2.GonderBuf[7] = Can.ToInv.Date_2.Day;
					Uart2.GonderBuf[8] = Can.ToInv.Date_2.Month;
					Uart2.GonderBuf[9] = Can.ToInv.Date_2.Year;
					Uart2.GonderBuf[10] = Can.ToInv.Date_2.Hour;
					Uart2.GonderBuf[11] = Can.ToInv.Date_2.Min;  
					Uart2.GonderBuf[12] = 0;													//Relative ambient humidity (Ba��l ortam nemi)
					U2_Gonder("?� � � � � � � ]]] ]:] %",Uart2.GonderBuf);	
					break;
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
					break;
				}		
			}
			else if ( (*U2_Buf == 'F') && (*(U2_Buf + 1) == '2') )
			{
				//#III/FFF_BBB/CCC_XXX/YYY_RR/EE_BBB_GG_UMRFNU_PPPPPP_RRRRRR<chr$13>
				for(Uart2_i = 0;Uart2_i < 23;Uart2_i++)											//Nominal values
					Uart2.GonderBuf[Uart2_i] = Label.NominalVoltage[Uart2_i];
					
				Uart2.GonderBuf[23] = Uart2.NumOfPhaseIn = 3;									//Input phases (options : 1P or 3P)
				Uart2.GonderBuf[24] = Uart2.NumOfPhaseOut;									//Output phases (options : 1P or 3P)
				Uart2.GonderBuf[25] = Can.FromInv.AkuSayisi;									//Number of 12 volts batteries in 1 group
				Uart2.GonderBuf[26] = Uart2.DeviceType = 0;										//Device type �0�=UPS ,�1�=converter
				Uart2.GonderBuf[27] = Can.FromInv.CalismaModu;									//Device Operation mode														
				Uart2.GonderBuf[28] = Uart2.BypassConfig = 1;									//Bypass configuration �0�=bypass not installed ,�1�=bypass installed
				Uart2.GonderBuf[29] = Uart2.BattConfig = 2;										//Battery �0�= not installed �1�=batteries installed �2�=2 battery group
				Uart2.GonderBuf[30] = Can.FromInv.N_1MinUps;									//N+1 min�mum UPS
				Uart2.GonderBuf[31] = Can.FromInv.KGKNo;										//UPS no
				
				for(Uart2_i = 0;Uart2_i < 6;Uart2_i++)
					Uart2.GonderBuf[Uart2_i + 32] = Label.SaseNo[Uart2_i];
				for(Uart2_i = 0;Uart2_i < 6;Uart2_i++)
					Uart2.GonderBuf[Uart2_i + 38] = Label.OutputPower[Uart2_i];
					
				U2_Gonder("#$$$$$$$$$$$$$$$$$$$$$$$ [P/[P % [[[[[[ $$$$$$ $$$$$$",Uart2.GonderBuf);
				break;
			}			
			else if( (*U2_Buf == 'T') && (*(U2_Buf + 1) == 'L') )
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{	
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{		
						Megatech.TL.TestUntilBattLow = 1;
						CanGonder(DefCanInv,28,'W',DefEmir_UzunAkuTestYap,0);	
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else
					U2_Gonder("ACCDE", Uart2.Dumm );
				break;
			}
			else if ((*U2_Buf == 'C') && (*(U2_Buf+1) == 'T'))										//CONTROL COMMAND from PC  (Cancel battery test)		
			{				 					
				if( EeKayit.Konfig.Bit.UzakErisim )				
				{		
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{	
						CanGonder(DefCanInv,28,'W',DefEmir_AkuTestIptal,0);	
						U2_Gonder("OK", Uart2.Dumm );	
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}					
				}
				else 
					U2_Gonder("ACCDE",Uart2.Dumm );
				break;
			}		
			else if(*U2_Buf == 'G')
			{
				if(*(U2_Buf + 1) == '1')
				{
					if( AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1 == 1 )
					{
						//TH1
						if( EeKayit.TermalSensor1.Olculen > 32767)
						{	
							Megatech.G1.Temperature = 65536 - EeKayit.TermalSensor1.Olculen;			//measured battery ambient temperature (1/10 deg C)
							Uart2.GonderBuf[4] = '-';
						}
						else if( EeKayit.TermalSensor1.Olculen == 0 )
						{
							Megatech.G1.Temperature = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart2.GonderBuf[4] = ' ';
						}
						else
						{
							Megatech.G1.Temperature = EeKayit.TermalSensor1.Olculen;					//measured battery ambient temperature (1/10 deg C)
							Uart2.GonderBuf[4] = '+';
						}
					}
					else																		//measured battery ambient temperature (1/10 deg C)
					{			
						//TH3				
						if( Can.FromPfc.RecTemp > 32767)
						{
							Megatech.G1.Temperature = 65536 - Can.FromPfc.RecTemp;	
							Uart2.GonderBuf[4] = '-';
						}
						else if( Can.FromPfc.RecTemp == 0 )
						{
							Megatech.G1.Temperature = Can.FromPfc.RecTemp;	
							Uart2.GonderBuf[4] = ' ';
						}
						else
						{
							Megatech.G1.Temperature = Can.FromPfc.RecTemp;	
							Uart2.GonderBuf[4] = '+';
						}
					}					
					//if( Alarm.Word.Pfc1.Bit.SebekeKesik ) DisCharge d�r			//GErekirse denenebilir.
					if( Can.FromPfc.DisCbattC.Pos > 0 )								//For Discharge mode
						Megatech.G1.BattCurrChrgDChrg = Can.FromPfc.SonucDisCbattC.Pos + Can.FromPfc.SonucDisCbattC.Neg;
					else															//For Charge mode
						Megatech.G1.BattCurrChrgDChrg = Can.FromPfc.CbattC.Pos + Can.FromPfc.CbattC.Neg;
					Megatech.G1.BattVoltg = Can.FromPfc.RecDCBus.Pos + Can.FromPfc.RecDCBus.Neg;
					
					Megatech.G1.BattCapPer = AkuKapasite.KalanAkuKap;
					
					if(( Alarm.Word.Pfc1.Bit.SebekeKesik == 1 ) && (AkuKapasite.IlkDakikaGecti == 1))
						Megatech.G1.BattTimeRem = AkuKapasite.KalanSure;
					else
						Megatech.G1.BattTimeRem = EeKayit.AkuSabitKalanSure;					
					
					Megatech.G1.FreqOfBypSource = Can.FromInv.BypFreq;
					Megatech.G1.IPFreq = Can.FromPfc.RecFreq;
					Megatech.G1.OPFreq = Can.FromInv.OutFreq;
					
					Uart2.GonderBuf[0] = Megatech.G1.BattVoltg;						//Battery Voltage 								SSS		000		-	999
					Uart2.GonderBuf[1] = Megatech.G1.BattCapPer;					//Battery Capacity Percentage					PPP		000		-	100
					Uart2.GonderBuf[2] = Megatech.G1.BattTimeRem;					//Battery Time Remaining						NNNN	0000	-	9999
					Uart2.GonderBuf[3] = Megatech.G1.BattCurrChrgDChrg;				//Battery Current Charge and Discharge mode		RRR.R	000.0	-	999.9	Depends on Megatech.G2.a2
					Uart2.GonderBuf[5] = Megatech.G1.Temperature;					//Temperature									+TT.T	-99.9	-	+99.9
					Uart2.GonderBuf[6] = Megatech.G1.IPFreq;						//I / P Frequency								FF.F	00.0	-	99.9
					Uart2.GonderBuf[7] = Megatech.G1.FreqOfBypSource;				//Frequency of Bypass Source					EE.E	00.0	-	99.9
					Uart2.GonderBuf[8] = Megatech.G1.OPFreq;						//O / P Frequency 													//Output Load Percentage (zero for this version)
											
					//UPS : !SSS PPP NNNN RRR.R +TT.T FF.F EE.E QQ.Q<13>
					//UPS : !SSS PPP NNNN RRR.R -TT.T FF.F EE.E QQ.Q<13>
					U2_Gonder("!% % @ � $^ ^ ^ ^",Uart2.GonderBuf);				//Temperature difference
					break;
				}
				if(*(U2_Buf + 1) == '2')											//Logic 0						Logic 1	
				{																	//--------					-	--------------
					Megatech.G2.a7 = 0;
					Megatech.G2.a6 = Alarm.Word.Pfc1.Bit.FazCevir;
					Megatech.G2.a5 = Alarm.Word.Inv1.Bit.AkuZayifKes;
					Megatech.G2.a4 = Alarm.Word.Inv2.Bit.AkuZayif;
					Megatech.G2.a3 = 0;
					Megatech.G2.a2 = (Alarm.Word.Pfc1.Bit.SebekeKesik | Alarm.Word.Pfc1.Bit.AcGirisYuksek);
					Megatech.G2.a1 = Alarm.Word.Pfc2.Bit.BoostSarj;
					Megatech.G2.a0 = ~Alarm.Word.Pfc2.Bit.PfcDurakladi;

					Megatech.G2.b7 = 0;
					Megatech.G2.b6 = 0;
					Megatech.G2.b5 = 0;
					Megatech.G2.b4 = Alarm.Word.Inv2.Bit.BypassFrekans;
					Megatech.G2.b3 = Alarm.Word.Inv1.Bit.Bakimda;
					Megatech.G2.b2 = ~(Alarm.Word.Inv2.Bit.BypassKesik | Alarm.Word.Inv2.Bit.BypassVolt);
					Megatech.G2.b1 = ~Alarm.Word.Inv2.Bit.CikisBypassta;
					Megatech.G2.b0 = ~Alarm.Word.Inv3.Bit.InvStop;

					Megatech.G2.c7 = 0;
					Megatech.G2.c6 = Alarm.Word.Inv1.Bit.AcilKapatma;
					Megatech.G2.c5 = Alarm.Word.Inv1.Bit.AkuYuksek;
					Megatech.G2.c4 = 0;
					Megatech.G2.c3 = Alarm.Word.Inv1.Bit.AsiriYukKes;
					Megatech.G2.c2 = 0;
					Megatech.G2.c1 = Alarm.Word.Inv1.Bit.AsiriIsiKes;
					Megatech.G2.c0 = Alarm.Word.Inv1.Bit.KisaDevre;


					Uart2.GonderBuf[0] = Megatech.G2.a7;							//Not used
					Uart2.GonderBuf[1] = Megatech.G2.a6;							//Normal					-	Rectifier Rotation Err
					Uart2.GonderBuf[2] = Megatech.G2.a5;							//Normal					-	Low Battery Shutdown
					Uart2.GonderBuf[3] = Megatech.G2.a4;							//Normal					-	Low Battery
					Uart2.GonderBuf[4] = Megatech.G2.a3;							//Not used				-	Three in/out
					Uart2.GonderBuf[5] = Megatech.G2.a2;							//AC Normal					-	Back Up		
					Uart2.GonderBuf[6] = Megatech.G2.a1;							//Float Charge				-	Boost Charge
					Uart2.GonderBuf[7] = Megatech.G2.a0;							//Rectifier Stop			-	Rectifier Operating
														
					Uart2.GonderBuf[8] = Megatech.G2.b7;							//Not used
					Uart2.GonderBuf[9] = Megatech.G2.b6;							//Not used
					Uart2.GonderBuf[10] = Megatech.G2.b5;							//Not used
					Uart2.GonderBuf[11] = Megatech.G2.b4;							//Bypass Freq OK			-	Bypass Freq Fail
					Uart2.GonderBuf[12] = Megatech.G2.b3;							//Manual Byp.Breaker Open	-	Manual Byp.Breaker On
					Uart2.GonderBuf[13] = Megatech.G2.b2;							//Bypass AC Abnormal		-	Bypass AC Normal
					Uart2.GonderBuf[14] = Megatech.G2.b1;							//Static switch in byp. mode-	Static Switch in Inver
					Uart2.GonderBuf[15] = Megatech.G2.b0;							//The fault condition of Inv-	Inverter Operation

					Uart2.GonderBuf[16] = Megatech.G2.c7;							//Not Used
					Uart2.GonderBuf[17] = Megatech.G2.c6;							//Normal					-	Emergency Stop (EPO)
					Uart2.GonderBuf[18] = Megatech.G2.c5;							//Normal					-	High DC Shutdown
					Uart2.GonderBuf[19] = Megatech.G2.c4;							//Not used					-	Manual Bypass Breaker 
					Uart2.GonderBuf[20] = Megatech.G2.c3;							//Normal					-	Over load shutdown
					Uart2.GonderBuf[21] = Megatech.G2.c2;							//Not used					-	Inverter O/P Fail shut
					Uart2.GonderBuf[22] = Megatech.G2.c1;							//Normal					-	Over Temperature shutd
					Uart2.GonderBuf[23] = Megatech.G2.c0;							//Normal					-	Short Circuit Shutdown
					//UPS : !a7a6a5a4a3a2a1a0 b7b6b5b4b3b2b1b0 c7c6c5c4c3c2c1c0<13>
					U2_Gonder("![[[[[[[[ [[[[[[[[ [[[[[[[[",Uart2.GonderBuf);
					break;
				}
				if(*(U2_Buf + 1) == '3')
				{
					Uart2.GonderBuf[0] = Megatech.G3.IPVoltageR;					//I/P voltage of R Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[1] = Megatech.G3.IPVoltageS;					//I/P voltage of S Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[2] = Megatech.G3.IPVoltageT;					//I/P voltage of T Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[3] = Megatech.G3.BypVoltageR;					//Byp voltage of R Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[4] = Megatech.G3.BypVoltageS;					//Byp voltage of S Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[5] = Megatech.G3.BypVoltageT;					//Byp voltage of T Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[6] = Megatech.G3.OPVoltageR;					//O/P voltage of R Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[7] = Megatech.G3.OPVoltageS;					//O/P voltage of S Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[8] = Megatech.G3.OPVoltageT;					//O/P voltage of T Phase						NNN.N	000.0	-	999.9
					Uart2.GonderBuf[9] = Megatech.G3.LoadPercentageR;				//Load Percentage of R Phase					NNN.N	000.0	-	999.9
					Uart2.GonderBuf[10] = Megatech.G3.LoadPercentageS;				//Load Percentage of S Phase					NNN.N	000.0	-	999.9
					Uart2.GonderBuf[11] = Megatech.G3.LoadPercentageT;				//Load Percentage of T Phase					NNN.N	000.0	-	999.9
					//UPS : !NNN.N/NNN.N/NNN.N PPP.P/PPP.P/PPP.P QQQ.Q/QQQ.Q/QQQ.Q SSS.S/SSS.S/SSS.S<13>
					U2_Gonder("!�/�/� �/�/� �/�/� �/�/�",Uart2.GonderBuf);
					break;
				}
				if(*(U2_Buf + 1) == 'F')
				{
					Megatech.GF.RecVoltPToN = 220;
					Megatech.GF.RecVoltPToP	= 380;
					Megatech.GF.RecFreq = 50;						
					Megatech.GF.BypVoltPToN = 220;
					Megatech.GF.BypVoltPToP = 380;
					Megatech.GF.BypFreq = 50;;	
					Megatech.GF.OPVoltPToN = 220;
					Megatech.GF.OPVoltPToP = 380;
					Megatech.GF.OPFreq = 50;	
					Megatech.GF.BattVoltage = (Can.FromInv.AkuSayisi * 12) * 2;
					Megatech.GF.PowerRate = (Label.OutputPower[0] - 48) * 10 + (Label.OutputPower[1] - 48);
					

					Uart2.GonderBuf[0] = Megatech.GF.RecVoltPToN;					//Rectifier Voltage of Ph To N					220	
					Uart2.GonderBuf[1] = Megatech.GF.RecVoltPToP;					//Rectifier Voltage of Ph To Ph					380
					Uart2.GonderBuf[2] = Megatech.GF.RecFreq;						//Rectifier Frequency							CCC	- 050
					Uart2.GonderBuf[3] = Megatech.GF.BypVoltPToN;					//Bypass Source Voltage of Ph To N				220
					Uart2.GonderBuf[4] = Megatech.GF.BypVoltPToP;					//Bypass Source Voltage of Ph To Ph				380
					Uart2.GonderBuf[5] = Megatech.GF.BypFreq;						//Bypass Source Frequency						FFF	- 050
					Uart2.GonderBuf[6] = Megatech.GF.OPVoltPToN;					//O/P Voltage of Ph To N						220
//					Uart2.GonderBuf[7] = Megatech.GF.OPVoltPToP;					//O/P Voltage of Ph To Ph						380
					Uart2.GonderBuf[7] = Megatech.GF.OPFreq;						//O/P Frequency									QQQ
					Uart2.GonderBuf[8] = Megatech.GF.BattVoltage;					//Battery Voltage								SSS
					Uart2.GonderBuf[9] = Megatech.GF.PowerRate;						//Power Rating									xxxxxxxxxx (10 characters)
					//UPS : !220V/380V 3P4W 060 220V/380V 3P4W 061 220V/3P3W      060 396 150KVA    <13>
					U2_Gonder("!%V/%V 3P4W % %V/%V 3P4W % %V/3P3W      % % %KVA    ",Uart2.GonderBuf);
					break;
				}
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 4:		
			if ((*U2_Buf == 'T') && (*(U2_Buf + 1) == 'I') && (*(U2_Buf + 2)== 'M'))
			{
				OkuRTC(&Date4);
				Uart2.GonderBuf[0] = Date4.Day;
				Uart2.GonderBuf[1] = Date4.Month;
				Uart2.GonderBuf[2] = Date4.Year;
				Uart2.GonderBuf[3] = Date4.Hour;
				Uart2.GonderBuf[4] = Date4.Min;
				
				U2_Gonder("]]] ]:]",Uart2.GonderBuf);
				break;
			}	
			else if ((*U2_Buf == 'C') && (*(U2_Buf + 1) == 'H') && (*(U2_Buf + 2)== 'K'))
			{
				Uart2.ChkSorgusuGeldi = 1;
				U2_Gonder("�", &Uart2.CheckSum );
				Uart2.ChkSorgusuGeldi = 0;
				break;
			}
			//Sxx<13> gelecek uart tan ve xx dakika i�eriside uyu yani shutdown emri g�nderilecek.
			else if ((*U2_Buf == 'S'))			
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{					
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{		
						if( *(U2_Buf + 1) != '.' )		
						{					
							Timer6.ShutdownTime = ((*(U2_Buf + 1) - 48) * 10 + (*(U2_Buf + 2) - 48)) * 60;
							if( Timer6.ShutdownTime == 0 )
								CanGonder(DefCanInv,28,'W',DefEmir_Uyu,0);
						}	
						else if( *(U2_Buf + 1) == '.' )		
							Timer6.ShutdownTime = ( 6 * (*(U2_Buf + 2) - 48) );
							
						Timer6.RestoreTime = 0;
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
				break;
			}
			//Txx<13> gelecek uart tan fakat buradan sadece k�sa test emri gidecek.
			else if ((*U2_Buf == 'T'))			
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{				
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{					
						if((*(U2_Buf + 1) > 47) && (*(U2_Buf + 1) < 58))
						{
							if((*(U2_Buf + 2) > 47) && (*(U2_Buf + 2) < 58))
							{									
								CanGonder(DefCanInv,28,'W',DefEmir_KisaAkuTestYap,0);					// command to UPS test Start
								U2_Gonder("OK", Uart2.Dumm );
								Megatech.T.TestForTenSec = 1;
							}
							else
							{
								U2_Gonder("ERROR",Uart2.Dumm );
								break;
							}
						}
						else
						{
							U2_Gonder("ERROR",Uart2.Dumm );
							break;
						}
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
			}
			else if ((*U2_Buf == 'K') && (*(U2_Buf + 1) == 'O') && (*(U2_Buf + 2) == 'D'))			
			{
				if( Can.FromInv.LogInDurum == 0 )
				{ 
					if( Uart2.PassWordHataliGeriSayac == 0 )
					{
						if( Uart2.KodIslemiGeriSayac == 0 )
						{
							//Yeni kod �ret ve �ifre de�i�tir.
							SifreAl();
							//Merkezi kod �ifresi ge�erli yani Kod Gen 1. sat�rda yaz�lacak
							if( Can.FromInv.SifreSistemi == 1 )
							{
								//Yeni servis kodlar�n� g�nder
								Uart2.GonderBuf[0] = Menu.ServisKodH;
								Uart2.GonderBuf[1] = Menu.ServisKodL;
								//3 sn lik saya� ba�lat
								Uart2.KodIslemiGeriSayac = 60;
								//Kod i�lemi yap�ld�.Ancak Password do�ru gelirse s�f�rlan�r.	
								Uart2.KodIslemiYapildi = 1;
								U2_Gonder("@@",Uart2.GonderBuf);
								break;
							}
							else if( Can.FromInv.SifreSistemi == 2 )
							{
								//De�er 0 ise 48 dir biz bunu 17 ile toplar�z ve 65 yani A elde ederiz. Kod lanarak �ifre g�nderilmi� olur.
								for( Uart2_i = 0; Uart2_i < 8;Uart2_i++ )
									Uart2.GonderBuf[Uart2_i] = EeKayit.BasitPassword[Uart2_i] + 17;	
								//7,5 sn lik saya� ba�lat
								Uart2.KodIslemiGeriSayac = 150;
								//Kod i�lemi yap�ld�.Ancak Password do�ru gelirse s�f�rlan�r.
								U2_Gonder("$$$$$$$$",Uart2.GonderBuf);	
							}
							else
								U2_Gonder("KOD SYSTEM ERROR",Uart2.Dumm);
						}
						else
							U2_Gonder("WAIT",Uart2.Dumm);
					}
					else
						U2_Gonder("WAIT",Uart2.Dumm);	
				}
				else
					U2_Gonder("LOGIN",Uart2.Dumm);
				break;
			}
			//Servis eleman�n�n i�i bitti.
			else if ((*U2_Buf == 'O') && (*(U2_Buf + 1) == 'U') && (*(U2_Buf + 2) == 'T'))							
			{
				//Yazma vb. i�lemler serbest de�il
	//			Can.FromInv.LogInDurum = 0;
				Genel.UserPassDogru15dklikIzin = 0;
				Genel.UserPassGeriSayac = 0;
				Uart2.KodIslemiGeriSayac = 0;
				CanGonder(DefCanInv,28,'W',DefEmir_LogOut,0);
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}
			else if ((*U2_Buf == 'C') && (*(U2_Buf + 1) == 'L') && (*(U2_Buf + 2) == 'K'))
			{
				OkuRTC(&Date4);
				Uart2.GonderBuf[0] = Date4.Hour;
				Uart2.GonderBuf[1] = Date4.Min;
				
				U2_Gonder("#]:]",Uart2.GonderBuf);
				break;
			}
			else if ((*U2_Buf == 'D') && (*(U2_Buf + 1) == 'A') && (*(U2_Buf + 2) == 'T'))
			{
				OkuRTC(&Date4);
				Uart2.GonderBuf[0] = Date4.Day;
				Uart2.GonderBuf[1] = Date4.Month;
				Uart2.GonderBuf[2] = Date4.Year;
				
				U2_Gonder("D]]]",Uart2.GonderBuf);
				break;
			}
			else if ((*U2_Buf == 'F') && (*(U2_Buf + 1) == 'I') && (*(U2_Buf + 2)== 'R'))
			{								
				//Variable length string according to firmware version
				U2_Gonder("$$$$$",Protokol);	
				break;
			}
			//----------------KOMUTLAR-----------------------
			//Komut	Inverter e ge� emri		
			else if ((*U2_Buf == 'I') && (*(U2_Buf + 1) == 'N') && (*(U2_Buf + 2) == 'V'))	
			{									
				if( EeKayit.Konfig.Bit.UzakErisim )	
				{			
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{			
						CanGonder(DefCanInv,28,'W',DefEmir_Inverter,0);	
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
					U2_Gonder("ACCDE", Uart2.Dumm );
				break;
			}	
			//Komut Bypass a ge� emri
			else if ((*U2_Buf == 'B') && (*(U2_Buf + 1) == 'Y') && (*(U2_Buf + 2) == 'P'))
			{									
				if( EeKayit.Konfig.Bit.UzakErisim )	
				{					
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{	
						CanGonder(DefCanInv,28,'W',DefEmir_Bypass,0);
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
					U2_Gonder("ACCDE", Uart2.Dumm );
				break;
			}
			//Komut (start/stop boost charge mode)
			else if ((*U2_Buf == 'B') && (*(U2_Buf + 1) == 'S') && (*(U2_Buf + 2) == 'T'))
			{									
				if( EeKayit.Konfig.Bit.UzakErisim )								
				{						
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{						
						Menu.EnterStopBoost ^= 1;
						if( Menu.EnterStopBoost == 1 )	
							CanGonder(DefCanInv,28,'W',DefEmir_Boost,0);
						if( Menu.EnterStopBoost == 0)
							CanGonder(DefCanInv,28,'W',DefEmir_CancelBoost,0);
							
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}																					
				else 
					U2_Gonder("ACCDE", Uart2.Dumm );
				break;
			}
			//Komut Inverter e ge� emri
			else if ((*U2_Buf == 'P') && (*(U2_Buf + 1) == 'O') && (*(U2_Buf + 2) == 'N'))
			{	
				if( EeKayit.Konfig.Bit.UzakErisim )									
				{						
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{								
						CanGonder(DefCanInv,28,'W',DefEmir_Inverter,0);	
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}																					
				else 
					U2_Gonder("ACCDE", Uart2.Dumm );
				break;
			}	
			else if ( (*U2_Buf == 'L') && (*(U2_Buf + 2) == 'X') )
			{	
				if( Can.FromInv.LogInDurum )
				{	
					if(*(U2_Buf + 1) == '1')
					{
						if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )) || ( Can.ToInv.Gonderildi.Bit.U2_W == 1 ))
						{
							YedekCanGonder(DefCanInv,28,'W',1,0);
							CanGonder(DefCanInv,28,'W',1,0);
							Can.ToInv.Gonderildi.Bit.U2_W = 1;
							break;
						}
					}
					if(*(U2_Buf + 1) == '2')
					{
						if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )) || ( Can.ToPfc.Gonderildi.Bit.U2_W == 1 ))
						{
							YedekCanGonder(DefCanPfc,55,'W',1,0);
							CanGonder(DefCanPfc,55,'W',1,0);
							Can.ToPfc.Gonderildi.Bit.U2_W = 1;
							break;
						}
					}
				}
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 5:		
			if ((*U2_Buf == 'C') && (*(U2_Buf + 1) == 'R') && (*(U2_Buf + 2)== 'S') && (*(U2_Buf + 3)== 'T'))
			{
				Uart2.CheckSum = 0;
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}
			else if ((*U2_Buf == 'L') && (*(U2_Buf + 1) == 'A') && (*(U2_Buf + 2)== 'M') && (*(U2_Buf + 3)== 'P'))
			{
		//		Menu.MimikSayac = 6;
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}
			else if ((*U2_Buf == 'W') && (*(U2_Buf + 1) == 'I') && (*(U2_Buf + 2)== 'N') && (*(U2_Buf + 3)== 'I'))
			{
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}
			//A�a��daki Lcd i�in bu TFT i�in olacak
			
			else if ((*U2_Buf == 'M') && (*(U2_Buf + 1) == 'E') && (*(U2_Buf + 2)== 'N') && (*(U2_Buf + 3)== 'U'))
			{
				
				Uart2.GonderBuf[0] = Menu.AnaSekme;
				Uart2.GonderBuf[1] = Menu.Alt1Sekme;
				Uart2.GonderBuf[2] = Menu.OlcumAltSekme;
				Uart2.GonderBuf[3] = Can.AyarMenuDizisi[0];	
				Uart2.GonderBuf[4] = 0;
					
				//Ana men�	
				if( Menu.Sekme.All == DefAnaMenu )
				{
					Uart2.GonderBuf[0] = Menu.AnaSekme;
					Uart2.GonderBuf[1] = 0;
				}					
				//Alt men�
				if( Menu.Sekme.All == DefAlt1Menu )
				{
					Uart2.GonderBuf[1] = Menu.Alt1Sekme;
					Uart2.GonderBuf[2] = 0;		
					Uart2.GonderBuf[3] = 0;		
					Uart2.GonderBuf[4] = 0;						
				}			
				//Ayar Alt men�s�	
				if( Menu.Sekme.All == DefAyarAltMenu )
					Uart2.GonderBuf[3] = Can.AyarMenuDizisi[0];	
				else
				{
					Uart2.GonderBuf[2] = 0;	
					Uart2.GonderBuf[3] = 0;	
					Uart2.GonderBuf[4] = 0;
				}
				//Alt Alt men�
				if( Menu.Sekme.All == DefOlcumAltMenu )	
					Uart2.GonderBuf[2] = Menu.OlcumAltSekme;
				else if( Menu.Sekme.All == DefTercihAltMenu )	
					Uart2.GonderBuf[2] = Menu.TercihAltSekme;
				else if( Menu.Sekme.All == DefAyarAnaMenu )
				{
					Uart2.GonderBuf[1] = 1;
					Uart2.GonderBuf[2] = Menu.AyarAnaSekme;
				}	
				
				if( Menu.Sekme.All == DefAyarAltMenu )
				{
					Uart2.GonderBuf[1] = 1;
					Uart2.GonderBuf[2] = Menu.AyarAnaSekme;
					if(( Can.AyarMenuDizisi[0] == 1171 ) || ( Can.AyarMenuDizisi[0] == 2160 ) || ( Can.AyarMenuDizisi[0] == 3415 ))
					{
						if( Can.AyarMenuDizisi[0] == 3415 )
						{
							if( Menu.AyarEtiket == 0 )
								Uart2.GonderBuf[4] = 9;
							if( Menu.AyarEtiket == 2 )
								Uart2.GonderBuf[4] = 6;
							if( Menu.AyarEtiket == 6 )
								Uart2.GonderBuf[4] = 7;
							if( Menu.AyarEtiket == 1 )
								Uart2.GonderBuf[4] = 10;
						}
						else
						{
							if( Can.AyarMenuDizisi[0] == 1171 )
							{
								if( Menu.AyarEtiket > 8 )
								{
									if( Menu.AyarEtiket == 9 )
										Uart2.GonderBuf[4] = 12;
									if( Menu.AyarEtiket == 10 )
										Uart2.GonderBuf[4] = 13;
									if( Menu.AyarEtiket == 11 )
										Uart2.GonderBuf[4] = 15;
									if( Menu.AyarEtiket == 12 )
										Uart2.GonderBuf[4] = 16;
								}
								else
									Uart2.GonderBuf[4] = Menu.AyarEtiket + 1;
							}
							if( Can.AyarMenuDizisi[0] == 2160 )
							{
								if( Menu.AyarEtiket > 4 )
								{
									if( Menu.AyarEtiket == 5 )
										Uart2.GonderBuf[4] = 7;
									if( Menu.AyarEtiket == 6 )
										Uart2.GonderBuf[4] = 8;
									if( Menu.AyarEtiket == 7 )
										Uart2.GonderBuf[4] = 9;
									if( Menu.AyarEtiket == 8 )
										Uart2.GonderBuf[4] = 10;
									if( Menu.AyarEtiket == 9 )
										Uart2.GonderBuf[4] = 11;
									if( Menu.AyarEtiket == 10 )
										Uart2.GonderBuf[4] = 12;
									if( Menu.AyarEtiket == 11 )
										Uart2.GonderBuf[4] = 14;
								}
								else
									Uart2.GonderBuf[4] = Menu.AyarEtiket + 1;
							}
						}
							
						if( Uart2.GonderBuf[4] < 10 )
							U2_Gonder("002_]_]_]>R@-[",Uart2.GonderBuf);			//Ba��ndaki 3 hane versiyon pc yard�m i�lemi i�in men� tft olursa falan de�i�sin diye
						else
							U2_Gonder("002_]_]_]>R@-]",Uart2.GonderBuf);
						break;
					}
					else
					{
						Uart2.GonderBuf[4] = 0;
						U2_Gonder("002_]_]_]>R@",Uart2.GonderBuf);
						break;
					}
				}
				else if( Menu.Sekme.All == DefAyarGrupAltMenu )
				{
					Uart2.GonderBuf[1] = 1;
					Uart2.GonderBuf[2] = Menu.AyarAnaSekme;
					
					if( Menu.AyarEtiket == 0 )
						Uart2.GonderBuf[3] = 2192;	
					if( Menu.AyarEtiket == 1 )
						Uart2.GonderBuf[3] = 2193;	
					if( Menu.AyarEtiket == 2 )
						Uart2.GonderBuf[3] = 2194;
					if( Menu.AyarEtiket == 3 )
						Uart2.GonderBuf[3] = 2185;	
					if( Menu.AyarEtiket == 4 )
						Uart2.GonderBuf[3] = 2142;	
					if( Menu.AyarEtiket == 5 )
						Uart2.GonderBuf[3] = 1187;
					if( Menu.AyarEtiket == 6 )
						Uart2.GonderBuf[3] = 1136;	
					if( Menu.AyarEtiket == 7 )
						Uart2.GonderBuf[3] = 1181;			
					
					Uart2.GonderBuf[4] = Can.AyarMenuDizisi[0];
					U2_Gonder("002_]_]_]>R@ - R@",Uart2.GonderBuf);
					
				}
				else
				{
					Uart2.GonderBuf[4] = 0;
					U2_Gonder("002_]_]_]>R@",Uart2.GonderBuf);
					break;
				}
					
			}
			else if((*U2_Buf == 'M') && (*(U2_Buf + 1) == 'F') && (*(U2_Buf + 2)== 'I') && (*(U2_Buf + 3)== 'R'))
			{
				Uart2.GonderBuf[0] = Can.FromInv.InvVersiyon;
				Uart2.GonderBuf[1] = Can.FromPfc.PfcVersiyon;
				Uart2.GonderBuf[2] = TftVersiyon;
				
				U2_Gonder("%_%_%",Uart2.GonderBuf);
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 6:
			//Adresten okuma
			if(*U2_Buf == 'R')					
			{
				Uart2.SonSorulanEmir = 'R';
				
				//Inverter e R1xxx sorgusu
				if(*(U2_Buf + 1) - 48 == 1)
				{
					if((( Can.ToPfc.Gonderildi.All == 0 ) && ( Can.ToInv.Gonderildi.All == 0 )))// || ( Can.ToInv.Gonderildi.Bit.U2_R == 1 ))
					{
						Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48));
						YedekCanGonder(DefCanInv,28,'R',0,Uart2.AraIslemDeger[0] );
						CanGonder(DefCanInv,28,'R',0,Uart2.AraIslemDeger[0] );
						Can.ToInv.Gonderildi.Bit.U2_R = 1;
						
						Can.FromInv.R_HataSayaci.Adres = 0;
						Can.FromInv.R_HataSayaci.Paket = 0;
						Can.FromInv.R_HataSayaci.Gorev = 0;
						Uart2.Tekrar = 19;
						break;
					}
				}
				//Pfc ye R2xxx sorgusu
				if(*(U2_Buf + 1) - 48 == 2)
				{
					if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToPfc.Gonderildi.Bit.U2_R == 1 ))
					{
						Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48));
						YedekCanGonder(DefCanPfc,55,'R',0,Uart2.AraIslemDeger[0] );
						CanGonder(DefCanPfc,55,'R',0,Uart2.AraIslemDeger[0] );
						Can.ToPfc.Gonderildi.Bit.U2_R = 1;
						
						Can.FromPfc.R_HataSayaci.Adres = 0;
						Can.FromPfc.R_HataSayaci.Paket = 0;
						Can.FromPfc.R_HataSayaci.Gorev = 0;
						Uart2.Tekrar = 19;
						break;
					}		
				}
				if(*(U2_Buf + 1) - 48 == 3)
				{
					Uart2.R_Adres = ( ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48)) << 1 ) + 2560;
					//Saat ayar� ram den okunmuyor cevap i�lendikten sonra gidiyor
					if( (Uart2.R_Adres == 3246) || (Uart2.R_Adres == 3248) || (Uart2.R_Adres == 3250) ) 
					{
						OkuRTC(&Uart2.Date_3);
						if(Uart2.R_Adres == 3246)
							U2_ZamanCevap = (Uart2.Date_3.Hour * 100) + Uart2.Date_3.Min;
						if(Uart2.R_Adres == 3248)
							U2_ZamanCevap = (Uart2.Date_3.Day * 100) + Uart2.Date_3.Month;
						if(Uart2.R_Adres == 3250)
							U2_ZamanCevap = Uart2.Date_3.Year + 2000;
							
						U2_Gonder("�",&U2_ZamanCevap);
						break;
					}
					else
					{
						U2_Gonder("�",Uart2.R_Adres);
						break;
					}
				}
			}
			
//			//User login i�in
			else if((*U2_Buf == 'U'))
			{
				if( Genel.UserPassDogru15dklikIzin == 1 )
				{
					U2_Gonder("USER LOGIN",Uart2.Dumm);
					break;
				}
				Menu.UserGolgeSifre[0] = *(U2_Buf + 1);
				Menu.UserGolgeSifre[1] = *(U2_Buf + 2);
				Menu.UserGolgeSifre[2] = *(U2_Buf + 3);
				Menu.UserGolgeSifre[3] = *(U2_Buf + 4);
				Uart2.Dumm[0] = UserSifreDogrula();
				if( Uart2.Dumm[0] == 1 )
				{
					Genel.UserPassDogru15dklikIzin = 1;
					Genel.LoginWaitButon = 0;
					//15 dk l�k geri saya� kuruldu.
					Genel.UserPassGeriSayac = 450;
					CanGonder(DefCanInv,28,'W',DefEmir_UserLogIn,0);
					U2_Gonder("OK", Uart2.Dumm );
					break;
				}
				else
				{
					U2_Gonder("ERROR", Uart2.Dumm );
					break;
				}
				
			}
			else if((*U2_Buf == 'E') && (*(U2_Buf + 1) == 'E') && (*(U2_Buf + 2) == 'C') && (*(U2_Buf + 3) == 'L') && (*(U2_Buf + 4) == 'R'))
			{
				for( Uart2_i = 0;Uart2_i < DefFullEeprom;Uart2_i++)
				{
					Nop();Nop();
					EeByteYaz( Uart2_i,255 );
				}
				asm("RESET");		
			}				
			//�zel Eepromdan direk adresinden 1 byte l�k data al�r.
			else if (*U2_Buf == 'E')
			{	
				Uart2.AraIslemDeger[0] = (*(U2_Buf + 1) - 48) * 1000 + (*(U2_Buf + 2) - 48) * 100 + ((*(U2_Buf + 3)-48) * 10) + (*(U2_Buf + 4) - 48);	
				Uart2.GonderBuf[0] = EeByteOku(Uart2.AraIslemDeger[0]);
				U2_Gonder("�",Uart2.GonderBuf);
				break;
			} 
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 7:		//Adresten okuma
			if((*U2_Buf == 'L') && (*(U2_Buf + 1) == 'O') && (*(U2_Buf + 2) == 'G')  && (*(U2_Buf + 3) == 'C')&& (*(U2_Buf + 4) == 'L') && (*(U2_Buf + 5) == 'R'))
			{
				if( Can.FromInv.LogInDurum )
				{	
					if( EeKayit.Konfig.Bit.UzakErisim )	
					{
						U2_Gonder("OK", Uart2.Dumm );
						LogIslem(DefLogSil);
					}
				}
			}
			else if(*U2_Buf == 'L')					
			{
				if((*(U2_Buf + 1) > 47) && (*(U2_Buf + 1) < 58))
				{
					if((*(U2_Buf + 2) > 47) && (*(U2_Buf + 2) < 58))
					{
						//Inverter e L1xxxx sorgusu
						if(*(U2_Buf + 1) - 48 == 1)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToInv.Gonderildi.Bit.U2_L == 1 ))
							{
								Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 1000 + (*(U2_Buf + 3) - 48) * 100 + (*(U2_Buf + 4) - 48) * 10 +  + (*(U2_Buf + 5) - 48) );
								YedekCanGonder(DefCanInv,28,'L',0,Uart2.AraIslemDeger[0] );
								CanGonder(DefCanInv,28,'L',0,Uart2.AraIslemDeger[0] );
								Can.ToInv.Gonderildi.Bit.U2_L = 1;
								
								Can.FromInv.L_HataSayaci.Adres = 0;
								Can.FromInv.L_HataSayaci.Paket = 0;
								Can.FromInv.L_HataSayaci.Gorev = 0;
								Uart2.Tekrar = 19;
								break;
							}	
						}
						//Pfc ye L2xxxx sorgusu
						if(*(U2_Buf + 1) - 48 == 2)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))// || ( Can.ToPfc.Gonderildi.Bit.U2_L == 1 ))
							{
								Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 1000 + (*(U2_Buf + 3) - 48) * 100 + (*(U2_Buf + 4) - 48) * 10 +  + (*(U2_Buf + 5) - 48) );
								YedekCanGonder(DefCanPfc,55,'L',0,Uart2.AraIslemDeger[0] );
								CanGonder(DefCanPfc,55,'L',0,Uart2.AraIslemDeger[0] );
								Can.ToPfc.Gonderildi.Bit.U2_L = 1;
								
								Can.FromPfc.L_HataSayaci.Adres = 0;
								Can.FromPfc.L_HataSayaci.Paket = 0;
								Can.FromPfc.L_HataSayaci.Gorev = 0;
								Uart2.Tekrar = 19;
								break;
							}	
						}
					}
					else
					{
						U2_Gonder("ERROR",Uart2.Dumm );
						break;
					}
				}
				else
				{
					U2_Gonder("ERROR",Uart2.Dumm );
					break;
				}
			}
			//Tft uart tan direk foto y�kleme i�lemi bitti.
			else if((*U2_Buf == 'T') && (*(U2_Buf + 1) == 'F') && (*(U2_Buf + 2) == 'T') && (*(U2_Buf + 3) == 'E') && (*(U2_Buf + 4) == 'N') && (*(U2_Buf + 5) == 'D'))
			{
				TFT.FotoDurum = 0;
				U2_Gonder("OK",Uart2.Dumm );
				break;
			}			
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;		
		case 8:
			//R�le simiulasyon. 
			//FORMAT.........:RELAYxx<13>
			if((*U2_Buf == 'R') && (*(U2_Buf + 1) == 'E') && (*(U2_Buf + 2) == 'L') && (*(U2_Buf + 3) == 'A') && (*(U2_Buf + 4) == 'Y'))
			{
				// 2 x 2s = 4s alarma ba�l� role �ekmesin 
				Menu.RoleTestSayac = 30;
				Uart2.AraIslemDeger[0] = (*(U2_Buf + 5)-48) * 10 + (*(U2_Buf + 6)-48);
				if(Uart2.AraIslemDeger[0] == 0)
				{
					for(Uart2_i = 0;Uart2_i < 13;Uart2_i++)
						RoleIslem(Uart2_i,0);
					U2_Gonder("R�LELER RESETLEND�.",Uart2.Dumm);
					break;
				}
				else
				{
					RoleIslem((Uart2.AraIslemDeger[0] - 1),1);
					U2_Gonder("R�LE ] SET ED�LD�.",Uart2.AraIslemDeger);
					break;
				}
			}	
			else if( (*U2_Buf == 'L') && (*(U2_Buf + 1) == 'O') && (*(U2_Buf + 2) == 'G') )
			{					
				// 2 x 50 ms = 100 ms log kayd� yap�lmas�n
				Genel.LogSorulduSayac = 2;										
				Uart2.AraIslemDeger[0] = (((*(U2_Buf + 3) - 48) * 1000) + ((*(U2_Buf + 4) - 48) * 100) + ((*(U2_Buf + 5) - 48) * 10) + ((*(U2_Buf + 6) - 48)));
		//		if( Uart2.AraIslemDeger[0] > ((DefLogLastAddr+1) / 16) )
				if( Uart2.AraIslemDeger[0] > (DefMaxLogSayisi-1) )
				{
					U2_Gonder("INVALID LOG ADDRESS",Uart2.Dumm);
					break;
				}
				else	
				{
					//En son kaydedilen Log0000 adresinde olmal�d�r.
				//	Uart2.AraIslemDeger[0] = (( (EeKayit.LogSayac - 1) - Uart2.AraIslemDeger[0] ) * 16 ) + DefLogFirstAddr;
				//	Uart2.AraIslemDeger[1] = EeWordOku(Uart2.AraIslemDeger[0]);
//					if(Uart2.AraIslemDeger[0] <= (EeKayit.LogSayac - 1))
//						Uart2.AraIslemDeger[3] = ((( EeKayit.LogSayac - 1 ) - Uart2.AraIslemDeger[0] ) * 16 ) + DefLogFirstAddr;	
//					else
//						Uart2.AraIslemDeger[3] = (((( DefLogLastAddr + 1 ) / 16) + ( EeKayit.LogSayac - 1 ) - Uart2.AraIslemDeger[0] ) * 16) + DefLogFirstAddr;
			
			
					if(Uart2.AraIslemDeger[0] > (EeKayit.LogSayac - 1))
					//	Uart2.AraIslemDeger[3] = (((( DefLogLastAddr + 1 ) / 16) + ( EeKayit.LogSayac - 1 ) - Uart2.AraIslemDeger[0] ) * 16) + DefLogFirstAddr;	
						Uart2.AraIslemDeger[3] = ((DefLogCount + ( EeKayit.LogSayac - 1 ) - Uart2.AraIslemDeger[0] ) * 16) + DefLogFirstAddr;	
					else
						Uart2.AraIslemDeger[3] = ((( EeKayit.LogSayac - 1 ) - Uart2.AraIslemDeger[0] ) * 16 ) + DefLogFirstAddr;
					Uart2.AraIslemDeger[1] = EeWordOku(Uart2.AraIslemDeger[3]);
					
					
					if( Uart2.AraIslemDeger[1] == 65535 )
					{
						U2_Gonder("LOG ADDRESS EMPTY",Uart2.Dumm);
						break;
					}
					else
					{
				//		EeAlarmOku(&Date,Uart2.AraIslemDeger[0]); 
						EeAlarmOku(&Date,Uart2.AraIslemDeger[3]); 
						if( Uart2.AraIslemDeger[1] == 65534 )
						{
							Uart2.GonderBuf[0] = Date.Day;
							Uart2.GonderBuf[1] = Date.Month;
							Uart2.GonderBuf[2] = Date.Year;
							Uart2.GonderBuf[3] = Date.Hour;
							Uart2.GonderBuf[4] = Date.Min;
							Uart2.GonderBuf[5] = Date.Sec;
							U2_Gonder("LOGS EVENTS CLEARED ]]] ]:]:]",Uart2.GonderBuf);
							break;
						}
						else
						{
							Uart2.GonderBuf[0] = LogAlarmKod.Kod.Inv;
							Uart2.GonderBuf[1] = LogAlarmKod.Kod.Pfc;
							Uart2.GonderBuf[2] = LogAlarm.Word.Lcd1.All;
							Uart2.GonderBuf[3] = LogAlarm.Word.Inv1.All;
							Uart2.GonderBuf[4] = LogAlarm.Word.Inv2.All;
							Uart2.GonderBuf[5] = LogAlarm.Word.Inv3.All;  //23.12.2014 - 02.01.2014 eklendi �nceden 0 d�.
							Uart2.GonderBuf[6] = LogAlarm.Word.Pfc1.All;
							Uart2.GonderBuf[7] = LogAlarm.Word.Pfc2.All;
							Uart2.GonderBuf[8] = Date.Day;
							Uart2.GonderBuf[9] = Date.Month;
							Uart2.GonderBuf[10] = Date.Year;
							Uart2.GonderBuf[11] = Date.Hour;
							Uart2.GonderBuf[12] = Date.Min;
							Uart2.GonderBuf[13] = Date.Sec;
							U2_Gonder("� � � � � � � � ]]] ]:]:]",Uart2.GonderBuf);
							break;
						}
					}	
				}
			}
			else if((*U2_Buf == 'T') && (*(U2_Buf + 1) == 'F') && (*(U2_Buf + 2) == 'T'))
			{
				Uart2.R_Adres = ((*(U2_Buf + 3) - 48) * 1000 + (*(U2_Buf + 4) - 48) * 100 + (*(U2_Buf + 5) - 48) * 10 + (*(U2_Buf + 6) - 48));
				U2_Gonder("�",Uart2.R_Adres);
				break;
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 9:
			//RS232 den Eeproma direk yazma i�lemi LAbel lar i�in
			//FORMAT.........:Wpaaavvv<13>  
			// p -> page (sayfa) , aaa -> adres , vvv -> de�er	
			if(*U2_Buf == 'W')
			{	
				if( Can.FromInv.LogInDurum )
				{	
					if( EeKayit.Konfig.Bit.UzakErisim )	
					{
						//Numerik kontrol yap�l�yor.
						for(Uart2_i = 1;Uart2_i < 8;Uart2_i++)								
						{
							if( (*(U2_Buf + Uart2_i) > 57) || (*(U2_Buf + Uart2_i) < 48) )
							{	
								U2_Gonder("BE MUST NUMERIC",Uart2.Dumm);
								break;
							}		
						}
						//Sayfa
						Uart2.AraIslemDeger[0] = (*(U2_Buf + 1) - 48);	
						//Adres
						Uart2.AraIslemDeger[1] = ((*(U2_Buf + 2)-48)*100) + ((*(U2_Buf + 3)-48) * 10) + *(U2_Buf + 4) - 48;
						//Eeprom datas�
						Uart2.AraIslemDeger[2] = ((*(U2_Buf + 5)-48)*100) + ((*(U2_Buf + 6)-48) * 10) + *(U2_Buf + 7) - 48;
						Uart2.R_Deger = Uart2.AraIslemDeger[2] & 0x00ff;
						//Eeprom adresi
						Uart2.R_Adres = (Uart2.AraIslemDeger[0] * 1024) + Uart2.AraIslemDeger[1] * 2;
						//Eeprom Label i�in girilen adres kontrol� yapar.
						if( (Uart2.R_Adres < DefEepromLabelAltSinir) || (Uart2.R_Adres > DefEepromLabelUstSinir) )
						{
							U2_Gonder("WRONG LABEL ADRES",Uart2.Dumm);
							break;
						}	
						else
						{
							*Uart2.R_Adres = Uart2.R_Deger;	
							EeWordYaz(Uart2.R_Adres, Uart2.R_Deger);	
							U2_Gonder("OK", Uart2.Dumm );
							break;
						}												
					}
					else 												
						U2_Gonder("ACCDE",Uart2.Dumm);	
				}
				else
					U2_Gonder("ACCDE",Uart2.Dumm);
				
				break;	
			}									

			else if((*U2_Buf == 'A') && (*(U2_Buf + 1) == 'C') && (*(U2_Buf + 2) == 'L'))		//RS232 YE SAAT CEVABI
			{
				Date.Hour = (((*(U2_Buf + 3) - 48) * 10) + (*(U2_Buf + 4) - 48));
				Date.Min = (((*(U2_Buf + 6) - 48) * 10) + (*(U2_Buf + 7) - 48));
				YazRTC(&Date);
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}
			else if((*U2_Buf == 'A') && (*(U2_Buf + 1) == 'D'))									//RS232 YE TAR�H CEVABI
			{
				Date.Day = (((*(U2_Buf + 2) - 48) * 10) + (*(U2_Buf + 3) - 48));
				Date.Month = (((*(U2_Buf + 4) - 48) * 10) + (*(U2_Buf + 5) - 48));
				Date.Year = (((*(U2_Buf + 6)-48) * 10) + (*(U2_Buf + 7) - 48));
				YazRTC(&Date);
				U2_Gonder("OK", Uart2.Dumm );	
				break;
			}		
			//SxxRyyyy<13> gelecek uart tan ve xx dakika i�eriside uyu (shutdown) yyyy dakika sonra uyan (Restore) emri g�nderilecek.
			else if ((*U2_Buf == 'S') && (*(U2_Buf + 3) == 'R'))			
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{				
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{		
						if( *(U2_Buf + 1) != '.' )							
							Timer6.ShutdownTime = ((*(U2_Buf + 1) - 48) * 10 + (*(U2_Buf + 2) - 48)) * 60;
						else if( *(U2_Buf + 1) == '.' )		
							Timer6.ShutdownTime = ( 6 * (*(U2_Buf + 2) - 48) );
							
						Timer6.RestoreTime = ( ((*(U2_Buf + 4) - 48) * 1000) + ((*(U2_Buf + 5) - 48) * 100) + ((*(U2_Buf + 6) - 48) * 10) + (*(U2_Buf + 7) - 48) ) * 60;						
						U2_Gonder("OK", Uart2.Dumm );
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
				break;
			}
			else if((*U2_Buf == 'T') && (*(U2_Buf + 1) == 'F') && (*(U2_Buf + 2) == 'T'))
			{
				Uart2.R_Adres = ((*(U2_Buf + 3) - 48) * 10000 + (*(U2_Buf + 4) - 48) * 1000 + (*(U2_Buf + 5) - 48) * 100 + (*(U2_Buf + 6) - 48) * 10 + (*(U2_Buf + 7) - 48));
				U2_Gonder("�",Uart2.R_Adres);
				break;
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 10:	
			//Gelen P12345678<13>
			if(*U2_Buf == 'P')	
			{	
				//Merkezi kod �ifresi ge�erli yani Kod Gen 1. sat�rda yaz�lacak
				if( Can.FromInv.SifreSistemi == 1 )
				{
					if( Uart2.KodIslemiYapildi == 1 )
					{
						//S�ras�yla	Hi word, alttaki Low word
						Uart2.AraIslemDeger[0] = ( ((*(U2_Buf + 1) - 48) * 1000) + ((*(U2_Buf + 2) - 48) * 100) + ((*(U2_Buf + 3) - 48) * 10) + (*(U2_Buf + 4) - 48) );
						Uart2.AraIslemDeger[1] = ( ((*(U2_Buf + 5) - 48) * 1000) + ((*(U2_Buf + 6) - 48) * 100) + ((*(U2_Buf + 7) - 48) * 10) + (*(U2_Buf + 8) - 48) );
						
						if(( Menu.SifreH == Uart2.AraIslemDeger[0] ) && ( Menu.SifreL == Uart2.AraIslemDeger[1]) )
						{
							if( Can.FromInv.LogInDurum == 0 )
							{
								CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
								//Servis kodlar�n� yenile
								SifreAl();
							}
							//Bir dahakinde kod istenmeden �ifre yaz�lmas�n diye s�f�rlan�r.
							Uart2.KodIslemiYapildi = 0;	
							U2_Gonder("OK", Uart2.Dumm );
							break;
						}
						else
						{
							//7,5 saniye geriye sayacak.
							Uart2.PassWordHataliGeriSayac = 150;
							U2_Gonder("ERROR", Uart2.Dumm );
							break;
						}
					}
					else
					{	
						U2_Gonder("ERROR", Uart2.Dumm );
						break;
					}	
				}	
				//Basit kod �ifresi ge�erli kod Gen 1. Sat�rda de�il onun yerine password yaz�l�.
				else if( Can.FromInv.SifreSistemi == 2 )
				{
					U2_SifreSayac = 0;
					for(Uart2_i = 0;Uart2_i < 8;Uart2_i++)
					{
						if( EeKayit.BasitPassword[Uart2_i] == ( *(U2_Buf + Uart2_i + 1)))
							U2_SifreSayac++;
					}
					if(U2_SifreSayac > 7)
					{
						U2_SifreSayac = 0;
						if( Can.FromInv.LogInDurum == 0 )
						{
							CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
						}
						//Bir dahakinde kod istenmeden �ifre yaz�lmas�n diye s�f�rlan�r.
						Uart2.KodIslemiYapildi = 0;	
						U2_Gonder("OK", Uart2.Dumm );
						break;
					}
					else
					{
						//7,5 saniye geriye sayacak.
						Uart2.PassWordHataliGeriSayac = 150;
						U2_Gonder("ERROR", Uart2.Dumm );
						break;
					}
				}
				else
				{	
					U2_Gonder("SifreSistemi Hatas�", Uart2.Dumm );
					break;
				}
			}		
			//Denemelerde Sadece Ram'e istenilen de�eri verebilmek i�in geli�tirildi.
			else if((*U2_Buf == 'L'))												
			{
				Uart2.R_Adres = ((*(U2_Buf + 1) - 48) * 100 + (*(U2_Buf + 2) - 48) * 10 + ((*(U2_Buf + 3) - 48)));		
				Uart2.R_Deger = (*(U2_Buf + 4) - 48) * 10000 + (*(U2_Buf + 5) - 48) * 1000 + (*(U2_Buf + 6) - 48) * 100 + (*(U2_Buf + 7) - 48) * 10 + (*(U2_Buf + 8) - 48);
				*Uart2.R_Adres = Uart2.R_Deger;	
				U2_Gonder("OK", Uart2.Dumm );
				break;
			}
			//Tft ye piksel datalar�n� al�r.
			else if((*U2_Buf == 'T'))
			{
				if( TFT.FotoDurum )
				{
					TFT.Foto_Renk = (unsigned long)(((*(U2_Buf + 1) - 48) * (unsigned long)10000000) + (unsigned long)(unsigned long)((*(U2_Buf + 2) - 48) * (unsigned long)1000000) + (unsigned long)((*(U2_Buf + 3) - 48) * (unsigned long)100000) + (unsigned long)((*(U2_Buf + 4) - 48) * (unsigned long)10000) + (unsigned long)((*(U2_Buf + 5) - 48) * 1000) + (unsigned long)((*(U2_Buf + 6) - 48) * 100) + (unsigned long)((*(U2_Buf + 7) - 48) * 10) + (*(U2_Buf + 8) - 48));
			//		TFT.Foto_Renk = /*(long)((*(U2_Buf + 1) - 48) * 100000000) + (long)((*(U2_Buf + 2) - 48) * 10000000) +*/ (long)((*(U2_Buf + 1) - 48) * 100000) + (long)((*(U2_Buf + 2) - 48) * 10000) + (long)((*(U2_Buf + 3) - 48) * 1000) + (*(U2_Buf + 4) - 48) * 100 + (*(U2_Buf + 5) - 48) * 10 + (*(U2_Buf + 6) - 48);
					
					SendPixel(TFT.Foto_Renk);
					U2_Gonder("OK", Uart2.Dumm );
				}
			}	
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		case 11:
			//Adrese yazma
			if((*U2_Buf == 'W') || (*U2_Buf == 'B'))				
			{	
				if(*U2_Buf == 'W')
					Uart2.W_B = 0;
				if(*U2_Buf == 'B')
					Uart2.W_B = 1;
				
				if( EeKayit.Konfig.Bit.UzakErisim == 1)
				{
					if(*U2_Buf == 'W')
						Uart2.SonSorulanEmir = 'W';	
					if(*U2_Buf == 'B')
						Uart2.SonSorulanEmir = 'B';	
					Uart2.CheckSum = Uart2.CheckSum + ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
					if( Can.FromInv.LogInDurum == 1 )
					{
						//Yanl�� komut olup olmad���na bakmak i�in
						Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48));
						Uart2.AraIslemDeger[1] = ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
						if( (Uart2.AraIslemDeger[0] == 0) && ((Uart2.AraIslemDeger[1] & 1) == 1) )	
						{
							//Wrong command
							U2_Gonder("WRCM", Uart2.Dumm );						
							break;
						}
						
						if(*(U2_Buf + 1) - 48 == 1)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))
							{
								Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48));
								Uart2.AraIslemDeger[1] = ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
							
								//Adres 0 ise gelen i�lem emir i�lemidir.
								if( Uart2.AraIslemDeger[0] == 0 )
									Uart2.EmirGonderildi = 1;
								else							
									Uart2.EmirGonderildi = 0;
									
								if( Uart2.W_B == 0 )
								{
									YedekCanGonder(DefCanInv,28,'W',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
									CanGonder(DefCanInv,28,'W',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
								}
								else
								{
									YedekCanGonder(DefCanInv,28,'B',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
									CanGonder(DefCanInv,28,'B',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
								}
								Can.ToInv.Gonderildi.Bit.U2_W = 1;
								Uart2.Tekrar = 19;
								break;
							}
						}
						if(*(U2_Buf + 1) - 48 == 2)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))
							{
								Uart2.AraIslemDeger[0] = (((*(U2_Buf + 2) - 48) * 100) + ((*(U2_Buf + 3) - 48) * 10) + (*(U2_Buf + 4) - 48));
								Uart2.AraIslemDeger[1] = ( ((*(U2_Buf + 5) - 48) * 10000) + ((*(U2_Buf + 6) - 48) * 1000) + ((*(U2_Buf + 7) - 48) * 100) + ((*(U2_Buf + 8) - 48) * 10) + (*(U2_Buf + 9) - 48) );
								
								if( Uart2.W_B == 0 )
								{
									YedekCanGonder(DefCanPfc,55,'W',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
									CanGonder(DefCanPfc,55,'W',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
								}
								else
								{
									YedekCanGonder(DefCanPfc,55,'B',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
									CanGonder(DefCanPfc,55,'B',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
								}
								Can.ToPfc.Gonderildi.Bit.U2_W = 1;
								Uart2.Tekrar = 19;
								break;
							}
						}
						if(*(U2_Buf + 1) - 48 == 3)
						{
							Uart2.R_Adres = ( ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48)) << 1 ) + 2560;
							Uart2.R_Deger = ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
							Uart2.RamLimitli_mi = Uart2.R_Deger;
							//Saat ayar� eeproma yaz�lmaz 
							if( (Uart2.R_Adres == 3246) || (Uart2.R_Adres == 3248) || (Uart2.R_Adres == 3250) ) 			
							{
								if(Uart2.R_Adres == 3246)
								{
									Date.Hour = Uart2.R_Deger / 100;
									Date.Min =  Uart2.R_Deger - Date.Hour * 100;
								}
								if(Uart2.R_Adres == 3248)
								{
									Date.Day =  Uart2.R_Deger / 100;
									Date.Month =  Uart2.R_Deger - Date.Day * 100;
								}
								if(Uart2.R_Adres == 3250)
									Date.Year =  Uart2.R_Deger - 2000;
								if(Date.Hour < 24)
								{
									if(Date.Min < 60)
									{
										if(Date.Day > 0 && Date.Day < 32)
										{
											if((Date.Month > 0) && (Date.Month < 13))
											{
												YazRTC(&Date);
												U2_Gonder("OK", Uart2.Dumm );
												break;
											}
											else
											{	U2_Gonder("LIMITED", Uart2.Dumm );}
										}
										else
										{	U2_Gonder("LIMITED", Uart2.Dumm );}
									}
									else
									{	U2_Gonder("LIMITED", Uart2.Dumm );}
								}
								else
								{	U2_Gonder("LIMITED", Uart2.Dumm );}	
							}
							else
							{
								//Label lar haricindeki eeprom de�erleri min - max limitlerden ge�er.
								if((Uart2.R_Adres > 3300) && (Uart2.R_Adres < DefEepromDegiskenUstSinir))									
								{
									U2_AraIslem = Uart2.R_Adres;
									U2_AraIslem = (U2_AraIslem-3302)/2;
									if( Uart2.R_Deger > MinMax[U2_AraIslem][MaxAddrKontrol] )
										Uart2.R_Deger = MinMax[U2_AraIslem][MaxAddrKontrol];
										
									if( ( Uart2.R_Deger > MinMax[U2_AraIslem][MinAddrKontrol] ) && ( Uart2.R_Deger< MinMax[U2_AraIslem][AraAddrKontrol] ) )
										Uart2.R_Deger = MinMax[U2_AraIslem][MinAddrKontrol];
										
									if( Uart2.R_Deger < MinMax[U2_AraIslem][MinAddrKontrol] )
										Uart2.R_Deger = MinMax[U2_AraIslem][MinAddrKontrol];
								}														
								*Uart2.R_Adres = Uart2.R_Deger;
								EeWordYaz( Uart2.R_Adres , Uart2.R_Deger );	
								
								//07.05.2014
								if( (Label.NominalVoltage[16] == '1') && ( (Label.NominalVoltage[17] == '1') || (Label.NominalVoltage[17] == '2') ) )
									UPS_I_O_Options = 1;
								else
									UPS_I_O_Options = 0;
									
									
								//02.10.2013---
								if( (Uart2.R_Adres == 3396) || (Uart2.R_Adres == 3404) )
								{
									Genel.Besleme = AdcOku(AN12);
									
									EeKayit.BeslemeIlk = Genel.Besleme;
									EeWordYaz( &EeKayit.BeslemeIlk , EeKayit.BeslemeIlk );								
								}			
								//------------	
								//Fan Bakim
								if( Uart2.R_Adres == 3316 )
								{
									//Datalar� ram den al�r ��nk� bir �nceki sat�rda ram e kay�t i�lemi ger�ekle�ir.
									EeKayit.Bakim[1].KalanSure = EeKayit.Bakim[1].AyarlananSure;
									EeKayit.Bakim[1].GecenSure = 0;
									//Alarm Varsa sil.
									Alarm.Word.Lcd1.Bit.FanBakimZamani = 0;
									EeKayit.Bakim[1].ServisSay++;
									
									if( EeKayit.Bakim[1].AyarlananSure == 0 )
										EeKayit.Bakim[1].Iptal = 1;
									else
										EeKayit.Bakim[1].Iptal = 0;
									//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
									EeWordYaz( &EeKayit.Bakim[1].Iptal , EeKayit.Bakim[1].Iptal );
									EeWordYaz( &EeKayit.Bakim[1].ServisSay , EeKayit.Bakim[1].ServisSay );
									EeWordYaz( &EeKayit.Bakim[1].GecenSure , EeKayit.Bakim[1].GecenSure );
									EeWordYaz( &EeKayit.Bakim[1].KalanSure , EeKayit.Bakim[1].KalanSure );
								}
								//Ak� Bakim
								if( Uart2.R_Adres == 3326 )
								{
									EeKayit.Bakim[2].KalanSure = EeKayit.Bakim[2].AyarlananSure;
									EeKayit.Bakim[2].GecenSure = 0;
									//Alarm Varsa sil.
									Alarm.Word.Lcd1.Bit.AkuBakimZamani = 0;
									EeKayit.Bakim[2].ServisSay++;
									
									if( EeKayit.Bakim[2].AyarlananSure == 0 )
										EeKayit.Bakim[2].Iptal = 1;
									else
										EeKayit.Bakim[2].Iptal = 0;
									//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
									EeWordYaz( &EeKayit.Bakim[2].Iptal , EeKayit.Bakim[2].Iptal );
									EeWordYaz( &EeKayit.Bakim[2].ServisSay , EeKayit.Bakim[2].ServisSay );
									EeWordYaz( &EeKayit.Bakim[2].GecenSure , EeKayit.Bakim[2].GecenSure );
									EeWordYaz( &EeKayit.Bakim[2].KalanSure , EeKayit.Bakim[2].KalanSure );
								}
								//Genel Bakim
								if( Uart2.R_Adres == 3336 )
								{
									EeKayit.Bakim[3].KalanSure = EeKayit.Bakim[3].AyarlananSure;
									EeKayit.Bakim[3].GecenSure = 0;
									//Alarm Varsa sil.
									Alarm.Word.Lcd1.Bit.GenelBakimZamani = 0;
									EeKayit.Bakim[3].ServisSay++;
									
									if( EeKayit.Bakim[3].AyarlananSure == 0 )
										EeKayit.Bakim[3].Iptal = 1;
									else
										EeKayit.Bakim[3].Iptal = 0;
									//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
									EeWordYaz( &EeKayit.Bakim[3].Iptal , EeKayit.Bakim[3].Iptal );
									EeWordYaz( &EeKayit.Bakim[3].ServisSay , EeKayit.Bakim[3].ServisSay );
									EeWordYaz( &EeKayit.Bakim[3].GecenSure , EeKayit.Bakim[3].GecenSure );
									EeWordYaz( &EeKayit.Bakim[3].KalanSure , EeKayit.Bakim[3].KalanSure );
								}					
							
								//Dil adresinde bir �ey yaz�l�yorsa ekran� yenile
								if( Uart2.R_Adres == 3372 )
									Menu.YenileGeriSayac = 5;
									
								if( Uart2.RamLimitli_mi == Uart2.R_Deger )	
									U2_Gonder("OK", Uart2.Dumm );
								else
									U2_Gonder("LIMITED", Uart2.Dumm );
							}	
						}	
					}				
					else if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{			
						//Yanl�� komut olup olmad���na bakmak i�in
						Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48));
						Uart2.AraIslemDeger[1] = ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
						if( (Uart2.AraIslemDeger[0] == 0) && ((Uart2.AraIslemDeger[1] & 1) == 1) )	
						{
							//Wrong command
							U2_Gonder("WRCM", Uart2.Dumm );							
							break;
						}	
						else if(*(U2_Buf + 1) - 48 == 1)
						{
							if((( Can.ToInv.Gonderildi.All == 0 ) && ( Can.ToPfc.Gonderildi.All == 0 )))
							{	
								Uart2.AraIslemDeger[0] = ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48));
								Uart2.AraIslemDeger[1] = ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
								
								//Adres say�s� artarsa burada kontrol� yap�labilir.
								if(( Uart2.AraIslemDeger[0] == 46 ) || ( Uart2.AraIslemDeger[0] == 0 ))			//W1046 - Inverter Options  , W1000 - Emir se
								{
									//Kay�tl� listeden hangilerine yazma i�lemi yapabilir onun kontrol�
									if( Uart2.AraIslemDeger[0] == 0 )
									{
										U2_Yetki = 0;
										for( Uart2_i = 0;Uart2_i < 7;Uart2_i++ )
										{
											if( Uart2.AraIslemDeger[1] == YazmaYetkileri_Emir[Uart2_i] )
												U2_Yetki++;
										}	
									}
									else
									{
										//0. adres de�ilse
										if( Uart2.AraIslemDeger[0] == 46 )
											U2_Yetki = 5;
									}
									if( U2_Yetki > 0 )
									{
										U2_Yetki = 0;
										//Adres 0 ise gelen i�lem emir i�lemidir.
										if( Uart2.AraIslemDeger[0] == 0 )
											Uart2.EmirGonderildi = 1;
										else							
											Uart2.EmirGonderildi = 0;
											
										if( Uart2.W_B == 0 )
										{
											YedekCanGonder(DefCanInv,28,'W',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
											CanGonder(DefCanInv,28,'W',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
										}
										else
										{
											YedekCanGonder(DefCanInv,28,'B',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
											CanGonder(DefCanInv,28,'B',Uart2.AraIslemDeger[1],Uart2.AraIslemDeger[0]);
										}
										Can.ToInv.Gonderildi.Bit.U2_W = 1;
										Uart2.Tekrar = 19;
										break;
									}	
									else
									{	U2_Gonder("ACCDE", Uart2.Dumm ); }		
								}
								else
								{	U2_Gonder("ACCDE", Uart2.Dumm ); }	
							}
						}
						else if(*(U2_Buf + 1) - 48 == 3)
						{
							Uart2.R_Adres = ( ((*(U2_Buf + 2) - 48) * 100 + (*(U2_Buf + 3) - 48) * 10 + (*(U2_Buf + 4) - 48)) << 1 ) + 2560;
							Uart2.R_Deger = ( (*(U2_Buf + 5) - 48) * 10000 + (*(U2_Buf + 6) - 48) * 1000 + (*(U2_Buf + 7) - 48) * 100 + (*(U2_Buf + 8) - 48) * 10 + (*(U2_Buf + 9) - 48) );
							Uart2.RamLimitli_mi = Uart2.R_Deger;
							
							//Kay�tl� listeden hangilerine yazma i�lemi yapabilir onun kontrol�
							U2_Yetki = 0;
							for( Uart2_i = 6;Uart2_i < 12;Uart2_i++ )
							{
								if( Uart2.R_Adres == YazmaYetkileri_Comm2[Uart2_i][0] )
									U2_Yetki++;
							}
							if( U2_Yetki > 0)
							{	
								U2_Yetki = 0;						
								//Label lar haricindeki eeprom de�erleri min - max limitlerden ge�er.
								if((Uart2.R_Adres > 3300) && (Uart2.R_Adres < DefEepromDegiskenUstSinir))								
								{
									U2_AraIslem = Uart2.R_Adres;
									U2_AraIslem = (U2_AraIslem-3302)/2;
									if( Uart2.R_Deger > MinMax[U2_AraIslem][MaxAddrKontrol] )
										Uart2.R_Deger = MinMax[U2_AraIslem][MaxAddrKontrol];
										
									if( ( Uart2.R_Deger > MinMax[U2_AraIslem][MinAddrKontrol] ) && ( Uart2.R_Deger< MinMax[U2_AraIslem][AraAddrKontrol] ) )
										Uart2.R_Deger = MinMax[U2_AraIslem][MinAddrKontrol];
										
									if( Uart2.R_Deger < MinMax[U2_AraIslem][MinAddrKontrol] )
										Uart2.R_Deger = MinMax[U2_AraIslem][MinAddrKontrol];
								}							
								*Uart2.R_Adres = Uart2.R_Deger;
								EeWordYaz( Uart2.R_Adres , Uart2.R_Deger );								
														
								//07.05.2014
								if( (Label.NominalVoltage[16] == '1') && ( (Label.NominalVoltage[17] == '1') || (Label.NominalVoltage[17] == '2') ) )
									UPS_I_O_Options = 1;
								else
									UPS_I_O_Options = 0;
									
								//Dil adresinde bir �ey yaz�l�yorsa ekran� yenile
								if( Uart2.R_Adres == 3372 )
									Menu.YenileGeriSayac = 5;
									
								if( Uart2.RamLimitli_mi == Uart2.R_Deger )	
									U2_Gonder("OK", Uart2.Dumm );
								else
									U2_Gonder("LIMITED", Uart2.Dumm );	
							}
							else
							{	U2_Gonder("ACCDE", Uart2.Dumm ); }	
						}
						else 
						{	U2_Gonder("ACCDE", Uart2.Dumm ); }
					}
					else 
					{	U2_Gonder("ACCDE", Uart2.Dumm ); }
				}
				else 
				{	U2_Gonder("ACCDE", Uart2.Dumm ); }
			}
			else if((*U2_Buf == 'R') && (*(U2_Buf + 1) == 'E') && (*(U2_Buf + 2) == 'S') && (*(U2_Buf + 3) == 'E') && (*(U2_Buf + 4) == 'T') && (*(U2_Buf + 5) == ' ') && (*(U2_Buf + 6) == 'P') && (*(U2_Buf + 7) == 'A') && (*(U2_Buf + 8) == 'S') && (*(U2_Buf + 9) == 'S'))
			{
				for( Uart2_i = 0; Uart2_i < 8; Uart2_i++ )
				{
					EeKayit.BasitPassword[0] = 48; EeKayit.BasitPassword[1] = 56; EeKayit.BasitPassword[2] = 51;
					EeKayit.BasitPassword[3] = 51; EeKayit.BasitPassword[4] = 51; EeKayit.BasitPassword[5] = 54;
					EeKayit.BasitPassword[6] = 48; EeKayit.BasitPassword[7] = 48;
					EeWordYaz( &EeKayit.BasitPassword[Uart2_i] , EeKayit.BasitPassword[Uart2_i] );
				}
				U2_Gonder("OK",Uart2.Dumm );
				break;
			}
			//Asm Reset i�lemi
			else if((*U2_Buf == 'R') && (*(U2_Buf + 1) == 'E') && (*(U2_Buf + 2) == 'S') && (*(U2_Buf + 3) == 'E') && (*(U2_Buf + 4) == 'T') && (*(U2_Buf + 5) == 'P') && (*(U2_Buf + 6) == 'A') && (*(U2_Buf + 7) == 'N') && (*(U2_Buf + 8) == 'E') && (*(U2_Buf + 9) == 'L'))
			{	asm("RESET");}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
        case 12:
            
            Uart2.R_Adres = ((*(U2_Buf + 2) - 48) * 1000 + (*(U2_Buf + 3) - 48) * 100 + (*(U2_Buf + 4) - 48) * 10 + (*(U2_Buf + 5) - 48));
            Uart2.R_Deger = ( (*(U2_Buf + 6) - 48) * 10000 + (*(U2_Buf + 7) - 48) * 1000 + (*(U2_Buf + 8) - 48) * 100 + (*(U2_Buf + 9) - 48) * 10 + (*(U2_Buf + 10) - 48) );
            EeByteYaz(Uart2.R_Adres,Uart2.R_Deger);
            U2_Gonder("OK",Uart2.Dumm );
            break;
		case 15:		
			if((*U2_Buf == 'A') && (*(U2_Buf + 1) == 'T'))									//RS232 YE TAR�H CEVABI
			{
				if( EeKayit.Konfig.Bit.UzakErisim )
				{				
					//Kullan�c� �ifresi do�ru girilmeli.
					if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
					{
						Date.Day = (((*(U2_Buf + 2) - 48) * 10) + (*(U2_Buf + 3) - 48));
						Date.Month = (((*(U2_Buf + 4) - 48) * 10) + (*(U2_Buf + 5) - 48));
						Date.Year = (((*(U2_Buf + 6)-48) * 10) + (*(U2_Buf + 7) - 48));
						Date.Hour = (((*(U2_Buf + 9) - 48) * 10) + (*(U2_Buf + 10) - 48));
						Date.Min = (((*(U2_Buf + 12) - 48) * 10) + (*(U2_Buf + 13) - 48));
						YazRTC(&Date);
						U2_Gonder("OK", Uart2.Dumm );	
						break;
					}
					else 
					{
						U2_Gonder("ACCDE",Uart2.Dumm );
					}
				}
				else 
				{
					U2_Gonder("ACCDE",Uart2.Dumm );
				}
			}
			//Tft uart tan direk foto y�kleme i�lemi ba�lad�.
			else if((*U2_Buf == 'W') && (*(U2_Buf + 1) == 'W'))
			{
				TFT.X1_Foto = ((*(U2_Buf + 2) - 48) * 100) + ((*(U2_Buf + 3) - 48) * 10) + (*(U2_Buf + 4) - 48);
				TFT.X2_Foto = ((*(U2_Buf + 5) - 48) * 100) + ((*(U2_Buf + 6) - 48) * 10) + (*(U2_Buf + 7) - 48);
				TFT.Y1_Foto = ((*(U2_Buf + 8) - 48) * 100) + ((*(U2_Buf + 9) - 48) * 10) + (*(U2_Buf + 10) - 48);
				TFT.Y2_Foto = ((*(U2_Buf + 11) - 48) * 100) + ((*(U2_Buf + 12) - 48) * 10) + (*(U2_Buf + 13) - 48);
				TFT.FotoDurum = 1;
				WindowSet(TFT.X1_Foto,TFT.X2_Foto,TFT.Y1_Foto,TFT.Y2_Foto);	
				Write_Command(0x2c);
				U2_Gonder("OK",Uart2.Dumm );
				break;
			}
			else
			{
				U2_Gonder("ERROR",Uart2.Dumm );
			}
		break;
		default:
//			BekleMs(1);
			U2_Gonder("OK", Uart2.Dumm );
		break;
	}	
}	






void U2_Gonder(char *U2_str,unsigned int *U2_Var)									
{
	unsigned int U2_x1 , U2_x2 , U2_x3;
	U2_x1 = 0;	U2_x2 = 0;	U2_x3 = 0;	
	unsigned int Uart2_z;	
	
	if( (Uart2.SonSorulanEmir=='R') || (Uart2.SonSorulanEmir == 'W') )
	{
		if( Uart2.ChkSorgusuGeldi == 0 )
		{ 
			Uart2.CheckSum = Uart2.CheckSum + *U2_Var;		
		}
	}
	Uart2.SonSorulanEmir = 0;
	
	while(*(U2_str+U2_x2))									//Sonland�rma simgesi
	{	
		if(*(U2_str+U2_x2) == '[')							//tek karakter
		{
			U2tx(U2_Var+U2_x1,1,U2_x3,0);
			U2_x1++;
		}
		else if(*(U2_str+U2_x2) == ']')						//iki karakter
		{
			U2tx(U2_Var+U2_x1,2,U2_x3,0);
			U2_x1++;
			U2_x3=U2_x3+1;
		}
		else if(*(U2_str+U2_x2) == '|')						//1.3
		{
			U2tx(U2_Var+U2_x1,2,U2_x3,1);
			U2_x1++;
			U2_x3=U2_x3+2;
		}
		else if(*(U2_str+U2_x2) == '%')						//�� karakter yazd�r
		{
			U2tx(U2_Var+U2_x1,3,U2_x3,0);
			U2_x1++;
			U2_x3=U2_x3+2;
		}
		else if(*(U2_str+U2_x2) == '^')						//50.1 gibi noktal� de�erleri yazd�rmak
		{
			U2tx(U2_Var+U2_x1,3,U2_x3,1);
			U2_x1++;
			U2_x3=U2_x3+3;		
		}
		else if(*(U2_str+U2_x2) == '@')						//4 karakter yazd�rmak
		{
			U2tx(U2_Var+U2_x1,4,U2_x3,0);
			U2_x1++;
			U2_x3=U2_x3+3;		
		}
		else if(*(U2_str+U2_x2) == '�')						//4 ve noktal� toplam 5 karakter yazd�rmak
		{													//�rn. 123.1 gibi.
			U2tx(U2_Var+U2_x1,4,U2_x3,1);
			U2_x1++;
			U2_x3=U2_x3+4;		
		}
		else if(*(U2_str+U2_x2) == '�')						//5 karakter yazd�rmak
		{
			U2tx(U2_Var+U2_x1,5,U2_x3,0);
			U2_x1++;
			U2_x3=U2_x3+4;		
		}
		else if(*(U2_str+U2_x2) == '~')						//Alarmlar� yazd�rmak i�in
		{
			Nop();
		}
		else if(*(U2_str+U2_x2)=='$')
		{		
			U2TxDmaBuf[U2_x3] = *(U2_Var+U2_x1);	
			U2_x1++;
		}
		else 
		{		
			U2TxDmaBuf[U2_x3] = *(U2_str+U2_x2);	
		}
		U2_x3++;
		U2_x2++;
	}
	Uart2.LokalSayac = 0;
	//Kelime sonlar� i�in <Chr13>
	U2TxDmaBuf[U2_x3] = 13;										

	DMA6CNT = U2_x3;
	DMA6STA = __builtin_dmaoffset(&U2TxDmaBuf);
	DMA6CONbits.CHEN = 1;								
	DMA6REQbits.FORCE = 1;
						
}

void U2tx(unsigned int *U2_Deger,unsigned int U2_Hane,unsigned int U2_HaneBuf,unsigned int U2_Nokta)
{		
	switch(U2_Hane)
	{
		case 5:
			U2TxDmaBuf[U2_HaneBuf] = (*U2_Deger / 10000) + 48;
		case 4:
			U2TxDmaBuf[U2_HaneBuf+U2_Hane-4] = ((*U2_Deger % 10000) / 1000) + 48;
		case 3:
			U2TxDmaBuf[U2_HaneBuf+U2_Hane-3] = (((*U2_Deger % 10000) % 1000) / 100) + 48;
		case 2:
			U2TxDmaBuf[U2_HaneBuf+U2_Hane-2] = ((((*U2_Deger % 10000) % 1000) % 100) / 10)+ 48;
			if(U2_Nokta == 1)
				U2TxDmaBuf[U2_HaneBuf+U2_Hane-1] = '.';
		case 1:
			U2TxDmaBuf[U2_HaneBuf+U2_Hane-1+U2_Nokta] = ((((*U2_Deger % 10000) % 1000) % 100) % 10) + 48;
			break;
		default:
			break;
	}
}