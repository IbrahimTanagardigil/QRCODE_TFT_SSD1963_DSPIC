#ifndef __TFTCANPFC_H__
#define __TFTCANPFC_H__


extern void CanPfcIslemFonk(unsigned int *);

#endif