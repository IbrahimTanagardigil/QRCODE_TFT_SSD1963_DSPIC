#include "p33FJ256MC710.h"

#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTVar.h"


#define TURKCE			//23.07.14
//#define FRANSIZCA	


void XtOsc(void)
{	
	asm("MOV	#0x001E, W0\n"
		"MOV	W0, PLLFBD\n"	
		"MOV	#0x3320, W0\n"
		"CLR	CLKDIV\n"	
		"MOV	#0x13, W0\n"
		"MOV	#OSCCONH, W1\n"
		"MOV	#0x78, W2\n"
		"MOV	#0x9A, W3\n"
		"MOV.B	W2, [W1]\n"	
		"MOV.B	W3, [W1]\n"		
		"MOV.B	W0, [W1]\n"	
		"MOV	#0x01, W0\n"
		"MOV	#OSCCONL, W1\n"
		"MOV	#0X46, W2\n"
		"MOV	#0X57, W3\n"
		"MOV.B	W2, [W1]\n" 	
		"MOV.B	W3, [W1]\n" 	
		"MOV.B	W0, [W1]\n"); 	
}

//�n y�klemelerin hepsi buradan �a�r�l�r.
void Initiliaze(void)								
{	
	volatile unsigned int Initz = 0;
	
	//Adc pinleri dijital							
	AD1PCFGH = 0xffff;									
	AD1PCFGL = 0xffff;	
	AD2PCFGL = 0xffff;	
	
	Timer6.Ilk_15sn_Sayac = 300;
		
	//Pin Tan�mlamalar�
	PinInit();
	//Buton Tan�mlamalar�
	InitCN();	
	//Timer tan�mlamalar�
	InitT4T5();									//Bak�m alarmlar� i�in
	InitT6();									//Zamanlama i�lemleri i�in
	InitT3();									//Giri� DC ka�ak �rne�i almak i�in
	InitT1();									//�ifre i�lemleri i�in
	InitT9();									//�ifre i�lemleri i�in
	InitT2();									//Tft gecikmeleri i�in
	//Can Tan�mlamalar�
	InitCAN1();	
	InitDMA0();
	InitDMA1();		
					
	//Spi tan�mlamalar�
	InitSPI1(1,1);								//Rtc
	InitSPI2(1,1);								//Eeprom
	//Uart tan�mlamalar�
//	InitUART1(9600);
//	InitDMA7();
//	InitUART2(9600);
//	InitDMA6();	
	//LcdBacklight Tan�mlamalar�
	
		
	//Denemelerde normalde silinecek.
	Can.FromInv.SifreSistemi = 2;
	Menu.ButonBayrak = 0;Menu.AlarmSesAcik = 1;Menu.ZamanAyarIci = 0;Menu.MaskeAlarmSesAcik = 1;
	Menu.EskiAlarmSesAcik = Menu.MaskeAlarmSesAcik;
	//Max log kapasitesi �uan i�in sabit Default larda da var.Sonra de�i�tirilebilir, yap�labilir.
	EeKayit.MaxLogKapasitesi = DefMaxLogSayisi;
	EeWordYaz( &EeKayit.MaxLogKapasitesi , EeKayit.MaxLogKapasitesi );
	
	//S�cakl�k �l��mleri i�in Adc tan�mlamalar�
//	AnalogKanalSayisi = 2; 
//	AnalogKanallar[0] = AN8; AnalogKanallar[1] = AN9;
//	InitADC(AnalogKanallar,AnalogKanalSayisi);
	
	//AnalogKanalSayisi = 5; 								//02.10.2013
	AnalogKanalSayisi = 7; 									//27.05.2015
	AnalogKanallar[0] = AN8; AnalogKanallar[1] = AN9;		//TH1,TH2
	AnalogKanallar[2] = AN10;								//Giri� DC ka�ak �rne�i
	AnalogKanallar[3] = AN11;								//Giri� DC ka�ak �rne�i
	AnalogKanallar[4] = AN12;								//Besleme gerilimi
	AnalogKanallar[5] = AN19;								//27.05.2015 Touch screen AnalogX -> RC4
	AnalogKanallar[6] = AN18;								//27.05.2015 Touch screen AnalogY -> RC3
	InitADC(AnalogKanallar,AnalogKanalSayisi);
	
	//Eeprom a default de�erlerin y�klenip y�klenmedi�ini kontrol eder.
	EepromBosKontrol = EeWordOku( DefEepromBosKontrol );
	if( EepromBosKontrol != 1 )
		DefaultDegerler();
	
	//Eeprom un gerekli adresler aras�n� Ram e aktar�yor.
	for( Initz = 3072;Initz < DefEepromDegiskenUstSinir;Initz+=2,RamAdres = Initz )
		*( RamAdres ) = EeWordOku( RamAdres );
		
	Genel.TFTRESET = 400;				//05.02.2015
	Genel.TFTRESETFLAG = 0;
	InitTFT();
	
	if( (Label.NominalVoltage[16] == '1') && ( (Label.NominalVoltage[17] == '1') || (Label.NominalVoltage[17] == '2') ) )			//07.05.2014
		UPS_I_O_Options = 1;
	else
		UPS_I_O_Options = 0;
		
		
	for( Initz = 0;Initz < 12;Initz++ )						//12.03.2014
		RoleIslem(Initz,EeKayit.Role_NoNc);
		
	if( EeKayit.LogCounterPage > 0 )
		LogSayisiToInv = DefLogUstSinir;
	else
		LogSayisiToInv = EeKayit.LogSayac;
	//Log sayac Inv taraf�ndan istenir.	
//	if( EeKayit.LogSayac > 1 )
//		LogSayisiToInv = EeKayit.LogSayac - 2;
//	else
//		LogSayisiToInv = 0;
	
	//Basit �ifre ve user �ifre e�er numerikten farkl�ysa i�erisine 0 (ascii 48) yaz.
	for( Initz = 0;Initz < 8;Initz++ )
	{
		if(( EeKayit.BasitPassword[Initz] > 57 ) || ( EeKayit.BasitPassword[Initz] < 48 ))
		{			
			EeKayit.BasitPassword[Initz] = 48;
			EeWordYaz( &EeKayit.BasitPassword[Initz] , EeKayit.BasitPassword[Initz] );
		}
		if(( EeKayit.UserPassword[Initz] > 57 ) || ( EeKayit.UserPassword[Initz] < 48 ))
		{			
			EeKayit.UserPassword[Initz] = 48;
			EeWordYaz( &EeKayit.UserPassword[Initz] , EeKayit.UserPassword[Initz] );
		}
	}			
	//R�le atamalar�n�n ilk de�er y�klemeleri
	for( Initz = 0;Initz < 12;Initz++ )
	{
		//Menu.RoleAtamaDeger[Initz] = EeKayit.Role[Initz];
		Menu.RoleAtamaDeger[Initz] = RoleAtamaIndex(EeKayit.Role[Initz]);		//Genel Alarm 06.07.2015 tarihinde RoleAtamaIndex() fonksiyonu eklendi eklendi Eski hali->Menu.RoleAtamaDeger[Initz] = EeKayit.Role[Initz];
		Menu.OldRoleAtamaDeger[Initz] = Menu.RoleAtamaDeger[Initz];
	}
	//Mimik i�lemi i�in
	MimikDurum.MimikUpdateSayac = 11;
	//Tercihler men�s� UyariSesAraligi ayar� update i i�in
	Genel.GolgeUyariSesAraligi = EeKayit.UyariSesAraligi;
	//Tercihler men�s� LcdBacklight ayar� update i i�in
	Genel.GolgeLcdBacklight = EeKayit.LcdBacklight;
	//Tercihler men�s� AcikSure ayar� update i i�in
	Genel.GolgeAcikSure = EeKayit.AcikSure;
	//Tercihler men�s� YarimAydinlikSure ayar� update i i�in
	Genel.GolgeYarimAydinlikSure = EeKayit.YarimAydinlikSure;
	//Yukar�daki i�lemler R�le ayarlar� i�in de yap�labilir.
	//Ayar > Panel ayarlar�nda bir i�lemlerini d�zg�n yapabilmek i�in konuldu.
	Genel.YedekKonfig.All = EeKayit.Konfig.All;
	//Uart tan�mlamalar�
	if( EeKayit.Konfig.Bit.Comm2Secim == DefServisPort )			//21.08.2013
		InitUART2(9600);
	if( EeKayit.Konfig.Bit.Comm2Secim == DefUserPort )
		InitUART2(2400);
	InitUART1(2400);
//	InitUART1(9600);
	InitDMA7();
//	InitUART2(9600);
	InitDMA6();	
			
	//Ba�lang�� De�erleri
	Menu.ButonBayrak = 0;
	Menu.AyarPssswordIci = 0; Menu.SifreDurum = 0;Menu.AyarAnaSekme = 0;
	Genel.EeSildenSonraAlrKayitSayac = 10;			//ilk 500 ms alarm kayd� yok
	Genel.IlkAcilisAlrSayac = 0;
	Menu.AyarAltSekme = 0;
	Genel.LoginWaitButon = 0;
	//Log silme i�lemi i�in kullan�l�r.
	Genel.LogSilmeSonu = 0;		
	Genel.LogSilEmri = 0;
	//�lk menu a��l��� ana men�	
	Menu.Sekme.All = 1;							
	Menu.Buton.All = 0;
	Buzzer = 0;
	Uart1.Dumm[0] = 0; Uart2.Dumm[0] = 0;
	Menu.EnterStopBoost = 0;
	Uart2.ChkSorgusuGeldi = 0; Uart1.ChkSorgusuGeldi = 0;
	Uart1.SonSorulanEmir = 0; Uart2.SonSorulanEmir = 0;
	Menu.AnaSekme = 1; Menu.Alt1Sekme = 1; Menu.OlcumAltSekme = 1; Menu.TercihAltSekme = 1;
	Menu.Koordinat = ( Menu.AnaSekme & 0x00ff ) + ( (Menu.Alt1Sekme << 8) % 0xff00 );
	Menu.AyarAnaSekme = 1; Menu.AyarAltSekme = 1;
	Menu.AyarKoordinat = ( Menu.AyarAnaSekme & 0x00ff ) + ( (Menu.AyarAltSekme << 8) % 0xff00 );
	//Ak� toplam enerji ilk ve bypass varken hep b�yledir.
	AkuKapasite.TopEnerji = 100 * EeKayit.AkuAh;
	AkuKapasite.IlkDakikaGecti = 0;
	//Alarma ba�l� r�leler �eksin diye.
	Menu.RoleTestSayac = 0;
	//O anki alarmlar� g�stersin diye.
	Menu.Log_AlarmGoster = DefOanAlrGoster;		
	//S�cakl�k �l��m�nde kullan�lacak i�lemler
	Genel.Th1Sayac = 0; Genel.Th2Sayac = 0;
	
	Menu.ExAnaSekme = 1;
	Menu.AnaSekme = 1;
	
	
//	TftVersiyon = 9;						//21.08.2013
//	TftVersiyon = 10;						//02.10.2013
//	TftVersiyon = 11;						//11.11.2013			//�l��mler/��k�� ta ��k�� ak�m� xx.x de�eri yanl�� yaz�l�yd�.
//	TftVersiyon = 12;						//18.02.2014			ispanyolca ve leh�e eklendi
//	TftVersiyon = 13;						//12.03.2014			Tercihler men�s� Haberle�me tercihleri epo lojik 0-1 role no-nc
//	TftVersiyon = 14;						//07.05.2014 tarihinde 110 V giri� ��k�� cihazlar i�in ayar men�s�nde de�i�iklik yap�ld�. Baz� de�erler 2 ye b�l�nerek g�steriliyor. (UPS_I_O_Options)
#ifdef TURKCE								//23.07.14
	TftVersiyon = 16;						//versiyon 15 -> 14.07.14 tarihinde 3 e 1 cihazlar i�in otomatik se�im eklendi.
#endif
#ifdef FRANSIZCA
	TftVersiyon = 1016;						//versiyon 15 -> 14.07.14 tarihinde 3 e 1 cihazlar i�in otomatik se�im eklendi.
#endif
	for(Initz=0;Initz<8;Initz++)
	{
		Menu.GolgeSifre[Initz] = 48;
		Menu.UserGolgeSifre[Initz] = 48;
	}
	InitPWM(0,1220);
	Menu.OldLcdBacklight = EeKayit.LcdBacklight;
	TftInitBackCounter = 4;					//09.07.2013 TFT yeniden ba�latma i�in ar�za durumunda kullan�lacak.

	NavigasyonuSil = 0;						//Touch i�in eklendi.
	_TouchCount = 0;						//Touch i�in eklendi
    BekleCounter = 0;
    BakimHesaplaFlag = 0;
}

int RoleAtamaIndex(int AlarmSira)		//06.07.2015 tarihinde eklendi	Genel Alarm
{
	int i;
	int a = 0;i = 0;
	
	while(RoleAtama[i] != '/n')
	{
		if( AlarmSira == RoleAtama[i] )
			return i;
		i++;			
	}	
	return a;
}
//Tan�mlama fonksiyonlar�
//-----------------------


//Pin Tan�mlamalar�									
void PinInit(void)
{	
	TRISA = 0;		
	TRISAbits.TRISA14 = 1;						//EMC Stop
	TRISAbits.TRISA15 = 1;						//RTC 1sn kesme pin i.
			
	TRISB = 0;
	TRISBbits.TRISB0 = 1;						//Buton	- CN2 - Asa��
	TRISBbits.TRISB1 = 1;						//Buton	- CN3 - Sol
	TRISBbits.TRISB2 = 1;						//Buton	- CN4 - Enter
	TRISBbits.TRISB3 = 1;						//Buton	- CN5 - Sa�
	TRISBbits.TRISB4 = 1;						//Buton	- CN6 - Yukar�
	TRISBbits.TRISB8 = 1;						//AN8 S�cakl�k Sens�r�	           TH1
	TRISBbits.TRISB9 = 1;						//AN9 Opsiyonel S�cakl�k Sens�r�   TH2
	TRISBbits.TRISB10 = 1;						//AN10 Opsiyonel Giri� DC ka�ak �rne�i
	TRISBbits.TRISB11 = 1;						//AN10 Opsiyonel Giri� DC ka�ak Vref
	TRISBbits.TRISB12 = 1;						//AN12 Besleme gerilimi			02.10.2013
		
	TRISC = 0;
	TRISD = 0;
	
	TRISE = 0;
	TRISEbits.TRISE8 = 1;						//BATT SW
	TRISEbits.TRISE9 = 1;						//GENIN1
	
	TRISF = 0;
	TRISFbits.TRISF0 = 1;						//C1Rx
	TRISFbits.TRISF2 = 1;						//U1Rx
	TRISFbits.TRISF4 = 1;						//U2Rx
	TRISFbits.TRISF7 = 1;						//Rtc Data in
	
	TRISG = 0;
	TRISGbits.TRISG0 = 1;						//OPT03 kart� IN3 OPT
	TRISGbits.TRISG1 = 1;						//OPT03 kart� IN4 OPT
	TRISGbits.TRISG7 = 1;						//Spi2 Eeprom Din

	LATA = 0; LATB = 0; LATC = 0; LATD = 0; LATE = 0; LATF = 0; LATG = 0;
	
	_LATA14=1;	_LATA15=1;	
	
	_LATB0=1;	_LATB1=1;	_LATB2=1;	_LATB3=1;	_LATB4=1;	_LATB8=1;	_LATB9=1;	_LATB10=1;	_LATB11=1;
	
   	_LATE8=1;	_LATE9=1;
   		
	_LATF0=1;	_LATF2=1;	_LATF4=1;	_LATF7=1;
	
	_LATG0=1;	_LATG1=1;	_LATG7=1;	
}

//Buton Tan�mlamalar�
void InitCN(void)
{
	IPC4bits.CNIP = 5;
	CNEN1bits.CN2IE = 1;						//Asagi					
	CNEN1bits.CN3IE = 1;						//Sol	
	CNEN1bits.CN4IE = 1;						//Enter
	CNEN1bits.CN5IE = 1;						//Sag	
	CNEN1bits.CN6IE = 1;						//Yukari
	IEC1bits.CNIE = 1;
	IFS1bits.CNIF = 0;
}
//Timer tan�mlamalar�

//LcdBacklight Tan�mlamalar�
void InitPWM(int Duty, int Freq)
{
//	PTPER = (long)( DefFcy / (Freq*2) - 1 );
	//1220 hz 40 mhz te
	PTPER = 16392;
	SEVTCMP = PTPER;
	PTMR = 0;
	PDC4 = 0;									//PWM4 duty cycle
	PWMCON1 = 0x0880;							//PWM4H pin is in the independet output mode, and PWM4H is allowed.
	DTCON1 = 0;									//About Dead - Time
	PTCONbits.PTMOD = 0;						//Free running mode
	PTCONbits.PTCKPS = 0;						//Time base is Tcy
	PTCONbits.PTOPS = 0;						//postscaler = 0
	PTCONbits.PTSIDL = 0;						//PWM time base runs in CPU Idle mode
	IFS3bits.PWMIF = 0;
	IEC3bits.PWMIE = 1;
	PTCONbits.PTEN = 1;
}
//Bak�m zamanlar�n�n hesab� i�in kullan�l�yor.
void InitT4T5(void)															//32 B�T L�K TIMER BAKIM SAATLER�N� AYALAMAK ���N 10 DK LIK TIMER
{
	T4CON = 0;
	T5CON = 0;
	T4CONbits.T32 = 1;														//Enable 32 bit timer
	T4CONbits.TCKPS = 3;													//1:256 Prescaler
	TMR5 = 0;
	TMR4 = 0;
	PR5 = 0x0596;															//10dkl�k timer	form�l : 256 x 25 x 10^-9  x PR5PR4 = SURE
	PR4 = 0x82F0;															//yeni2
	T4CONbits.TON = 1;														//Do not start timer 2
	INTCON2bits.INT4EP=1;													//INT BACA�I Y�KSELEN KENARDA TET�KLEN�R.
	IFS1bits.T5IF = 0;														//Clear timer 2 interrupt flag
	IEC1bits.T5IE = 1;
}
//Genel i�lemler i�in
void InitT6(void)															//50ms
{
	T6CON = 0;
	T6CONbits.TCKPS = 3;
	PR6 = 7812;							
	T6CONbits.TON = 0;
	IFS2bits.T6IF = 0;					
	IEC2bits.T6IE = 1;
	T6CONbits.TON = 1;	
}
//Giri� DC ka�ak �rne�i almak i�in
void InitT3(void)
{
	T3CON = 0;																//Clear TIMER5 control register
	T3CONbits.TCKPS = 1;													//1:1 Prescaler
	PR3 = 16000;															//for 400us
	T3CONbits.TON = 0;														//Do not start timer 3
	IFS0bits.T3IF = 0;														//Clear timer 9 interrupt flag
	IEC0bits.T3IE = 1;														//Interrupt enable
	T3CONbits.TON = 1;														//Start timer 9
}
//Timer 1 ve Timer 9 �ifre sistemi i�in kullan�l�yor.
//Kesmeler kapal�
void InitT1(void)
{
	T1CON = 0;																//Clear TIMER1 control register
	T1CONbits.TCKPS = 2;													//1:1 Prescaler
	PR1 = 0;																//Adjust timer period	
	T1CONbits.TON = 0;														//Do not start timer 1
	IFS0bits.T1IF = 0;														//Clear timer 1 interrupt flag
	T1CONbits.TON = 1;														//Start timer 1
}
void InitT9(void)
{
	T9CON = 0;																//Clear TIMER8 control register
	T9CONbits.TCKPS = 1;													//1:1 Prescaler
	PR9 = 0;																//Adjust timer period
	T8CONbits.T32 = 0;														//Do not start timer 9	
	T9CONbits.TON = 0;														//Do not start timer 9
	IFS3bits.T9IF = 0;														//Clear timer 9 interrupt flag
	T9CONbits.TON = 1;														//Start timer 9
}
void InitT2(void)
{
	T2CON = 0;																//Clear TIMER2 control register
	T2CONbits.TCKPS = 1;													//1:8 Prescaler
	PR2 = 100;																//Adjust timer period		//20 us
	T2CONbits.TON = 0;														//Do not start timer 6
	IFS0bits.T2IF = 0;														//Clear timer 6 interrupt flag
	IEC0bits.T2IE = 1;
	T2CONbits.TON = 1;														//Start timer 6
}

//Can Tan�mlamalar�
void InitCAN1(void)
{
	//CAN configuration
	C1CTRL1bits.REQOP = 0x4;												//Requested operation mode is configuration mode
	while(C1CTRL1bits.OPMODE != 4);											//Wait until the module gets into the configuration mode

#if CAN_111kHz						//Eski
	//CAN clock initialization
	C1CTRL1bits.CANCKS = 1;				//Fcan is selected to be Fcy
	C1CFG1bits.BRP = 0x11;				//BRPVAL;//CAN baud rate configuration register
	C1CFG1bits.SJW = 2;
	C1CFG2bits.SEG2PHTS = 1;			//Phase segment 2 select bit is freely programmable
	C1CFG2bits.PRSEG = 3;
	C1CFG2bits.SEG1PH = 5;
	C1CFG2bits.SEG2PH = 4;
	C1CFG2bits.SAM = 1;					//Sample the bus 3 times
#endif
#if CAN_100kHz						//28.02.2013 inv ve pfc s�r�mleri ile birlikte de�i�tirildi.Panel versiyon V0007 olacak.�nv ve pfc s�r�m no : 10 olacak	
	//CAN clock initialization(100 kHz)
	C1CTRL1bits.CANCKS = 1;				//Fcan is selected to be Fcy
	C1CFG1bits.BRP = 0x09;				//BRPVAL;//CAN baud rate configuration register
	C1CFG1bits.SJW = 2;
	C1CFG2bits.SEG2PHTS = 1;			//Phase segment 2 select bit is freely programmable
	C1CFG2bits.PRSEG = 3;
	C1CFG2bits.SEG1PH = 8;
	C1CFG2bits.SEG2PH = 5;
	C1CFG2bits.SAM = 1;					//Sample the bus 3 times	
#endif

	//CAN reception registers configuration
	C1CTRL1bits.WIN = 1;													//Enable window to access acceptance filter registers
	C1FMSKSEL1 = 0xfff0;													//Select acceptance filter mask0 for acceptance filter 0 and 1
	C1FMSKSEL2 = 0xffff;

	C1RXM0SID = 0xffe8;														//Include bits [10-0] in the filter comparison and match only standard identifiers
	C1RXM1SID = 0xffe8;
	C1RXM2SID = 0xffff;

	//Acceptance filter configuration
	C1RXF0SID = 0x5a00;														//Data received from the inverter
	C1RXF1SID = 0x7a00;														//Data received from the rectifier
	C1RXF2SID = 0x0000;
	C1RXF3SID = 0x0000;
	C1RXF4SID = 0x0000;
	C1RXF5SID = 0x0000;
	C1RXF6SID = 0x0000;
	C1RXF7SID = 0x0000;
	C1RXF8SID = 0x0000;
	C1RXF9SID = 0x0000;
	C1RXF10SID = 0x0000;
	C1RXF11SID = 0x0000;
	C1RXF12SID = 0x0000;
	C1RXF13SID = 0x0000;
	C1RXF14SID = 0x0000;
	C1RXF15SID = 0x0000;

	C1FEN1 = 0;
	C1FEN1bits.FLTEN0 = 1;
	C1FEN1bits.FLTEN1 = 1;
	C1BUFPNT1 = 0x21;

	//CAN transmission registers configuration
	C1FCTRL = 0x3;
	C1CTRL1bits.WIN = 0;													//Clear window to access CAN control registers

	C1RXFUL1 = 0;
	C1RXFUL2 = 0;
	C1RXOVF1 = 0;
	C1RXOVF2 = 0;

	//Buffer 0 is assigned for transmission and buffer 1 and 2 are assigned for reception
	C1TR01CON = 0x0083;														//TXEN0 = 1, TXEN1 = 0
	C1TR23CON = 0x0003;														//TXEN2 = 0, TXEN3 = 0

	//Interrupt configuration
	C1INTE = 0xffff;
	C1INTF = 0;
	IEC2bits.C1IE = 1;
	IFS2bits.C1IF = 0;


	//Return to normal operation mode
	C1CTRL1bits.REQOP = 0;
	while(C1CTRL1bits.OPMODE != 0);
}
void InitDMA0(void)
{
	DMA0CON = 0x2020;														//Peripheral indirect addressing mode
	DMA0REQ = 0x0046;														//Select ECAN TX as DMA request
	DMA0CNT = 7;															//8 DMA requests
	DMA0STA = __builtin_dmaoffset(&ecanmsgbuf);
	DMA0PAD = &C1TXD;
	DMA0CONbits.CHEN = 1;													//Enable DMA0 channel
}

void InitDMA1(void)
{
	DMA1CON = 0x0020;														//Peripheral indirect addressing mode
	DMA1REQ = 0x0022;														//Select ECAN RX as DMA request
	DMA1CNT = 7;															//8 DMA requests
	DMA1STA = __builtin_dmaoffset(&ecanmsgbuf);
	DMA1PAD = &C1RXD;
	DMA1CONbits.CHEN = 1;
	IEC0bits.DMA1IE = 1;													//Enable DMA1 interrupt
	IFS0bits.DMA1IF = 0;													//Clear DMA1 interrupt flag
}
//Spi tan�mlamalar�
void InitSPI1(int spre, int ppre)	//Rtc
{
	SPI1BUF = 0x0000;
	SPI1CON1 = 0x0020;
	SPI1CON1bits.SPRE = spre;
	SPI1CON1bits.PPRE = ppre;

	SPI1CON2 = 0x0000;
	SPI1STATbits.SPIEN = 1;	
	IFS0bits.SPI1IF = 0;
	IEC0bits.SPI1IE = 0;
}
void InitSPI2(int spre, int ppre)	//Eeprom										
{
	SPI2BUF = 0x0000;	
	SPI2CON1 = 0x0020;
	SPI2CON1bits.CKE = 1;
	SPI2CON1bits.SPRE = spre;
	SPI2CON1bits.PPRE = ppre;

	SPI2CON2 = 0x0000;												
	SPI2STATbits.SPIEN = 1;											
	IFS2bits.SPI2IF = 0;											
	IEC2bits.SPI2IE = 0;	
	
	//Eeprom pinleri
	EeHold = 1; EeWp = 1; Ee_Cs = 1;								
}

//S�cakl�k �l��mleri i�in Adc tan�mlamalar�
void InitADC(unsigned int *AnChannel,unsigned int AnChannelNo)
{
	unsigned int An_i;
	
	AD1CON2bits.VCFG = 0;													//External Vref+ and external Vref-
	AD1CON2bits.CSCNA = 0;													//Don't Scan inputs for channel 0
	AD1CON2bits.CHPS = 0;													//Convert only channel 0
	AD1CON2bits.SMPI = 0;													//Generate interrupt after complition of every 15th sample/conversion operation
	AD1CON2bits.BUFM = 0;													//Start filling the buffer from the start address
	AD1CON2bits.ALTS = 0;													//Use only sample A

	AD1CON3bits.ADRC = 0;													//System clock is used
	AD1CON3bits.SAMC = 15;													//15 TAD �NCEDEN 1 TAD TI
	AD1CON3bits.ADCS = 9;													//TAD = 10 * TCY (250 nS)	�NCEDEN 4 T�.

	AD1CON4bits.DMABL = 0;													//Allocate 1 word of buffer for each analog input

	AD1CHS123 = 0;															//?
	AD1CHS0 = 0; 															//��MD�L�K B�YLE ADC OKUNACA�I ZAMAN KANALLAR SE��LECEK

	AD1CSSH = 0x0000;														//NOT SCAN ANY CHANNELS
	AD1CSSL = 0x0000; 			

	AD1PCFGH = 0xffff;
	AD1PCFGL = 0xffff;
	
	for( An_i = 0;An_i < AnChannelNo;An_i++ )
	{
		if(*(AnChannel + An_i) < 16 )
			AD1PCFGL &= ~( 1 << (*(AnChannel + An_i)));	
		else
			AD1PCFGH &= ~( 1 << (*(AnChannel + An_i) - 16));	
	}

	AD1CON1bits.ADON = 1;													//Start analog to digital converter module
}

//Uart tan�mlamalar�
void InitUART1(unsigned int BaudRate1)
{
	IPC2bits.U1RXIP = 6;
	U1TXREG = 0;
	U1RXREG = 0;
	if( BaudRate1 == 9600 )
		U1BRG = 259;
	if( BaudRate1 == 2400 )
		U1BRG = 1040;		
	U1MODE = 0x8800;											
	U1STA = 0x8400;
	IFS0bits.U1TXIF = 0;												
	IFS0bits.U1RXIF = 0;												
	IEC0bits.U1TXIE = 0;												
	IEC0bits.U1RXIE = 1;												
}
void InitDMA7(void)
{
	DMA7CON = 0x2001;													
	DMA7REQ = 0x000c;														
	DMA7CNT = 3;				
	DMA7STA = __builtin_dmaoffset(&U1TxDmaBuf);
	DMA7PAD = &U1TXREG;
	DMA7CONbits.CHEN = 1;		
	IFS4bits.DMA7IF = 0;
	IEC4bits.DMA7IE = 0;
}
void InitUART2(unsigned int BaudRate2)
{
	IPC7bits.U2RXIP = 7;
	U2TXREG = 0;
	U2RXREG = 0;
	if( BaudRate2 == 38400 )
		U2BRG = 64;
	if( BaudRate2 == 19200 )
		U2BRG = 129;
	if( BaudRate2 == 9600 )
		U2BRG = 259;
	if( BaudRate2 == 2400 )
		U2BRG = 1040;											
	U2MODE = 0x8800;													
	U2STA = 0x8400;
	//Sinyalleri invert etmede kullan�l�r.
//	U2STAbits.UTXINV = 1;
//	U2MODEbits.URXINV = 1;
	
	IFS1bits.U2TXIF = 0;
	IFS1bits.U2RXIF = 0;
	IEC1bits.U2TXIE = 0;
	IEC1bits.U2RXIE = 1;
}
void InitDMA6(void)
{
	DMA6CON = 0x2001;													
	DMA6REQ = 31;														
	DMA6CNT = 3;				
	DMA6STA = __builtin_dmaoffset(&U2TxDmaBuf);
	DMA6PAD = &U2TXREG;
	DMA6CONbits.CHEN = 1;		
	IFS4bits.DMA6IF = 0;
	IEC4bits.DMA6IE = 0;
}


