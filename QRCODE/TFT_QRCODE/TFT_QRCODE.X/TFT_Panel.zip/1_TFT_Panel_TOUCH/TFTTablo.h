#ifndef __TFTTABLO_H__
#define __TFTTABLO_H__



extern volatile unsigned  char *AnaMenu[5][10];
//Yeni eklendi.23.07.2012
extern volatile unsigned  char *ParalelMenu[4][5];
//extern volatile unsigned  char *UstKelime[32][5];
extern volatile unsigned  char *StatusMenu[3][5];
extern volatile unsigned  char *OlcumAnaMenu[5][7];
extern volatile unsigned  char *OlcumAltMenu[16][5];	
extern volatile unsigned  char *TercihAnaMenu[5][4];

extern volatile unsigned  char *EkranTercih[37][5];
extern volatile unsigned  char *EkranTercihSigns[36][5];

extern volatile unsigned  char *BypTercih[6][5]; 
extern volatile unsigned  char *AlrTercih[7][5];	
extern volatile unsigned  char *CommTercih[18][5];






extern volatile unsigned  char *GenelTablo[21][5];

extern volatile unsigned  char *TouchTablo[3][5];


extern volatile unsigned  char *BilgiAnaMenu[10][5];


extern volatile unsigned  char *EmirMenu[15][5];
extern volatile unsigned  char *ServisMenu[15][5];

extern volatile unsigned  char *AyarOnMenu_Cevap[7][5];
extern volatile unsigned  char *AyarOnMenu_4[1][5];  	
extern volatile unsigned  char *AyarOnMenu_3[2][5]; 
extern volatile unsigned  char *AyarOnMenu_2[3][5];
extern volatile unsigned  char *AyarOnMenu_1[2][5]; 






extern volatile unsigned  char *ZamanMenu[9][5];
extern volatile unsigned  char *AyarAnaMenu[11];
extern volatile unsigned  char *Ayar_GrupAdj[10][5];
extern volatile unsigned  char *Ayar_GrupAdj_2192[19][5];	
extern volatile unsigned  char *Ayar_GrupAdj_2193[5][5];
extern volatile unsigned  char *Ayar_GrupAdj_2194[5][5];
extern volatile unsigned  char *Ayar_GrupAdj_2185[4][5];
extern volatile unsigned  char *Ayar_GrupAdj_2142[4][5];
extern volatile unsigned  char *Ayar_GrupAdj_1187[11][5];
extern volatile unsigned  char *Ayar_GrupAdj_1136[8][5];
extern volatile unsigned  char *Ayar_GrupAdj_1181[10][5];
extern volatile unsigned  char *Ayar_GrupAdj_1233[3][5];
extern volatile unsigned  char *Ayar_GrupAdj_2233[3][5];	



extern volatile unsigned  char *Ayar_InvFactOpt[17][5];
extern volatile unsigned  char *Ayar_PfcFactOpt[12][5];
extern volatile unsigned  char *Ayar_PanelOpt[20][5];			//26.11.2014 tarihinde 16 dan 19 yap�ld�
extern volatile unsigned  char *Ayar_AcInput[13][5]; 
extern volatile unsigned  char *Ayar_AcBypass[6][5]; 
extern volatile unsigned  char *Ayar_AcOutput[12][5]; 
extern volatile unsigned  char *Ayar_DcAdj[13][5]; 
extern volatile unsigned  char *Ayar_Power[26][5];
extern volatile unsigned  char *Ayar_SysAdj[7][5];


extern volatile unsigned  char *AyarAltMenu[51];

extern volatile unsigned  char *Alarms[112][5];

#endif