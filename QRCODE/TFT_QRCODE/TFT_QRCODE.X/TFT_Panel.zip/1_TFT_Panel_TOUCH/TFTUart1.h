#ifndef __TFTUART1_H__
#define __TFTUART1_H__


extern void Uart1_Fonk( unsigned int *, unsigned int );
extern void U1_Gonder(char *,unsigned int *);
extern void U1tx(unsigned int *,unsigned int ,unsigned int ,unsigned int );

#endif