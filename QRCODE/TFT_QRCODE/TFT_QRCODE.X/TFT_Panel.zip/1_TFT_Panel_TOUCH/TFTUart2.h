#ifndef __TFTUART2_H__
#define __TFTUART2_H__

extern void Uart2_Fonk( unsigned int *, unsigned int );
extern void U2_Gonder(char *,unsigned int *);
extern void U2tx(unsigned int *,unsigned int ,unsigned int ,unsigned int );

#endif