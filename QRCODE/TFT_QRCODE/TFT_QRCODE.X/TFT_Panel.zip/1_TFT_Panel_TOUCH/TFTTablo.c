#include "p33FJ256MC710.h"
#include "TFTTablo.h"

#define TURKCE			//23.07.14
//#define FRANSIZCA	

asm("org = 0x0c00");
#ifdef TURKCE
volatile unsigned  char *AnaMenu[5][10]		__attribute__((far)) =	
{	
	{	{"<<STATUS"},{"MEASUREMENT"},{"ALARM LOGS"},{"INFORMATION"},{"OPTIONS  >"}	,{"<COMMAND"},{"   TIME    "}	,{" SERVICE "}	,{"  ADJUST   "}		,{"T.CALIB>>"}	},		//�ngilizce
	{	{"<<DURUM "},{"  �L��MLER "},{"ALARM KAY."},{" B�LG�LER  "},{"TERC�HLER>"}	,{"<EM�RLER"},{" TAR�H-SAAT"}	,{"  SERV�S "}	,{"  AYARLAR  "}		,{"T.KAL�B>>"}	},		//T�rk�e
	{	{"<< STATO"},{"   MISURE  "},{"LOG EVENTI"},{"INFORMAZION"},{"OPZIONI  >"}	,{"<COMANDI"},{"   TEMPO   "}	,{" SERVICE "}	,{"REGOLAZIONI"}		,{"T.CALIB>>"}	},		//�TALYANCA
	{	{"<<ESTATO"},{"MEDICIONES "},{"REG.ALARMA"},{"INFORMACION"},{"OPCIONES >"}	,{"<COMANDO"},{"   HORA    "}	,{"SERVICIO "}	,{"  AJUSTES  "}		,{"T.CALIB>>"}	},		//�SPANYOLCA
	{	{"<<STATUS"},{"  POMIARY  "},{"LOG ALARMO"},{"INFORMACJE "},{"  OPCJE  >"}	,{"<KOMENDY"},{"   CZAS    "}	,{" SERWIS  "}	,{"USTAWIENIA "}		,{"T.KALIB>>"}	}		//POLONYACA (LEH�E)
};
//Yeni eklendi.23.07.2012

volatile unsigned  char *ParalelMenu[4][5]	__attribute__((far)) =		 
{	
	{	{"ONLINE MODE         "}	,{"ONLINE MOD          "}	,{"MODO ONLINE         "}	,{"MODO EN LINEA       "}	,{"TRYB ONLINE         "}	},
	{	{"ECONO MODE          "}	,{"EKONO MOD           "}	,{"MODO ECO            "}	,{"MODO ECO            "}	,{"TRYB ECONO          "}	},
	{	{"SYNC MODE           "}	,{"SENKRON MOD         "}	,{"MODO SYNC           "}	,{"MODO SINCRONIZACION "}	,{"TRYB SYNCHRO        "}	},	
	{	{"PARALLEL MODE   / ��"}	,{"PARALEL MOD     / ��"}	,{"PARALLELO       / ��"}	,{"MODO PARALELO   / ��"}	,{"PRACA ROWNOLEGLA/ ��"}	}
};
/*	
volatile unsigned  char *UstKelime[32][5]		__attribute__((far)) = 				12.03.2014
{
	{	{"STATUS                  "}	,{"DURUM                   "}	,{"STATO                   "}	,{"ESTATO                  "}	,{"STATUS                  "}	},		//0
	
	{	{"MEASUREMENT             "}	,{"�L��MLER                "}	,{"MISURE                  "}	,{"MEDICIONES              "}	,{"POMIARY                 "}	},		//1
	{	{"MEASUREMENT>INPUT       "}	,{"�L��MLER>G�R��          "}	,{"MISURE>INGRESSO         "}	,{"MEDICIONES>ENTRADA      "}	,{"POMIARY>WEJSCIE         "}	},		//2
	{	{"MEASUREMENT>BYPASS      "}	,{"�L��MLER>BYPASS         "}	,{"MISURE>RISERVA          "}	,{"MEDICIONES>BYPASS       "}	,{"POMIARY>BYPASS          "}	},		//3
	{	{"MEASUREMENT>INVERTER    "}	,{"�L��MLER>EV�R�C�        "}	,{"MISURE>INVERTER         "}	,{"MEDICIONES>INVERSOR     "}	,{"POMIARY>FALOWNIK        "}	},		//4
	{	{"MEASUREMENT>OUTPUT      "}	,{"�L��MLER>�IKI�          "}	,{"MISURE>USCITA           "}	,{"MEDICIONES>SALIDA       "}	,{"POMIARY>WYJSCIE         "}	},		//5
	{	{"MEASUREMENT>DC          "}	,{"�L��MLER>DC             "}	,{"MISURE>DC               "}	,{"MEDICIONES>CC           "}	,{"POMIARY>DC              "}	},		//6
	{	{"MEASUREMENT>GENERAL     "}	,{"�L��MLER>GENEL          "}	,{"MISURE>GENERALI         "}	,{"MEDICIONES>GENERAL      "}	,{"POMIARY>PODSTAWOWE      "}	},		//7	
	{	{"MEASUREMENT             "}	,{"�L��MLER                "}	,{"MISURE                  "}	,{"MEDICIONES              "}	,{"POMIARY                 "}	},		//8

	{	{"ALARM LOGS              "}	,{"ALARM KAYITLARI         "}	,{"LOG EVENTI              "}	,{"REGISTROS ALARMAS       "}	,{"LOG ALARMOW             "}	},		//9	
	{	{"INFORMATIONS            "}	,{"B�LG�LER                "}	,{"INFORMAZIONI            "}	,{"INFORMACION             "}	,{"INFORMACJE              "}	},		//10
	
	{	{"OPTIONS                 "}	,{"TERC�HLER               "}	,{"OPZIONI                 "}	,{"OPCIONES                "}	,{"OPCJE                   "}	},		//11	
	{	{"OPTIONS>LCD OPT.        "}	,{"TERC�HLER>EKRAN TERC�H  "}	,{"OPZIONI>OPZIONI LCD     "}	,{"OPCIONES>OPCIONES DE LCD"}	,{"OPCJE>OPCJE LCD         "}	},		//12
	{	{"OPTIONS>COMM. OPT.      "}	,{"TERC�HLER>HABERL�.TERC�H"}	,{"OPZIONI>OPZIONI COMUNI. "}	,{"OPCIONES>COMUNICACION   "}	,{"OPCJE>OPCJE KOMUNIKACJI "}	},		//13
	{	{"OPTIONS>ALARM OPT.      "}	,{"TERC�HLER>ALARM TERC�H  "}	,{"OPZIONI>OPZIONI ALLARMI "}	,{"OPCIONES>OPCIONES DE ALR"}	,{"OPCJE>OPCJE ALARMOW     "}	},		//14
	{	{"OPTIONS>BYPASS OPT.     "}	,{"TERC�HLER>BYPASS TERC�H "}	,{"OPZIONI>OPZIONI BYPASS  "}	,{"OPCIONES>OPCIONES DE BYP"}	,{"OPCJE>OPCJE BYPASS      "}	},		//15
	
	{	{"COMMAND                 "}	,{"EM�RLER                 "}	,{"COMANDI                 "}	,{"COMANDOS                "}	,{"KOMENDY                 "}	},		//16
	{	{"COMMAND>RELAY TEST      "}	,{"EM�RLER>R�LE TEST       "}	,{"COMANDI>TEST RELE       "}	,{"COMANDOS>TEST RELE      "}	,{"KOMENDY>TEST PRZEK      "}	},		//17
	
	{	{"TIME                    "}	,{"TAR�H-SAAT              "}	,{"TEMPO                   "}	,{"HORA                    "}	,{"CZAS                    "}	},		//18
	{	{"SERVICE                 "}	,{"SERV�S                  "}	,{"SERVICE                 "}	,{"SERVICIO                "}	,{"SERWIS                  "}	},		//19
		
	{	{"ADJUST                  "}	,{"AYARLAR"}					,{"REGOLAZIONI             "}	,{"AJUSTES                 "}	,{"USTAWIENIA              "}	},		//20
	{	{"ADJUST>GROUP ADJ.       "}	,{"AYARLAR>GROUP ADJ.      "}	,{"REGOLAZIONI>GROUP ADJ.  "}	,{"AJUSTES>GROUP ADJ.      "}	,{"USTAWIENIA>GROUP ADJ.   "}	},		//21
	{	{"ADJUST>INV FACTORY OPT. "}	,{"AYARLAR>INV FACTORY OPT."}	,{"REGOLAZIONI>INV FACT OPT"}	,{"AJUSTES>INV FACTORY OPT."}   ,{"USTAWIENIA>INV FACT.OPT."}	},		//22
	{	{"ADJUST>REC FACTORY OPT. "}	,{"AYARLAR>REC FACTORY OPT."}	,{"REGOLAZIONI>REC FACT OPT"}	,{"AJUSTES>REC FACTORY OPT."}	,{"USTAWIENIA>REC FACT.OPT."}	},		//23
	{	{"ADJUST>PANEL ADJ.       "}	,{"AYARLAR>PANEL ADJ.      "}	,{"REGOLAZIONI>PANEL ADJ.  "}	,{"AJUSTES>PANEL ADJ.      "}	,{"USTAWIENIA>PANEL ADJ    "}	},		//24
	{	{"ADJUST>AC INPUT ADJ.    "}	,{"AYARLAR>AC INPUT ADJ.   "}	,{"REGOLAZIONI>AC INPUT ADJ"}	,{"AJUSTES>AC INPUT ADJ.   "}	,{"USTAWIENIA>AC INPUT ADJ "}	},		//25
	{	{"ADJUST>AC BYPASS ADJ.   "}	,{"AYARLAR>AC BYPASS ADJ.  "}	,{"REGOLAZIONI>AC BYP ADJ  "}	,{"AJUSTES>AC BYPASS ADJ.  "}	,{"USTAWIENIA>AC BYPASS ADJ"}	},		//26
	{	{"ADJUST>AC OUTPUT ADJ.   "}	,{"AYARLAR>AC OUTPUT ADJ.  "}	,{"REGOLAZIONI>AC OUT ADJ  "}	,{"AJUSTES>AC OUTPUT ADJ.  "}	,{"USTAWIENIA>AC OUTPUT ADJ"}	},		//27
	{	{"ADJUST>DC ADJ.          "}	,{"AYARLAR>DC ADJ.         "}	,{"REGOLAZIONI>DC ADJ.     "}	,{"AJUSTES>DC ADJ.         "}	,{"USTAWIENIA>DC ADJ.      "}	},		//28
	{	{"ADJUST>POWER ADJ.       "}	,{"AYARLAR>POWER ADJ.      "}	,{"REGOLAZIONI>POWER ADJ.  "}	,{"AJUSTES>POWER ADJ.      "}	,{"USTAWIENIA>POWER ADJ.   "}	},		//29
	{	{"ADJUST                  "}	,{"AYARLAR                 "}	,{"REGOLAZIONI             "}	,{"AJUSTES                 "}	,{"USTAWIENIA              "}	},		//30
	
	{	{"HELP                    "}	,{"YARDIM                  "}	,{"HELP                    "}	,{"HELP                    "}	,{"HELP                    "}	}		//31
};
*/
volatile unsigned  char *OlcumAnaMenu[5][7]	__attribute__((far)) =		 
{					 			  			   				        				  
	{	{"INPUT   "},{"BYPASS  "},{"INVERTER"},{"OUTPUT  "},{"DC      "},{"GENERAL "},{"EXIT    "}	},
	{	{"G�R��   "},{"BYPASS  "},{"EV�R�C� "},{"�IKI�   "},{"DC      "},{"GENEL   "},{"EXIT    "}	},
	{	{"INGRESSO"},{"RISERVA "},{"INVERTER"},{"USCITA  "},{"DC      "},{"GENERALI"},{"ESCI    "}	},
	{	{"ENTRADA "},{"BYPASS  "},{"INVERSOR"},{"SALIDA  "},{"CC      "},{"GENERAL "},{"SALIDA  "}	},
	{	{"WEJSCIE "},{"BYPASS  "},{"FALOWNIK"},{"WYJSCIE "},{"DC      "},{"PODSTAWO"},{"WYJSCIE "}	}
};

volatile unsigned  char *OlcumAltMenu[16][5]				 __attribute__((far)) =
{
	{	{"P-N  L1   L2   L3    "}	,{"F-N  L1   L2   L3    "}			,{"F-N  L1   L2   L3    "}		,{"F-N  L1   L2   L3    "}		,{"L-N  L1   L2   L3    "}		},		//0
	{	{"P-P  L1-3 L2-1 L3-2  "}	,{"F-F  L1-3 L2-1 L3-2  "}			,{"F-F  L1-3 L2-1 L3-2  "}		,{"F-F  L1-3 L2-1 L3-2  "}		,{"L-L  L1-3 L2-1 L3-2  "}		},		//1
	{	{"LOAD �  �  �  %"}			,{"Y�K  �  �  �  %"}				,{"Car  �  �  �  %"}			,{"CARG �  �  �  %"}			,{"OBC  �  �  �  %"} 			},		//2
	{	{"V BATT   �  �   V"}		,{"V AK�    �  �   V"}				,{"V BATT   �  �   V"}			,{"V BAT    �  �   V"}			,{"V BAT    �  �   V"}			},		//3
	{	{"V BATT   � -�   V"}		,{"V AK�    � -�   V"}				,{"V BATT   � -�   V"}			,{"V BAT    � -�   V"}			,{"V BAT    � -�   V"}			},		//4
	{	{"I CHRG   ^  ^ A"}			,{"I �ARJ   ^  ^ A"}				,{"I CAPT   ^  ^ A"}			,{"I CARGA  ^  ^ A"}			,{"I NALA   ^  ^ A"}			},		//5
	{	{"I DSCHRG @  @ A"}			,{"I DSCHRG @  @ A"}				,{"I SCAR   @  @ A"}			,{"I DSCRG  @  @ A"}			,{"I ROZL   @  @ A"}			},		//6
	{	{"I DSCHRG ^  ^ A"}			,{"I DE�ARJ ^  ^ A"}				,{"I SCAR   ^  ^ A"}			,{"I DSCRG  ^  ^ A"}			,{"I ROZL   ^  ^ A"}			},		//7
	{	{"BATTERIES   ]     x2"}	,{"AK� SAYISI  ]     x2"}			,{"BATTERIA    ]     x2"}		,{"BATERIAS    ]     x2"}		,{"BATERIE     ]     x2"}		},		//8
	{	{"PAR.BAT     [        "}	,{"AK� KOL     [        "}			,{"PARAL BATT  [        "}		,{"BATE.PARAL  [        "}		,{"BAT.DODATK  [        "}		},		//9
	{	{"BATT.A/H    �    Ah"}		,{"AK� .A/H    �    Ah"}			,{"BATT.A/H    �    Ah"}		,{"BAT. A/H    �    Ah"}		,{"BAT. A/H    �    Ah"}		},		//10
	{	{"BACKUP TIME ����  min"}	,{"AK� S�RES�  ����  dak"}			,{"AUTONOMIA   ����  min"}		,{"TMPO RESPAL ����  min"}		,{"CZAS PODT   ����  min"}		},		//11
	{	{"FREQ ^          Hz"}		,{"FRE  ^          Hz"}				,{"FREQ ^          Hz"}			,{"FRCU ^          Hz"}			,{"CZEST ^         Hz"}			},		//12
	{	{"FREQ ^ - ���    Hz"}		,{"FRE  ^ - ���    Hz"}				,{"FREQ ^ - ���    Hz"}			,{"FRCU ^ - ���    Hz"}			,{"CZEST ^ - ���   Hz"}			},		//13
	{	{"P-N  L               "}	,{"F-N  L               "}			,{"F-N  L               "}		,{"F-N  L               "}		,{"L-N  L               "}		},		//14		//14.07.14
	{	{"LOAD �            %"}		,{"Y�K  �            %"}			,{"Car  �            %"}		,{"CARG �            %"}		,{"OBC  �            %"}		}		//15		//14.07.14
	
	
	
}; 
volatile unsigned  char *BilgiAnaMenu[10][5]				 __attribute__((far)) =
{
	{	{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		},		//0
	{	{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		},		//1
	{	{"MAX POWER (VA):������   "}			,{"MAX G�� (VA)  :������   "}			,{"MAX POTEN (VA):������   "}			,{"MAX PODER (VA):������   "}			,{"MOC MAKS  (VA):������   "}			},		//2
	{	{"NOMINAL VALUE :������� �������  "}	,{"NOM�NAL DE�ER :������� �������  "}	,{"VALORE NOMIN  :������� �������  "}	,{"VALOR NOMINAL :������� �������  "}	,{"NOMINALNA WART:������� �������  "}	},		//3
	{	{"INV VERSION   :!"}					,{"INV VERS�YON  :!"}					,{"INV VERSIONE  :!"}					,{"INV VERSION   :!"}					,{"INV WERSJA    :!"}					},		//4
	{	{"PFC VERSION   :!"}					,{"PFC VERS�YON  :!"}					,{"PFC VERSIONE  :!"}					,{"PFC VERSION   :!"}					,{"PFC WERSJA    :!"}					},		//5
	{	{"LCD VERSION   :!"}					,{"LCD VERS�YON  :!"}					,{"LCD VERSIONE  :!"}					,{"LCD VERSION   :!"}					,{"LCD WERSJA    :!"}					},		//6
	{	{"MODEL         :������"}				,{"MODEL         :������"}				,{"MODELLO       :������"}				,{"MODELO        :������"}				,{"MODEL         :������"}				},		//7
	{	{"PROTOCOL      :����������"}			,{"PROTOKOL      :����������"}			,{"PROTOCOLLO    :����������"}			,{"PROTOCOLO     :����������"}			,{"PROTOKOL      :����������"}			},		//8
	{	{"CHASSIS NO    :������         "}		,{"�ASE NO       :������         "}		,{"NR TELAIO     :������         "}		,{"NO CHASIS     :������         "}		,{"CHASSIS NR    :������         "}		}		//9
};

volatile unsigned  char *TercihAnaMenu[5][4]				__attribute__((far)) =		 
{		
	{	{"LCD OPTIONS          "},{"COMMUNICATION OPTIONS"},{"ALARM OPTIONS        "},{"BYPASS OPTIONS       "}	},		//0
	{	{"EKRAN TERC�HLER�     "},{"HABERLE�ME TERC�HLER�"},{"ALARM TERC�HLER�     "},{"BYPASS TERC�HLER�    "}	},		//1
	{	{"OPZIONI LCD          "},{"OPZIONI COMUNICAZ    "},{"OPZIONI ALLARMI      "},{"OPZIONI BYPASS       "}	},		//2
	{	{"OPCIONES DE LCD      "},{"COMUNICACION         "},{"OPCIONES DE ALARMA   "},{"OPCIONES DE BYPASS   "}	},		//3
	{	{"OPCJE LCD            "},{"OPCJE KOMUNIKACJI    "},{"OPCJE ALARMOW        "},{"OPCJE BYPASS         "}	}		//4
};

volatile unsigned  char *EkranTercih[37][5]				 __attribute__((far)) =
{
	//Ekran Tercihleri
	{	{" LANGUAGE : �������"}		,{" LANGUAGE : �������"}	,{" LANGUAGE : �������"}	,{" LANGUAGE : �������"}	,{" LANGUAGE : �������"}	},		//1.Sat�r	0	
	{	{" CLICK    : ������"}		,{" BUTON SES: ������"}		,{" CLICK    : ������"}		,{" CLICK    : ������"}		,{" KLIK     : ������"}		},		//2.Sat�r	1

	{	{" BACKLIGHT: ]"}			,{" AYDINLIK : ]"}			,{" ILLUMINAZ: ]"}			,{" BRILLO   : ]"}			,{" PODSWIETL: ]"}			},		//1.Sat�r	2
	{	{" BL DELAY : ] sn "}		,{" BEKLEME  : ] sn "}		,{" RIT ILL  : ] sc "}		,{" TMP BRILL: ] sg "}		,{" OP. PODSW: ] s. "}		},		//2.Sat�r	3
	{	{" BL DIM   : ] sn "}		,{" KARARTMA : ] sn "}		,{" SPEG ILL : ] sc "}		,{" MNS BRILL: ] sg "}		,{" KTRST LCD: ] s. "}		},		//3.Sat�r	4
		
	{	{" BL DELAY : CLOSED"}		,{" BEKLEME  : KAPALI"}		,{" RIT ILL  : CHIUSO"}		,{" TMP BRILL: CERRAD"}		,{" OP. PODSW: ZAMKNI"}		},		//2.Sat�r	5
	{	{" BL DIM   : CLOSED"}		,{" KARARTMA : KAPALI"}		,{" SPEG ILL : CHIUSO"}		,{" MNS BRILL: CERRAD"}		,{" KTRST LCD: ZAMKNI"}		},		//3.Sat�r	6
	{	{" ENTER  -  EXIT   "}		,{" ENTER  -  �IKI�  "}		,{" CONFERMA - ESCI  "}		,{" ENTRAR - SALIDA  "}		,{" WLACZ - WYJSCIE  "}		},		//7			7

	//Haberle�me Tercihleri
	{	{" REMOTE CNTRL:������"}	,{" UZAK KONTROL:������"}	,{" CNTRL REMOTO:������"}	,{" CNTRL RMOTO :������"}	,{" ZDALNA KONTR:������"}	},		//0		8
	{	{" COM2 :���������"}		,{" COM2 :���������"}		,{" COM2 :���������"}		,{" COM2 :���������"}		,{" COM2 :���������"}		},		//1		9
	{	{" SNMP :��������     "}	,{" SNMP :��������     "}	,{" SNMP :��������     "}	,{" SNMP :��������     "}	,{" SNMP :��������     "}	},		//2		10
	{	{" REPO :������      "}		,{" REPO :������      "}	,{" REPO :������      "}	,{" REPO :������      "}	,{" REPO :������      "}	},		//3		11
		
	{	{" ENTER  -  EXIT   "}		,{" ENTER  -  �IKI�  "}		,{" CONFERMA - ESCI  "}		,{" ENTRAR - SALIDA  "}		,{" WLACZ - WYJSCIE  "}		},		//7		12
	//R�le atamas�nda sadece RLxx olarak yaz�l�yor herhangi bir dilde de b�yle.Yani Buffer �n [0]. hanesi kullan�l�yor.
	{	{" RL1 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//4		13
	{	{" RL2 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//5		14
	{	{" RL3 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//6		15
	//OPT03 kart�n�n r�leleri
	{	{" RL4 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//7		16
	{	{" RL5 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//8		17
	{	{" RL6 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//9		18
	{	{" RL7 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//10	19
	{	{" RL8 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//11	20
	{	{" RL9 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//12	21
	{	{" RL10:  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//13	22
	{	{" RL11:  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//14	23
	{	{" RL12:  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//15	24
		
	//Alarm Tercihleri
	{	{" WARNING INTRVL:�����"}	,{" UYARI ARALI�I:����� "}	,{" INTERV AVVISI :�����"}	,{" ADVRT INTERVAL:�����"}	,{" INTER ZDARTZ. :�����"}	},		//0		25
	{	{" WARNING LOG :������"}	,{" UYARI KAYIT :������"}	,{" LOG AVVISO  :������"}	,{" REGIS ADVRT :������"}	,{" LOG ZDARZEN :������"}	},		//1		26
	{	{" STATUS LOG  :������"}	,{" DURUM KAYIT :������"}	,{" STATO EVENTI:������"}	,{" REGIS ESTADO:������"}	,{" LOG STATUS  :������"}	},		//2		27
	{	{" ALF RESTART :���������"}	,{" ELG BASLA   :���������"},{" RIAVVIO     :���������"},{" REINIC INVER:��������"}	,{" AUTO RESTART:��������"}	},		//3		28

	//Bypass Tercihleri								 
	{	{" VAT TRANSFER:������  "}	,{" VAT TRANS   :������  "} ,{" TRASF REG TENS:������"}	,{" VAT TRANSFER:������  "}	,{" VAT TRANSFER:������  "}	},		//0		29
	{	{" GEN.BYPASS  :��������"}	,{" JEN.BYPASS  :��������"}	,{" GEN.BYPASS  :��������"}	,{" BYP. GENER  :��������"}	,{" GEN.BYPASS  :��������"}	},		//1		30
	{	{" GEN.SET SYNC:����"}		,{" JEN.SENKRON :����"}		,{" GEN.SET SYNC:����"}		,{" SINC GENERAD:����"}		,{" UST.SYN.GEN.:����"}		},		//2		31
	
	//Haberle�me Tercihleri sonradan
	{	{" RELAY-ALARM ASSIGN"}		,{" R�LE-ALARM ATAMASI"}	,{" ASS ALLARMI & RELE"}	,{" ASIGNAR ALARMAS   "}	,{" PRZYP.ALARM PRZEK."}	},		//3		32
	
	//Bypass Tercihleri sonradan	26.09.12
	{	{" OPERAT. MODE:��������"}	,{" �ALI�MA MODU:��������"}	,{" MODO OPERAT :��������"}	,{" MODO OPERACI:��������"}	,{" TRYB PRACY  :��������"}	},		//		33

	//12.03.2014 - BPC->Akk�n->Ben
	{	{" GENIN: �������     "}	,{" JENIN: �������     "}	,{" GENIN: �������     "}	,{" GENIN: �������     "}	,{" GENIN: �������     "}	},		//1.Sat�r	34
	{	{" EPO  : �������     "}	,{" EPO  : �������     "}	,{" EPO  : �������     "}	,{" EPO  : �������     "}	,{" EPO  : �������     "}	},		//2.Sat�r	35
	{	{" RELAY CONTACTS : ��"}	,{" R�LE KONTAKLARI: ��"}	,{" CONTATTI RELE  : ��"}	,{" CONTACTOS AUX  : ��"}	,{" STYK.PRZEKAZNIK: ��"}	}		//1.Sat�r	36
};

volatile unsigned  char *EkranTercihSigns[36][5]				 __attribute__((far)) =
{
	//Ekran Tercih
	//------------
	//Dil
	{	{"ENGLISH"}	,{"TURKISH"},{"ITALIAN"},{"ESPANOL"},{"POLSKI "}	},		//0
	//Buton click sesi , Remote Control , Repo ,Warning log , Status Log
	{	{"OFF   "}	,{"KAPALI"}	,{"OFF   "}	,{"APA   "}	,{"WYL   "}		},		//1
	{	{"ON    "}	,{"A�IK  "}	,{"ON    "}	,{"ENC   "}	,{"WL    "}		},		//2
	//Backlight seviye ayar�
	{	{"2"}	,{"2"}	,{"2"}	,{"2"}	,{"2"}		},		//3
	{	{"4"}	,{"4"}	,{"4"}	,{"4"}	,{"4"}		},		//4
	{	{"6"}	,{"6"}	,{"6"}	,{"6"}	,{"6"}		},		//5
	{	{"8"}	,{"8"}	,{"8"}	,{"8"}	,{"8"}		},		//6
	//Bekleme - Karartma s�re ayar�
	{	{"CLOSED"}	,{"KAPALI"}	,{"CHIUSO"}	,{"CERRAD"}	,{"ZAMKNI"}		},		//7
	{	{"10 sn"}	,{"10 sn"}	,{"10 sc"}	,{"10 sg"}	,{"10 s."}		},		//8
	{	{"15 sn"}	,{"15 sn"}	,{"15 sc"}	,{"15 sg"}	,{"15 s."}		},		//9
	{	{"20 sn"}	,{"20 sn"}	,{"20 sc"}	,{"20 sg"}	,{"20 s."}		},		//10
	{	{"30 sn"}	,{"30 sn"}	,{"30 sc"}	,{"30 sg"}	,{"30 s."}		},		//11
	//Comm Tercih
	//------------
	//COM2
	{	{"SERVICE  "}	,{"SERV�S   "}	,{"SERVICE  "}	,{"SERVICIO "}	,{"SERWIS   "}	},		//12
	{	{"USER     "}	,{"KULLANICI"}	,{"UTENTE   "}	,{"MANUAL   "}	,{"UZYTK    "}	},		//13
	//SNMP
	{	{"EXTERNAL"}	,{"HAR�C�  "}	,{"ESTERNO "}	,{"EXTERNO "}	,{"ZEWNATRZ"}	},		//14
	{	{"INTERNAL"}	,{"DAH�L�  "}	,{"INTERNO "}	,{"INTERNO "}	,{"WEWNETRZ"}	},		//15
	
	//Alarm Tercihleri
	//----------------
	//Uyar� Aral���	
	{	{"5  sn"}	,{"5  sn"}	,{"5  sc"}	,{"5  sg"}	,{"5  s."}		},		//16
	{	{"6  sn"}	,{"6  sn"}	,{"6  sc"}	,{"6  sg"}	,{"6  s."}		},		//17
	{	{"7  sn"}	,{"7  sn"}	,{"7  sc"}	,{"7  sg"}	,{"7  s."}		},		//18
	{	{"8  sn"}	,{"8  sn"}	,{"8  sc"}	,{"8  sg"}	,{"8  s."}		},		//19
	{	{"9  sn"}	,{"9  sn"}	,{"9  sc"}	,{"9  sg"}	,{"9  s."}		},		//20
	{	{"10 sn"}	,{"10 sn"}	,{"10 sc"}	,{"10 sg"}	,{"10 s."}		},		//21
	//Alf (Elg) Start
	{	{"USER     "}	,{"KULLANICI"}	,{"UTENTE   "}	,{"MANUAL   "}	,{"UZYTK    "}	},		//22
	{	{"AUTO     "}	,{"OTOMAT�K "}	,{"AUTOMATIC"}	,{"AUTO     "}	,{"AUTO     "}	},		//23
	
	//Bypass Tercihleri
	//-----------------
	{	{"FORBID. "}	,{"YASAK   "}	,{"VIETATO "}	,{"PROHIB  "}	,{"BLOK.   "}	},		//24
	{	{"FREE    "}	,{"SERBEST "}	,{"NULLO   "}	,{"FREE    "}	,{"FREE    "}	},		//25
	
	{	{"XTAL"}	,{"XTAL"}	,{"XTAL"}	,{"CRST"}	,{"XTAL"}	},		//26	
	{	{"SYNC"}	,{"SYNC"}	,{"SYNC"}	,{"SINC"}	,{"SYNC"}	},		//27
	
	
	{	{"ONLINE  "}	,{"ONLINE  "}	,{"ONLINE  "}	,{"EN LINEA"}	,{"ONLINE  "}	},		//28
	{	{"ECONO   "}	,{"EKONO   "}	,{"ECO     "}	,{"ECO     "}	,{"ECONO   "}	},		//29
	{	{"SYNC    "}	,{"SENKRON "}	,{"SYNC    "}	,{"SINCRON "}	,{"SYNCHR  "}	},		//30
	{	{"PARALLEL"}	,{"PARALEL "}	,{"PARALLEL"}	,{"PARALELO"}	,{"P.ROWNOL"}	},		//31
	
	{	{"LOGIC-0"}		,{"LOJ�K-0"}	,{"LOGIC-0"}	,{"LOGIC-0"}	,{"LOGIKA-0"}	},		//32
	{	{"LOGIC-1"}		,{"LOJ�K-1"}	,{"LOGIC-1"}	,{"LOGIC-1"}	,{"LOGIKA-1"}	},		//33
	{	{"NO"}			,{"NO"}			,{"NA"}			,{"NA"}			,{"NO"}			},		//34
	{	{"NC"}			,{"NC"}			,{"NC"}			,{"NC"}			,{"NC"}			}		//35
	
};
volatile unsigned  char *EmirMenu[15][5]			__attribute__((far)) =
{
	{	{" ENTER <BYPASS>     "}	,{" ENTER <BYPASS>     "}	,{" CONF <RISERVA>     "}	,{" ENTRAR  < BYPASS > "}	,{" WLACZ < BYPASS >   "}	},		//0
	{	{" ENTER <INVERTER>   "}	,{" ENTER <INVERT�R>   "}	,{" CONF <INVERTER>    "}	,{" ENTRAR  <INVERTER> "}	,{" WLACZ < FALOWNIK > "}	},		//1

	{	{" ENTER < BOOST >    "}	,{" ENTER < BOOST >    "}	,{" CONF < BOOST >     "}	,{" ENTRAR  < BOOSTER >"}	,{" WLACZ < MOCNE LAD >"}	},		//2
	{	{" STOP  < BOOST >    "}	,{" STOP < BOOST >     "}	,{" STOP < BOOST >     "}	,{" DETENER < BOOSTER >"}	,{" STOP  < MOCNE LAD >"}	},		//3

	{	{" ENTER B.TEST> �  "}		,{" ENTER A.TEST> �  "}		,{" TEST BATT.  > �  "}		,{" TEST BATERIA> �  "}		,{" WL.TEST BAT.> �  "}		},		//4
	{	{" STOP B.TEST > �  "}  	,{" STOP A.TEST > �  "}		,{" STOP TEST B.> �  "}		,{" DETE.TEST B.>    "}		,{" STOP TEST B.>    "}		},		//5

	{	{" RELAY TEST         "}	,{" R�LE TEST          "}	,{" TEST RELE          "}	,{" TEST RELE          "}	,{" TEST PRZEK         "}	},		//6
	{	{" RELAY TEST         "}	,{" R�LE TEST          "}	,{" TEST RELE          "}	,{" TEST RELE          "}	,{" TEST PRZEK         "}	},		//7

	{	{" ENTER: MODEM INIT  "}	,{" ENTER: MODEM INIT  "}	,{" CONF:MODEM INIZ    "}	,{" ENTRAR:INI. MODEM  "}	,{" WLACZ: MODEM AKTYW "}	},		//8
	{	{" MODEM INITIALIZING "}	,{" MODEM BA�LATILIYOR "}	,{" INIZIALIZ MODEM    "}	,{" MODEM INICIANDO... "}	,{" AKTYWACJA MODEM... "}	},		//9
						
	{	{" ALARM SOUND : OFF  "}	,{" ALARM SES : KAPALI "}	,{" CICALINO ALLAR: OFF"}	,{" SONIDO ALARM: OFF  "}	,{" DZWIEK ALARM: OFF  "}	},		//10
	{	{" ALARM SOUND : ON   "}	,{" ALARM SES : A�IK   "}	,{" CICALINO ALLAR: ON "}	,{" SONIDO ALARM: ON   "}	,{" DZWIEK ALARM: ON   "}	},		//11
	
	{	{" ENTER  -  EXIT     "}	,{" ENTER  -  �IKI�    "}	,{"  CONFERMA - ESCI   "}	,{" ENTRAR - SALIDA    "}	,{" WLACZ - WYJSCIE    "}	},		//12	

	{	{" MIMIC LED TEST     "}	,{" M�M�K LED TEST     "}	,{" TEST LAMP CONFERMA "}	,{" TEST LAMPARA       "}	,{" WLACZ TEST WSKAZNIK"}	},		//13	//TFT de kullan�lm�yor.	
	//Yeni eklenenler
	{	{" COMMAND SENDING...."}	,{" EM�R G�NDER�L�YOR.."}	,{" INVIO COMANDO...   "}	,{" ENVIANDO COMANDO..."}	,{" WYSLANIE POLECEN..."}	}
};

volatile unsigned  char *ServisMenu[15][5]	__attribute__((far)) =
{
	{	{" HOURMETER : ! h"}		,{" TOPLAM SAAT: ! h"}		,{" CONTATORE : ! h"}		,{" TIEMP FUNC: ! h"}		,{" LICZ.GODZ : ! g"}		},		//0
	{	{" MAXLOAD:� � �"}			,{" MAX.Y�K:� � �"}			,{" CARMAX :� � �"}			,{" CARG.MX:� � �"}			,{" MAX.OBC:� � �"}			},		//1

	{	{" ENTER<FAULT RESET> "}	,{" ENTER<HATA SIFIRLA>"}	,{" CONF <RESET GUASTI>"}	,{" ENTRA<RESET FALLAS>"}	,{" WLACZ<KASUJ BLEDY> "}	},		//2

	{	{" FAN MAINT..: CANCEL "}	,{" FAN BAKIM..: �PTAL  "}	,{" MANUT VENT.:CANCELLA"}	,{" MNTN.VENTIL:CANCELAR"}	,{" WENT.SERW..:ANULOWAC"}	},		//3
	{	{" FAN MAINT..: ! h"}		,{" FAN BAKIM..: ! h"}		,{" MANUT VENT.: ! h"}		,{" MNTN.VENTIL: ! h"}		,{" WENT.SERW..: ! h"}		},		//4
	{	{" FAN MAINT..:-! h"}		,{" FAN BAKIM..: ! h"}		,{" MANUT VENT.:-! h"}		,{" MNTN.VENTIL:-! h"}		,{" WENT.SERW..:-! h"}		},		//5
	
	{	{" BAT.MAINT..: CANCEL "}	,{" AK� BAKIM..: �PTAL  "}	,{" MANUT BATT.:CANCELLA"}	,{" MNTN.BATERI:CANCELAR"}	,{" BAT.SERW...:ANULOWAC"}	},		//6
	{	{" BAT.MAINT..: ! h"}		,{" AK� BAKIM..: ! h"}		,{" MANUT BATT.: ! h"}		,{" MNTN.BATERI: ! h"}		,{" BAT.SERW...: ! h"}		},		//7
	{	{" BAT.MAINT..:-! h"}		,{" AK� BAKIM..: ! h"}		,{" MANUT BATT.:-! h"}		,{" MNTN.BATERI:-! h"}		,{" BAT.SERW...:-! h"}		},		//8
	
	{	{" GEN.MAINT..: CANCEL "}	,{" GENEL BAKIM: �PTAL  "}	,{" MANUT GENER:CANCELLA"}	,{" MNTN.GENERA:CANCELAR"}	,{" GEN.SERW...:ANULOWAC"}	},		//9
	{	{" GEN.MAINT..: ! h"}		,{" GENEL BAKIM: ! h"}		,{" MANUT GENER: ! h"}		,{" MNTN.GENERA: ! h"}		,{" GEN.SERW...: ! h"}		},		//10
	{	{" GEN.MAINT..:-! h"}		,{" GENEL BAKIM: ! h"}		,{" MANUT GENER:-! h"}		,{" MNTN.GENERA:-! h"}		,{" GEN.SERW...:-! h"}		},		//11
	
	{	{" LOGOUT....: ��     "}	,{" LOGOUT....: ��     "}	,{" USCIRE....: ��     "}	,{" SALIR.....: ��     "}	,{" WYLOGUJ...: ��     "}	},		//12
};	

volatile unsigned  char *AyarOnMenu_1[2][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.CODE: @@"}			,{" SERV.CODE: @@"}				,{" COD.SERV : @@"}				,{" CODIG.SER: @@"}				,{" KOD SERW : @@"}			},		
	{	{" SERV.PASS: ��������"}	,{" SERV.PASS: ��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	}		
};
volatile unsigned  char *AyarOnMenu_2[3][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.CODE: @@"}			,{" SERV.CODE: @@"}				,{" COD.SERV : @@"}				,{" CODIG.SER: @@"}				,{" SERV.CODE: @@"}			},		
	{	{" SERV.PASS: ��������"}	,{" SERV.PASS: ��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	},		
	{	{" USER PASW: ����    "}	,{" USER PASW: ����    "}		,{" PASSW UTILIZ: ���� "}		,{" CLAVE USU: ����    "}		,{" HASLO UZY: ����    "}	}			
};
volatile unsigned  char *AyarOnMenu_3[2][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.PASS: ��������"}	,{" SERV.PASS: ��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	},		
	{	{" USER PASW: ����    "}	,{" USER PASW: ����    "}		,{" PASSW UTILIZ: ���� "}		,{" CLAVE USU: ����    "}		,{" HASLO UZY: ����    "}	}			
};
volatile unsigned  char *AyarOnMenu_4[1][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.PASS: ��������"}	,{" SERV.PASS: ��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	}		
};
volatile unsigned  char *AyarOnMenu_Cevap[7][5]  	 __attribute__((far)) = 
{	
	{	{"<<<PASSWORD WRONG>>>"}	,{"<<<PASSWORD WRONG>>>"}		,{"<<PASSWORD ERRATO>> "}		,{"<<< CLAVE ERRONEO>>>"}		,{"<<<   HASLO ZLE  >>>"}	},
	{	{"<<< PASSWORD OK >>> "}	,{"<<< PASSWORD OK >>> "}		,{"<<< PASSWORD OK >>> "}		,{" <<<  CLAVE OK  >>> "}		,{"<<<   HASLO OK  >>> "}	},		
	{	{"<<<<CONTROL MODE>>>>"}	,{"<<<<CONTROL MODE>>>>"}		,{"<<<MODO CONTROLLO>>>"}		,{"<<<<MODO CONTROL>>>>"}		,{"<<<<TRYB KONTROLA>>>"}	},
	{	{" <<USER.PASW.WRONG>>"}	,{" <<USER.PASW.WRONG>>"}		,{"PASSW UTILIZ ERRATO "}		,{" <CLAVE USUARIO ERR>"}		,{" <<HASLO UZYTK ZLE>>"}	},			
	{	{" << USER.PASW.OK >> "}	,{" << USER.PASW.OK >> "}		,{" <<PASSW UTILIZ OK>>"}		,{"<<CLAVE USUARIO OK>>"}		,{" <<HASLO UZYTK OK>> "}	},
	{	{"                    "}	,{"                    "}		,{"                    "}		,{"                    "}		,{"                    "}	},		
	{	{" << SERVICE LOGIN >>"}	,{" << SERV�S LOGIN >> "}		,{" << SERVICE LOGIN >>"}		,{" <<ACCESO SERVICIO>>"}		,{" <<ZALOGOWANO SERW>>"}	}
};
		
volatile unsigned  char *GenelTablo[21][5] 	__attribute__((far)) =
{	
	{	{"   ENTER  -  EXIT   "}	,{"  ENTER  -  �IKI�   "}	,{"   CONFERMA - ESCI  "}	,{"   ENTRAR - SALIDA  "}	,{"   WLACZ - WYJSCIE  "}	},			//0
	{	{"     WARNING !      "}	,{"       UYARI !      "}	,{"    ATTENZIONE !    "}	,{"      ALERTA !      "}	,{"     OSTRZEZENIE!   "}	},			//1
	{	{"--------------------"}	,{"--------------------"}	,{"--------------------"}	,{"--------------------"}	,{"--------------------"}	},			//2
	{	{"    PLEASE ENTER    "}	,{"  L�TFEN KULLANICI  "}	,{"      INSERIRE      "}	,{"  POR FAVOR ENTRAR  "}	,{"    PROSZE PODAC    "}	},			//3
	{	{"   USER PASSWORD    "}	,{" ��FRES�N� G�R�N�Z. "}	,{"   PASSWORD UTENTE  "}	,{"  CLAVE DE USUARIO  "}	,{" HASLO UZYTKOWNIKA  "}	},			//4
	{	{"    PLEASE ENTER    "}	,{"   L�TFEN SERV�S    "}	,{"      INSERIRE      "}	,{"  POR FAVOR ENTRAR  "}	,{"    PROSZE PODAC    "}	},			//5
	{	{"  SERVICE PASSWORD  "}	,{" ��FRES�N� G�R�N�Z. "}	,{"  PASSWORD SERVICE  "}	,{"  CLAVE DE SERVICIO "}	,{"   HASLO SERWISOWE  "}	},			//6
	{	{"      * ���� *      "}	,{"      * ���� *      "}	,{"      * ���� *      "}	,{"      * ���� *      "}	,{"      * ���� *      "}	},			//7
	
	{	{" <<USER PASW.WRONG>>"}	,{"<<KUL.��FRE HATALI>>"}	,{" <<PASSWORD ERRATA>>"}	,{"<<ERROR CLVE.USUAR>>"}	,{" <<ZLE HASLO UZYTK>>"}	},		//4.Sat�r	8
	{	{" << USER PASW.OK >> "}	,{"<<KUL.��FRE DO�RU >>"}	,{"<PASSWORD UTENTE OK>"}	,{"<<CLAVE USUARIO OK>>"}	,{" <<HASLO UZYTK OK>> "}	},		//4.Sat�r	9
	{	{"INVERTER STARTING   "}	,{"INVERT�R BA�LIYOR   "}	,{"AVVIO INVERTER      "}	,{"INICIO INVERSOR     "}	,{"START FALOWNIKA     "}	},			//10
	{	{"     ---PRESS & HOLD ENTER FOR 3 SEC TO CLEAR LOGS---  "} ,{"  ---KAYITLARI S�LMEK ���N ENTER'A 3 SN BASILI TUTUN---"} 	,{"    ---PREMERE ENTER PER 3 SEC PER CANCELLARE LOGS---  "}	,{"     ---PRESIONE ENTER 3 SEG. PARA BORRAR REGISTROS--- "}	,{"  -NACISNIJ I PRZYTRZYMAJ PRZEZ 3 S ZEBY SKASOWAC LOG- "}    },
	{	{"                 ---LOGS CLEARING...---                "} ,{"               ---KAYITLAR S�L�N�YOR...---             "} 	,{"              --- EVENTI IN ELIMINAZ ...---            "}	,{"                ---BORRANDO REGISTRO---                "}	,{"                 ---KASOWANIE LOGU---                  "} 	},
	{	{"       --LOG CLEARED--     "} 							,{"     --KAYITLAR S�L�ND�--  "} 								,{"     --EVENTI ELIMINATI--    "} 								,{"   --REGISTRO BORRADO--    "}								,{"      --LOG SKASOWANY--    "} 								},
	{	{">�>       EMPTY       "} 									,{">�>        BO�        "} 									,{">�>      ASSENTI      "} 									,{">�>       VACIO       "}										,{">�>       PUSTY       "}		 								},
	{	{"         --EMPTY--       "} 								,{"         -- BO� --       "} 									,{"        --ASSENTI--      "} 									,{"         --VACIO--       "}									,{"         --PUSTY--       "}	 								},
	{	{"      ---PRESS ENTER FOR RECORDING ALARM ASSIGNED---   "}	,{"     ---ALARM ATAMA KAYDI ���N ENTER'A BASINIZ---      "} 	,{" ---PREMERE ENTER PER REGISTRAZIONE ALLAR ASSEGNATO--- "} 	,{"  --PRESIONE ENTER PARA GUARDAR ALARMA ASIGNADA--"} 			,{" --NACISNIJ ENTER ZEBY ZAPISAC PRZYPISANE ALARMY--"} 		},
	{	{"  ---ENTER USER OR SERVICE PASSWORD---         "} 		,{"  ---KULLANICI VEYA SERV�S ��FRES�N� G�R�N�Z---"} 			,{"  ---IMMETTERE PASSWORD SERVICE O UTENTE---    "} 			,{"  ---INTRODUSCA CLAVE DE USUARIO O SERVICIO--- "}			,{"  ---WPISZ UZYTKOWNIKA ALBO PODAJ HASLO---     "} 			},
	{	{"  ---ENTER SERVICE PASSWORD---                 "} 		,{"  ---SERV�S ��FRES�N� G�R�N�Z---               "} 			,{"  ---IMMETTERE PASSWORD SERVICE ---            "} 			,{"  ---INTRODUSCA CLAVE DE SERVICIO---           "}  			,{"  ---WPISZ HASLO SERWISOWE---                  "} 			},
	{	{"<< FORBIDDEN-SERVICE LOGIN? >>"}							,{"<< YASAK - SERV�S LOGIN? >>   "}								,{"<<PROIBIRE ACCESSO SERVICE? >>"}								,{"<< PROHIBIR MODO SERVICIO? >> "}								,{"<< ZABRONIONE-WYMAGANE HASLO SERWISOWE >>"}					},			//19
	{	{".........UPS OFF.........       "}					   	,{".......UPS KAPALI........       "}							,{".........UPS OFF.........       "}					   		,{".........UPS APA........."}									,{".........UPS WYL........."}									}			//20

};	


//Touch Calibration Menu
volatile unsigned  char *TouchTablo[3][5] 	__attribute__((far)) =
{
	{	
		{"     TOUCH THE STATED POINTS FOR CALIBRATION     "},
		{"  KAL�BRASYON ���N BEL�RT�LEN NORTALARA DOKUNUN  "},
		{"  TOCCARE I PUNTI DICHIARATI PER LA CALIBRAZIONE "},
		{"TOCAR LOS PUNTOS ESTABLECIDOS PARA LA CALIBRACION"},
		{     "DOTYKAC USTALONYCH PUNKTOW DO KALIBRACJI    "}	
	},
	{	
		{"               CALIBRATION COMPLETED             "},
		{"               KAL�BRASYON TAMAMLANDI            "},
		{"              CALIBRAZIONE COMPLETATA            "},
		{"             COMPLETADO LA CALIBRACION           "},
		{"               KALIBRACJA ZAKONCZONA             "}	
	},
	{	
		{"               TOUCH PANEL IS PASSIVE            "},
		{"               DOKUNMATIK PANEL PASIF            "},
		{"               TOUCH PANEL E PASSIVO             "},
		{"               PANEL TACTIL ES PASIVA            "},
		{"              PANEL TOUCH JEST BIERNY            "}	
	},
};	


volatile unsigned  char *Alarms[112][5]		 __attribute__((far)) =
{
	{	{"A01 O/P OVERCURRENT "},{"A01 A�IRI AKIM      "},{"A01 USC SOVRACCOR   "},{"A01 SBRE.CRRT.SALIDA"},{"A01 WYJ.OGRN.PRADU  "}	},//0   ALARM (INV) - AlarmInv (LCD)				0		
	{	{"A02 OVERTEMP SHUT   "},{"A02 A�IRI ISI KESME "},{"A02 SOVRATEMPERATURA"},{"A02 APAG.SOBRE T    "},{"A02 WYS.TEMP.WYLACZ "}	},//1   SAN�YEDE B�R 1 SAN�YE SESL� UYARI			1	
	{	{"A03 BATT HIGH       "},{"A03 AK� Y�KSEK      "},{"A03 BATT ALTA       "},{"A03 TENSION BAT.ALTA"},{"A03 WYSOKA TEMP BAT "}	},//2												2
	{	{"A04 OUTPUT V.LOW    "},{"A04 �IKI� D���K     "},{"A04 TENS USC BASSA  "},{"A04 TENSION SAL.BAJA"},{"A04 NISKIE NAP.WYJ  "}	},//3												3
	{	{"A05 OUTPUT V.HIGH   "},{"A05 �IKI� Y�KSEK    "},{"A05 TENS USC ALTA   "},{"A05 TENSION SAL.ALTA"},{"A05 WYSOKIE NAP.WYJ "}	},//4												4
	{	{"A06 OVERLOAD SHUT   "},{"A06 A�IRI Y�K KESME "},{"A06 SOVRACCARICO    "},{"A06 APAG.SOBRECARGA "},{"A06 PREZEC. WYLACZ  "}	},//5												5
	{	{"A07 SHORT CIRCUIT   "},{"A07 KISA DEVRE      "},{"A07 CORTO CIRCUITO  "},{"A07 CORTO CIRCUITO  "},{"A07 KROTKIE ZWARCIE "}	},//6												6	
	{	{"A08 ON MAINTENANCE  "},{"A08 BAKIMDA         "},{"A08 IN MANUTENZIONE "},{"A08 EN MANTENIMIENTO"},{"A08 SERWIS WLACZ    "}	},//7												7	
	{	{"A09 MANUAL BYPASS   "},{"A09 ELLE BYPASS     "},{"A09 BYPASS MANUALE  "},{"A09 BYPASS MANUAL   "},{"A09 BYPASS MANUALNY "}	},//8												8	
	{	{"A10 BATTERY LOW SHUT"},{"A10 AK� ZAYIF KESME "},{"A10 BATT BASSA SPEGN"},{"A10 APAG.BATERI.BAJA"},{"A10 NIS.NAP.BAT.WYL "}	},//9												9	
	{	{"A11 REPO STOP       "},{"A11 AC�L KAPATMA    "},{"A11 REPO STOP       "},{"A11 DETENER REPO    "},{"A11 EPO STOP        "}	},//10												10	
	{	{"A12 DC BALANCE BAD  "},{"A12 DC DENGE        "},{"A12 DC SBILANCIATO  "},{"A12 BALANCE CC MAL  "},{"A12 NIEPR.DC BALANCE"}	},//11												11
	{	{"A13 PEAK VOLTAGE    "},{"A13 TEPE Y�KSEK     "},{"A13 PICCO TENSIONE  "},{"A13 PEAK TENSION    "},{"A13 NAPIECIE SZYT.  "}	},//12												12
	{	{"A14 INV NOT START   "},{"A14 INV BA�LAYAMADI "},{"A14 INV NON AVVIATO "},{"A14 INVER.NO INICIA "},{"A14 FAL.NIE STARTUJE"}	},//13												13
	{	{"POWER ON FAULT TRIP "},{"�NCEK� HATA         "},{"GUASTO ACCENSIONE   "},{"PROTEC.ENTRADA TRIP "},{"ZASIL.ZADZ.ZAB.     "}	},//14												14	
	{	{"A00 INV FAULT=@  "}	,{"A00 INV HATASI=@ "}	 ,{"A00 INV GUASTO=@ "}   ,{"A00 FALLA INVER=@"}   ,{"A00 BLAD FAL.= @ "}		},//15												15

	{	{"A17 BYPASS FAILURE  "},{"A17 BYPASS KES�K    "},{"A17 BYPASS GUASTO   "},{"A17 FALLA BYPASS    "},{"A17 AWARIA BYPASS   "}	},//0   UYARILAR (INV) - UyariInv (LCD)				16	
	{	{"A18 BYPASS VOLT     "},{"A18 BYPASS VOLT     "},{"A18 TENS BYPASS     "},{"A18 TENSION BYPASS  "},{"A18 NAP.BYPASS      "}	},//1   4 SAN�YEDE B�R 0.5 SAN�YE SESL� UYARI		17	
	{	{"A19 BYP FREQ.TOLER. "},{"A19 BYPASS FREKANS  "},{"A19 TOLL FREQ BYPASS"},{"A19 FRCU.BYP.FUE.TOL"},{"A19 CZEST.BYPASS    "}	},//2												18	
	{	{"A20 OVERLOAD        "},{"A20 A�IRI Y�K       "},{"A20 USCITA SPENTA   "},{"A20 SOBRECARGA      "},{"A20 PRZECIAZENIE    "}	},//3												19
	{	{"A21 OVERTEMP        "},{"A21 A�IRI ISI       "},{"A21 SOVRATEMPERATURA"},{"A21 SOBRE T         "},{"A21 WYSOKA TEMP.    "}	},//4												20
	{	{"A22 OUTPUT OFF      "},{"A22 �IKI� KES�K     "},{"A22 USCITA SPENTA   "},{"A22 SALIDA APAGADA  "},{"A22 WYJSCIE WYLACZON"}	},//5												21	
	{	{"A23 ON BYPASS       "},{"A23 �IKI� BYPASSTA  "},{"A23 IN BYPASS       "},{"A23 EN BYPASS       "},{"A23 BYPASS WLACZONY "}	},//6												22
	{	{"A24 REVERSE CURRENT "},{"A24 TERS AKIM       "},{"A24 INVERTIRE CORR  "},{"A24 CORRIENTE RESERV"},{"A24 PRAD WSTECZNY   "}	},//7												23
	{	{"A25 INV RESET       "},{"A25 INV RESET       "},{"A25 RESET INVERTER  "},{"A25 RESETAR INVERSOR"},{"A25 RESET FALOWNIKA "}	},//8												24	
	{	{"A26 BATTERY LOW     "},{"A26 AK� ZAYIF       "},{"A26 BATTERIA BASSA  "},{"A26 BATERIA BAJA    "},{"A26 NISKIE NAP.BAT. "}	},//9												25
	{	{"A27 GENERATOR MODE  "},{"A27 JENERAT�R MODU  "},{"A27 MODO GENERATORE "},{"A27 MODO GENERADOR  "},{"A27 TRYB GENERATOR  "}	},//10												26
	{	{"A28 O/P PHASE LOSS  "},{"A28 FAZ KAYBI       "},{"A28 PERD FASE USCITA"},{"A28 FASE SAL PERDIDA"},{"A28 BRAK FAZY WYJ.  "}	},//11												27
	{	{"A29 SYNCHRON BAD    "},{"A29 SENKRON YOK     "},{"A29 NON SINCRONIZ   "},{"A29 MAL SINCRONIZADO"},{"A29 BLAD SYNCHRON.  "}	},//12												28	
	{	{"A30 SHORT CIRCUIT   "},{"A30 KISA DEVRE      "},{"A30 CORTO CIRCUITO  "},{"A30 CORTO CIRCUITO  "},{"A30 KROTKIE ZWARCIE "}	},//13												29
	{	{"A31 OUTPUT SWITCH   "},{"A31 �IKI� �ALTER�   "},{"A31 INTERR USCITA   "},{"A31 INTERRUP.SALIDA "},{"A31 WYL.NAP.WYJSCIA "}	},//14												30
	{	{"A32 SERVICE LOGIN   "},{"A32 SERV�S LOGIN    "},{"A32 SERVICE LOGIN   "},{"A32 ACCESO SERVICIO "},{"A32 ZALOGOWANO SERW."}	},//15												31
	
	{	{"R01 AC INPUT HIGH   "},{"R01 AC G�R�� Y�KSEK "},{"R01 TENS ING ALTA   "},{"R01 ENTRADA AC ALTA "},{"R01 WYS.NAP.WEJ.    "}	},//0  PFC ALARMS - AlarmPfc						32
	{	{"R02 LINE FAILURE    "},{"R02 �EBEKE KES�K    "},{"R02 SENZA LINEA     "},{"R02 FALLA DE LINEA  "},{"R02 AWARIA ZASILANIA"}	},//1  SAN�YEDE B�R 1 SAN�YE SESL� UYARI			33
	{	{"R03 DC BUS HIGH     "},{"R03 DC Y�KSEK       "},{"R03 DC BUS ALTA     "},{"R03 CC BUS ALTA     "},{"R03 WYSOKIE NAP.DC  "}	},//2												34
	{	{"R04 DC BUS LOW      "},{"R04 DC D���K        "},{"R04 DC BUS BASSA    "},{"R04 CC BUS BAJA     "},{"R04 NISKIE NAP. DC  "}	},//3	//14 ile ayn�								35
	{	{"R05 FREQ TOLER      "},{"R05 FREK TOLER      "},{"R05 TOLL FREQ       "},{"R05 TOLERANCIA FRECU"},{"R05 CZEST.P.TOL.    "}	},//4												36
	{	{"R06 OVERTEMPERATURE "},{"R06 A�IRI ISI       "},{"R06 SOVRATEMPERATURA"},{"R06 SOBRE T         "},{"R06 WYSOKA TEMP     "}	},//5												37
	{	{"R07 BLACKOUT        "},{"R07 KISA KES�NT�    "},{"R07 BLACKOUT        "},{"R07 BLACKOUT        "},{"R07 BLACKOUT        "}	},//6												38
	{	{"R08 I/P OVERCURRENT "},{"R08 IGBT HATASI     "},{"R08 SOVRACORR INGR  "},{"R08 SOBRECORRIEN.SAL"},{"R08 WEJ.OGRN.PRADOWE"}	},//7												39	
	{	{"R09 ROTATE PHASE    "},{"R09 FAZ �EV�R       "},{"R09 FASE INVERTITA  "},{"R09 FASE DE ROTACION"},{"R09 KIERUNEK WIR.FAZ"}	},//8												40
	{	{"R10 NU              "},{"R10 NU              "},{"R10 NU              "},{"R10 NU              "},{"R10 NU              "}	},//9												41
	{	{"R11 NU              "},{"R11 NU              "},{"R11 NU              "},{"R11 NU              "},{"R11 NU              "}	},//10												42
	{	{"R12 NU              "},{"R12 NU              "},{"R12 NU              "},{"R12 NU              "},{"R12 NU              "}	},//11												43
	{	{"R13 NU              "},{"R13 NU              "},{"R13 NU              "},{"R13 NU              "},{"R13 NU              "}	},//12												44
	{	{"R14 PFC MANUAL STOP "},{"R14 PFC DURAKLATILDI"},{"R14 PFC MANUAL STOP "},{"R14 DTNCION MANU.PFC"},{"R14 PFC RECZNY STOP "}	},//13												45
	{	{"R15 DC LOW          "},{"R15 DC D���K        "},{"R15 DC BASSA        "},{"R15 CC BAJA         "},{"R15 NIS.NAP.DC      "}	},//14												46
	{	{"R00 REC FAULT=@ "}	,{"R00 PFC HATASI=@ "}	 ,{"R00 RADD GUAST=@"}	  ,{"R00 FALLA RECT=@ "}   ,{"R00 PROST.BLAD=@"}		},//15												47
														  						  
	{	{"R17 BATTERY TEST    "},{"R17 AK� TEST�       "},{"R17 TEST BATTERIA   "},{"R17 TEST BATERIA    "},{"R17 TEST BATERII    "}	},//0  PFC DEN D�REK GELEN UYARILAR - UyariPfc		48
	{	{"R18 BOOST CHARGE    "},{"R18 BOOST �ARJ      "},{"R18 CARICA BOOST    "},{"R18 CARGA BOOST     "},{"R18 MOCNE LADOWANIE "}	},//1  SAN�YEDE B�R O.5 SAN�YE SESL� UYARI			49
	{	{"R19 AC HIGH         "},{"R19 AC Y�KSEK       "},{"R19 ALTA AC         "},{"R19 CA ALTA         "},{"R19 WYSOKIE NAP. AC "}	},//2												50
	{	{"R20 INPUT CB OPEN   "},{"R20 G�R�� KONTAKT�R "},{"R20 INTERR INGR APER"},{"R20 CB NTRDA ABIERTO"},{"R20 WEJ. CB OTWARTE "}	},//3												51
	{	{"R21 PFC STOP        "},{"R21 PFC DURAKLADI   "},{"R21 PFC STOP        "},{"R21 PFC DETENIDO    "},{"R21 PFC STOP        "}	},//4												52
	{	{"R22 POS CHG LIMIT   "},{"R22 POS �ARJ L�M�T  "},{"R22 POS LIMIT CARICA"},{"R22 LIMITE CRGA POS "},{"R22 OGR. PR. PLUS   "}	},//5												53
	{	{"R23 NEG CHG LIMIT   "},{"R23 NEG �ARJ L�M�T  "},{"R23 NEG LIMIT CARICA"},{"R23 LIMITE CRGA NEG "},{"R23 OGR. PR. MINUS  "}	},//6												54
	{	{"R24 WAITING DC BUS  "},{"R24 DC BARA BEKLEME "},{"R24 ATTESA DC BUS   "},{"R24 ESPERANDO CC BUS"},{"R24 CZEK. NAP. DC   "}	},//7												55
	{	{"R25 BATTERY FAILURE "},{"R25 AK� ARIZASI     "},{"R25 BATTERIA GUASTA "},{"R25 FALLA BATERIA   "},{"R25 USZKODZ. BAT.   "}	},//8												56
	{	{"R26 BATT TEMP SENSOR"},{"R26 AK� ISI SENS�R� "},{"R26 SENS TEMPER BATT"},{"R26 T SENSOR BAT    "},{"R26 CZUJ. TEMP. BAT."}	},//9												57
	{	{"R27 BATT TEMP HIGH  "},{"R27 AK� ISISI Y�KSEK"},{"R27 TEMP BATT ALTA  "},{"R27 T BAT ALTA      "},{"R27 WYS .TEMP. BAT. "}	},//10												58
	{	{"R28 NO BATTERY      "},{"R28 AK� YOK         "},{"R28 NO BATTERIA     "},{"R28 NO BATERIA      "},{"R28 NIE BATERIA     "}	},//11												59
	{	{"R29 PFC RESET       "},{"R29 PFC RESET       "},{"R29 RESET PFC       "},{"R29 REINICIAR PFC   "},{"R29 PFC RESET       "}	},//12												60
	{	{"R30 PLEASE WAIT!    "},{"R30 BEKLEY�N�Z!     "},{"R30 ATTENDERE!      "},{"R30 ESPERE POR FAVOR"},{"R30 PROSZE CZEKAC   "}	},//13												61
	{	{"RECTIFIER STARTING  "},{"DOGRULTUCU BA�LIYOR "},{"RADDRIZZ AVVIATO    "},{"INICIO RECTIFICADOR "},{"START PROSTOWNIKA   "}	},//14												62
	{	{"R32 NU              "},{"R32 NU              "},{"R32 NU              "},{"R32 NU              "},{"R32 NU              "}	},//15												63

	{	{"L01 TH1 TEMP HIGH   "},{"L01 TH1 ISI Y�KSEK  "},{"L01 TH1 TEMP ALTA   "},{"L01 T TH1 ALTA      "},{"L01 WYSOKA TEMP. TH1"}	},//0  PANEL DEN D�REK GELEN UYARILAR - ALARMLAR OLAB�L�R					64
	{	{"L02 TH2 TEMP HIGH   "},{"L02 TH2 ISI Y�KSEK  "},{"L02 TH2 TEMP ALTA   "},{"L02 T TH2 ALTA      "},{"L02 WYSOKA TEMP. TH2"}	},//1  �UAN UYARILAR-----AlarmLcd------										65
	{	{"L03 TH1 TEMP LOW    "},{"L03 TH1 ISI D���K   "},{"L03 TH1 TEMP BASSA  "},{"L03 T TH1 BAJA      "},{"L03 NISKA TEMP. TH1 "}	},//2												66
	{	{"L04 TH2 TEMP LOW    "},{"L04 TH2 ISI D���K   "},{"L04 TH2 TEMP BASSA  "},{"L04 T TH2 BAJA      "},{"L04 NISKA TEMP. TH2 "}	},//3												67
	{	{"L05 FAN MAINT       "},{"L05 FAN BAKIMI      "},{"L05 MANUT VENTOLE   "},{"L05 MANTEN.VENTILADO"},{"L05 SERWIS WENTYLAT "}	},//4												68
	{	{"L06 BATTERY MAINT   "},{"L06 AK� BAKIMI      "},{"L06 MANUT BATTERIA  "},{"L06 MANTEN.BATERIA  "},{"L06 SERWIS BATERII  "}	},//5												69
//	{	{"L07 OPT MAINT       "},{"L07 OPT BAKIM       "},{"L07 OPT MANUTENZIONE"},{"L07 OPC.MANTENIMIENT"},{"L07 OPCJ. SERWIS    "}	},//6  SAN�YEDE B�R O.5 SAN�YE SESL� UYARI			70
	{	{"L07 GENERAL ALARM   "},{"L07 GENEL ALARM     "},{"L07 ALLARME GENERALE"},{"L07 ALARMA GENERAL  "},{"L07 ALARM OGOLNY    "}	},//6                                               70	genel alarm eklendi
	{	{"L08 TH1 SENSOR FAIL "},{"L08 TH1 SENS�R HATA "},{"L08 TH1 SENSOR GUAST"},{"L08 FALLA SENSOR TH1"},{"L08 USZK. CZUJ. TH1 "}	},//7	//EEproma kaydedilemiyor.Yer yok.			71
	{	{"L09 TH2 SENSOR FAIL "},{"L09 TH2 SENS�R HATA "},{"L09 TH2 SENSOR GUAST"},{"L09 FALLA SENSOR TH2"},{"L09 USZK. CZUJ. TH2 "}	},//8												72
	{	{"L10 ENTER FAULT RST "},{"L10 HATA RESETLE    "},{"L10 RESET GUASTI    "},{"L10 RESEAR FALLAS   "},{"L10 ENTER KASUJ BLAD"}	},//9	//Baz� �artlar ger�ekle�ince 1 olur.		73
	{	{"L11 BATT CB OPEN    "},{"L11 AK� DEVRE DI�I  "},{"L11 INTERR BATT APER"},{"L11 PROTEC.BAT.ABIER"},{"L11 OTWARTY CB BAT. "}	},//10	//Sadece Relay1 e ait (Batt.CB)ve Batt.Sw a��k olunca alarm gelir.  74
	{	{"L12 GENERAL MAINT   "},{"L12 GENEL BAKIM     "},{"L12 MANUT GENERALE  "},{"L12 MANTEN. GENERAL "},{"L12 WYMAGANY SERWIS "}	},//11												75
	{	{"L13 PFC CAN COMM ERR"},{"L13 PFC CAN COMM ERR"},{"L13 PFC CAN COMM ERR"},{"L13 CAN ERR.COM.PFC "},{"L13 PFC BLAD CAN    "}	},//12												76
	{	{"L14 INV CAN COMM ERR"},{"L14 INV CAN COMM ERR"},{"L14 INV CAN COMM ERR"},{"L14 CAN ERR.COM.INV "},{"L14 FAL.BLAD CAN    "}	},//13												77
	{	{"INV CODE = @     "}	,{"INV KOD = @      "}	 ,{"INV CODE = @     "}	  ,{"CODIGO INVER. = @"}   ,{"KOD FALOWNIKA = @"}		},//14	PANEL TARAFINDAN �RET�LD��� ���N BURAYA KONDULAR					78
	{	{"REC CODE = @     "}	,{"REC KOD = @      "}	 ,{"RADD CODE = @    "}	  ,{"CODIGO RECTIF.= @"}   ,{"KOD PROST. = @   "}		},//15												79

	//Uyari Inv 2ari Inv 2
	{	{"A33 TEST MODE       "},{"A33 TEST MODU       "},{"A33 MODO TEST       "},{"A33 MODO TEST       "},{"A33 TRYB TESTOWY    "}	},//0  Inv den login bilgisinin geldi�i data		80
	{	{"A34 BYP.ROTATE PHASE"},{"A34 BYP.FAZ �EV�R   "},{"A34 FASE BYP GIRATA "},{"A34 FASE ROTAC. BYP "},{"A34 BYP.KIER.WIR.FAZ"}	},//1  												81
	{	{"A35 INV STOP        "},{"A35 INV STOP        "},{"A35 INV STOP        "},{"A35 INVERSOR DETENID"},{"A35 FALOWNIK STOP   "}	},//2  												82
	{	{"A36 INV DC DOWN     "},{"A36 INV DC D���K    "},{"A36 INV DC BASSA    "},{"A36 CC INVERSOR BAJA"},{"A36 NIS.NAP.DC FAL. "}	},//3												83
	{	{"A37 AC CURR.LIMIT   "},{"A37 AC AKIM L�M�T   "},{"A37 AC LIMITAZ CORR "},{"A37 AC DE CORRIENTE "},{"A37 OGR. PRADU AC   "}	},//4												84
	{	{"A38 FUSE FAILURE    "},{"A38 S�GORTA ATIK    "},{"A38 FUSIBILI GUASTI "},{"A38 FALLA FUSIBLE   "},{"A38 USZKODZ. BEZP.  "}	},//5												85
	{	{"A39 PSP FAILURE     "},{"A39 BESLEME TOL.    "},{"A39 ALIMENTAT GUASTO"},{"A39 FALLA ENTRADA   "},{"A39 AWARIA ZASILACZA"}	},//6												86
	{	{"INVERTER STARTING   "},{"INVERT�R BA�LIYOR   "},{"INVERTER AVVIATO    "},{"INVERSOR INICIANDO  "},{"START FALOWNIKA     "}	},//7												87
	{	{"A41 SLEEP MODE      "},{"A41 UYKU MODU       "},{"A41 MODO PAUSA      "},{"A41 MODO REPOSO     "},{"A41 TRYB USPIENIA   "}	},//8												88
	{	{"A42 PARALLEL ALARM  "},{"A42 PARALEL ALARM   "},{"A42 ALLARME PARALL  "},{"A42 ALARMA PARALELO "},{"A42 BLAD PR.ROWNOLEG"}	},//9												89
	{	{"A43 USER LOGIN      "},{"A43 KULLANICI LOGIN "},{"A43 LOGIN UTENTE    "},{"A43 ACCESO USUARIO  "},{"A43 LOGIN UZYTKOWNIK"}	},//10												90
	{	{"A44 WAITING MINIMUM "},{"A44 M�N�MUM BEKLEME "},{"A44 MINIMA ATTESA   "},{"A44 MINIMO DE ESPERA"},{"A44 MINIMUM CZEKAM  "}	},//11												91
	{	{"A45 SERV. PASSWORD? "},{"A45 ��FRE G�R�N�Z   "},{"A45 SERV. PASSWORD? "},{"A45 CLAVE SERVICIO? "},{"A45 HASLO SERWIS?   "}	},//12												92
	{	{"A46 NU              "},{"A46 NU              "},{"A46 NU              "},{"A46 NU              "},{"A46 NU              "}	},//13												93
	{	{"A47 MASTER UPS      "},{"A47 MASTER KGK      "},{"A47 MASTER UPS      "},{"A47 MAESTRO UPS     "},{"A47 MISTRZ UPS      "}	},//14												94		//23.12.2014
	{	{"A48 INV STEP MODE   "},{"A48 INV ADIM MODU   "},{"A48 PASS MODO INV   "},{"A48 MODO PASO INVER."},{"A48 FAL. TRYB STEP  "}	},//15												95
	//Uyari Lcd 2ari Lcd 2
	{	{"L17 WAIT SLEEP      "},{"L17 UYKU BEKLEME    "},{"L17 ATTESA PAUSA    "},{"L17 ESPERE REPOSO   "},{"L17 CZEKAJ USYPIANIE"}	},//0 												96
	{	{"L18 WAIT WAKEUP     "},{"L18 UYAN BEKLEME    "},{"L18 RIPARTENZA      "},{"L18 ESPERE INICIANDO"},{"L18 CZEKAJ WYBUDZANI"}	},//1  												97
	{	{"L19 NU19            "},{"L19 NU19            "},{"L19 NU19            "},{"L19 NU19            "},{"L19 NU19            "}	},//2  												98
	{	{"L20 NU20            "},{"L20 NU20            "},{"L20 NU20            "},{"L20 NU20            "},{"L20 NU20            "}	},//3												99
	{	{"L21 NU21            "},{"L21 NU21            "},{"L21 NU21            "},{"L21 NU21            "},{"L21 NU21            "}	},//4											   100
	{	{"L22 NU22            "},{"L22 NU22            "},{"L22 NU22            "},{"L22 NU22            "},{"L22 NU22            "}	},//5											   101
	{	{"L23 NU23            "},{"L23 NU23            "},{"L23 NU23            "},{"L23 NU23            "},{"L23 NU23            "}	},//6											   102
	{	{"L24 NU24            "},{"L24 NU24            "},{"L24 NU24            "},{"L24 NU24            "},{"L24 NU24            "}	},//7											   103
	{	{"L25 NU25            "},{"L25 NU25            "},{"L25 NU25            "},{"L25 NU25            "},{"L25 NU25            "}	},//8											   104
	{	{"L26 NU26            "},{"L26 NU26            "},{"L26 NU26            "},{"L26 NU26            "},{"L26 NU26            "}	},//9											   105
	{	{"L27 NU27            "},{"L27 NU27            "},{"L27 NU27            "},{"L27 NU27            "},{"L27 NU27            "}	},//10											   106
	{	{"L28 NU28            "},{"L28 NU28            "},{"L28 NU28            "},{"L28 NU28            "},{"L28 NU28            "}	},//11											   107
	{	{"L29 NU29            "},{"L29 NU29            "},{"L29 NU29            "},{"L29 NU29            "},{"L29 NU29            "}	},//12											   108
	{	{"L30 NU30            "},{"L30 NU30            "},{"L30 NU30            "},{"L30 NU30            "},{"L30 NU30            "}	},//13											   109
	{	{"L31 SOLAR CAN ERR   "},{"L31 SOLAR CAN ERR   "},{"L31 SOLAR CAN ERR   "},{"L31 CAN ERROR SOLAR "},{"L31 SOLAR BLAD CAN  "}	},//14											   110				//CAN_100kHz Solar can ile birlikte eklendi.
	{	{"��������������������"},{"��������������������"},{"��������������������"},{"��������������������"},{"��������������������"}	} //15											   111
};

#endif


#ifdef FRANSIZCA

volatile unsigned  char *AnaMenu[5][10]		__attribute__((far)) =	
{	
	{	{"<<STATUS"},{"MEASUREMENT"},{"ALARM LOGS"},{"INFORMATION"},{"OPTIONS >"}	,{"<COMMAND"},{"   TIME    "}	,{" SERVICE "}	,{"  ADJUST   "}		,{"T.CALIB>>"}	},		//�ngilizce
	{	{"<< ETAT "},{"  MESURES  "},{"HIST.EVEN."},{"INFORMATION"},{"OPTIONS >"}	,{"<COMMAND"},{"   TEMPS   "}	,{" SERVICE "}	,{" REGULATION"}		,{"T.CALIB>>"}	},		//FRANSIZCA
	{	{"<< STATO"},{"   MISURE  "},{"LOG EVENTI"},{"INFORMAZION"},{"OPZIONI >"}	,{"<COMANDI"},{"   TEMPO   "}	,{" SERVICE "}	,{"REGOLAZIONI"}		,{"T.CALIB>>"}	},		//�TALYANCA
	{	{"<<ESTATO"},{"MEDICIONES "},{"REG.ALARMA"},{"INFORMACION"},{"OPCIONES>"}	,{"<COMANDO"},{"   HORA    "}	,{"SERVICIO "}	,{"  AJUSTES  "}		,{"T.CALIB>>"}	},		//�SPANYOLCA
	{	{"<<STATUS"},{"  POMIARY  "},{"LOG ALARMO"},{"INFORMACJE "},{"  OPCJE >"}	,{"<KOMENDY"},{"   CZAS    "}	,{" SERWIS  "}	,{"USTAWIENIA "}		,{"T.KAL�B>>"}	}		//POLONYACA (LEH�E)
};
//Yeni eklendi.23.07.2012

volatile unsigned  char *ParalelMenu[4][5]	__attribute__((far)) =		 
{	
	{	{"ONLINE MODE         "}	,{"MODE ONLINE         "}	,{"MODO ONLINE         "}	,{"MODO EN LINEA       "}	,{"TRYB ONLINE         "}	},
	{	{"ECONO MODE          "}	,{"MODE ECO            "}	,{"MODO ECO            "}	,{"MODO ECO            "}	,{"TRYB ECONO          "}	},
	{	{"SYNC MODE           "}	,{"MODE SYNC           "}	,{"MODO SYNC           "}	,{"MODO SINCRONIZACION "}	,{"TRYB SYNCHRO        "}	},	
	{	{"PARALLEL MODE   / ��"}	,{"MODE PARALLELE  / ��"}	,{"PARALLELO       / ��"}	,{"MODO PARALELO   / ��"}	,{"PRACA ROWNOLEGLA/ ��"}	}
};
/*	
volatile unsigned  char *UstKelime[32][5]		__attribute__((far)) = 				12.03.2014
{
	{	{"STATUS                  "}	,{"DURUM                   "}	,{"STATO                   "}	,{"ESTATO                  "}	,{"STATUS                  "}	},		//0
	
	{	{"MEASUREMENT             "}	,{"�L��MLER                "}	,{"MISURE                  "}	,{"MEDICIONES              "}	,{"POMIARY                 "}	},		//1
	{	{"MEASUREMENT>INPUT       "}	,{"�L��MLER>G�R��          "}	,{"MISURE>INGRESSO         "}	,{"MEDICIONES>ENTRADA      "}	,{"POMIARY>WEJSCIE         "}	},		//2
	{	{"MEASUREMENT>BYPASS      "}	,{"�L��MLER>BYPASS         "}	,{"MISURE>RISERVA          "}	,{"MEDICIONES>BYPASS       "}	,{"POMIARY>BYPASS          "}	},		//3
	{	{"MEASUREMENT>INVERTER    "}	,{"�L��MLER>EV�R�C�        "}	,{"MISURE>INVERTER         "}	,{"MEDICIONES>INVERSOR     "}	,{"POMIARY>FALOWNIK        "}	},		//4
	{	{"MEASUREMENT>OUTPUT      "}	,{"�L��MLER>�IKI�          "}	,{"MISURE>USCITA           "}	,{"MEDICIONES>SALIDA       "}	,{"POMIARY>WYJSCIE         "}	},		//5
	{	{"MEASUREMENT>DC          "}	,{"�L��MLER>DC             "}	,{"MISURE>DC               "}	,{"MEDICIONES>CC           "}	,{"POMIARY>DC              "}	},		//6
	{	{"MEASUREMENT>GENERAL     "}	,{"�L��MLER>GENEL          "}	,{"MISURE>GENERALI         "}	,{"MEDICIONES>GENERAL      "}	,{"POMIARY>PODSTAWOWE      "}	},		//7	
	{	{"MEASUREMENT             "}	,{"�L��MLER                "}	,{"MISURE                  "}	,{"MEDICIONES              "}	,{"POMIARY                 "}	},		//8

	{	{"ALARM LOGS              "}	,{"ALARM KAYITLARI         "}	,{"LOG EVENTI              "}	,{"REGISTROS ALARMAS       "}	,{"LOG ALARMOW             "}	},		//9	
	{	{"INFORMATIONS            "}	,{"B�LG�LER                "}	,{"INFORMAZIONI            "}	,{"INFORMACION             "}	,{"INFORMACJE              "}	},		//10
	
	{	{"OPTIONS                 "}	,{"TERC�HLER               "}	,{"OPZIONI                 "}	,{"OPCIONES                "}	,{"OPCJE                   "}	},		//11	
	{	{"OPTIONS>LCD OPT.        "}	,{"TERC�HLER>EKRAN TERC�H  "}	,{"OPZIONI>OPZIONI LCD     "}	,{"OPCIONES>OPCIONES DE LCD"}	,{"OPCJE>OPCJE LCD         "}	},		//12
	{	{"OPTIONS>COMM. OPT.      "}	,{"TERC�HLER>HABERL�.TERC�H"}	,{"OPZIONI>OPZIONI COMUNI. "}	,{"OPCIONES>COMUNICACION   "}	,{"OPCJE>OPCJE KOMUNIKACJI "}	},		//13
	{	{"OPTIONS>ALARM OPT.      "}	,{"TERC�HLER>ALARM TERC�H  "}	,{"OPZIONI>OPZIONI ALLARMI "}	,{"OPCIONES>OPCIONES DE ALR"}	,{"OPCJE>OPCJE ALARMOW     "}	},		//14
	{	{"OPTIONS>BYPASS OPT.     "}	,{"TERC�HLER>BYPASS TERC�H "}	,{"OPZIONI>OPZIONI BYPASS  "}	,{"OPCIONES>OPCIONES DE BYP"}	,{"OPCJE>OPCJE BYPASS      "}	},		//15
	
	{	{"COMMAND                 "}	,{"EM�RLER                 "}	,{"COMANDI                 "}	,{"COMANDOS                "}	,{"KOMENDY                 "}	},		//16
	{	{"COMMAND>RELAY TEST      "}	,{"EM�RLER>R�LE TEST       "}	,{"COMANDI>TEST RELE       "}	,{"COMANDOS>TEST RELE      "}	,{"KOMENDY>TEST PRZEK      "}	},		//17
	
	{	{"TIME                    "}	,{"TAR�H-SAAT              "}	,{"TEMPO                   "}	,{"HORA                    "}	,{"CZAS                    "}	},		//18
	{	{"SERVICE                 "}	,{"SERV�S                  "}	,{"SERVICE                 "}	,{"SERVICIO                "}	,{"SERWIS                  "}	},		//19
		
	{	{"ADJUST                  "}	,{"AYARLAR"}					,{"REGOLAZIONI             "}	,{"AJUSTES                 "}	,{"USTAWIENIA              "}	},		//20
	{	{"ADJUST>GROUP ADJ.       "}	,{"AYARLAR>GROUP ADJ.      "}	,{"REGOLAZIONI>GROUP ADJ.  "}	,{"AJUSTES>GROUP ADJ.      "}	,{"USTAWIENIA>GROUP ADJ.   "}	},		//21
	{	{"ADJUST>INV FACTORY OPT. "}	,{"AYARLAR>INV FACTORY OPT."}	,{"REGOLAZIONI>INV FACT OPT"}	,{"AJUSTES>INV FACTORY OPT."}   ,{"USTAWIENIA>INV FACT.OPT."}	},		//22
	{	{"ADJUST>REC FACTORY OPT. "}	,{"AYARLAR>REC FACTORY OPT."}	,{"REGOLAZIONI>REC FACT OPT"}	,{"AJUSTES>REC FACTORY OPT."}	,{"USTAWIENIA>REC FACT.OPT."}	},		//23
	{	{"ADJUST>PANEL ADJ.       "}	,{"AYARLAR>PANEL ADJ.      "}	,{"REGOLAZIONI>PANEL ADJ.  "}	,{"AJUSTES>PANEL ADJ.      "}	,{"USTAWIENIA>PANEL ADJ    "}	},		//24
	{	{"ADJUST>AC INPUT ADJ.    "}	,{"AYARLAR>AC INPUT ADJ.   "}	,{"REGOLAZIONI>AC INPUT ADJ"}	,{"AJUSTES>AC INPUT ADJ.   "}	,{"USTAWIENIA>AC INPUT ADJ "}	},		//25
	{	{"ADJUST>AC BYPASS ADJ.   "}	,{"AYARLAR>AC BYPASS ADJ.  "}	,{"REGOLAZIONI>AC BYP ADJ  "}	,{"AJUSTES>AC BYPASS ADJ.  "}	,{"USTAWIENIA>AC BYPASS ADJ"}	},		//26
	{	{"ADJUST>AC OUTPUT ADJ.   "}	,{"AYARLAR>AC OUTPUT ADJ.  "}	,{"REGOLAZIONI>AC OUT ADJ  "}	,{"AJUSTES>AC OUTPUT ADJ.  "}	,{"USTAWIENIA>AC OUTPUT ADJ"}	},		//27
	{	{"ADJUST>DC ADJ.          "}	,{"AYARLAR>DC ADJ.         "}	,{"REGOLAZIONI>DC ADJ.     "}	,{"AJUSTES>DC ADJ.         "}	,{"USTAWIENIA>DC ADJ.      "}	},		//28
	{	{"ADJUST>POWER ADJ.       "}	,{"AYARLAR>POWER ADJ.      "}	,{"REGOLAZIONI>POWER ADJ.  "}	,{"AJUSTES>POWER ADJ.      "}	,{"USTAWIENIA>POWER ADJ.   "}	},		//29
	{	{"ADJUST                  "}	,{"AYARLAR                 "}	,{"REGOLAZIONI             "}	,{"AJUSTES                 "}	,{"USTAWIENIA              "}	},		//30
	
	{	{"HELP                    "}	,{"YARDIM                  "}	,{"HELP                    "}	,{"HELP                    "}	,{"HELP                    "}	}		//31
};
*/
volatile unsigned  char *OlcumAnaMenu[5][7]	__attribute__((far)) =		 
{					 			  			   				        				  
	{	{"INPUT   "},{"BYPASS  "},{"INVERTER"},{"OUTPUT  "},{"DC      "},{"GENERAL "},{"EXIT    "}	},
	{	{"ENTREE  "},{"RESEAU  "},{"ONDULEUR"},{"UTILISAT"},{"DC      "},{"GENERAL "},{"SORTIE  "}	},
	{	{"INGRESSO"},{"RISERVA "},{"INVERTER"},{"USCITA  "},{"DC      "},{"GENERALI"},{"ESCI    "}	},
	{	{"ENTRADA "},{"BYPASS  "},{"INVERSOR"},{"SALIDA  "},{"CC      "},{"GENERAL "},{"SALIDA  "}	},
	{	{"WEJSCIE "},{"BYPASS  "},{"FALOWNIK"},{"WYJSCIE "},{"DC      "},{"PODSTAWO"},{"WYJSCIE "}	}
};

volatile unsigned  char *OlcumAltMenu[16][5]				 __attribute__((far)) =
{
	{	{"P-N  L1   L2   L3    "}	,{"F-N  L1   L2   L3    "}			,{"F-N  L1   L2   L3    "}		,{"F-N  L1   L2   L3    "}		,{"L-N  L1   L2   L3    "}		},		//0
	{	{"P-P  L1-3 L2-1 L3-2  "}	,{"F-F  L1-3 L2-1 L3-2  "}			,{"F-F  L1-3 L2-1 L3-2  "}		,{"F-F  L1-3 L2-1 L3-2  "}		,{"L-L  L1-3 L2-1 L3-2  "}		},		//1
	{	{"LOAD �  �  �  %"}			,{"Y�K  �  �  �  %"}				,{"Car  �  �  �  %"}			,{"CARG �  �  �  %"}			,{"OBC  �  �  �  %"} 			},		//2
	{	{"V BATT   �  �   V"}		,{"V AK�    �  �   V"}				,{"V BATT   �  �   V"}			,{"V BAT    �  �   V"}			,{"V BAT    �  �   V"}			},		//3
	{	{"V BATT   � -�   V"}		,{"V AK�    � -�   V"}				,{"V BATT   � -�   V"}			,{"V BAT    � -�   V"}			,{"V BAT    � -�   V"}			},		//4
	{	{"I CHRG   ^  ^ A"}			,{"I �ARJ   ^  ^ A"}				,{"I CAPT   ^  ^ A"}			,{"I CARGA  ^  ^ A"}			,{"I NALA   ^  ^ A"}			},		//5
	{	{"I DSCHRG @  @ A"}			,{"I DSCHRG @  @ A"}				,{"I SCAR   @  @ A"}			,{"I DSCRG  @  @ A"}			,{"I ROZL   @  @ A"}			},		//6
	{	{"I DSCHRG ^  ^ A"}			,{"I DE�ARJ ^  ^ A"}				,{"I SCAR   ^  ^ A"}			,{"I DSCRG  ^  ^ A"}			,{"I ROZL   ^  ^ A"}			},		//7
	{	{"BATTERIES   ]     x2"}	,{"AK� SAYISI  ]     x2"}			,{"BATTERIA    ]     x2"}		,{"BATERIAS    ]     x2"}		,{"BATERIE     ]     x2"}		},		//8
	{	{"PAR.BAT     [        "}	,{"AK� KOL     [        "}			,{"PARAL BATT  [        "}		,{"BATE.PARAL  [        "}		,{"BAT.DODATK  [        "}		},		//9
	{	{"BATT.A/H    �    Ah"}		,{"AK� .A/H    �    Ah"}			,{"BATT.A/H    �    Ah"}		,{"BAT. A/H    �    Ah"}		,{"BAT. A/H    �    Ah"}		},		//10
	{	{"BACKUP TIME ����  min"}	,{"AK� S�RES�  ����  dak"}			,{"AUTONOMIA   ����  min"}		,{"TMPO RESPAL ����  min"}		,{"CZAS PODT   ����  min"}		},		//11
	{	{"FREQ ^          Hz"}		,{"FRE  ^          Hz"}				,{"FREQ ^          Hz"}			,{"FRCU ^          Hz"}			,{"CZEST ^         Hz"}			},		//12
	{	{"FREQ ^ - ���    Hz"}		,{"FRE  ^ - ���    Hz"}				,{"FREQ ^ - ���    Hz"}			,{"FRCU ^ - ���    Hz"}			,{"CZEST ^ - ���   Hz"}			},		//13
	{	{"P-N  L               "}	,{"F-N  L               "}			,{"F-N  L               "}		,{"F-N  L               "}		,{"L-N  L               "}		},		//14		//14.07.14
	{	{"LOAD �            %"}		,{"Y�K  �            %"}			,{"Car  �            %"}		,{"CARG �            %"}		,{"OBC  �            %"}		}		//15		//14.07.14
	
	
	
}; 
volatile unsigned  char *BilgiAnaMenu[10][5]				 __attribute__((far)) =
{
	{	{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		,{"RS232 COMM1   : ��           "}		},		//0
	{	{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		,{"RS232 COMM2   : ��           "}		},		//1
	{	{"MAX POWER (VA):������   "}			,{"PUIS.MAXI(VA) :������   "}			,{"MAX POTEN (VA):������   "}			,{"MAX PODER (VA):������   "}			,{"MOC MAKS  (VA):������   "}			},		//2
	{	{"NOMINAL VALUE :������� �������  "}	,{"VALEUR NOMINAL:������� �������  "}	,{"VALORE NOMIN  :������� �������  "}	,{"VALOR NOMINAL :������� �������  "}	,{"NOMINALNA WART:������� �������  "}	},		//3
	{	{"INV VERSION   :!"}					,{"OND VERSION   :!"}					,{"INV VERSIONE  :!"}					,{"INV VERSION   :!"}					,{"INV WERSJA    :!"}					},		//4
	{	{"PFC VERSION   :!"}					,{"PFC VERSION   :!"}					,{"PFC VERSIONE  :!"}					,{"PFC VERSION   :!"}					,{"PFC WERSJA    :!"}					},		//5
	{	{"LCD VERSION   :!"}					,{"LCD VERSION   :!"}					,{"LCD VERSIONE  :!"}					,{"LCD VERSION   :!"}					,{"LCD WERSJA    :!"}					},		//6
	{	{"MODEL         :������"}				,{"MODELE        :������"}				,{"MODELLO       :������"}				,{"MODELO        :������"}				,{"MODEL         :������"}				},		//7
	{	{"PROTOCOL      :����������"}			,{"PROTOCOLE     :����������"}			,{"PROTOCOLLO    :����������"}			,{"PROTOCOLO     :����������"}			,{"PROTOKOL      :����������"}			},		//8
	{	{"CHASSIS NO    :������         "}		,{"N CHASSIS     :������         "}		,{"NR TELAIO     :������         "}		,{"NO CHASIS     :������         "}		,{"CHASSIS NR    :������         "}		}		//9
};

volatile unsigned  char *TercihAnaMenu[5][4]				__attribute__((far)) =		 
{		
	{	{"LCD OPTIONS          "},{"COMMUNICATION OPTIONS"},{"ALARM OPTIONS        "},{"BYPASS OPTIONS       "}	},		//0
	{	{"OPTIONS LCD          "},{"OPTIONS COMMUNICAT.  "},{"OPTIONS ALARMES      "},{"OPTIONS BYPASS       "}	},		//1
	{	{"OPZIONI LCD          "},{"OPZIONI COMUNICAZ    "},{"OPZIONI ALLARMI      "},{"OPZIONI BYPASS       "}	},		//2
	{	{"OPCIONES DE LCD      "},{"COMUNICACION         "},{"OPCIONES DE ALARMA   "},{"OPCIONES DE BYPASS   "}	},		//3
	{	{"OPCJE LCD            "},{"OPCJE KOMUNIKACJI    "},{"OPCJE ALARMOW        "},{"OPCJE BYPASS         "}	}		//4
};

volatile unsigned  char *EkranTercih[37][5]				 __attribute__((far)) =
{
	//Ekran Tercihleri
	{	{" LANGUAGE : �������"}		,{" LANGUE   : �������"}	,{" LANGUAGE : �������"}	,{" LANGUAGE : �������"}	,{" LANGUAGE : �������"}	},		//1.Sat�r	0	
	{	{" CLICK    : ������"}		,{" CLIC     : ������"}		,{" CLICK    : ������"}		,{" CLICK    : ������"}		,{" KLIK     : ������"}		},		//2.Sat�r	1

	{	{" BACKLIGHT: ]"}			,{" ILLUMINAT: ]"}			,{" ILLUMINAZ: ]"}			,{" BRILLO   : ]"}			,{" PODSWIETL: ]"}			},		//1.Sat�r	2
	{	{" BL DELAY : ] sn "}		,{" ATE ECLAI: ] sn "}		,{" RIT ILL  : ] sc "}		,{" TMP BRILL: ] sg "}		,{" OP. PODSW: ] s. "}		},		//2.Sat�r	3
	{	{" BL DIM   : ] sn "}		,{" DIM ECLAI: ] sn "}		,{" SPEG ILL : ] sc "}		,{" MNS BRILL: ] sg "}		,{" KTRST LCD: ] s. "}		},		//3.Sat�r	4
		
	{	{" BL DELAY : CLOSED"}		,{" ATE ECLAI: FERME "}		,{" RIT ILL  : CHIUSO"}		,{" TMP BRILL: CERRAD"}		,{" OP. PODSW: ZAMKNI"}		},		//2.Sat�r	5
	{	{" BL DIM   : CLOSED"}		,{" DIM ECLAI: FERME "}		,{" SPEG ILL : CHIUSO"}		,{" MNS BRILL: CERRAD"}		,{" KTRST LCD: ZAMKNI"}		},		//3.Sat�r	6
	{	{" ENTER  -  EXIT   "}		,{" CONFIRMER-SORTIE "}		,{" CONFERMA - ESCI  "}		,{" ENTRAR - SALIDA  "}		,{" WLACZ - WYJSCIE  "}		},		//7			7

	//Haberle�me Tercihleri
	{	{" REMOTE CNTRL:������"}	,{" CNTRL A DIST:������"}	,{" CNTRL REMOTO:������"}	,{" CNTRL RMOTO :������"}	,{" ZDALNA KONTR:������"}	},		//0		8
	{	{" COM2 :���������"}		,{" COM2 :���������"}		,{" COM2 :���������"}		,{" COM2 :���������"}		,{" COM2 :���������"}		},		//1		9
	{	{" SNMP :��������     "}	,{" SNMP :��������     "}	,{" SNMP :��������     "}	,{" SNMP :��������     "}	,{" SNMP :��������     "}	},		//2		10
	{	{" REPO :������      "}		,{" EPO  :������      "}	,{" REPO :������      "}	,{" REPO :������      "}	,{" REPO :������      "}	},		//3		11
		
	{	{" ENTER  -  EXIT   "}		,{" CONFIRMER-SORTIE "}		,{" CONFERMA - ESCI  "}		,{" ENTRAR - SALIDA  "}		,{" WLACZ - WYJSCIE  "}		},		//7		12
	//R�le atamas�nda sadece RLxx olarak yaz�l�yor herhangi bir dilde de b�yle.Yani Buffer �n [0]. hanesi kullan�l�yor.
	{	{" RL1 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//4		13
	{	{" RL2 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//5		14
	{	{" RL3 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//6		15
	//OPT03 kart�n�n r�leleri
	{	{" RL4 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//7		16
	{	{" RL5 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//8		17
	{	{" RL6 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//9		18
	{	{" RL7 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//10	19
	{	{" RL8 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//11	20
	{	{" RL9 :  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//12	21
	{	{" RL10:  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//13	22
	{	{" RL11:  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//14	23
	{	{" RL12:  �������������������� "}	,{""}	,{""}	,{""}	,{""}	},		//15	24
		
	//Alarm Tercihleri
	{	{" WARNING INTRVL:�����"}	,{" INTERV ATTENT:����� "}	,{" INTERV AVVISI :�����"}	,{" ADVRT INTERVAL:�����"}	,{" INTER ZDARTZ. :�����"}	},		//0		25
	{	{" WARNING LOG :������"}	,{" LOG AVVISO  :������"}	,{" LOG AVVISO  :������"}	,{" REGIS ADVRT :������"}	,{" LOG ZDARZEN :������"}	},		//1		26
	{	{" STATUS LOG  :������"}	,{" ETAT EVENEEM:������"}	,{" STATO EVENTI:������"}	,{" REGIS ESTADO:������"}	,{" LOG STATUS  :������"}	},		//2		27
	{	{" ALF RESTART :���������"}	,{" REDEMMAR    :���������"},{" RIAVVIO     :���������"},{" REINIC INVER:��������"}	,{" AUTO RESTART:��������"}	},		//3		28

	//Bypass Tercihleri								 
	{	{" VAT TRANSFER:������  "}	,{" TRANS.REG TENS:������"} ,{" TRASF REG TENS:������"}	,{" VAT TRANSFER:������  "}	,{" VAT TRANSFER:������  "}	},		//0		29
	{	{" GEN.BYPASS  :��������"}	,{" GEN.BYPASS  :��������"}	,{" GEN.BYPASS  :��������"}	,{" BYP. GENER  :��������"}	,{" GEN.BYPASS  :��������"}	},		//1		30
	{	{" GEN.SET SYNC:����"}		,{" GEN.SET SYNC:����"}		,{" GEN.SET SYNC:����"}		,{" SINC GENERAD:����"}		,{" UST.SYN.GEN.:����"}		},		//2		31
	
	//Haberle�me Tercihleri sonradan
	{	{" RELAY-ALARM ASSIGN"}		,{" PRG ALARMES&RELAIS"}	,{" ASS ALLARMI & RELE"}	,{" ASIGNAR ALARMAS   "}	,{" PRZYP.ALARM PRZEK."}	},		//3		32
	
	//Bypass Tercihleri sonradan	26.09.12
	{	{" OPERAT. MODE:��������"}	,{" MODE OPERAT :��������"}	,{" MODO OPERAT :��������"}	,{" MODO OPERACI:��������"}	,{" TRYB PRACY  :��������"}	},		//		33

	//12.03.2014 - BPC->Akk�n->Ben
	{	{" GENIN: �������     "}	,{" GENIN: �������     "}	,{" GENIN: �������     "}	,{" GENIN: �������     "}	,{" GENIN: �������     "}	},		//1.Sat�r	34
	{	{" EPO  : �������     "}	,{" EPO  : �������     "}	,{" EPO  : �������     "}	,{" EPO  : �������     "}	,{" EPO  : �������     "}	},		//2.Sat�r	35
	{	{" RELAY CONTACTS : ��"}	,{" CONTACTS RELAIS: ��"}	,{" CONTATTI RELE  : ��"}	,{" CONTACTOS AUX  : ��"}	,{" STYK.PRZEKAZNIK: ��"}	}		//1.Sat�r	36
};


volatile unsigned  char *EkranTercihSigns[36][5]				 __attribute__((far)) =
{
	//Ekran Tercih
	//------------
	//Dil
	{	{"ENGLISH"}	,{"FRENCH "},{"ITALIAN"},{"ESPANOL"},{"POLSKI "}	},		//0
	//Buton click sesi , Remote Control , Repo ,Warning log , Status Log
	{	{"OFF   "}	,{"OFF   "}	,{"OFF   "}	,{"APA   "}	,{"WYL   "}		},		//1
	{	{"ON    "}	,{"ON    "}	,{"ON    "}	,{"ENC   "}	,{"WL    "}		},		//2
	//Backlight seviye ayar�
	{	{"2"}	,{"2"}	,{"2"}	,{"2"}	,{"2"}		},		//3
	{	{"4"}	,{"4"}	,{"4"}	,{"4"}	,{"4"}		},		//4
	{	{"6"}	,{"6"}	,{"6"}	,{"6"}	,{"6"}		},		//5
	{	{"8"}	,{"8"}	,{"8"}	,{"8"}	,{"8"}		},		//6
	//Bekleme - Karartma s�re ayar�
	{	{"CLOSED"}	,{"FREME "}	,{"CHIUSO"}	,{"CERRAD"}	,{"ZAMKNI"}		},		//7
	{	{"10 sn"}	,{"10 sn"}	,{"10 sc"}	,{"10 sg"}	,{"10 s."}		},		//8
	{	{"15 sn"}	,{"15 sn"}	,{"15 sc"}	,{"15 sg"}	,{"15 s."}		},		//9
	{	{"20 sn"}	,{"20 sn"}	,{"20 sc"}	,{"20 sg"}	,{"20 s."}		},		//10
	{	{"30 sn"}	,{"30 sn"}	,{"30 sc"}	,{"30 sg"}	,{"30 s."}		},		//11
	//Comm Tercih
	//------------
	//COM2
	{	{"SERVICE  "}	,{"SERVICE  "}	,{"SERVICE  "}	,{"SERVICIO "}	,{"SERWIS   "}	},		//12
	{	{"USER     "}	,{"UTILISAT "}	,{"UTENTE   "}	,{"MANUAL   "}	,{"UZYTK    "}	},		//13
	//SNMP
	{	{"EXTERNAL"}	,{"EXTERNE "}	,{"ESTERNO "}	,{"EXTERNO "}	,{"ZEWNATRZ"}	},		//14
	{	{"INTERNAL"}	,{"INTERNE "}	,{"INTERNO "}	,{"INTERNO "}	,{"WEWNETRZ"}	},		//15
	
	//Alarm Tercihleri
	//----------------
	//Uyar� Aral���	
	{	{"5  sn"}	,{"5  s."}	,{"5  sc"}	,{"5  sg"}	,{"5  s."}		},		//16
	{	{"6  sn"}	,{"6  s."}	,{"6  sc"}	,{"6  sg"}	,{"6  s."}		},		//17
	{	{"7  sn"}	,{"7  s."}	,{"7  sc"}	,{"7  sg"}	,{"7  s."}		},		//18
	{	{"8  sn"}	,{"8  s."}	,{"8  sc"}	,{"8  sg"}	,{"8  s."}		},		//19
	{	{"9  sn"}	,{"9  s."}	,{"9  sc"}	,{"9  sg"}	,{"9  s."}		},		//20
	{	{"10 sn"}	,{"10 s."}	,{"10 sc"}	,{"10 sg"}	,{"10 s."}		},		//21
	//Alf (Elg) Start
	{	{"USER     "}	,{"MANUAL   "}	,{"UTENTE   "}	,{"MANUAL   "}	,{"UZYTK    "}	},		//22
	{	{"AUTO     "}	,{"AUTOMATIQ"}	,{"AUTOMATIC"}	,{"AUTO     "}	,{"AUTO     "}	},		//23
	
	//Bypass Tercihleri
	//-----------------
	{	{"FORBID. "}	,{"INTERDIT"}	,{"VIETATO "}	,{"PROHIB  "}	,{"BLOK.   "}	},		//24
	{	{"FREE    "}	,{"NUL     "}	,{"NULLO   "}	,{"FREE    "}	,{"FREE    "}	},		//25
	
	{	{"XTAL"}	,{"XTAL"}	,{"XTAL"}	,{"CRST"}	,{"XTAL"}	},		//26	
	{	{"SYNC"}	,{"SYNC"}	,{"SYNC"}	,{"SINC"}	,{"SYNC"}	},		//27
	
	
	{	{"ONLINE  "}	,{"ONLINE  "}	,{"ONLINE  "}	,{"EN LINEA"}	,{"ONLINE  "}	},		//28
	{	{"ECONO   "}	,{"ECO     "}	,{"ECO     "}	,{"ECO     "}	,{"ECONO   "}	},		//29
	{	{"SYNC    "}	,{"SYNC    "}	,{"SYNC    "}	,{"SINCRON "}	,{"SYNCHR  "}	},		//30
	{	{"PARALLEL"}	,{"PARALLEL"}	,{"PARALLEL"}	,{"PARALELO"}	,{"P.ROWNOL"}	},		//31
		
	{	{"LOGIC-0"}		,{"LOGIC-0"}	,{"LOGIC-0"}	,{"LOGIC-0"}	,{"LOGIKA-0"}	},		//32
	{	{"LOGIC-1"}		,{"LOGIC-1"}	,{"LOGIC-1"}	,{"LOGIC-1"}	,{"LOGIKA-1"}	},		//33
	{	{"NO"}			,{"NO"}			,{"NA"}			,{"NA"}			,{"NO"}			},		//34
	{	{"NC"}			,{"NF"}			,{"NC"}			,{"NC"}			,{"NC"}			}		//35
	
	
};

volatile unsigned  char *EmirMenu[15][5]			__attribute__((far)) =
{
	{	{" ENTER <BYPASS>     "}	,{" CONF < RESEAU >    "}	,{" CONF <RISERVA>     "}	,{" ENTRAR  < BYPASS > "}	,{" WLACZ < BYPASS >   "}	},		//0
	{	{" ENTER <INVERTER>   "}	,{" CONF < ONDULEUR >  "}	,{" CONF <INVERTER>    "}	,{" ENTRAR  <INVERTER> "}	,{" WLACZ < FALOWNIK > "}	},		//1

	{	{" ENTER < BOOST >    "}	,{" CONF < BOOST >     "}	,{" CONF < BOOST >     "}	,{" ENTRAR  < BOOSTER >"}	,{" WLACZ < MOCNE LAD >"}	},		//2
	{	{" STOP  < BOOST >    "}	,{" STOP < BOOST >     "}	,{" STOP < BOOST >     "}	,{" DETENER < BOOSTER >"}	,{" STOP  < MOCNE LAD >"}	},		//3

	{	{" ENTER B.TEST> �  "}		,{" TEST BATT.  > �  "}		,{" TEST BATT.  > �  "}		,{" TEST BATERIA> �  "}		,{" WL.TEST BAT.> �  "}		},		//4
	{	{" STOP B.TEST > �  "}  	,{" STOP TEST B.> �  "}		,{" STOP TEST B.> �  "}		,{" DETE.TEST B.>    "}		,{" STOP TEST B.>    "}		},		//5

	{	{" RELAY TEST         "}	,{" TEST RELAI         "}	,{" TEST RELE          "}	,{" TEST RELE          "}	,{" TEST PRZEK         "}	},		//6
	{	{" RELAY TEST         "}	,{" TEST RELAI         "}	,{" TEST RELE          "}	,{" TEST RELE          "}	,{" TEST PRZEK         "}	},		//7

	{	{" ENTER: MODEM INIT  "}	,{" CONF : MODEM INIT  "}	,{" CONF:MODEM INIZ    "}	,{" ENTRAR:INI. MODEM  "}	,{" WLACZ: MODEM AKTYW "}	},		//8
	{	{" MODEM INITIALIZING "}	,{" INITIALIS MODEM... "}	,{" INIZIALIZ MODEM    "}	,{" MODEM INICIANDO... "}	,{" AKTYWACJA MODEM... "}	},		//9
						
	{	{" ALARM SOUND : OFF  "}	,{" ALARME SONORE : OFF"}	,{" CICALINO ALLAR: OFF"}	,{" SONIDO ALARM: OFF  "}	,{" DZWIEK ALARM: OFF  "}	},		//10
	{	{" ALARM SOUND : ON   "}	,{" ALARME SONORE : ON "}	,{" CICALINO ALLAR: ON "}	,{" SONIDO ALARM: ON   "}	,{" DZWIEK ALARM: ON   "}	},		//11
	
	{	{" ENTER  -  EXIT     "}	,{"  CONFIRMER-SORTIE  "}	,{"  CONFERMA - ESCI   "}	,{" ENTRAR - SALIDA    "}	,{" WLACZ - WYJSCIE    "}	},		//12	

	{	{" MIMIC LED TEST     "}	,{" CONF TEST LAMPE    "}	,{" TEST LAMP CONFERMA "}	,{" TEST LAMPARA       "}	,{" WLACZ TEST WSKAZNIK"}	},		//13	//TFT de kullan�lm�yor.	
	//Yeni eklenenler
	{	{" COMMAND SENDING...."}	,{" ENVOI COMMANDE...  "}	,{" INVIO COMANDO...   "}	,{" ENVIANDO COMANDO..."}	,{" WYSLANIE POLECEN..."}	}
};

volatile unsigned  char *ServisMenu[15][5]	__attribute__((far)) =
{
	{	{" HOURMETER : ! h"}		,{" COMPTEUR   : ! h"}		,{" CONTATORE : ! h"}		,{" TIEMP FUNC: ! h"}		,{" LICZ.GODZ : ! g"}		},		//0
	{	{" MAXLOAD:� � �"}			,{" UTILMAX:� � �"}			,{" CARMAX :� � �"}			,{" CARG.MX:� � �"}			,{" MAX.OBC:� � �"}			},		//1

	{	{" ENTER<FAULT RESET> "}	,{" CONF <RESET DEFAUT>"}	,{" CONF <RESET GUASTI>"}	,{" ENTRA<RESET FALLAS>"}	,{" WLACZ<KASUJ BLEDY> "}	},		//2

	{	{" FAN MAINT..: CANCEL "}	,{" MAINT VENT.:ANULOWAC"}	,{" MANUT VENT.:CANCELLA"}	,{" MNTN.VENTIL:CANCELAR"}	,{" WENT.SERW..:ANULOWAC"}	},		//3
	{	{" FAN MAINT..: ! h"}		,{" MAINT VENT.: ! h"}		,{" MANUT VENT.: ! h"}		,{" MNTN.VENTIL: ! h"}		,{" WENT.SERW..: ! h"}		},		//4
	{	{" FAN MAINT..:-! h"}		,{" MAINT VENT.: ! h"}		,{" MANUT VENT.:-! h"}		,{" MNTN.VENTIL:-! h"}		,{" WENT.SERW..:-! h"}		},		//5
	
	{	{" BAT.MAINT..: CANCEL "}	,{" MAINT BATT.:ANULOWAC"}	,{" MANUT BATT.:CANCELLA"}	,{" MNTN.BATERI:CANCELAR"}	,{" BAT.SERW...:ANULOWAC"}	},		//6
	{	{" BAT.MAINT..: ! h"}		,{" MAINT BATT.: ! h"}		,{" MANUT BATT.: ! h"}		,{" MNTN.BATERI: ! h"}		,{" BAT.SERW...: ! h"}		},		//7
	{	{" BAT.MAINT..:-! h"}		,{" MAINT BATT.: ! h"}		,{" MANUT BATT.:-! h"}		,{" MNTN.BATERI:-! h"}		,{" BAT.SERW...:-! h"}		},		//8
	
	{	{" GEN.MAINT..: CANCEL "}	,{" MAINT GENER:ANULOWAC"}	,{" MANUT GENER:CANCELLA"}	,{" MNTN.GENERA:CANCELAR"}	,{" GEN.SERW...:ANULOWAC"}	},		//9
	{	{" GEN.MAINT..: ! h"}		,{" MAINT GENER: ! h"}		,{" MANUT GENER: ! h"}		,{" MNTN.GENERA: ! h"}		,{" GEN.SERW...: ! h"}		},		//10
	{	{" GEN.MAINT..:-! h"}		,{" GENEL BAKIM: ! h"}		,{" MANUT GENER:-! h"}		,{" MNTN.GENERA:-! h"}		,{" GEN.SERW...:-! h"}		},		//11
	
	{	{" LOGOUT....: ��     "}	,{" SORTIR....: ��     "}	,{" USCIRE....: ��     "}	,{" SALIR.....: ��     "}	,{" WYLOGUJ...: ��     "}	},		//12
};	

volatile unsigned  char *AyarOnMenu_1[2][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.CODE: @@"}			,{" COD SERV.: @@"}				,{" COD.SERV : @@"}				,{" CODIG.SER: @@"}				,{" KOD SERW : @@"}			},		
	{	{" SERV.PASS: ��������"}	,{" SERV. PASS:��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	}		
};
volatile unsigned  char *AyarOnMenu_2[3][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.CODE: @@"}			,{" COD SERV.: @@"}				,{" COD.SERV : @@"}				,{" CODIG.SER: @@"}				,{" SERV.CODE: @@"}			},		
	{	{" SERV.PASS: ��������"}	,{" SERV. PASS:��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	},		
	{	{" USER PASW: ����    "}	,{" PASSE UTIL:����    "}		,{" PASSW UTILIZ: ���� "}		,{" CLAVE USU: ����    "}		,{" HASLO UZY: ����    "}	}			
};
volatile unsigned  char *AyarOnMenu_3[2][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.PASS: ��������"}	,{" SERV. PASS:��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	},		
	{	{" USER PASW: ����    "}	,{" PASSE UTIL:����    "}		,{" PASSW UTILIZ: ���� "}		,{" CLAVE USU: ����    "}		,{" HASLO UZY: ����    "}	}			
};
volatile unsigned  char *AyarOnMenu_4[1][5]  	 __attribute__((far)) = 
{	
	{	{" SERV.PASS: ��������"}	,{" SERV.PASS: ��������"}		,{" SERV.PASS: ��������"}		,{" CLAVE.SER: ��������"}		,{" HASLO SER: ��������"}	}		
};
volatile unsigned  char *AyarOnMenu_Cevap[7][5]  	 __attribute__((far)) = 
{	
	{	{"<<<PASSWORD WRONG>>>"}	,{"<<< PASSE ERREUR >>>"}		,{"<<PASSWORD ERRATO>> "}		,{"<<< CLAVE ERRONEO>>>"}		,{"<<<   HASLO ZLE  >>>"}	},
	{	{"<<< PASSWORD OK >>> "}	,{"<<<   PASSE OK  >>> "}		,{"<<< PASSWORD OK >>> "}		,{" <<<  CLAVE OK  >>> "}		,{"<<<   HASLO OK  >>> "}	},		
	{	{"<<<<CONTROL MODE>>>>"}	,{"<<<<MODE CONTROLE>>>"}		,{"<<<MODO CONTROLLO>>>"}		,{"<<<<MODO CONTROL>>>>"}		,{"<<<<TRYB KONTROLA>>>"}	},
	{	{" <<USER.PASW.WRONG>>"}	,{"<PASSE UTILI ERREUR>"}		,{"PASSW UTILIZ ERRATO "}		,{" <CLAVE USUARIO ERR>"}		,{" <<HASLO UZYTK ZLE>>"}	},			
	{	{" << USER.PASW.OK >> "}	,{"<PASSE UTILISAT OK> "}		,{" <<PASSW UTILIZ OK>>"}		,{"<<CLAVE USUARIO OK>>"}		,{" <<HASLO UZYTK OK>> "}	},
	{	{"                    "}	,{"                    "}		,{"                    "}		,{"                    "}		,{"                    "}	},		
	{	{" << SERVICE LOGIN >>"}	,{"<< SERVICE LOGIN >> "}		,{" << SERVICE LOGIN >>"}		,{" <<ACCESO SERVICIO>>"}		,{" <<ZALOGOWANO SERW>>"}	}
};


volatile unsigned  char *GenelTablo[21][5] 	__attribute__((far)) =
{	
	{	{"   ENTER  -  EXIT   "}	,{"  CONFIRMER-SORTIE  "}	,{"   CONFERMA - ESCI  "}	,{"   ENTRAR - SALIDA  "}	,{"   WLACZ - WYJSCIE  "}	},			//0
	{	{"     WARNING !      "}	,{"      ATTENTION!    "}	,{"    ATTENZIONE !    "}	,{"      ALERTA !      "}	,{"     OSTRZEZENIE!   "}	},			//1
	{	{"--------------------"}	,{"--------------------"}	,{"--------------------"}	,{"--------------------"}	,{"--------------------"}	},			//2
	{	{"    PLEASE ENTER    "}	,{"     ENTRER SVP     "}	,{"      INSERIRE      "}	,{"  POR FAVOR ENTRAR  "}	,{"    PROSZE PODAC    "}	},			//3
	{	{"   USER PASSWORD    "}	,{" MOT DE PASSE UTILIS"}	,{"   PASSWORD UTENTE  "}	,{"  CLAVE DE USUARIO  "}	,{" HASLO UZYTKOWNIKA  "}	},			//4
	{	{"    PLEASE ENTER    "}	,{"     ENTRER SVP     "}	,{"      INSERIRE      "}	,{"  POR FAVOR ENTRAR  "}	,{"    PROSZE PODAC    "}	},			//5
	{	{"  SERVICE PASSWORD  "}	,{"MOT DE PASSE SERVICE"}	,{"  PASSWORD SERVICE  "}	,{"  CLAVE DE SERVICIO "}	,{"   HASLO SERWISOWE  "}	},			//6
	{	{"      * ���� *      "}	,{"      * ���� *      "}	,{"      * ���� *      "}	,{"      * ���� *      "}	,{"      * ���� *      "}	},			//7
	
	{	{" <<USER PASW.WRONG>>"}	,{"<<ERREUR MOT PASSE>>"}	,{" <<PASSWORD ERRATA>>"}	,{"<<ERROR CLVE.USUAR>>"}	,{" <<ZLE HASLO UZYTK>>"}	},		//4.Sat�r	8
	{	{" << USER PASW.OK >> "}	,{"<PASSE UTILISAT. OK>"}	,{"<PASSWORD UTENTE OK>"}	,{"<<CLAVE USUARIO OK>>"}	,{" <<HASLO UZYTK OK>> "}	},		//4.Sat�r	9
	{	{"INVERTER STARTING   "}	,{"DEMARRAGE ONDULEUR  "}	,{"AVVIO INVERTER      "}	,{"INICIO INVERSOR     "}	,{"START FALOWNIKA     "}	},			//10
	{	{"     ---PRESS & HOLD ENTER FOR 3 SEC TO CLEAR LOGS---  "} ,{"  --- APPUYER SUR ENTER 3 SEC POUR EFFACER LES LOGS ---"} 	,{"    ---PREMERE ENTER PER 3 SEC PER CANCELLARE LOGS---  "}	,{"     ---PRESIONE ENTER 3 SEG. PARA BORRAR REGISTROS--- "}	,{"  -NACISNIJ I PRZYTRZYMAJ PRZEZ 3 S ZEBY SKASOWAC LOG- "}    },
	{	{"                 ---LOGS CLEARING...---                "} ,{"               ---EVENEMENTS EN SUPPR..---             "} 	,{"              --- EVENTI IN ELIMINAZ ...---            "}	,{"                ---BORRANDO REGISTRO---                "}	,{"                 ---KASOWANIE LOGU---                  "} 	},
	{	{"       --LOG CLEARED--     "} 							,{"     --EVEN. SUPPRIMES--   "} 								,{"     --EVENTI ELIMINATI--    "} 								,{"   --REGISTRO BORRADO--    "}								,{"      --LOG SKASOWANY--    "} 								},
	{	{">�>       EMPTY       "} 									,{">�>   ABSESCE EVENEM  "} 									,{">�>      ASSENTI      "} 									,{">�>       VACIO       "}										,{">�>       PUSTY       "}		 								},
	{	{"         --EMPTY--       "} 								,{"         --ABSESCE--     "} 									,{"        --ASSENTI--      "} 									,{"         --VACIO--       "}									,{"         --PUSTY--       "}	 								},
	{	{"      ---PRESS ENTER FOR RECORDING ALARM ASSIGNED---   "}	,{"     -APPUYER SUR ENTER POUR ENREGISTRER L ALARM-      "} 	,{" ---PREMERE ENTER PER REGISTRAZIONE ALLAR ASSEGNATO--- "} 	,{"  --PRESIONE ENTER PARA GUARDAR ALARMA ASIGNADA--"} 			,{" --NACISNIJ ENTER ZEBY ZAPISAC PRZYPISANE ALARMY--"} 		},
	{	{"  ---ENTER USER OR SERVICE PASSWORD---         "} 		,{"    -ENTRER L UTILI. OU LE MOT DE PASSE MAINT.-"} 			,{"  ---IMMETTERE PASSWORD SERVICE O UTENTE---    "} 			,{"  ---INTRODUSCA CLAVE DE USUARIO O SERVICIO--- "}			,{"  ---WPISZ UZYTKOWNIKA ALBO PODAJ HASLO---     "} 			},
	{	{"  ---ENTER SERVICE PASSWORD---                 "} 		,{"  -ENTRER LE MOT DE PASSE MAINT-               "} 			,{"  ---IMMETTERE PASSWORD SERVICE ---            "} 			,{"  ---INTRODUSCA CLAVE DE SERVICIO---           "}  			,{"  ---WPISZ HASLO SERWISOWE---                  "} 			},
	{	{"<< FORBIDDEN-SERVICE LOGIN? >>"}							,{"<INTERDIRE L ACCES A LA MAINT>"}								,{"<<PROIBIRE ACCESSO SERVICE? >>"}								,{"<< PROHIBIR MODO SERVICIO? >> "}								,{"<< ZABRONIONE-WYMAGANE HASLO SERWISOWE >>"}					},			//19
	{	{".........UPS OFF.........       "}					   	,{".........ASI OFF.........       "}							,{".........UPS OFF.........       "}					   		,{".........UPS APA........."}									,{".........UPS WYL........."}									}			//20

};		



volatile unsigned  char *Alarms[112][5]		 __attribute__((far)) =
{
	{	{"A01 O/P OVERCURRENT "},{"A01 UTIL SURINTENSIT"},{"A01 USC SOVRACCOR   "},{"A01 SBRE.CRRT.SALIDA"},{"A01 WYJ.OGRN.PRADU  "}	},//0   ALARM (INV) - AlarmInv (LCD)				0		
	{	{"A02 OVERTEMP SHUT   "},{"A02 SURTEMP. SHUT   "},{"A02 SOVRATEMPERATURA"},{"A02 APAG.SOBRE T    "},{"A02 WYS.TEMP.WYLACZ "}	},//1   SAN�YEDE B�R 1 SAN�YE SESL� UYARI			1	
	{	{"A03 BATT HIGH       "},{"A03 BATTERIE HAUT   "},{"A03 BATT ALTA       "},{"A03 TENSION BAT.ALTA"},{"A03 WYSOKA TEMP BAT "}	},//2												2
	{	{"A04 OUTPUT V.LOW    "},{"A04 TENS UTIL BASSE "},{"A04 TENS USC BASSA  "},{"A04 TENSION SAL.BAJA"},{"A04 NISKIE NAP.WYJ  "}	},//3												3
	{	{"A05 OUTPUT V.HIGH   "},{"A05 TENS UTIL HAUTE "},{"A05 TENS USC ALTA   "},{"A05 TENSION SAL.ALTA"},{"A05 WYSOKIE NAP.WYJ "}	},//4												4
	{	{"A06 OVERLOAD SHUT   "},{"A06 SURCHARGE SHUT  "},{"A06 SOVRACCARICO    "},{"A06 APAG.SOBRECARGA "},{"A06 PREZEC. WYLACZ  "}	},//5												5
	{	{"A07 SHORT CIRCUIT   "},{"A07 COURT CIRCUIT   "},{"A07 CORTO CIRCUITO  "},{"A07 CORTO CIRCUITO  "},{"A07 KROTKIE ZWARCIE "}	},//6												6	
	{	{"A08 ON MAINTENANCE  "},{"A08 EN MAINTENANCE  "},{"A08 IN MANUTENZIONE "},{"A08 EN MANTENIMIENTO"},{"A08 SERWIS WLACZ    "}	},//7												7	
	{	{"A09 MANUAL BYPASS   "},{"A09 BYPASS MANUEL   "},{"A09 BYPASS MANUALE  "},{"A09 BYPASS MANUAL   "},{"A09 BYPASS MANUALNY "}	},//8												8	
	{	{"A10 BATTERY LOW SHUT"},{"A10 ARRET BATT BASSE"},{"A10 BATT BASSA SPEGN"},{"A10 APAG.BATERI.BAJA"},{"A10 NIS.NAP.BAT.WYL "}	},//9												9	
	{	{"A11 REPO STOP       "},{"A11 REPO STOP       "},{"A11 REPO STOP       "},{"A11 DETENER REPO    "},{"A11 EPO STOP        "}	},//10												10	
	{	{"A12 DC BALANCE BAD  "},{"A12 DC DESEQUILIBRE "},{"A12 DC SBILANCIATO  "},{"A12 BALANCE CC MAL  "},{"A12 NIEPR.DC BALANCE"}	},//11												11
	{	{"A13 PEAK VOLTAGE    "},{"A13 PIC DE TENSION  "},{"A13 PICCO TENSIONE  "},{"A13 PEAK TENSION    "},{"A13 NAPIECIE SZYT.  "}	},//12												12
	{	{"A14 INV NOT START   "},{"A14 OND NON DEMARRE "},{"A14 INV NON AVVIATO "},{"A14 INVER.NO INICIA "},{"A14 FAL.NIE STARTUJE"}	},//13												13
	{	{"POWER ON FAULT TRIP "},{"DEFAULT ASCENSION   "},{"GUASTO ACCENSIONE   "},{"PROTEC.ENTRADA TRIP "},{"ZASIL.ZADZ.ZAB.     "}	},//14												14	
	{	{"A00 INV FAULT=@  "}	,{"A00 OND DEFAUT=@ "}	,{"A00 INV GUASTO=@ "}   ,{"A00 FALLA INVER=@"}   ,{"A00 BLAD FAL.= @ "}		},//15												15

	{	{"A17 BYPASS FAILURE  "},{"A17 BYPASS DEFAUT   "},{"A17 BYPASS GUASTO   "},{"A17 FALLA BYPASS    "},{"A17 AWARIA BYPASS   "}	},//0   UYARILAR (INV) - UyariInv (LCD)				16	
	{	{"A18 BYPASS VOLT     "},{"A18 TENSION BYPASS  "},{"A18 TENS BYPASS     "},{"A18 TENSION BYPASS  "},{"A18 NAP.BYPASS      "}	},//1   4 SAN�YEDE B�R 0.5 SAN�YE SESL� UYARI		17	
	{	{"A19 BYP FREQ.TOLER. "},{"A19 TOL. FREQ BYPASS"},{"A19 TOLL FREQ BYPASS"},{"A19 FRCU.BYP.FUE.TOL"},{"A19 CZEST.BYPASS    "}	},//2												18	
	{	{"A20 OVERLOAD        "},{"A20 SURCHARGE       "},{"A20 USCITA SPENTA   "},{"A20 SOBRECARGA      "},{"A20 PRZECIAZENIE    "}	},//3												19
	{	{"A21 OVERTEMP        "},{"A21 SURTEMPERATURE  "},{"A21 SOVRATEMPERATURA"},{"A21 SOBRE T         "},{"A21 WYSOKA TEMP.    "}	},//4												20
	{	{"A22 OUTPUT OFF      "},{"A22 UTILISATION OFF "},{"A22 USCITA SPENTA   "},{"A22 SALIDA APAGADA  "},{"A22 WYJSCIE WYLACZON"}	},//5												21	
	{	{"A23 ON BYPASS       "},{"A23 SUR BYPASS      "},{"A23 IN BYPASS       "},{"A23 EN BYPASS       "},{"A23 BYPASS WLACZONY "}	},//6												22
	{	{"A24 REVERSE CURRENT "},{"A24 INVERSER COURANT"},{"A24 INVERTIRE CORR  "},{"A24 CORRIENTE RESERV"},{"A24 PRAD WSTECZNY   "}	},//7												23
	{	{"A25 INV RESET       "},{"A25 RESET ONDULEUR  "},{"A25 RESET INVERTER  "},{"A25 RESETAR INVERSOR"},{"A25 RESET FALOWNIKA "}	},//8												24	
	{	{"A26 BATTERY LOW     "},{"A26 BATTERIE BASSE  "},{"A26 BATTERIA BASSA  "},{"A26 BATERIA BAJA    "},{"A26 NISKIE NAP.BAT. "}	},//9												25
	{	{"A27 GENERATOR MODE  "},{"A27 MODE GENERATEUR "},{"A27 MODO GENERATORE "},{"A27 MODO GENERADOR  "},{"A27 TRYB GENERATOR  "}	},//10												26
	{	{"A28 O/P PHASE LOSS  "},{"A28 PERTE PHASE UTIL"},{"A28 PERD FASE USCITA"},{"A28 FASE SAL PERDIDA"},{"A28 BRAK FAZY WYJ.  "}	},//11												27
	{	{"A29 SYNCHRON BAD    "},{"A29 MAUVAISE SYNCHRO"},{"A29 NON SINCRONIZ   "},{"A29 MAL SINCRONIZADO"},{"A29 BLAD SYNCHRON.  "}	},//12												28	
	{	{"A30 SHORT CIRCUIT   "},{"A30 COURT CIRCUIT   "},{"A30 CORTO CIRCUITO  "},{"A30 CORTO CIRCUITO  "},{"A30 KROTKIE ZWARCIE "}	},//13												29
	{	{"A31 OUTPUT SWITCH   "},{"A31 INTER. UTILISAT."},{"A31 INTERR USCITA   "},{"A31 INTERRUP.SALIDA "},{"A31 WYL.NAP.WYJSCIA "}	},//14												30
	{	{"A32 SERVICE LOGIN   "},{"A32 SERVICE LOGIN   "},{"A32 SERVICE LOGIN   "},{"A32 ACCESO SERVICIO "},{"A32 ZALOGOWANO SERW."}	},//15												31
	
	{	{"R01 AC INPUT HIGH   "},{"R01 TENS ENT. HAUTE "},{"R01 TENS ING ALTA   "},{"R01 ENTRADA AC ALTA "},{"R01 WYS.NAP.WEJ.    "}	},//0  PFC ALARMS - AlarmPfc						32
	{	{"R02 LINE FAILURE    "},{"R02 SMANQU E TENSION"},{"R02 SENZA LINEA     "},{"R02 FALLA DE LINEA  "},{"R02 AWARIA ZASILANIA"}	},//1  SAN�YEDE B�R 1 SAN�YE SESL� UYARI			33
	{	{"R03 DC BUS HIGH     "},{"R03 DC BUS HAUT     "},{"R03 DC BUS ALTA     "},{"R03 CC BUS ALTA     "},{"R03 WYSOKIE NAP.DC  "}	},//2												34
	{	{"R04 DC BUS LOW      "},{"R04 DC BUS BAS      "},{"R04 DC BUS BASSA    "},{"R04 CC BUS BAJA     "},{"R04 NISKIE NAP. DC  "}	},//3	//14 ile ayn�								35
	{	{"R05 FREQ TOLER      "},{"R05 TOL. FREQUENCE  "},{"R05 TOLL FREQ       "},{"R05 TOLERANCIA FRECU"},{"R05 CZEST.P.TOL.    "}	},//4												36
	{	{"R06 OVERTEMPERATURE "},{"R06 SURTEMPERATURE  "},{"R06 SOVRATEMPERATURA"},{"R06 SOBRE T         "},{"R06 WYSOKA TEMP     "}	},//5												37
	{	{"R07 BLACKOUT        "},{"R07 BLACKOUT        "},{"R07 BLACKOUT        "},{"R07 BLACKOUT        "},{"R07 BLACKOUT        "}	},//6												38
	{	{"R08 I/P OVERCURRENT "},{"R08 SUR COURANT ENTR"},{"R08 SOVRACORR INGR  "},{"R08 SOBRECORRIEN.SAL"},{"R08 WEJ.OGRN.PRADOWE"}	},//7												39	
	{	{"R09 ROTATE PHASE    "},{"R09 PHASE INVERSEE  "},{"R09 FASE INVERTITA  "},{"R09 FASE DE ROTACION"},{"R09 KIERUNEK WIR.FAZ"}	},//8												40
	{	{"R10 NU              "},{"R10 NU              "},{"R10 NU              "},{"R10 NU              "},{"R10 NU              "}	},//9												41
	{	{"R11 NU              "},{"R11 NU              "},{"R11 NU              "},{"R11 NU              "},{"R11 NU              "}	},//10												42
	{	{"R12 NU              "},{"R12 NU              "},{"R12 NU              "},{"R12 NU              "},{"R12 NU              "}	},//11												43
	{	{"R13 NU              "},{"R13 NU              "},{"R13 NU              "},{"R13 NU              "},{"R13 NU              "}	},//12												44
	{	{"R14 PFC MANUAL STOP "},{"R14 PFC MANUEL STOP "},{"R14 PFC MANUAL STOP "},{"R14 DTNCION MANU.PFC"},{"R14 PFC RECZNY STOP "}	},//13												45
	{	{"R15 DC LOW          "},{"R15 DC BASSE        "},{"R15 DC BASSA        "},{"R15 CC BAJA         "},{"R15 NIS.NAP.DC      "}	},//14												46
	{	{"R00 REC FAULT=@ "}	,{"R00 REDR DEFAU=@"}    ,{"R00 RADD GUAST=@"}	  ,{"R00 FALLA RECT=@ "}   ,{"R00 PROST.BLAD=@"}		},//15												47
								 						  
	{	{"R17 BATTERY TEST    "},{"R17 TEST BATTERIE   "},{"R17 TEST BATTERIA   "},{"R17 TEST BATERIA    "},{"R17 TEST BATERII    "}	},//0  PFC DEN D�REK GELEN UYARILAR - UyariPfc		48
	{	{"R18 BOOST CHARGE    "},{"R18 CHARGE EGALISAT."},{"R18 CARICA BOOST    "},{"R18 CARGA BOOST     "},{"R18 MOCNE LADOWANIE "}	},//1  SAN�YEDE B�R O.5 SAN�YE SESL� UYARI			49
	{	{"R19 AC HIGH         "},{"R19 TENSION AC HAUTE"},{"R19 ALTA AC         "},{"R19 CA ALTA         "},{"R19 WYSOKIE NAP. AC "}	},//2												50
	{	{"R20 INPUT CB OPEN   "},{"R20 INTER.PROT.ENTRE"},{"R20 INTERR INGR APER"},{"R20 CB NTRDA ABIERTO"},{"R20 WEJ. CB OTWARTE "}	},//3												51
	{	{"R21 PFC STOP        "},{"R21 PFC STOP        "},{"R21 PFC STOP        "},{"R21 PFC DETENIDO    "},{"R21 PFC STOP        "}	},//4												52
	{	{"R22 POS CHG LIMIT   "},{"R22 POS LIMIT CHARGE"},{"R22 POS LIMIT CARICA"},{"R22 LIMITE CRGA POS "},{"R22 OGR. PR. PLUS   "}	},//5												53
	{	{"R23 NEG CHG LIMIT   "},{"R23 NEG LIMIT CHARGE"},{"R23 NEG LIMIT CARICA"},{"R23 LIMITE CRGA NEG "},{"R23 OGR. PR. MINUS  "}	},//6												54
	{	{"R24 WAITING DC BUS  "},{"R24 ATTENTE DC BUS  "},{"R24 ATTESA DC BUS   "},{"R24 ESPERANDO CC BUS"},{"R24 CZEK. NAP. DC   "}	},//7												55
	{	{"R25 BATTERY FAILURE "},{"R25 DEFAUT BATTERIE "},{"R25 BATTERIA GUASTA "},{"R25 FALLA BATERIA   "},{"R25 USZKODZ. BAT.   "}	},//8												56
	{	{"R26 BATT TEMP SENSOR"},{"R26 CAPT TEMPER BATT"},{"R26 SENS TEMPER BATT"},{"R26 T SENSOR BAT    "},{"R26 CZUJ. TEMP. BAT."}	},//9												57
	{	{"R27 BATT TEMP HIGH  "},{"R27 TEMP BATT HAUTE "},{"R27 TEMP BATT ALTA  "},{"R27 T BAT ALTA      "},{"R27 WYS .TEMP. BAT. "}	},//10												58
	{	{"R28 NO BATTERY      "},{"R28 PAS DE BATTERIE "},{"R28 NO BATTERIA     "},{"R28 NO BATERIA      "},{"R28 NIE BATERIA     "}	},//11												59
	{	{"R29 PFC RESET       "},{"R29 RESET PFC       "},{"R29 RESET PFC       "},{"R29 REINICIAR PFC   "},{"R29 PFC RESET       "}	},//12												60
	{	{"R30 PLEASE WAIT!    "},{"R30 ATTENDRE        "},{"R30 ATTENDERE!      "},{"R30 ESPERE POR FAVOR"},{"R30 PROSZE CZEKAC   "}	},//13												61
	{	{"RECTIFIER STARTING  "},{"DEMARRAGE REDRESSEUR"},{"RADDRIZZ AVVIATO    "},{"INICIO RECTIFICADOR "},{"START PROSTOWNIKA   "}	},//14												62
	{	{"R32 NU              "},{"R32 NU              "},{"R32 NU              "},{"R32 NU              "},{"R32 NU              "}	},//15												63

	{	{"L01 TH1 TEMP HIGH   "},{"L01 TH1 TEMP HAUTE  "},{"L01 TH1 TEMP ALTA   "},{"L01 T TH1 ALTA      "},{"L01 WYSOKA TEMP. TH1"}	},//0  PANEL DEN D�REK GELEN UYARILAR - ALARMLAR OLAB�L�R					64
	{	{"L02 TH2 TEMP HIGH   "},{"L02 TH2 TEMP HAUTE  "},{"L02 TH2 TEMP ALTA   "},{"L02 T TH2 ALTA      "},{"L02 WYSOKA TEMP. TH2"}	},//1  �UAN UYARILAR-----AlarmLcd------										65
	{	{"L03 TH1 TEMP LOW    "},{"L03 TH1 TEMP BASSE  "},{"L03 TH1 TEMP BASSA  "},{"L03 T TH1 BAJA      "},{"L03 NISKA TEMP. TH1 "}	},//2												66
	{	{"L04 TH2 TEMP LOW    "},{"L04 TH2 TEMP BASSE  "},{"L04 TH2 TEMP BASSA  "},{"L04 T TH2 BAJA      "},{"L04 NISKA TEMP. TH2 "}	},//3												67
	{	{"L05 FAN MAINT       "},{"L05 MANUT VENTILAT. "},{"L05 MANUT VENTOLE   "},{"L05 MANTEN.VENTILADO"},{"L05 SERWIS WENTYLAT "}	},//4												68
	{	{"L06 BATTERY MAINT   "},{"L06 MANUT BATTERIE  "},{"L06 MANUT BATTERIA  "},{"L06 MANTEN.BATERIA  "},{"L06 SERWIS BATERII  "}	},//5												69
	//{	{"L07 OPT MAINT       "},{"L07 MAUNT OPT.      "},{"L07 OPT MANUTENZIONE"},{"L07 OPC.MANTENIMIENT"},{"L07 OPCJ. SERWIS    "}	},//6  SAN�YEDE B�R O.5 SAN�YE SESL� UYARI			70
	{	{"L07 GENERAL ALARM   "},{"L07 ALARME GENERALE "},{"L07 ALLARME GENERALE"},{"L07 ALARMA GENERAL  "},{"L07 ALARM OGOLNY    "}	},//6                                               70	genel alarm eklendi
	{	{"L08 TH1 SENSOR FAIL "},{"L08 TH1 CAPTEUR DEF."},{"L08 TH1 SENSOR GUAST"},{"L08 FALLA SENSOR TH1"},{"L08 USZK. CZUJ. TH1 "}	},//7	//EEproma kaydedilemiyor.Yer yok.			71
	{	{"L09 TH2 SENSOR FAIL "},{"L09 TH2 CAPTEUR DEF."},{"L09 TH2 SENSOR GUAST"},{"L09 FALLA SENSOR TH2"},{"L09 USZK. CZUJ. TH2 "}	},//8												72
	{	{"L10 ENTER FAULT RST "},{"L10 RESET DEFAUT    "},{"L10 RESET GUASTI    "},{"L10 RESEAR FALLAS   "},{"L10 ENTER KASUJ BLAD"}	},//9	//Baz� �artlar ger�ekle�ince 1 olur.		73
	{	{"L11 BATT CB OPEN    "},{"L11 PROT BATT OUVERT"},{"L11 INTERR BATT APER"},{"L11 PROTEC.BAT.ABIER"},{"L11 OTWARTY CB BAT. "}	},//10	//Sadece Relay1 e ait (Batt.CB)ve Batt.Sw a��k olunca alarm gelir.  74
	{	{"L12 GENERAL MAINT   "},{"L12 MANUT GENERALE  "},{"L12 MANUT GENERALE  "},{"L12 MANTEN. GENERAL "},{"L12 WYMAGANY SERWIS "}	},//11												75
	{	{"L13 PFC CAN COMM ERR"},{"L13 PFC CAN COMM ERR"},{"L13 PFC CAN COMM ERR"},{"L13 CAN ERR.COM.PFC "},{"L13 PFC BLAD CAN    "}	},//12												76
	{	{"L14 INV CAN COMM ERR"},{"L14 OND CAN COMM ERR"},{"L14 INV CAN COMM ERR"},{"L14 CAN ERR.COM.INV "},{"L14 FAL.BLAD CAN    "}	},//13												77
	{	{"INV CODE = @     "}	,{"OND CODE  = @    "}	,{"INV CODE = @     "}	  ,{"CODIGO INVER. = @"}   ,{"KOD FALOWNIKA = @"}		},//14	PANEL TARAFINDAN �RET�LD��� ���N BURAYA KONDULAR					78
	{	{"REC CODE = @     "}	,{"REDR CODE = @    "}	,{"RADD CODE = @    "}	  ,{"CODIGO RECTIF.= @"}   ,{"KOD PROST. = @   "}		},//15												79

	//Uyari Inv 2ari Inv 2
	{	{"A33 TEST MODE       "},{"A33 MODE TEST       "},{"A33 MODO TEST       "},{"A33 MODO TEST       "},{"A33 TRYB TESTOWY    "}	},//0  Inv den login bilgisinin geldi�i data		80
	{	{"A34 BYP.ROTATE PHASE"},{"A34 PH BYPAS INVERSE"},{"A34 FASE BYP GIRATA "},{"A34 FASE ROTAC. BYP "},{"A34 BYP.KIER.WIR.FAZ"}	},//1  												81
	{	{"A35 INV STOP        "},{"A35 OND STOP        "},{"A35 INV STOP        "},{"A35 INVERSOR DETENID"},{"A35 FALOWNIK STOP   "}	},//2  												82
	{	{"A36 INV DC DOWN     "},{"A36 DC OND BASSE    "},{"A36 INV DC BASSA    "},{"A36 CC INVERSOR BAJA"},{"A36 NIS.NAP.DC FAL. "}	},//3												83
	{	{"A37 AC CURR.LIMIT   "},{"A37 AC LIMIT COURANT"},{"A37 AC LIMITAZ CORR "},{"A37 AC DE CORRIENTE "},{"A37 OGR. PRADU AC   "}	},//4												84
	{	{"A38 FUSE FAILURE    "},{"A38 FUSIBLES HS     "},{"A38 FUSIBILI GUASTI "},{"A38 FALLA FUSIBLE   "},{"A38 USZKODZ. BEZP.  "}	},//5												85
	{	{"A39 PSP FAILURE     "},{"A39 ALIMENTATION HS "},{"A39 ALIMENTAT GUASTO"},{"A39 FALLA ENTRADA   "},{"A39 AWARIA ZASILACZA"}	},//6												86
	{	{"INVERTER STARTING   "},{"ONDULEUR DEMARRAGE  "},{"INVERTER AVVIATO    "},{"INVERSOR INICIANDO  "},{"START FALOWNIKA     "}	},//7												87
	{	{"A41 SLEEP MODE      "},{"A41 MODE PAUSE      "},{"A41 MODO PAUSA      "},{"A41 MODO REPOSO     "},{"A41 TRYB USPIENIA   "}	},//8												88
	{	{"A42 PARALLEL ALARM  "},{"A42 ALARMES PARALL. "},{"A42 ALLARME PARALL  "},{"A42 ALARMA PARALELO "},{"A42 BLAD PR.ROWNOLEG"}	},//9												89
	{	{"A43 USER LOGIN      "},{"A43 LOGIN UTILISAT. "},{"A43 LOGIN UTENTE    "},{"A43 ACCESO USUARIO  "},{"A43 LOGIN UZYTKOWNIK"}	},//10												90
	{	{"A44 WAITING MINIMUM "},{"A44 MINIMUM ATTENTE "},{"A44 MINIMA ATTESA   "},{"A44 MINIMO DE ESPERA"},{"A44 MINIMUM CZEKAM  "}	},//11												91
	{	{"A45 SERV. PASSWORD? "},{"A45 MOT PASS SERVICE"},{"A45 SERV. PASSWORD? "},{"A45 CLAVE SERVICIO? "},{"A45 HASLO SERWIS?   "}	},//12												92
	{	{"A46 NU              "},{"A46 NU              "},{"A46 NU              "},{"A46 NU              "},{"A46 NU              "}	},//13												93
	{	{"A47 MASTER UPS      "},{"A47 MAITRE ASI      "},{"A47 MASTER UPS      "},{"A47 MAESTRO UPS     "},{"A47 MISTRZ UPS      "}	},//14												94		//23.12.2014
	{	{"A48 INV STEP MODE   "},{"A48 OND EN MODE STEP"},{"A48 PASS MODO INV   "},{"A48 MODO PASO INVER."},{"A48 FAL. TRYB STEP  "}	},//15												95
	//Uyari Lcd 2ari Lcd 2
	{	{"L17 WAIT SLEEP      "},{"L17 ATTENTE PAUSE   "},{"L17 ATTESA PAUSA    "},{"L17 ESPERE REPOSO   "},{"L17 CZEKAJ USYPIANIE"}	},//0 												96
	{	{"L18 WAIT WAKEUP     "},{"L18 REDEMARRAGE     "},{"L18 RIPARTENZA      "},{"L18 ESPERE INICIANDO"},{"L18 CZEKAJ WYBUDZANI"}	},//1  												97
	{	{"L19 NU19            "},{"L19 NU19            "},{"L19 NU19            "},{"L19 NU19            "},{"L19 NU19            "}	},//2  												98
	{	{"L20 NU20            "},{"L20 NU20            "},{"L20 NU20            "},{"L20 NU20            "},{"L20 NU20            "}	},//3												99
	{	{"L21 NU21            "},{"L21 NU21            "},{"L21 NU21            "},{"L21 NU21            "},{"L21 NU21            "}	},//4											   100
	{	{"L22 NU22            "},{"L22 NU22            "},{"L22 NU22            "},{"L22 NU22            "},{"L22 NU22            "}	},//5											   101
	{	{"L23 NU23            "},{"L23 NU23            "},{"L23 NU23            "},{"L23 NU23            "},{"L23 NU23            "}	},//6											   102
	{	{"L24 NU24            "},{"L24 NU24            "},{"L24 NU24            "},{"L24 NU24            "},{"L24 NU24            "}	},//7											   103
	{	{"L25 NU25            "},{"L25 NU25            "},{"L25 NU25            "},{"L25 NU25            "},{"L25 NU25            "}	},//8											   104
	{	{"L26 NU26            "},{"L26 NU26            "},{"L26 NU26            "},{"L26 NU26            "},{"L26 NU26            "}	},//9											   105
	{	{"L27 NU27            "},{"L27 NU27            "},{"L27 NU27            "},{"L27 NU27            "},{"L27 NU27            "}	},//10											   106
	{	{"L28 NU28            "},{"L28 NU28            "},{"L28 NU28            "},{"L28 NU28            "},{"L28 NU28            "}	},//11											   107
	{	{"L29 NU29            "},{"L29 NU29            "},{"L29 NU29            "},{"L29 NU29            "},{"L29 NU29            "}	},//12											   108
	{	{"L30 NU30            "},{"L30 NU30            "},{"L30 NU30            "},{"L30 NU30            "},{"L30 NU30            "}	},//13											   109
	{	{"L31 SOLAR CAN ERR   "},{"L31 SOLAR CAN ERREUR"},{"L31 SOLAR CAN ERR   "},{"L31 CAN ERROR SOLAR "},{"L31 SOLAR BLAD CAN  "}	},//14											   110				//CAN_100kHz Solar can ile birlikte eklendi.
	{	{"��������������������"},{"��������������������"},{"��������������������"},{"��������������������"},{"��������������������"}	} //15											   111
};

//Touch Calibration Menu
volatile unsigned  char *TouchTablo[3][5] 	__attribute__((far)) =
{
	{	
		{"     TOUCH THE STATED POINTS FOR CALIBRATION     "},
		{"    TOUCHER LES POINTS FIXES POUR LETALONNAGE    "},
		{"  TOCCARE I PUNTI DICHIARATI PER LA CALIBRAZIONE "},
		{"TOCAR LOS PUNTOS ESTABLECIDOS PARA LA CALIBRACION"},
		{     "DOTYKAC USTALONYCH PUNKTOW DO KALIBRACJI    "}	
	},
	{	
		{"            CALIBRATION COMPLETED                "},
		{"             CALIBRATION ACHEVEE                 "},
		{"           CALIBRAZIONE COMPLETATA               "},
		{"          COMPLETADO LA CALIBRACION              "},
		{"            KALIBRACJA ZAKONCZONA                "}	
	}
	{	
		{"               TOUCH PANEL IS PASSIVE            "},
		{"              ECRAN TACTILE EST PASSIF           "},
		{"               TOUCH PANEL E PASSIVO             "},
		{"               PANEL TACTIL ES PASIVA            "},
		{"              PANEL TOUCH JEST BIERNY            "}	
	},
};	
	
#endif


volatile unsigned  char *AyarAnaMenu[11]		 __attribute__((far)) = 
{												
	{" GROUP ADJUSTMENT   "},		//1 --> 0.bit												
	{" INV FACTORY OPTIONS"},		//2 --> 1.bit		
	{" REC FACTORY OPTIONS"},		//3 --> 2.bit
	{" PANEL ADJUSTMENT   "},		//4 --> 3.bit
	{" AC INPUT ADJ.      "},		//5 --> 4.bit
	{" AC BYPASS ADJ.     "},		//6 --> 5.bit
	{" AC OUTPUT ADJ.     "},		//7 --> 6.bit
	{" DC ADJUSTMENT      "},		//8 --> 7.bit
	{" POWER ADJUSTMENT   "},		//9 --> 8.bit
//	{" SYSTEM ADJUSTMENT  "},		//11--> 9.bit
	{" ENTER  -  EXIT     "}
	
};



//Ayar men�s�ndeki son hane silinebilir kullan�lm�yor.
//W yazan grup ekranda 2. sat�rda g�r�nen adresten 128 eksiktir.
//Okuma adresi serbesttir o adresten sadece okunur ona ba��ml� bir i�lem yap�lmaz.
//Yetki : 0 --> Serbest , 1 --> Kullan�c� �ifresi , 2 --> Servis �ifresi 
volatile unsigned  char *Ayar_GrupAdj[10][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" PFC BATT QUANTITY  "}	, 2064,2192,{"pcs"}  ,0 },			//0					 
	{	{" A(+)FLOAT CHR VOLT "}	, 2065,2193,{"   "}  ,0 },			//1	
	{	{" A(-)FLOAT CHR VOLT "} 	, 2066,2194,{"   "}  ,0 },			//2	
	{	{" I/P VOLT RANGE     "} 	, 2057,2185,{"VAC"}  ,0 },			//3	
	{	{" I/P FREQ RANGE     "} 	, 2014,2142,{"Hz "}  ,0 },			//4		
	{	{" O/P VOLT RANGE     "}	, 1059,1187,{"VAC"}  ,0 },			//5		
	{	{" O/P FREQ RANGE     "}	, 1008,1136,{"Hz "}  ,0 },			//6		
	{	{" INV BATT QUANTITY  "} 	, 1053,1181,{"pcs"}  ,0 },			//7		
	{	{" A.PFC PWM FREQUENCY"} 	, 2105,2233,{"Hz "}  ,0 },			//8		
	{	{" A.INV PWM FREQUENCY"}	, 1105,1233,{"Hz "}  ,0 }			//9		
};
//2192 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_2192[19][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
//	{	{" A PFC BATT QUANTITY"}	, 2001,2129,{"pcs"}  ,0	},			//Kald�r�ld�.	
	{	{" A TEST FAULT VOLT  "}	, 2002,2130,{"VDC"}  ,2	},			//0
	{	{" A PFC BATT HIGH    "}	, 2003,2131,{"VDC"}  ,2	},			//1
	{	{" A PFC BATT HIGH RST"}	, 2038,2166,{"min"}  ,0	},			//2	
	{	{" A PFC DC START     "} 	, 2004,2132,{"VDC"}  ,2 },			//3	
	{	{" A PFC MIN DC VOLT  "} 	, 2005,2133,{"VDC"}  ,2 },			//4
	{	{" A (+)FLOAT CHR.VOLT"} 	, 2006,2028,{"VDC"}  ,2 },			//5
	{	{" A (-)FLOAT CHR.VOLT"}	, 2007,2029,{"VDC"}  ,2 },			//6	
	{	{" A BOOST CHARGE VOLT"}	, 2008,2136,{"VDC"}  ,2 },			//7			//R --> 2028 di	
//	{	{" A (-)BOOST CHR.VOLT"} 	, 2009,2029,{"VDC"}  ,0 },			//Kald�r�ld�.	
	{	{" A BATTERY TEST VOLT"} 	, 2010,2138,{"VDC"}  ,2 },			//8			//R --> 2028 di
//	{	{" A (-)BATT TEST VOLT"} 	, 2011,2029,{"VDC"}  ,0 },			//Kald�r�ld�.		
	{	{" A BATT TEMP HIGH   "}	, 2083,2211,{"C  "}  ,0 },			//9	
	{	{" BTT.TEMP.COMP(mV/C)"}	, 2045,2173,{"mV "}  ,0 },			//10
	{	{" A PFC REGEN PWM    "} 	, 2086,2214,{"PWM"}  ,0 },			//11							
	{	{" A PFC REGEN DC     "} 	, 2087,2215,{"VDC"}  ,2 },			//12	
	{	{" A BATT TEST INTRVAL"} 	, 2092,2220,{"min"}  ,0 },			//13			
	{	{" A BOOST CHARGE TIME"}	, 2044,2172,{"min"} ,0	}			//14
};
//2193 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_2193[5][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
//	{	{" A PFC MIN REF      "}	, 2005,2133,{"   "}  ,0	},			//Kald�r�ld�.
	{	{" A (+)FLOAT CHR.VOLT"}	, 2006,2028,{"VDC"}  ,2	},			//0
//	{	{" A (+)BOOST CHR.VOLT"}	, 2008,2028,{"VDC"}  ,0	},			//Kald�r�ld�.	
//	{	{" A (+)BATT TEST VOLT"} 	, 2010,2028,{"VDC"}  ,0 },			//Kald�r�ld�.
	{	{" C.PFC(+)BATT VOLT  "} 	, 2024,2028,{"VDC"}  ,2 }			//1
};
//2194 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_2194[5][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
//	{	{" A PFC MIN REF      "}	, 2005,2133,{"   "}  ,0	},			//Kald�r�ld�.
	{	{" A (-)FLOAT CHR.VOLT"}	, 2007,2029,{"VDC"}  ,2	},			//0
//	{	{" A (-)BOOST CHR.VOLT"}	, 2009,2029,{"VDC"}  ,0	},			//Kald�r�ld�.		
//	{	{" A (-)BATT TEST VOLT"} 	, 2011,2029,{"VDC"}  ,0 },			//Kald�r�ld�.
	{	{" C.PFC(-)BATT VOLT  "} 	, 2025,2029,{"VDC"}  ,2 }			//1
};
//2185 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_2185[4][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" A PFC START DELAY  "}	, 2046,2174,{"sec"}  ,0	},			//0
	{	{" A PFC SFTSTRT SPEED"}	, 2047,2175,{"sec"}  ,0	},			//1
	{	{" A I/P LINE HIGH    "}	, 2058,2186,{"VAC"}  ,2	},			//2		
	{	{" A I/P LINE FAIL    "} 	, 2059,2187,{"VAC"}  ,2 }			//3
};
//2142 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_2142[4][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" A I/P LOW FREQ     "}	, 2015,2143,{"Hz "}  ,0	},			//0
	{	{" A I/P HIGH FREQ    "}	, 2016,2144,{"Hz "}  ,0	}			//1
};
//1187 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_1187[11][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" A O/P LOW          "}	, 1060,1188,{"VAC"}  ,2	},			//0
	{	{" A O/P HIGH         "}	, 1061,1189,{"VAC"}  ,2	},			//1
	{	{" A INV O/P LOW RESET"}	, 1085,1213,{"min"}  ,0	},			//2	
	{	{" A INV O/P HIGH RST "}	, 1086,1214,{"min"}  ,0	},			//3
	{	{" A BYPASS  FAILURE  "}	, 1062,1190,{"VAC"}  ,2	},			//4		
	{	{" A BYPASS LOW       "} 	, 1063,1191,{"VAC"}  ,2 },			//5
	{	{" A BYPASS HIGH      "} 	, 1064,1192,{"VAC"}  ,2 },			//6	
	{	{" A VAT LOW LIMIT    "} 	, 1068,1196,{"VAC"}  ,2 },			//7	
	{	{" A VAT HIGH LIMIT   "} 	, 1069,1197,{"VAC"}  ,2 },			//8	
	{	{" A INV BALANCE TIME "} 	, 1089,1217,{"sec"}  ,0 },			//9	
	{	{" A INV BALANCE VOLT "} 	, 1090,1218,{"VDC"}  ,2 }			//10
};
//1136 n�n alt grubu
volatile unsigned  char *Ayar_GrupAdj_1136[8][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" A O/P FRQ SPEED    "}	, 1001,1129,{"   "}  ,0	},			//0
	{	{" A O/P PERIOD       "}	, 1009,1137,{"Hz "}  ,0	},			//1	
	{	{" A PHASE SHIFT      "}	, 1010,1138,{"   "}  ,0	},			//2		
	{	{" A O/P FRQ FINE     "} 	, 1011,1139,{"   "}  ,0 },			//3
	{	{" A O/P HIGH FREQ    "} 	, 1012,1140,{"Hz "}  ,0 },			//4	
	{	{" A O/P LOW FREQ     "} 	, 1013,1141,{"Hz "}  ,0 },			//5	
	{	{" A SYNC DELAY       "} 	, 1098,1226,{"sec"}  ,0 },			//6	
	{	{" A SYNC TOL         "} 	, 1099,1227,{"VAC"}  ,2 }			//7
};
//1181 n�n alt grubu
volatile unsigned  char *Ayar_GrupAdj_1181[10][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
//	{	{" INV BATTERRIES     "}	, 1002,1130,{"pcs"}  ,0	},			//0
	{	{" A INV BATT LOW     "}	, 1003,1131,{"VDC"}  ,2	},			//1	
	{	{" A INV BATT WARNING "}	, 1004,1132,{"VDC"}  ,2	},			//2		
	{	{" A INV BATT HIGH    "} 	, 1005,1133,{"VDC"}  ,2 },			//3
	{	{" A INV DC START     "} 	, 1006,1134,{"VDC"}  ,2 },			//4	
	{	{" A INV REGEN LEVEL  "} 	, 1007,1135,{"VDC"}  ,2 },			//5	
	{	{" A INV DC HIGH DELAY"} 	, 1093,1221,{"msc"}  ,0 },			//6
	{	{" A INV BATT HIGH RST"}	, 1084,1212,{"min"}  ,0	}			//7
};

//2233 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_2233[3][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" PFC ALARM HOLD TIME"}	, 2084,2212,{"sec"} ,0	},			//0
	{	{" A PFC IGBT RESET   "}	, 2037,2165,{"min"} ,0	},			//1
	{	{" A PFC OVERTEMP RST "}	, 2039,2167,{"min"} ,0	}			//2
};
//1233 nin alt grubu
volatile unsigned  char *Ayar_GrupAdj_1233[3][5]		 __attribute__((far)) = 
{												
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" INV ALARM HOLD TIME"}	, 1091,1219,{"sec"} ,0	},			//0	
	{	{" A INV IGBT RESET   "}	, 1087,1215,{"min"} ,0	},			//1
	{	{" A INV OVERTEMP RST "}	, 1088,1216,{"min"} ,0	}			//2
};
//* --> Ayar isimleri de�i�enler
//** -> Komple eklenenler

//*****Inv Factory Options
volatile unsigned  char *Ayar_InvFactOpt[17][5] 	__attribute__((far)) =
 {			
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" O/P SWITCH         "} 	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	0.bit		USED - NOT USED
	{	{" TEMP SENSOR        "} 	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	1.bit		USED - NOT USED
	{	{" O/P CB SENSE       "} 	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	2.bit		ON - OFF*		
	{	{" SCR FAULT          "}	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	3.bit		ON - OFF*	
	{	{" INV EPROM FAULT    "} 	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	4.bit		ON - OFF*
	{	{" O/P MODUL TYPE     "} 	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	5.bit		IGBT - IPM	
	{	{" PFC SYSTEM         "}	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	6.bit		USED - NOT USED		
	{	{" DC BALANCE FAULT   "}  	, 1043,1171,{"   "}  ,0 },				//W1043		-	R1171	- 	7.bit		ON - OFF*	
	{	{" BYP SYNCHRON       "}	, 1043,1171,{"   "}  ,0 },				//W10043	-	R1171	- 	8.bit		XTAL - SYNC		
	{	{" SHORT CIRCUIT PHASE"}	, 1043,1171,{"   "}  ,0 },				//W1043		-	R1171	- 	11.bit		SHUT1 - SHUT3
	{	{" BYP SHORT CIRCUIT  "}	, 1043,1171,{"   "}  ,0 },				//W1043		-	R1171	- 	12.bit		ON - OFF*	
	{	{" BYPASS LKG.CURR.   "}	, 1043,1171,{"   "}  ,0 },				//W1043		-	R1171	- 	14.bit		ON - OFF**	
	{	{" BYPASS CURR.TRF.   "}	, 1043,1171,{"   "}  ,0 },				//W1043		-	R1171	- 	15.bit		1 - 3**	
	{	{" OPERATING MODE     "}	, 1100,1228,{"   "}  ,0 },				//W1100		-	R1228					N+1 REDUN - ONLINE - ECONO - PARALLEL
	{	{" UPS NO             "}	, 1101,1229,{"   "}  ,0 },				//W1101		-	R1229					1 - 8
	{	{" N + 1 MINIMUM      "}	, 1102,1230,{"   "}  ,0 },				//W1102		-	R1230					1 - 8
	{	{" OUTPUT PHASE COUNT "}	, 1049,1177,{"   "}  ,0 }				//W1049		-	R1177					1 ya da 3				//14.07.14
};
//*****Pfc Factory Options
volatile unsigned  char *Ayar_PfcFactOpt[12][5] 	__attribute__((far)) =
{
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" I/P MODULE TYPE    "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	0.bit	(PFC)	IGBT - IPM
	{	{" BT.TEMPERATURE KOMP"}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	1.bit	(PFC)	ON - OFF*	
	{	{" PFC EPROM FAULT    "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	2.bit	(PFC)	ON - OFF*
	{	{" BOOST CHARGE       "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	3.bit	(PFC)	ON - OFF*
//	{	{" I/P CURRENT PROTECT"}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	4.bit	(PFC)	ON - OFF*
	{	{" I/P CB SENSE       "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	6.bit	(PFC)	ON - OFF*
	{ 	{" I/P CURR TRANS.ALR "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	7.bit	(PFC)	ON - OFF*
	{	{" AC INPUT TEST      "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	8.bit	(PFC)	ON - OFF*
	{	{" PFC THERMAL PROTECT"}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	9.bit	(PFC)	ON - OFF*
	{	{" I/P REGEN.SYSTEM   "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	10.bit	(PFC)	ON - OFF*
	{	{" AUTOMATIC BATT.TEST"}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	11.bit	(PFC)	ON - OFF*
	{	{" USE SENSOR         "}	, 2032,2160,{"   "}  ,0 },				//W2032	-	R2160	- 	13.bit	(PFC)	TH3 - TH1**
	{	{" PFC DC LEAKAGE     "}	, 2032,2160,{"   "}  ,0 }				//W2032	-	R2160	- 	14.bit	(PFC)	Giri� DC ka�ak ayar�
};

//*****Panel Options
volatile unsigned  char *Ayar_PanelOpt[20][5] 	__attribute__((far)) =
{
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" OPTIONAL CARD      "}	,3415,3415,{"   "} ,0	},				//W3415	-	R3415	-	USED - NOT USED	
	{	{" USER PASSWORD      "}	,3415,3415,{"   "} ,0	}, 				//W3415	-	R3415   -   USED - NOT USED	
	{	{" TH1 SENSOR         "}	,3415,3415,{"   "} ,0	},				//W3415	-	R3415	-	USED - NOT USED					
	{	{" C.TH1 SENSOR       "}	,3418,3419,{"  C"} ,0	},			
	{	{" A.TH1 TEMP HIGH    "}	,3420,3420,{"  C"} ,0	},			
	{	{" A.TH1 TEMP LOW     "}	,3421,3421,{"  C"} ,0	},
	{	{" TH2 SENSOR         "}	,3415,3415,{"   "} ,0	}, 				//W3415	-	R3415	-	USED - NOT USED	
	{	{" C.TH2 SENSOR       "}	,3422,3423,{"  C"} ,0	}, 			
	{	{" A.TH2 TEMP HIGH    "}	,3424,3424,{"  C"} ,0	},			
	{	{" A.TH2 TEMP LOW     "}	,3425,3425,{"  C"} ,0	},				
	{	{" A.PANEL BATTERIES  "}	,3428,3428,{"pcs"} ,0	},			
	{	{" A.PANEL BATT.GROUPS"}	,3426,3426,{"   "} ,0	},		
	{	{" A.PANEL BATT. A/H  "}	,3427,3427,{"A/H"} ,0	},		
	{	{" FREQ CONVERTER(BYP)"}	,3415,3415,{"   "} ,0	},				//21.07.14				USED - NOT USED	
	{	{" EPO STATUS         "}	,3415,3415,{"   "} ,0	},				//21.07.14				USED - NOT USED	
	{	{" GENIN STATUS       "}	,3415,3415,{"   "} ,0	},				//21.07.14				USED - NOT USED	
	{	{" FAN MAINT          "}	,3378,3376,{"  h"} ,0	},				//26.11.2014 te eklendi
	{	{" BATT MAINT         "}	,3383,3381,{"  h"} ,0	},				//26.11.2014 te eklendi
	{	{" GENERAL MAINT      "}	,3388,3386,{"  h"} ,0	},				//26.11.2014 te eklendi	
	{	{" TOUCH PANEL        "}	,3415,3415,{"   "} ,0	},				//24.06.2015 te eklendi	touch
};

//*****AC INPUT (PFC)(3)
volatile unsigned  char *Ayar_AcInput[13][5] 	__attribute__((far)) =
{
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" C.VINP L1-N        "}	, 2021,2022,{"VAC"} ,2	},							
	{	{" C.VINP L2-N        "}	, 2022,2023,{"VAC"} ,2	},			
	{	{" C.VINP L3-N        "}	, 2023,2024,{"VAC"} ,2	},			
	{	{" A I/P VOFFSET L1   "}	, 2093,2283,{"   "} ,0	},		// + / -			
	{	{" A I/P VOFFSET L2   "}	, 2094,2284,{"   "} ,0	},		// + / -			
	{	{" A I/P VOFFSET L3   "}	, 2095,2285,{"   "} ,0	},		// + / -			
	{	{" C.I INPUT L1       "}	, 2018,2019,{"A  "} ,0	},			
	{	{" C.I INPUT L2       "}	, 2019,2020,{"A  "} ,0	},			
	{	{" C.I INPUT L3       "}	, 2020,2021,{"A  "} ,0	},			
	{	{" A I/P CURR LIMIT   "}	, 2060,2188,{"   "} ,0	},
	{	{" A I/P IOFFSET L1   "}	, 2096,2014,{"   "} ,0	},		// + / -			
	{	{" A I/P IOFFSET L2   "}	, 2097,2015,{"   "} ,0	},		// + / -			
	{	{" A I/P IOFFSET L3   "}	, 2098,2016,{"   "} ,0	}		// + / -			
};	
//*****AC BYPASS (INV)(4)
volatile unsigned  char *Ayar_AcBypass[6][5] 		__attribute__((far)) =
{
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" C.VBYPASS L1-N     "} 	, 1023,1027,{"VAC"} ,2	},							
	{	{" C.VBYPASS L2-N     "} 	, 1024,1028,{"VAC"} ,2	},			
	{	{" C.VBYPASS L3-N     "} 	, 1025,1029,{"VAC"} ,2	},			
	{	{" A BYP LKG CUR.DELAY"} 	, 1070,1198,{"msc"} ,0	},			
	{	{" A BYP LKG CUR.LEVEL"} 	, 1071,1199,{"   "} ,0	},
	{	{" A INV O/P CB DELAY "}	, 1094,1222,{"msc"} ,0	}					
};		
//*****AC OUTPUT (INV)(5)
volatile unsigned  char *Ayar_AcOutput[12][5] 	__attribute__((far)) =
{						
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" C.VINV L1-N        "}	, 1020,1024,{"VAC"} ,2	},			
	{	{" C.VINV L2-N        "}	, 1021,1025,{"VAC"} ,2	},			
	{	{" C.VINV L3-N        "}	, 1022,1026,{"VAC"} ,2	},			
	{	{" A INV BAL L1       "}	, 1017,1050,{"   "} ,0	},		// + / -	
	{	{" A INV BAL L2       "}	, 1018,1051,{"   "} ,0	},		// + / -	
	{	{" A INV BAL L3       "}	, 1019,1052,{"   "} ,0	},		// + / - 	
	{	{" A INV O/P VOLT L1  "}	, 1065,1024,{"VAC"} ,2	},			
	{	{" A INV O/P VOLT L2  "}	, 1066,1025,{"VAC"} ,2	},			
	{	{" A INV O/P VOLT L3  "}	, 1067,1026,{"VAC"} ,2	},			
	{	{" C.VOUT L1-N        "}	, 1026,1021,{"VAC"} ,2	},			
	{	{" C.VOUT L2-N        "}	, 1027,1022,{"VAC"} ,2	},			
	{	{" C.VOUT L3-N        "}	, 1028,1023,{"VAC"} ,2	}			
//	{	{" C L1 OUT CURRENT   "}	, 1029,1030,{"  A"} ,0	},			
//	{	{" C L2 OUT CURRENT   "}	, 1030,1031,{"  A"} ,0	},			
//	{	{" C L3 OUT CURRENT   "}	, 1031,1032,{"  A"} ,0	},			
//	{	{" A L1 CURR OFFSET   "}	, 1081,1418,{"   "} ,0	},		// + / - 			
//	{	{" A L2 CURR OFFSET   "}	, 1082,1419,{"   "} ,0	},		// + / - 			
//	{	{" A L3 CURR OFFSET   "}	, 1083,1420,{"   "} ,0	}		// + / - 			
};		
//*****DC ADJUSTMENT (6)
volatile unsigned  char *Ayar_DcAdj[13][5] 	__attribute__((far)) =
{
//			 Etiket			  	   	   W    R    Birim	 Yetki
	{	{" C.INV(+) BATT.VOLT "}	, 1041,1045,{"VDC"} ,2	},			
	{	{" C.INV(-) BATT.VOLT "}	, 1042,1046,{"VDC"} ,2	},			
	{	{" C.(+)DISCHARGE CURR"}	, 2028,2074,{"A  "} ,0	},			
	{	{" C.(-)DISCHARGE CURR"}	, 2029,2075,{"A  "} ,0	},			
	{	{" C.(+)CHARGE CURRENT"}	, 2030,2032,{"A  "} ,0	},			
	{	{" C.(-)CHARGE CURRENT"}	, 2031,2033,{"A  "} ,0	},			
	{	{" C.BATT TEMP        "} 	, 2033,2034,{"C  "} ,0	},			
	{	{" A.(+)BAT Ichg.OFSET"}	, 2034,2040,{"   "} ,0	},			//- de�erler yaz�lacak	
	{	{" A.(-)BAT Ichg.OFSET"}	, 2035,2041,{"   "} ,0	},			//- de�erler yaz�lacak			
	{	{" A BATT CHARGE LIMIT"}	, 2041,2169,{"A  "} ,0	},			
	{	{" A BATT TEMP COMP   "}	, 2045,2173,{"   "} ,0	},				
	{	{" A (+)CHARGE GAIN   "}	, 2108,2032,{"A  "} ,0	},			
	{	{" A (-)CHARGE GAIN   "}	, 2109,2033,{"A  "} ,0	}			
};	
//*****POWER (INV)(7)
volatile unsigned  char *Ayar_Power[26][5] 	__attribute__((far)) =
{
//			 Etiket			  	   	   W    R    Birim	 Yetki
//	{	{" C.CREST FACTOR L1  "}	, 1035,1036,{"   "} ,0	},			
//	{	{" C.CREST FACTOR L2  "}	, 1036,1037,{"   "} ,0	},			
//	{	{" C.CREST FACTOR L3  "}	, 1037,1038,{"   "} ,0	},
					
	{	{" A MAX.WATTS        "}	, 1076,1204,{"kW "} ,0	},		
	{	{" C.L1 WATTS         "}	, 1056,1118,{"kW "} ,0	},			
	{	{" C.L2 WATTS         "}	, 1057,1119,{"kW "} ,0	},			
	{	{" C.L3 WATTS         "}	, 1058,1120,{"kW "} ,0	},			
	{	{" A CURR DIGIT POINT "}	, 1080,1208,{"dig"} ,0	},			
	{	{" A UPS MAX CURRENT  "}	, 1079,1207,{"A  "} ,0	},				
	{	{" A INV CURR LIMIT   "}	, 1075,1203,{"   "} ,0	},		
	{	{" A SHORT CURR.REF   "}	, 1040,1168,{"A  "} ,0	},	
	{	{" A SHORT TIME       "}	, 1039,1167,{"alt"} ,0	},		
	{	{" A O/P SHUT CURR    "}	, 1077,1205,{"A  "} ,0	},				
	{	{" A O/P CURR SHUT DLY"}	, 1078,1206,{"usc"} ,0	},	
	{	{" C L1 OUT CURRENT   "}	, 1029,1030,{"A  "} ,0	},			
	{	{" C L2 OUT CURRENT   "}	, 1030,1031,{"A  "} ,0	},			
	{	{" C L3 OUT CURRENT   "}	, 1031,1032,{"A  "} ,0	},
	{	{" A L1 CURR OFFSET   "}	, 1081,1418,{"   "} ,0	},		// + / - 			
	{	{" A L2 CURR OFFSET   "}	, 1082,1419,{"   "} ,0	},		// + / - 			
	{	{" A L3 CURR OFFSET   "}	, 1083,1420,{"   "} ,0	},		// + / - 
	{	{" A 125% TIME        "}	, 1044,1172,{"sec"} ,0	},
	{	{" A 150% TIME        "}	, 1045,1173,{"sec"} ,0	},					
	{	{" A 180% TIME        "}	, 1103,1231,{"msc"} ,0	},		
	{	{" A 100% LOAD LEVEL  "}	, 1106,1234,{"   "} ,0	},				
	{	{" A 125% LOAD LEVEL  "}	, 1107,1235,{"   "} ,0	},				
	{	{" A 150% LOAD LEVEL  "}	, 1108,1236,{"   "} ,0	},			
	{	{" A PFC PID V LIMIT  "}	, 2043,2077,{"   "} ,0	},		
	{	{" A PFC PID I LIMIT  "}	, 2056,2184,{"   "} ,0	},
	{	{" A INV PID V LIMIT  "}	, 1074,1202,{"   "} ,0	}
											
};
//*****SYSTEM ADJUSTMENT (INV)(10)
//volatile unsigned  char *Ayar_SysAdj[7][5] 	__attribute__((far)) =
//{			
//			 Etiket			  	   	   W    R    Birim	 Yetki
//	{	{" A INV IGBT RESET   "}	, 1087,1215,{"min"} ,0	},			//0
//	{	{" A INV OVERTEMP RST "}	, 1088,1216,{"min"} ,0	},			//1
//	{	{" INV ALARM HOLD TIME"}	, 1091,1219,{"sec"} ,0	},			//2	
//	{	{" A INV O/P CB DELAY "}	, 1094,1222,{"msc"} ,0	},			//3	
//	{	{" PFC ALARM HOLD TIME"}	, 2084,2212,{"sec"} ,0	},			//4
//	{	{" A PFC IGBT RESET   "}	, 2037,2165,{"min"} ,0	},			//5
//	{	{" A PFC OVERTEMP RST "}	, 2039,2167,{"min"} ,0	}			//6
//};

volatile unsigned  char *AyarAltMenu[51]	  	 __attribute__((far)) =
{	
	{"��������������������"}, 				//0
	{" SET(@):!    "},		 				//1
	{" VALUE....:! ���"},	 				//2
	//Noktal� de�erleri g�stermek i�in	
	{" VALUE....:� ���"}, 					//3
	
	//Bit anlaml� i�lemler i�in
	{" SET(@): NOT USED"}, 					//4	
	{" SET(@): USED    "}, 					//5
	
	{" SET(@): IGBT    "}, 					//6	
	{" SET(@): IPM     "}, 					//7
	
	{" SET(@): XTAL    "}, 					//8	
	{" SET(@): SYNC    "}, 					//9
	
	{" SET(@): NORMAL  "}, 					//10	
	{" SET(@): ADVC    "}, 					//11
	
	{" SET(@): SHUT1   "}, 					//12	
	{" SET(@): SHUT3   "}, 					//13
		
	{" SET(@):ONLINE   "}, 					//14
	{" SET(@):ECONO    "}, 					//15
	{" SET(@):SYNC     "}, 					//16
	{" SET(@):PARALLEL "}, 					//17
	
	{" VALUE....: NOT USED"}, 					//18	
	{" VALUE....: USED    "}, 					//19
	
	{" VALUE....: IGBT    "}, 					//20	
	{" VALUE....: IPM     "}, 					//21
	
	{" VALUE....: XTAL    "}, 					//22	
	{" VALUE....: SYNC    "}, 					//23
	
	{" VALUE....: NORMAL  "}, 					//24	
	{" VALUE....: ADVC    "}, 					//25
	
	{" VALUE....: SHUT1   "}, 					//26	
	{" VALUE....: SHUT3   "}, 					//27
		
	{" VALUE....:ONLINE   "}, 					//28
	{" VALUE....:ECONO    "}, 					//29
	{" VALUE....:SYNC     "}, 					//30
	{" VALUE....:PARALLEL "}, 					//31

	//Sonradan yap�lan de�i�ikliklerle eklenenler
	{" GROUP VARIABLES    "}, 					//32
	
	{" VALUE....: OFF     "}, 					//33	
	{" VALUE....: ON      "}, 					//34
	
	{" SET(@): OFF     "}, 						//35	
	{" SET(@): ON      "}, 						//36
	
	{" VALUE....: 1       "}, 					//37	
	{" VALUE....: 3       "}, 					//38
	
	{" SET(@): 1       "}, 						//39	
	{" SET(@): 3       "}, 						//40
	
	{" VALUE....:� ���"}, 						//41
		
	{" SET(@): TH3     "}, 						//42
	{" SET(@): TH1     "}, 						//43
	
	{" VALUE....: TH3     "}, 					//44	
	{" VALUE....: TH1     "}, 					//45
	// - de�er 4 haneli g�sterilmesi i�in
	{" VALUE....:-@ ���"},  					//46
	{" VALUE....: @ ���"},  					//47
	
	{" VALUE....:����� ���"},					//48
	{" ENTER  -  EXIT "},  						//49
	{"-��������������������-"} 					//50
};																																								



