#include "p33FJ256MC710.h"

#include "TFTDef.h"
#include "TFTVar.h"
#include "TFTTablo.h"
#include "TFTCanInv.h"


void CanInvIslemFonk(unsigned int *CanInv_Buf)
{
	unsigned int InvID;
	static int CalismaModSayac = 0;
	
	Can.FromInv.InvGeldi = 0;
	InvID = *CanInv_Buf & 0x00ff;
	
	switch( InvID )
	{
		case 0x0010:
			if(*(CanInv_Buf + 3) == (*CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
			{ 
				if( Can.FromInv.CalismaModuSayac < 4 )
					Can.FromInv.CalismaModuSayac++;
				CalismaModSayac++;
				if( CalismaModSayac > 10 )
				{
					CalismaModSayac = 11;
					//Son sat�rda alarm ve uyar�larla birlikte paralel, online alarmlar�n sonuna eklenecek
					Alarm.Word.Lcd2.Bit.Paralel_Durum = 1;
				}
				Paralel.All = *(CanInv_Buf + 1) & 0x00ff;
				
				//CalismaDurumu.Bit.Bit0 = 1 ise Cihaz kapal� ona g�re i�lem yap 0 ise a��k normal �al��ma devam etsin.
				CalismaDurumu.All = 0;//*(CanInv_Buf + 2);		DIKKAT ACILACAK DENEMELER ICIN KAPATILDI.

				//ups normal �al��madan kapal�ya ilk ge�i�teki i�lemler
				if(( CalismaDurumu.Bit.Bit0 == 1 ) && ( EskiCalismaDurumu.Bit.Bit0 == 0 ))			//3.12.2012 de eklendi.
				{			//3.12.2012 de eklendi.
					Genel.UPSKapaliGeriSayac = 0;													//3.12.2012 de eklendi.
					UPS_Durdu_Fonk();																//3.12.2012 de eklendi.
					ChangePage(2); 																	//3.12.2012 de eklendi.
				}
				//ups kapal�dan normal �al��maya ilk ge�i�te alarm sat�r�ndaki ups kapal� silinsin
				if(( CalismaDurumu.Bit.Bit0 == 0 ) && ( EskiCalismaDurumu.Bit.Bit0 == 1 ))			//3.12.2012 de eklendi.
				{			//3.12.2012 de eklendi.
					Genel.UPSKapaliGeriSayac = 0;			//3.12.2012 de eklendi.
					ASendText(10,250+(272*1),GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,1);			//3.12.2012 de eklendi.
					ASendText(10,250+(272*0),GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,1);			//3.12.2012 de eklendi.
				}
				if( CalismaDurumu.Bit.Bit0 == 0 )
				{
					if( CalismaDurumu.Bit.Bit0 != EskiCalismaDurumu.Bit.Bit0 )
					{
						if( Menu.AnaSekme > 5 )
							ChangePage(1); 
						else
							ChangePage(0); 
						Menu.Yenile = 1;
					}
				}
				EskiCalismaDurumu.Bit.Bit0 = CalismaDurumu.Bit.Bit0;
				
				Can.ToInv.Zaman[0] = Can.ToInv.Date_2.Day;
				Can.ToInv.Zaman[1] = Can.ToInv.Date_2.Month;
				Can.ToInv.Zaman[2] = Can.ToInv.Date_2.Year;
				Can.ToInv.Zaman[3] = Can.ToInv.Date_2.Sec;
				Can.ToInv.Zaman[4] = Can.ToInv.Date_2.Min;
				Can.ToInv.Zaman[5] = Can.ToInv.Date_2.Hour;
				Can.ToInv.Zaman[6] = ((Can.ToInv.Zaman[0] & 0x1f)<<11)|((Can.ToInv.Zaman[1] & 0x0f)<<7)|(Can.ToInv.Zaman[2] & 0x7f);
				Can.ToInv.Zaman[7] = ((Can.ToInv.Zaman[3] & 0x3e)<<10)|((Can.ToInv.Zaman[4] & 0x3f)<<5)|(Can.ToInv.Zaman[5] & 0x1f);
				//Gelen ID nin ayn�s�yla s�k��t�r�lan zaman� g�nder.
				CanGonder(DefCanInv,InvID,'T',Can.ToInv.Zaman[7],Can.ToInv.Zaman[6]);
			}
			//30 x 100 ms = 3 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0011:
			if(*(CanInv_Buf + 3) == (*CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
			{ 
				Date4.Year = (*(CanInv_Buf+1)) & 0x7f;
				Date4.Month = (((((*(CanInv_Buf+1)) & 0x00ff) >> 7) & 0x01) | ((((*(CanInv_Buf+1)) & 0xff00) >> 7) & 0x0e));
				Date4.Day = (((*(CanInv_Buf+1)) & 0xff00) >> 11) & 0x1f;
				Date4.Hour = (*(CanInv_Buf+2)) & 0x1f;
				Date4.Min = (((*(CanInv_Buf+2) & 0x00ff) >> 5) & 0x07) | (((*(CanInv_Buf+2) & 0xff00) >> 5) & 0x38);
				Date4.Sec = 0;
				
				if(Date4.Hour < 24)
				{
					if(Date4.Min < 60)
					{
						if((Date4.Day > 0) && (Date4.Day < 32))
						{
							if((Date4.Month > 0) && (Date4.Month < 13))
								YazRTC(&Date4);
						}
					}
				}				
			}
			//30 x 100 ms = 3 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0012:
			if(*(CanInv_Buf + 3) == (*CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
			{ 
				Can.ToInv.BasitSifreGonder[0] = ( EeKayit.BasitPassword[0] - 48 ) * 1000 + ( EeKayit.BasitPassword[1] - 48 ) * 100 + ( EeKayit.BasitPassword[2] - 48 ) * 10 + ( EeKayit.BasitPassword[3] - 48 );
				Can.ToInv.BasitSifreGonder[1] = ( EeKayit.BasitPassword[4] - 48 ) * 1000 + ( EeKayit.BasitPassword[5] - 48 ) * 100 + ( EeKayit.BasitPassword[6] - 48 ) * 10 + ( EeKayit.BasitPassword[7] - 48 );	
				// 'S' �nemsiz 
				CanGonder(DefCanInv,InvID,'S',Can.ToInv.BasitSifreGonder[0],Can.ToInv.BasitSifreGonder[1]);			
			}
			//30 x 100 ms = 3 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		//Uart'tan g�nderilen Can den sorgular�n cevaplar�
		case 28:
			//Gelen Paket
			/*
				Gelen Paket[0] (*CanInv_Buf) 	 --> (( 'R' << 8 ) & 0xff00) | 28
				Gelen Paket[1] (*(CanInv_Buf+1)) --> Adres
				Gelen Paket[2] (*(CanInv_Buf+2)) --> Adres teki de�er
				Gelen Paket[3] (*(CanInv_Buf+3)) --> Gelen Paket[0] + Gelen Paket[1] + Gelen Paket[2]
			*/
			if( (Can.ToInv.Gonderildi.Bit.U1_R == 1) || ( Can.ToInv.Gonderildi.Bit.U2_R == 1 ) ) 
			{
				//G�rev CRC
				if((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'R')
				{
					//Paket CRC
					if( *(CanInv_Buf + 3) == ( *CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
					{
						//Adres CRC
						if( *(CanInv_Buf + 1) == Can.ToInv.TekrarIcinBuff[4] )
						{
							//Hata olmu�sa s�f�rla
							Can.FromInv.R_HataSayaci.Adres = 0;
							Can.FromInv.R_HataSayaci.Paket = 0;
							Can.FromInv.R_HataSayaci.Gorev = 0;
							
							if( Can.ToInv.Gonderildi.Bit.U1_R )
							{								
								Uart1.Tekrar = 0;
								Can.ToInv.Gonderildi.Bit.U1_R = 0; 
								U1_Gonder("�",( CanInv_Buf+2 ));
								break;
							}
							else if( Can.ToInv.Gonderildi.Bit.U2_R )
							{
								Uart2.Tekrar = 0;
								Can.ToInv.Gonderildi.Bit.U2_R = 0;
								U2_Gonder("�",( CanInv_Buf+2 ));
								break;
							}
						}
						else
						{
							if( ++Can.FromInv.R_HataSayaci.Adres > DefCanHataSinir )
							{
								Can.FromInv.R_HataSayaci.Adres = 0;
								if( Can.ToInv.Gonderildi.Bit.U1_R )
								{
									Can.ToInv.Gonderildi.Bit.U1_R = 0; 
									U1_Gonder("R-ERR",Uart1.Dumm);
									break;
								}
								if( Can.ToInv.Gonderildi.Bit.U2_R )
								{
									Can.ToInv.Gonderildi.Bit.U2_R = 0;
									U2_Gonder("R-ERR",Uart2.Dumm);
									break;
								}
							}
						}
					}					
					else
					{
						if( ++Can.FromInv.R_HataSayaci.Paket > DefCanHataSinir )
						{
							Can.FromInv.R_HataSayaci.Paket = 0;
							if( Can.ToInv.Gonderildi.Bit.U1_R )
							{
								Can.ToInv.Gonderildi.Bit.U1_R = 0; 
								U1_Gonder("R-ERR",Uart1.Dumm);
								break;
							}
							else if( Can.ToInv.Gonderildi.Bit.U2_R )
							{
								Can.ToInv.Gonderildi.Bit.U2_R = 0;
								U2_Gonder("R-ERR",Uart2.Dumm);
								break;
							}
						}
					}
				}					
				else
				{
					if( ++Can.FromInv.R_HataSayaci.Gorev > DefCanHataSinir )
					{
						Can.FromInv.R_HataSayaci.Gorev = 0;
						if( Can.ToInv.Gonderildi.Bit.U1_R )
						{
							Can.ToInv.Gonderildi.Bit.U1_R = 0; 
							U1_Gonder("R-ERR",Uart1.Dumm);
							break;
						}
						else if( Can.ToInv.Gonderildi.Bit.U2_R )
						{
							Can.ToInv.Gonderildi.Bit.U2_R = 0;
							U2_Gonder("R-ERR",Uart2.Dumm);
							break;
						}
					}
				}
			}
			else if( (Can.ToInv.Gonderildi.Bit.U1_L == 1) || ( Can.ToInv.Gonderildi.Bit.U2_L == 1 ) ) 
			{
				//G�rev CRC
				if((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'L')
				{
					//Paket CRC
					if( *(CanInv_Buf + 3) == ( *CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
					{
						//Adres CRC
						if( *(CanInv_Buf + 1) == Can.ToInv.TekrarIcinBuff[4] )
						{
							//Hata olmu�sa s�f�rla
							Can.FromInv.L_HataSayaci.Adres = 0;
							Can.FromInv.L_HataSayaci.Paket = 0;
							Can.FromInv.L_HataSayaci.Gorev = 0;
							
							if( Can.ToInv.Gonderildi.Bit.U1_L )
							{
								Uart1.Tekrar = 0;
								Can.ToInv.Gonderildi.Bit.U1_L = 0; 
								U1_Gonder("�",( CanInv_Buf+2 ));
								break;
							}
							else if( Can.ToInv.Gonderildi.Bit.U2_L )
							{
								Uart2.Tekrar = 0;
								Can.ToInv.Gonderildi.Bit.U2_L = 0;
								U2_Gonder("�",( CanInv_Buf+2 ));
								break;
							}
						}
						else
						{
							if( ++Can.FromInv.L_HataSayaci.Adres > DefCanHataSinir )
							{
								Can.FromInv.L_HataSayaci.Adres = 0;
								if( Can.ToInv.Gonderildi.Bit.U1_L )
								{
									Can.ToInv.Gonderildi.Bit.U1_L = 0; 
									U1_Gonder("R-ERR",Uart1.Dumm);
									break;
								}
								if( Can.ToInv.Gonderildi.Bit.U2_L )
								{
									Can.ToInv.Gonderildi.Bit.U2_L = 0;
									U2_Gonder("R-ERR",Uart2.Dumm);
									break;
								}
							}
						}
					}					
					else
					{
						if( ++Can.FromInv.L_HataSayaci.Paket > DefCanHataSinir )
						{
							Can.FromInv.L_HataSayaci.Paket = 0;
							if( Can.ToInv.Gonderildi.Bit.U1_L )
							{
								Can.ToInv.Gonderildi.Bit.U1_L = 0; 
								U1_Gonder("R-ERR",Uart1.Dumm);
								break;
							}
							else if( Can.ToInv.Gonderildi.Bit.U2_L )
							{
								Can.ToInv.Gonderildi.Bit.U2_L = 0;
								U2_Gonder("R-ERR",Uart2.Dumm);
								break;
							}
						}
					}
				}					
				else
				{
					if( ++Can.FromInv.L_HataSayaci.Gorev > DefCanHataSinir )
					{
						Can.FromInv.L_HataSayaci.Gorev = 0;
						if( Can.ToInv.Gonderildi.Bit.U1_L )
						{
							Can.ToInv.Gonderildi.Bit.U1_L = 0; 
							U1_Gonder("R-ERR",Uart1.Dumm);
							break;
						}
						else if( Can.ToInv.Gonderildi.Bit.U2_L )
						{
							Can.ToInv.Gonderildi.Bit.U2_L = 0;
							U2_Gonder("R-ERR",Uart2.Dumm);
							break;
						}
					}
				}
			}			
			else if( (Can.ToInv.Gonderildi.Bit.U1_W == 1) || ( Can.ToInv.Gonderildi.Bit.U2_W == 1 ) ) 
			{
				//G�rev CRC
				if(((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'W') || ((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'B'))
				{
					//Paket CRC
					if( *(CanInv_Buf + 3) == ( *CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
					{
						//Adres CRC
						if( *(CanInv_Buf + 1) == Can.ToInv.TekrarIcinBuff[4] )
						{
							//De�er CRC
							if( *(CanInv_Buf + 2) == Can.ToInv.TekrarIcinBuff[3] )
							{	
								if( Can.ToInv.Gonderildi.Bit.U1_W )
								{		
									Uart1.EmirGonderildi = 0;
									Uart1.Tekrar = 0;
									Can.ToInv.Gonderildi.Bit.U1_W = 0; 
									U1_Gonder("OK",Uart1.Dumm);
									break;
								}
								else if( Can.ToInv.Gonderildi.Bit.U2_W )
								{	
									Uart2.EmirGonderildi = 0;
									Uart2.Tekrar = 0;
									Can.ToInv.Gonderildi.Bit.U2_W = 0;
									U2_Gonder("OK",Uart2.Dumm);
									break;
								}
							}
							else
							{
								if( Can.ToInv.Gonderildi.Bit.U1_W )
								{
									Can.ToInv.Gonderildi.Bit.U1_W = 0; 
									U1_Gonder("LIMITED",Uart1.Dumm);
									break;
								}
								if( Can.ToInv.Gonderildi.Bit.U2_W )
								{
									Can.ToInv.Gonderildi.Bit.U2_W = 0;
									U2_Gonder("LIMITED",Uart2.Dumm);
									break;
								}
							}
						}				
						else
						{
							if( Can.ToInv.Gonderildi.Bit.U1_W )
							{
								Can.ToInv.Gonderildi.Bit.U1_W = 0; 
								U1_Gonder("R-ERR",Uart1.Dumm);
								break;
							}
							else if( Can.ToInv.Gonderildi.Bit.U2_W )
							{
								Can.ToInv.Gonderildi.Bit.U2_W = 0;
								U2_Gonder("R-ERR",Uart2.Dumm);
								break;
							}
						}	
					}					
					else
					{
						if( Can.ToInv.Gonderildi.Bit.U1_W )
						{
							Can.ToInv.Gonderildi.Bit.U1_W = 0; 
							U1_Gonder("R-ERR",Uart1.Dumm);
							break;
						}
						else if( Can.ToInv.Gonderildi.Bit.U2_W )
						{
							Can.ToInv.Gonderildi.Bit.U2_W = 0;
							U2_Gonder("R-ERR",Uart2.Dumm);
							break;
						}
					}	
				}					
				else
				{
					if( Can.ToInv.Gonderildi.Bit.U1_W )
					{
						Can.ToInv.Gonderildi.Bit.U1_W = 0; 
						U1_Gonder("R-ERR",Uart1.Dumm);
						break;
					}
					else if( Can.ToInv.Gonderildi.Bit.U2_W )
					{
						Can.ToInv.Gonderildi.Bit.U2_W = 0;
						U2_Gonder("R-ERR",Uart2.Dumm);
						break;
					}
				}
			}
			//Ram den 0.65 sn bir istenen adreslerin cevaplar�
			//Paket CRC
//			if( *(CanInv_Buf + 3) == ( *CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
//			{
//				//G�rev CRC
//				if((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'R')
//				{
//					if( *(CanInv_Buf+1) == 174 )
//					{
//						Can.FromInv.KonfigInv.All = *(CanInv_Buf+2);
//						//ZamanBagliIsler() fonk. kontrol edilir.
//					}
//					else if( *(CanInv_Buf+1) == 171 )
//					{
//						AyarBitAnlam.InvFactOpt.All = *(CanInv_Buf+2); 
//					}
//				}
//			}
			//D�nen adres s�rekli ram den sorgulanan adresse birbirine e�itle
			//E�er men�.koordinat istenilen yerdeyse ekran� yenile.	
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 29:
			//Rs232 -> Inv -> Can -> Lcd .Lcd burada uzak sistem olarak �al���yor.	
			//Do�rulama i�in geriye g�nderiliyor.
			CanInvGeriAdres = *(CanInv_Buf + 1);
			CanInvData = *(CanInv_Buf + 2);
			CanInvRamAdres = (*(CanInv_Buf + 1) << 1) + 2560;														
			if(*(CanInv_Buf + 3) == (*CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
			{
				//Login se yazma i�lemine izin ver.
				if( Can.FromInv.LogInDurum == 1 )
				{
					if((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'W')
					{
					//	*CanInvRamAdres = CanInvData;
						//Saat ayar� eeproma yaz�lmaz 
						if((*(CanInv_Buf + 1) == 343) || (*(CanInv_Buf + 1) == 344) || (*(CanInv_Buf + 1) == 345))				
						{
							if(*(CanInv_Buf + 1) == 343)
							{
								Date.Hour = CanInvData / 100;
								Date.Min =  CanInvData - Date.Hour*100;
							}
							if(*(CanInv_Buf + 1) == 344)
							{
								Date.Day =  CanInvData / 100;
								Date.Month =  CanInvData - Date.Day*100;
							}
							if(*(CanInv_Buf + 1) == 345)
								Date.Year =  CanInvData - 2000;
							if(Date.Hour < 24)
							{
								if(Date.Min < 60)
								{
									if(Date.Day > 0 && Date.Day < 32)
									{
										if((Date.Month > 0) && (Date.Month < 13))
											YazRTC(&Date);
									}
								}
							}
						}
						else
						{
							//Label lar haricindeki eeprom de�erleri min - max limitlerden ge�er.
							if((*(CanInv_Buf + 1) > 370) && (*(CanInv_Buf + 1) < 432))									
							{
								if( CanInvData > MinMax[*(CanInv_Buf + 1)-371][MaxAddrKontrol] )
									CanInvData = MinMax[*(CanInv_Buf + 1)-371][MaxAddrKontrol];
									
								if( ( CanInvData > MinMax[*(CanInv_Buf + 1)-371][MinAddrKontrol] ) && ( CanInvData < MinMax[*(CanInv_Buf + 1)-371][AraAddrKontrol] ) )
									CanInvData = MinMax[*(CanInv_Buf + 1)-371][MinAddrKontrol];
									
								if( CanInvData < MinMax[*(CanInv_Buf + 1)-371][MinAddrKontrol] )
									CanInvData = MinMax[*(CanInv_Buf + 1)-371][MinAddrKontrol];
							}
							if((CanInvRamAdres > (DefEepromAltSinir+2)) && (CanInvRamAdres < DefEepromUstSinir))
								EeWordYaz(CanInvRamAdres, CanInvData);
								
							*CanInvRamAdres = CanInvData;
							
							//Fan Bakim
							if( *(CanInv_Buf + 1) == 378 )
							{
								//Datalar� ram den al�r ��nk� bir �nceki sat�rda ram e kay�t i�lemi ger�ekle�ir.
								EeKayit.Bakim[1].KalanSure = EeKayit.Bakim[1].AyarlananSure;
								EeKayit.Bakim[1].GecenSure = 0;
								//Alarm Varsa sil.
								Alarm.Word.Lcd1.Bit.FanBakimZamani = 0;
								EeKayit.Bakim[1].ServisSay++;
								
								if( EeKayit.Bakim[1].AyarlananSure == 0 )
									EeKayit.Bakim[1].Iptal = 1;
								else
									EeKayit.Bakim[1].Iptal = 0;
								//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
								EeWordYaz( &EeKayit.Bakim[1].Iptal , EeKayit.Bakim[1].Iptal );
								EeWordYaz( &EeKayit.Bakim[1].ServisSay , EeKayit.Bakim[1].ServisSay );
								EeWordYaz( &EeKayit.Bakim[1].GecenSure , EeKayit.Bakim[1].GecenSure );
								EeWordYaz( &EeKayit.Bakim[1].KalanSure , EeKayit.Bakim[1].KalanSure );
							}
							//Ak� Bakim
							if( *(CanInv_Buf + 1) == 383 )
							{
								EeKayit.Bakim[2].KalanSure = EeKayit.Bakim[2].AyarlananSure;
								EeKayit.Bakim[2].GecenSure = 0;
								//Alarm Varsa sil.
								Alarm.Word.Lcd1.Bit.AkuBakimZamani = 0;
								EeKayit.Bakim[2].ServisSay++;
								
								if( EeKayit.Bakim[2].AyarlananSure == 0 )
									EeKayit.Bakim[2].Iptal = 1;
								else
									EeKayit.Bakim[2].Iptal = 0;
								//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
								EeWordYaz( &EeKayit.Bakim[2].Iptal , EeKayit.Bakim[2].Iptal );
								EeWordYaz( &EeKayit.Bakim[2].ServisSay , EeKayit.Bakim[2].ServisSay );
								EeWordYaz( &EeKayit.Bakim[2].GecenSure , EeKayit.Bakim[2].GecenSure );
								EeWordYaz( &EeKayit.Bakim[2].KalanSure , EeKayit.Bakim[2].KalanSure );
							}
							//Genel Bakim
							if( *(CanInv_Buf + 1) == 388 )
							{
								EeKayit.Bakim[3].KalanSure = EeKayit.Bakim[3].AyarlananSure;
								EeKayit.Bakim[3].GecenSure = 0;
								//Alarm Varsa sil.
								Alarm.Word.Lcd1.Bit.GenelBakimZamani = 0;
								EeKayit.Bakim[3].ServisSay++;
								
								if( EeKayit.Bakim[3].AyarlananSure == 0 )
									EeKayit.Bakim[3].Iptal = 1;
								else
									EeKayit.Bakim[3].Iptal = 0;
								//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
								EeWordYaz( &EeKayit.Bakim[3].Iptal , EeKayit.Bakim[3].Iptal );
								EeWordYaz( &EeKayit.Bakim[3].ServisSay , EeKayit.Bakim[3].ServisSay );
								EeWordYaz( &EeKayit.Bakim[3].GecenSure , EeKayit.Bakim[3].GecenSure );
								EeWordYaz( &EeKayit.Bakim[3].KalanSure , EeKayit.Bakim[3].KalanSure );
							}
						}
						CanGonder(DefCanInv,29,'W',CanInvData,CanInvGeriAdres);	
						Menu.Yenile = 1;	
					}
				}	
				if((( ( *CanInv_Buf ) >> 8) & 0x00ff) == 'R')
				{
					CanInvData = *CanInvRamAdres;												
					CanGonder(DefCanInv,29,'R',CanInvData,CanInvGeriAdres);			
				}
			}
			//30 x 100 ms = 3 sn lik saya�
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		//Adjust men� i�in Can trafi�i
		case 30:
			/*
				Gelen Paket[0] --> Paket no
				Gelen Paket[1] --> Set sat�r�ndaki de�er
				Gelen Paket[2] --> Sonu�
				Gelen Paket[3] --> [0] + [1] + [2]
			*/
			//Paket CRC
			if( *(CanInv_Buf + 3) == ( *CanInv_Buf + *(CanInv_Buf + 1) + *(CanInv_Buf + 2)))
			{		
				//Yeni bir de�i�kene bak�l�nca eski sorgulanan adres can de kal�yor o y�zden ilk gelen data de�il ikinci data i�lensin.
				if(++Can.FromInv.DogruDataGosterSayac > 1)
				{
					Can.FromInv.DogruDataGosterSayac = 3;
					//Gelen Set de�eri eskisinden farkl�ysa ekranda yenile
					if( Can.ToInv.AyarGonderilenData != *(CanInv_Buf + 1 ) )
						Can.FromInv.GonderilendenFarkliDataGeldi = 1;
					
					//Inv factory option da bit i�lemleri i�in
					if(( Ayar_InvFactOpt[Menu.AyarEtiket][2] == 1171 ))
					{
						AyarBitAnlam.InvFactOpt.All = *(CanInv_Buf + 1 );
						Can.FromInv.BitIslemDatasiGeldi = 1;
					}
					//Ayar Sekmesindeyse ayar i�lemi s�ras�nda Set de�eri de�i�mesin
					if( Menu.Sekme.All == DefAyarGrupAltMenu ) 
					{
						if((Menu.AyarGrupAltSekme != 2) || ( Can.FromInv.GonderilendenFarkliDataGeldi == 1 ))
						{
							Menu.AyarAyar = *(CanInv_Buf + 1 );
							Can.FromInv.GonderilendenFarkliDataGeldi = 0;
							Can.ToInv.AyarGonderilenData = *(CanInv_Buf + 1 );
						}
					}
					else
					{
						if(( Menu.AyarAltSekme != 1 ) || ( Can.FromInv.GonderilendenFarkliDataGeldi == 1 )) 
						{
							Menu.AyarAyar = *(CanInv_Buf + 1 );
							Can.FromInv.GonderilendenFarkliDataGeldi = 0;
							Can.ToInv.AyarGonderilenData = *(CanInv_Buf + 1 );
						}	
					}
					Menu.AyarSonuc = *(CanInv_Buf + 2 );
					if( Menu.EnterExit == 0 )
						Menu.Yenile = 1;
					//Gelmeme durumunda ekran� s�f�rlar.
					Can.FromInv.AyarDatasiGelmediSayac = 4;
				}
			}
		break;
//-----------------------------------------------------------------------------------------------------------------
//Periyodik Inv den gelen datalar
		case 0x0050:
			Can.FromInv.VinvRMS.L1 = *(CanInv_Buf + 1);
			Can.FromInv.VinvRMS.L2 = *(CanInv_Buf + 2);
			Can.FromInv.VinvRMS.L3 = *(CanInv_Buf + 3);		
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0051:		
			Can.FromInv.VoutRMS.L1 = *(CanInv_Buf + 1);
			Can.FromInv.VoutRMS.L2 = *(CanInv_Buf + 2);
			Can.FromInv.VoutRMS.L3 = *(CanInv_Buf + 3);
			
			Megatech.G3.OPVoltageR = Can.FromInv.VoutRMS.L1 * 10;
			Megatech.G3.OPVoltageS = Can.FromInv.VoutRMS.L2 * 10;
			Megatech.G3.OPVoltageT = Can.FromInv.VoutRMS.L3 * 10;
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0052:
			Can.FromInv.BypStatus.All = (*CanInv_Buf >> 8) & 0x00ff;
			Can.FromInv.VbypRMS.L1 = *(CanInv_Buf + 1);
			Can.FromInv.VbypRMS.L2 = *(CanInv_Buf + 2);
			Can.FromInv.VbypRMS.L3 = *(CanInv_Buf + 3);
			
			Megatech.G3.BypVoltageR = Can.FromInv.VbypRMS.L1 * 10;
			Megatech.G3.BypVoltageS = Can.FromInv.VbypRMS.L2 * 10;
			Megatech.G3.BypVoltageT = Can.FromInv.VbypRMS.L3 * 10;
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0053:
			Can.FromInv.Load.L1 = *(CanInv_Buf + 1);
			Can.FromInv.Load.L2 = *(CanInv_Buf + 2);
			Can.FromInv.Load.L3 = *(CanInv_Buf + 3);
			
			Megatech.G3.LoadPercentageR = Can.FromInv.Load.L1;
			Megatech.G3.LoadPercentageS = Can.FromInv.Load.L2;
			Megatech.G3.LoadPercentageT = Can.FromInv.Load.L3;
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0054:
			Can.FromInv.CoutRMS.L1 = *(CanInv_Buf + 1);
			Can.FromInv.CoutRMS.L2 = *(CanInv_Buf + 2);
			Can.FromInv.CoutRMS.L3 = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0055:
			Can.FromInv.InvDCBus.Pos = *(CanInv_Buf + 1);
			Can.FromInv.InvDCBus.Neg = *(CanInv_Buf + 2);
			Can.FromInv.Digit = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0056:
			Can.FromInv.InvFreq = (long)(3129000 / *(CanInv_Buf + 1));
			Can.FromInv.OutFreq = (long)(3129000 / *(CanInv_Buf + 2));
			Can.FromInv.BypFreq = (long)(3129000 / *(CanInv_Buf + 3));	
							
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0057:
			Can.FromInv.CrestFactor.L1 = *(CanInv_Buf + 1);
			Can.FromInv.CrestFactor.L2 = *(CanInv_Buf + 2);
			Can.FromInv.CrestFactor.L3 = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0058:							
			Can.FromInv.PowerWatt.L1 = *(CanInv_Buf + 1);
			Can.FromInv.PowerWatt.L2 = *(CanInv_Buf + 2);
			Can.FromInv.PowerWatt.L3 = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x0059:													
			Can.FromInv.PowerVa.L1 = *(CanInv_Buf + 1);
			Can.FromInv.PowerVa.L2 = *(CanInv_Buf + 2);
			Can.FromInv.PowerVa.L3 = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x005A:
			Can.FromInv.VinvRMS.L1L3 = *(CanInv_Buf + 1);
			Can.FromInv.VinvRMS.L2L1 = *(CanInv_Buf + 2);
			Can.FromInv.VinvRMS.L3L2 = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x005B:
			Can.FromInv.VbypRMS.L1L3 = *(CanInv_Buf + 1);
			Can.FromInv.VbypRMS.L2L1 = *(CanInv_Buf + 2);
			Can.FromInv.VbypRMS.L3L2 = *(CanInv_Buf + 3);
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x005C:
			Can.FromInv.ChkBuffer[0] = *(CanInv_Buf + 1);				//Alarm.Word.Inv1.All
			Can.FromInv.ChkBuffer[1] = *(CanInv_Buf + 2);				//Alarm.Word.Inv2.All
			Can.FromInv.ChkBuffer[2] = *(CanInv_Buf + 3);				//Alarm.Word.Inv3.All		
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;
		case 0x005D:
			Can.FromInv.ChkBuffer[3] = *(CanInv_Buf + 1);				//AlarmKod.Kod.Inv
			Can.FromInv.ChkBuffer[4] = *(CanInv_Buf + 2);				//Can.FromInv.InvVersiyon
			Can.FromInv.ChkBuffer[5] = *(CanInv_Buf + 3);				//0x001D ve 0x001E nin check sum �
			Can.FromInv.ChkBuffer[6] = 0x005C + 0x005D + Can.FromInv.ChkBuffer[0] + Can.FromInv.ChkBuffer[1] + Can.FromInv.ChkBuffer[2] + Can.FromInv.ChkBuffer[3] + Can.FromInv.ChkBuffer[4];
			if( Can.FromInv.ChkBuffer[5] == Can.FromInv.ChkBuffer[6] )	//�ki paketin check sum � do�ruysa.
			{
				Alarm.Word.Inv1.All = Can.FromInv.ChkBuffer[0];
				Alarm.Word.Inv2.All = Can.FromInv.ChkBuffer[1];
				//Inv den gelen yedek uyar�
				Alarm.Word.Inv3.All = Can.FromInv.ChkBuffer[2];
				//Kayit s�n�r� 1023 ,ba�ka s��m�yor
				AlarmKod.Kod.Inv = Can.FromInv.ChkBuffer[3] & 1023;
				Can.FromInv.InvVersiyon = Can.FromInv.ChkBuffer[4];
				
				
				if( EeKayit.Konfig.Bit.BypassVarYok == 0 )				//Bypass men�s� (bypass yoksa) yoksa	26.09.14 Serkan 60Hz converter
				{
					Alarm.Word.Inv2.Bit.BypassFrekans = 0;
					Alarm.Word.Inv2.Bit.BypassKesik = 0;
					Alarm.Word.Inv2.Bit.BypassVolt = 0;
					Alarm.Word.Inv2.Bit.CikisBypassta = 0;
					Alarm.Word.Inv2.Bit.SenkronYok = 0;
				}
 				
				//Emirler ve Tercihler men�s�ndeki i�lemler serbestlik kontrol�nde login daha �ncelikli
				Can.FromInv.UserLogInDurum = Alarm.Word.Inv3.Bit.UserLogin;
				
				if( Alarm.Word.Inv2.Bit.BypassKesik )
				{
					Alarm.Word.Inv2.Bit.BypassVolt = 0;
					Alarm.Word.Inv2.Bit.BypassFrekans = 0;
				}
				else if( Alarm.Word.Inv2.Bit.BypassFrekans )
					Alarm.Word.Inv2.Bit.BypassVolt = 0;
					
					
				//A�a��dakinin ayn�s�ndan Alarm g�sterme fonksiyonunda da var.
				//Fault kod mu Status Kod mu o ayr��t�r�l�r.Yanl��l�klara �nlem al�r.	
				if( Alarm.Word.Inv1.Bit.InvFaultKod )
				{						
					Alarm.Word.Lcd1.Bit.InvDurumKod = 0;
					//Can �zerinden yanl�� bir �ekilde kod = 0 ve fault var g�r�nmesin diye
					if( AlarmKod.Kod.Inv == 0 )
						Alarm.Word.Inv1.Bit.InvFaultKod = 0;
				}
				else
				{
					if( AlarmKod.Kod.Inv == 0 )
						Alarm.Word.Lcd1.Bit.InvDurumKod = 0;
					else
						Alarm.Word.Lcd1.Bit.InvDurumKod = 1;							
				}
				
				if( Alarm.Word.Inv2.Bit.ServisLogin )
				{
					//Yazma vb. i�lemler serbest
					Can.FromInv.LogInDurum = 1;
					Genel.LoginWaitButon = 0;
					//Servis login > User Login
					Genel.UserPassDogru15dklikIzin = 1;
					//15 dk l�k geri saya� kuruldu.
					Genel.UserPassGeriSayac = 450;
					
					//Merkezi kod aktif uyar�s� Inv3 �n i�erisinde var.
					
					if( Alarm.Word.Inv3.Bit.ServisPassw == 0 )
						Alarm.Word.Lcd1.Bit.HataResetle = Alarm.Word.Inv1.Bit.InvFaultKod | Alarm.Word.Pfc1.Bit.PfcFaultKod;
					else
						Alarm.Word.Lcd1.Bit.HataResetle = 0;						
				}
				else
				{
					Can.FromInv.LogInDurum = 0;
				}
				MaskedAlarm.Word.Inv2.All = Alarm.Word.Inv2.All & EeKayit.InvLogMaske;
				MaskedAlarm.Word.Lcd1.All = Alarm.Word.Lcd1.All & EeKayit.LcdLogMaske;
				
				
				//Alarm.Word.Lcd1.Bit.SifreGiriniz = Alarm.Word.Inv3.Bit.ServisPassw;
				//Alarm.Word.Inv3.Bit.Nu1 --> Test modu ile alakal�
				
			}				
			if( Genel.IlkAcilisAlrSayac < 5 )
				Genel.IlkAcilisAlrSayac++;		
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;				
		case 0x005E:
			Can.FromInv.KonfigInv.All = *(CanInv_Buf + 1);	
			AyarBitAnlam.InvFactOpt.All = *(CanInv_Buf + 2);
			Can.FromInv.AkuSayisi = *(CanInv_Buf + 3);		
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30; 
		break;		
		case 0x005F:
			if( Can.FromInv.CalismaModuSayac < 4 )
				Can.FromInv.CalismaModuSayac++;
			CalismaModSayac++;
			if( CalismaModSayac > 10 )
			{
				CalismaModSayac = 11;
				//Son sat�rda alarm ve uyar�larla birlikte paralel, online alarmlar�n sonuna eklenecek
				Alarm.Word.Lcd2.Bit.Paralel_Durum = 1;
			}
			Can.FromInv.CalismaModu = *(CanInv_Buf + 1) & 0x00ff;
			Can.FromInv.SifreSistemi = (*(CanInv_Buf + 1) & 0xff00 ) >> 8;	
						
			Can.FromInv.KGKNo = *(CanInv_Buf + 2) & 0x00ff;
			
			Can.FromInv.OutputPhaseCount = (*(CanInv_Buf + 2) >> 8) & 0x00ff;				//14.07.14
			if( Can.FromInv.OutputPhaseCount != 1 )											//14.07.14
				Can.FromInv.OutputPhaseCount = 3;
			Uart2.NumOfPhaseOut = Can.FromInv.OutputPhaseCount;		//14.07.14
			Uart1.NumOfPhaseOut = Uart2.NumOfPhaseOut;

			Can.FromInv.N_1MinUps = *(CanInv_Buf + 3);		
			//30 x 100 ms = 8 sn
			Can.FromInv.DataGelmediSayac = 30;
		break;
		default:
		break;
	}
}
void YedekCanGonder(unsigned int YedekTo,unsigned int YedekCan_PaketNo,unsigned int YedekCan_OkuYaz,unsigned int YedekCan_Deger,unsigned int YedekCan_EepromAdres)
{	
	if( YedekTo == DefCanInv )
	{
		Can.ToInv.TekrarIcinBuff[0] = YedekTo;
		Can.ToInv.TekrarIcinBuff[1] = YedekCan_PaketNo;
		Can.ToInv.TekrarIcinBuff[2] = YedekCan_OkuYaz;
		Can.ToInv.TekrarIcinBuff[3] = YedekCan_Deger;
		Can.ToInv.TekrarIcinBuff[4] = YedekCan_EepromAdres;
	}	
	else if( YedekTo == DefCanPfc )
	{
		Can.ToPfc.TekrarIcinBuff[0] = YedekTo;
		Can.ToPfc.TekrarIcinBuff[1] = YedekCan_PaketNo;
		Can.ToPfc.TekrarIcinBuff[2] = YedekCan_OkuYaz;
		Can.ToPfc.TekrarIcinBuff[3] = YedekCan_Deger;
		Can.ToPfc.TekrarIcinBuff[4] = YedekCan_EepromAdres;
	}	
}


void CanGonder(unsigned int To,unsigned int Can_PaketNo,unsigned int Can_OkuYaz,unsigned int Can_Deger,unsigned int Can_EepromAdres)
{
	unsigned int SID,SRR,IDE,RTR,DLC;
	
	SRR = 0; IDE = 0; RTR = 0; DLC = 8;
	SID = To;

	Can.GonderPaket[0] = ((Can_OkuYaz << 8) & 0xff00) | Can_PaketNo;
	Can.GonderPaket[1] = Can_EepromAdres;																		//2816 taban�na g�re g�nderilir.
	Can.GonderPaket[2] = Can_Deger;																				//KALIBRE DEGERI GELECEK GERI ALI�TA
	Can.GonderPaket[3] = Can.GonderPaket[0] + Can.GonderPaket[1] + Can.GonderPaket[2];		
	
	ecanmsgbuf[0][0] = (SID << 2) | (SRR << 1) | IDE;
	ecanmsgbuf[0][1] = 0;																	
	ecanmsgbuf[0][2] = (RTR << 9) | DLC;
	ecanmsgbuf[0][3] = Can.GonderPaket[0];
	ecanmsgbuf[0][4] = Can.GonderPaket[1];
	ecanmsgbuf[0][5] = Can.GonderPaket[2];
	ecanmsgbuf[0][6] = Can.GonderPaket[3];
	
	C1TR01CONbits.TXREQ0 = 1;																		
}