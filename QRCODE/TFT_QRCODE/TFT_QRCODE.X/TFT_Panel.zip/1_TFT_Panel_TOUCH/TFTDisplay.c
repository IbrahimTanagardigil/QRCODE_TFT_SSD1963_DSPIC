#include "p33FJ256MC710.h"

#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTVar.h"
#include "BigTable.h"

//Ana fonksiyonlar 
//---------------------------------------------------------------------------------------------------------------------
void InitTFT(void)
{
	TFT_DISP_ON = 1;
	Wait(50000);
			asm("CLRWDT");
	Wait(50000);
			asm("CLRWDT");
	Wait(50000);
	FirstState();
			asm("CLRWDT");
	SSD1963Init();
	Wait(50000);
			asm("CLRWDT");
	SSD1963Init();
	Wait(50000);
			asm("CLRWDT");
	SSD1963Init();
}
//4.3 WQVGA
void SSD1963Init (void) 													
{
	TFT_RES = 0;
	Nop();
	Nop();
	Nop();
	TFT_RES = 1;
	Nop();
	Nop();
	Nop();


	Write_Command(0x01);													//Software Reset
	Write_Command(0x01);
	Write_Command(0x01);	
	Komut_TekParametre(0xe0,0x01);											//START PLL
	Komut_TekParametre(0xe0,0x03);											//LOCK PLL
	
	Write_Command(45);
	Write_Data(0);
	Write_Data(0x54);
	
	
	
	
	Write_Command(0xb0);													//SET LCD MODE SET TFT 18Bits MODE
	
//	if( EeKayit.YeniTFT == 0 )			//23.12.2014 - 29.12.2014	eklendi. R3414
		Write_Data(0x08);														//SET TFT MODE & hsync+Vsync+DEN MODE Write_Data(0x80); //SET TFT MODE & hsync+Vsync+DEN MODE
//	else
	//	Write_Data(0x28);														//Yeni TFT ucuz olan �zdisan �n ,

	Write_Data(0x80);														//SET TFT MODE & hsync+Vsync+DEN MODE Write_Data(0x80); //SET TFT MODE & hsync+Vsync+DEN MODE
	Write_Data(0x01);														//SET horizontal size=480-1 HightByte
	Write_Data(0xdf);														//SET horizontal size=480-1 LowByte
	Write_Data(0x01);														//SET vertical size=272-1 HightByte
	Write_Data(0x0f);														//SET vertical size=272-1 LowByte
	Write_Data(0x00);														//SET even/odd line RGB seq.=RGB
	Komut_TekParametre(0xf0,0x00);											//SET pixel data I/F format=8bit
	Komut_TekParametre(0x3a,0x60);											//SET R G B format = 6 6 6
	Write_Command(0xe6);													//SET PCLK freq=9MHz ; pixel clock frequency
	Write_Data(0x01);
	Write_Data(0x45);
	Write_Data(0x47);
	Write_Command(0xb4);													//SET HBP
	Write_Data(0x02);														//SET HSYNC Total = 525
	Write_Data(0x0d);
	Write_Data(0x00);														//SET HBP = 43
	Write_Data(0x2b);
	Write_Data(0x28);														//SET VBP 41 = 40 + 1
	Write_Data(0x00);														//SET Hsync pulse start position
	Write_Data(0x00);
	Write_Data(0x00);														//SET Hsync pulse subpixel start position
	Write_Command(0xb6);													//SET VBP
	Write_Data(0x01);														//SET Vsync total 286 = 285 + 1
	Write_Data(0x1d);
	Write_Data(0x00);														//SET VBP = 12
	Write_Data(0x0c);
	Write_Data(0x09);														//SET Vsync pulse 10 = 9 + 1
	Write_Data(0x00); 														//SET Vsync pulse start position
	Write_Data(0x00);
	Write_Command(0x2a); 													//SET column address
	Write_Data(0x00); 														//SET start column address=0
	Write_Data(0x00);
	Write_Data(0x01); 														//SET end column address=480
	Write_Data(0xdf);
	Write_Command(0x2b); 													//SET page address
	Write_Data(0x00); 														//SET start page address=0
	Write_Data(0x00);
	Write_Data(0x01); 														//SET end page address=272
	Write_Data(0x0f);
	Write_Command(0x29); 													//SET display on
	Write_Command(0x2c);
	
}
void Write_Command (unsigned char command)
{
	TFT_RD = 1;															
	Nop();	
	TFT_RS = 0; 														
	Nop();	
	TFT_WR= 0; 														
	Nop();	
	TFT_CS = 0; 													
	Nop();	
	BusSend(command); 												
	Nop();	
	TFT_CS = 1; 														
	Nop();	
	TFT_WR= 1; 														
}
void Write_Data (unsigned int data1)
{
	TFT_RD = 1;
	Nop();	
	TFT_RS = 1;
	Nop();	
	TFT_WR = 0;
	Nop();	
	TFT_CS = 0;
	Nop();	
	BusSend(data1); 														// Data Bus OUT
	Nop();	
	TFT_CS = 1;
	Nop();
	TFT_WR= 1;
}
//Komutun arkas�ndan tek parametre varsa kullan�l�r.
void Komut_TekParametre(unsigned char command,unsigned char data1)
{
	Write_Command(command);
	Write_Data(data1);
}
//Bir pixeli g�ndermek i�in kullan�l�r.
void SendPixel(unsigned long color)
{
	Write_Data(((color)>>16)&0x00ff);										// color is red
	Write_Data(((color)>>8)&0x00ff);										// color is green
	Write_Data(color&0x00ff);												// color is blue
}
//Bir pixeli g�ndermek i�in kullan�l�r.
void FotoSendPixel(unsigned long color)
{
	Write_Data(((color)>>12)&0x003f);										// color is red
	Write_Data(((color)>>6)&0x003f);										// color is green
	Write_Data(color&0x003f);												// color is blue
}
//Datalar� paralel olarak g�nderir.
void BusSend(unsigned int DATA)
{
	unsigned int PARALEL_DATA,portdd;

	PARALEL_DATA = (DATA & 0x00FF)<<1;										//PORTLARIN KAYMASINDAN DOLAYI 
	portdd = (LATD & 0xFE01);												//�K� SATIR KOD KONULUYOR.
	LATD = portdd | PARALEL_DATA;
	
	
	//YAVA�LATIYOR BASKA B�R ��Z�M BULUNMALI
//	TFT_D0 = DATA & 1;
//	TFT_D1 = (DATA>>1) & 1;
//	TFT_D2 = (DATA>>2) & 1;
//	TFT_D3 = (DATA>>3) & 1;
//	TFT_D4 = (DATA>>4) & 1;
//	TFT_D5 = (DATA>>5) & 1;
//	TFT_D6 = (DATA>>6) & 1;
//	TFT_D7 = (DATA>>7) & 1;

	//ALTERNAT�F
}
//�lk durumu port durumlar�
void FirstState(void)
{
	TFT_CS = 1;
	TFT_RD = 1;
	TFT_WR = 1;
	TFT_RS = 1;	
}
//Net gecikme olsun diye  Timer2 int ile gecikme yap�l�r.(time x 20 us = X us GEC�KME)
void Wait(unsigned int time)										
{	
    Genel.EepromKilitSayac = 50;
	TFT.TftTimer = time;												
	while(TFT.TftTimer > 0)
    {
        if( Genel.EepromKilitSayac == 0 )
            break;
    };
}
//Pixelleri arka arkaya g�ndermek i�in a��lan pencere
void WindowSet(unsigned int s_x,unsigned int e_x,unsigned int s_y,unsigned int e_y)
{
	Write_Command(0x2a);									
	Write_Data(((s_x)>>8)&0x00ff);										
	Write_Data(s_x&0x00ff);
	Write_Data(((e_x)>>8)&0x00ff);											
	Write_Data(e_x&0x00ff);
	Write_Command(0x2b);												
	Write_Data(((s_y)>>8)&0x00ff);										
	Write_Data(s_y&0x00ff);
	Write_Data(((e_y)>>8)&0x00ff);										
	Write_Data(e_y&0x00ff);
}
//Built-in controller '�n Ram i 1,2Mb bu y�zden 480x272 lik TFT nin sayfas�ndan 3 adet i�erisinde tutabilir. Onlar�n aras�nda ge�i� yapmaya yarar.
void ChangePage(unsigned int Page)
{
	unsigned int PageH;
	unsigned int PageL;
	
//	Sayfa = Page;
	PageH = ((Page * 272) & 0xff00) >> 8;
	PageL = ((Page * 272) & 0x00ff);
	Write_Command(0x37); 													
	Write_Data(PageH); 													
	Write_Data(PageL); 
}
//Ek fonksiyonlar 
//---------------------------------------------------------------------------------------------------------------------
void FullScreen(unsigned long dat)
{
	unsigned int x,y;
	WindowSet(0x0000,0x01df,0x0000,0x010f);									//4.3"  
	Write_Command(0x2c);
	for (y=0;y<272;y++)
	{
		for (x= 0;x<480;x++)
		{
			SendPixel(dat);
		}
	}
}

/*	Optimizasyon
void ChangeSatir(unsigned int Satir)
{
	unsigned int SatirH;
	unsigned int SatirL;
	SatirH = (Satir & 0xff00) >> 8;
	SatirL = (Satir & 0x00ff);
	Write_Command(0x37); 													
	Write_Data(SatirH); 													
	Write_Data(SatirL); 
}
*/
/*	Optimizasyon
void goToAddress(unsigned int s_x1,unsigned int s_y1)
{
	Write_Command(0x2a);												
	Write_Data(((s_x1)>>8)&0x00ff);										
	Write_Data(s_x1&0x00ff);
	Write_Command(0x2b);												
	Write_Data(((s_y1)>>8)&0x00ff);										
	Write_Data(s_y1&0x00ff);
}
*/


/*	Optimizasyon

//�rn.  DigitalText(100,10,"NABER 12",0xffffff,NotClear);
//8x5 lik karakterler sadece dijital yaz�l�r.font size 2 dir ve dijital silinebilir.
void DigitalText(unsigned int D_Xbas,unsigned int D_Ybas,const char* D_str,unsigned long D_YaziRenk,unsigned int D_ClEar)
{
	unsigned int D_col,D_BitCounter,D_size,D_say;
	unsigned char D_YAZ;
	D_say = 0;

    while( *D_str ) 
    {	
		for( D_BitCounter = 0;D_BitCounter<8;D_BitCounter++ )
		{
			for( D_col = 0;D_col<5;D_col++ )
			{
				if( *D_str == '�' )
					D_YAZ = 95;
				else if(*D_str == '�')
					D_YAZ = 96;
				else if(*D_str == '�')
					D_YAZ = 98;
				else if(*D_str == '�')
					D_YAZ = 99;
				else if(*D_str == '�')
					D_YAZ = 100;
				else			
					//Liste ile ascii tablosu tam �ak��s�n diye.				
					D_YAZ = *D_str-32;
				//~ bo�luk anlam�na gelir.
				if( *D_str != '~' )
				{
					if( D_ClEar == NotClear )
					{
						if( BitCntrl(FONT[D_YAZ][D_col],D_BitCounter) )
							PixelPoint(D_Xbas+(D_col*2)+(D_say*6*2),D_Ybas+(D_BitCounter*2),D_YaziRenk,0);
					}
					else
					{
						TextColor = GetPixelColor(D_Xbas+D_col+(D_say*6),D_Ybas+(D_BitCounter*2),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
						PixelPoint(D_Xbas+(D_col*2)+(D_say*6*2),D_Ybas+(D_BitCounter*2),TextColor,0);	
					}
				}
			}
		}			
       D_str++;    
	   D_say++;
	}
}
*/

//De�i�kenleri tutar Buffer4 ise de�i�kenlerin rengini tutar.
void BufferedText(unsigned int Buffer1,unsigned int Buffer2,unsigned int Buffer3,unsigned long Buffer4)
{
	TextBuffer[0] = Buffer1;
	TextBuffer[1] = Buffer2;
	TextBuffer[2] = Buffer3;
	TextBufferLong[0] = Buffer4;
}
//Fontlar� size lar� 1 veya 2 yaparak ve Gradient(GR) yi se�erek arka plan rengini gradient ya da YaziDis ile 8x5 yaz� yaz�l�r.
void ASendText(unsigned int Xbas,unsigned int Ybas,const char* str,unsigned int SIZE,unsigned long YaziRenk,unsigned long YaziDis,unsigned int Clr)
{
	unsigned int col,BitCounter,size,say,aa;
	unsigned char YAZ;
	unsigned long YaziRenkAra;
	
	YaziRenkAra = YaziRenk;
	say = 0;
	klm = 0;

    while( *str ) 
    {	
		if(*str == '�')
			YAZ = 95;
		else if(*str == '�')
			YAZ = 96;
		else if(*str == '�')
			YAZ = 97;				//Derece
		else if(*str == '�')
			YAZ = 98;		
		else if(*str == '�')
			YAZ = 99;		
		else if(*str == '�')
			YAZ = 100;	
		else if(*str == '�')
			YAZ = 101;
		else if(*str == '�')		//Tek karakterlik 4 TextBuffer buffer kullan�larak dizi g�nderilecek "ok" vb.
		{
			if(TextBuffer[klm] == 221)			//�
				YAZ = 95;
			else if(TextBuffer[klm] == 208)
				YAZ = 96;
			else if(TextBuffer[klm] == 244)
				YAZ = 97;						//Derece
			else if(TextBuffer[klm] == 214)
				YAZ = 98;		
			else if(TextBuffer[klm] == 220)
				YAZ = 99;		
			else if(TextBuffer[klm] == 199)		//�
				YAZ = 100;	
			else if(TextBuffer[klm] == 222)
				YAZ = 101;
			else
				YAZ = TextBuffer[klm]-32;
			YaziRenk = TextBufferLong[0];
			klm++;
		}		
		else 
		{							
			YaziRenk = YaziRenkAra;
			YAZ = *str-32;
		}
		
		
		if( *str == '[')			//Tek karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],1,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;
		}
		else if( *str == ']')		//�ki karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],2,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;  
		  	say++;
		}
		else if(*str == '|')		//0.9 gibi noktal� de�erleri yazd�rmak
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],2,1,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++; 
		  	say = say + 2;
		}
		else if( *str == '�')		//�� karakterlik 
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],3,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;  
		  	say = say + 2;
		}
		else if( *str == '^')		//Noktal� �� karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],3,1,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 3;
		}
		else if( *str == '@')		//D�rt karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],4,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 3;
		}
		else if( *str == '�')		//Be� karakterlik noktal� 0.001
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],4,1,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 4;
		}
		else if( *str == '!')		//Be� karakterlik 
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],5,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 4;
		}
		else if(*str == '�')        //12.12
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],4,2,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 4;
		}
		else if( *str == '~')		//Bo� - karaktersiz 
		{
			Nop();					//��lem yok bo� karakter de de�il
		}
		else
		{
			WindowSet(Xbas+(say*((SIZE*5)+3)),Xbas+(say*((SIZE*5)+3))+(SIZE*5)-1,Ybas,Ybas+(SIZE*8)-1);		
			Write_Command(0x2c);
			for(BitCounter = 0;BitCounter<8;BitCounter++)
			{
				for(size = 0;size<SIZE;size++)			
				{
					for(col = 0;col<5;col++)
					{
						if(BitCntrl(FONT[YAZ][col],BitCounter))
						{
							if(Clr == 1)
							{
								TextColor = GetPixelColor(Xbas,Ybas+(BitCounter*SIZE),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
								for(aa = 0;aa<SIZE;aa++)	
									SendPixel(TextColor);
							}
							if(Clr == 0)
							{
								for(aa = 0;aa<SIZE;aa++)	
									SendPixel(YaziRenk);
							}
						}
						else
						{
							
							if(GRADIENT == Gradient)
							{
								TextColor = GetPixelColor(Xbas,Ybas+(BitCounter*SIZE),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
								for(aa = 0;aa<SIZE;aa++)
									SendPixel(TextColor);
							}
							else
							{
								for(aa = 0;aa<SIZE;aa++)
									SendPixel(YaziDis);
							}
						}	
					}
				}			
			}		
		}
       	str++;    
	   	say++;
	}
}//Fontlar� size lar� 1 veya 2 yaparak ve Gradient(GR) yi se�erek arka plan rengini gradient ya da YaziDis ile 8x5 yaz� yaz�l�r.
void ASendText2(unsigned int Xbas,unsigned int Ybas,const char* str,unsigned int SIZE,unsigned long YaziRenk,unsigned long YaziDis,unsigned int Clr)
{
	unsigned int col,BitCounter,size,say,aa;
	unsigned char YAZ;
	unsigned long YaziRenkAra;
	
	YaziRenkAra = YaziRenk;
	say = 0;
	klm2 = 0;

    while( *str ) 
    {	
		if(*str == '�')
			YAZ = 95;
		else if(*str == '�')
			YAZ = 96;
		else if(*str == '�')
			YAZ = 97;				//Derece
		else if(*str == '�')
			YAZ = 98;		
		else if(*str == '�')
			YAZ = 99;		
		else if(*str == '�')
			YAZ = 100;	
		else if(*str == '�')
			YAZ = 101;
		else if(*str == '�')		//Tek karakterlik 4 TextBuffer buffer kullan�larak dizi g�nderilecek "ok" vb.
		{
			if(TextBuffer[klm] == 221)			//�
				YAZ = 95;
			else if(TextBuffer[klm] == 208)
				YAZ = 96;
			else if(TextBuffer[klm] == 244)
				YAZ = 97;						//Derece
			else if(TextBuffer[klm] == 214)
				YAZ = 98;		
			else if(TextBuffer[klm] == 220)
				YAZ = 99;		
			else if(TextBuffer[klm] == 199)		//�
				YAZ = 100;	
			else if(TextBuffer[klm] == 222)
				YAZ = 101;
			else
				YAZ = TextBuffer[klm]-32;
			YaziRenk = TextBufferLong[0];
			klm++;
		}		
		else 
		{							
			YaziRenk = YaziRenkAra;
			YAZ = *str-32;
		}
		
		
		if( *str == '[')			//Tek karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],1,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;
		}
		else if( *str == ']')		//�ki karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],2,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;  
		  	say++;
		}
		else if(*str == '|')		//0.9 gibi noktal� de�erleri yazd�rmak
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],2,1,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++; 
		  	say = say + 2;
		}
		else if( *str == '�')		//�� karakterlik 
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],3,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;  
		  	say = say + 2;
		}
		else if( *str == '^')		//Noktal� �� karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],3,1,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 3;
		}
		else if( *str == '@')		//D�rt karakterlik
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],4,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 3;
		}
		else if( *str == '�')		//Be� karakterlik noktal� 0.001
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],4,1,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 4;
		}
		else if( *str == '!')		//Be� karakterlik 
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],5,0,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 4;
		}
		else if(*str == '�')        //12.12
		{
			OutVariable(Xbas+(say*((SIZE*5)+3)),Ybas,TextBuffer[klm],4,2,SIZE,TextBufferLong[0],NOTGRADIENTCOLOR,Clr);
			klm++;   
		  	say = say + 4;
		}
		else if( *str == '~')		//Bo� - karaktersiz 
		{
			Nop();					//��lem yok bo� karakter de de�il
		}
		else
		{
			WindowSet(Xbas+(say*((SIZE*5)+3)),Xbas+(say*((SIZE*5)+3))+(SIZE*5)-1,Ybas,Ybas+(SIZE*8)-1);		
			Write_Command(0x2c);
			for(BitCounter = 0;BitCounter<8;BitCounter++)
			{
				for(size = 0;size<SIZE;size++)			
				{
					for(col = 0;col<5;col++)
					{
						if(BitCntrl(FONT[YAZ][col],BitCounter))
						{
							if(Clr == 1)
							{
								TextColor = GetPixelColor(Xbas,Ybas+(BitCounter*SIZE),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
								for(aa = 0;aa<SIZE;aa++)	
									SendPixel(TextColor);
							}
							if(Clr == 0)
							{
								for(aa = 0;aa<SIZE;aa++)	
									SendPixel(YaziRenk);
							}
						}
						else
						{
							
							if(GRADIENT == Gradient)
							{
								TextColor = GetPixelColor(Xbas,Ybas+(BitCounter*SIZE),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
								for(aa = 0;aa<SIZE;aa++)
									SendPixel(TextColor);
							}
							else
							{
								for(aa = 0;aa<SIZE;aa++)
									SendPixel(YaziDis);
							}
						}	
					}
				}			
			}		
		}
       	str++;    
	   	say++;
	}
}
/*	Optimizasyon

//DegiskenTablo sunun boyutlar�na g�re i�lem yapabilen fonksiyondur.
//�rn. DegiskenFONTFonk(200,100,"BUR~ASI^ @ �",2,0xffffff,NOTGRADIENTCOLOR,NotClear,5,8);
void DegiskenFONTFonk(unsigned int Xbas1,unsigned int Ybas1,const char* str1,unsigned int SIZE1,unsigned long YaziRenk1,unsigned long YaziDis1,unsigned int Clr8x8,unsigned int x_pixel,unsigned int y_pixel)
{
	unsigned int col1,BitCounter1,size1,say1,aa1;
	unsigned char YAZ1;
	say1 = 0;
	klm = 0;

    while( *str1 ) 
    {	
		if(*str1 == '�')
			YAZ1 = 95;
		else if(*str1 == '�')
			YAZ1 = 96;
		else if(*str1 == '�')
			YAZ1 = 97;				//Derece
		else if(*str1 == '�')
			YAZ1 = 98;			
		else if(*str1 == '�')
			YAZ1 = 99;				
		else if(*str1 == '�')
			YAZ1 = 100;				
		else if(*str1 == '�')
			YAZ1 = 101;				
		else							
			YAZ1 = *str1-32;
		if( *str1 == '[')			//Tek karakterlik
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],1,0,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;
		}
		else if( *str1 == ']')		//�ki karakterlik
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],2,0,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;  
		  	say1++;
		}
		else if( *str1 == '�')		//�� karakterlik 
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],3,0,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;  
		  	say1 = say1 + 2;
			if(PfVar == 1)			//Power factor de 1 karakter daha ay�r�r.
		  		say1 = say1 + 1;
		}
		else if( *str1 == '^')		//Noktal� �� karakterlik
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],3,1,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;   
		  	say1 = say1 + 3;
		}
		else if( *str1 == '@')		//D�rt karakterlik
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],4,0,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;   
		  	say1 = say1 + 3;
		}
		else if( *str1 == '�')		//Be� karakterlik noktal�
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],4,1,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;   
		  	say1 = say1 + 4;
		}
		else if( *str1 == '!')		//Be� karakterlik 
		{
			OutVariable(Xbas1+(say1*((SIZE1*x_pixel)+3)),Ybas1,TextBuffer[klm],5,0,2,TextBufferLong[0],NOTGRADIENTCOLOR,Clr8x8);
			klm++;   
		  	say1 = say1 + 4;
		}
		else if( *str1 == '~')		//Be� karakterlik 
		{
			Nop();					//��lem yok bo� karakter de de�il
		}
		else
		{
			//Font lar 8x8 den daha fazla olunce birbirlerine yak�nl�klar� = 3 s�k�nt� yaratabilir.
			WindowSet(Xbas1+(say1*((SIZE1*x_pixel)+3)),Xbas1+(say1*((SIZE1*x_pixel)+3))+(SIZE1*x_pixel)-1,Ybas1,Ybas1+(SIZE1*y_pixel)-1);		
			Write_Command(0x2c);
			for(BitCounter1 = 0;BitCounter1<y_pixel;BitCounter1++)
			{
				for(size1 = 0;size1<SIZE1;size1++)			
				{
					for(col1 = 0;col1<x_pixel;col1++)
					{
						if(BitCntrl(DegiskenFont[YAZ1][col1],BitCounter1))
						{
							if(Clr8x8 == 1)
							{
								TextColor = GetPixelColor(Xbas1,Ybas1+(BitCounter1*SIZE1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
								for(aa1 = 0;aa1<SIZE1;aa1++)	
									SendPixel(TextColor);
							}
							if(Clr8x8 == 0)
							{
								for(aa1 = 0;aa1<SIZE1;aa1++)	
									SendPixel(YaziRenk1);
							}
						}
						else
						{
							if(GRADIENT == Gradient)
							{
								TextColor = GetPixelColor(Xbas1,Ybas1+(BitCounter1*SIZE1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
								for(aa1 = 0;aa1<SIZE1;aa1++)
									SendPixel(TextColor);
							}
							else
							{
								for(aa1 = 0;aa1<SIZE1;aa1++)
									SendPixel(YaziDis1);
							}
						}
					}
				}
			}
		}
       str1++;    
	   say1++;
	}
}
*/

//Font gibi tablolardan bitlerin hangilerinde arka plan yazd�r�lacak onlar� al�r.
unsigned char BitCntrl(unsigned int var,unsigned char abit)
{
	unsigned char a;
		
	a=var>>abit;
	a=a&0x01;
	return(a);
}
//De�i�kenleri basamaklara ay�r�r.
void OutVariable(unsigned int X,unsigned int Y,unsigned int ekran,unsigned char digit,unsigned char DOT,unsigned int SiZe,unsigned long REnk,unsigned long Renksiz,unsigned int CLR)
{
	switch(digit)
	{
		case 5:
			ASendVariable(X,Y,(int)(ekran / 10000),SiZe,REnk,Renksiz,CLR);
			X = X + (SiZe*5)+3;
		case 4:
			ASendVariable(X,Y,(int)((ekran % 10000) / 1000),SiZe,REnk,Renksiz,CLR);
			X = X + (SiZe*5)+3;
		case 3:
			ASendVariable(X,Y,(int)((ekran % 1000)/100),SiZe,REnk,Renksiz,CLR);			
			X = X + (SiZe*5)+3;
			if( DOT == 2 )
			{
				ASendText2(X,Y,".",SiZe,REnk,NOTGRADIENTCOLOR,CLR);
				X = X + (SiZe*5)+3;
			}
		case 2:
			ASendVariable(X,Y,(int)(((ekran % 1000)%100)/10),SiZe,REnk,Renksiz,CLR);
			X = X + (SiZe*5)+3;
			if(DOT==1)
			{
				ASendText2(X,Y,".",SiZe,REnk,NOTGRADIENTCOLOR,CLR);
				X = X + (SiZe*5)+3;
			}
		case 1:
			ASendVariable(X,Y,(int)(((ekran % 1000)%100)%10),SiZe,REnk,Renksiz,CLR);
		break;
		default:
		break;
	}
}
void ASendVariable(unsigned int X3,unsigned int Y3,unsigned int Variable3,unsigned int Size3,unsigned long ReNK3,unsigned long RENk3,unsigned int CleaR)
{
	unsigned int colVar3,BitCounterVar3,sizeVar3,bb3;
	
	WindowSet(X3,X3+(Size3*5)-1,Y3,Y3+(Size3*8)-1);		
	Write_Command(0x2c);
	for(BitCounterVar3 = 0;BitCounterVar3<8;BitCounterVar3++)
	{
		for(sizeVar3 = 0;sizeVar3<Size3;sizeVar3++)			
		{
			for(colVar3 = 0;colVar3<5;colVar3++)
			{
				if(BitCntrl(FONT[Variable3+16][colVar3],BitCounterVar3))
				{
					if(CleaR == 1)
					{
						TextColor = GetPixelColor(X3,Y3+(BitCounterVar3*Size3),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
						if(DIGITAL == Digital)
							PixelPoint(X3+(colVar3*Size3) + Size3,Y3+(BitCounterVar3*Size3),TextColor,0);
						else
						{
							for(bb3 = 0;bb3<Size3;bb3++)		
								SendPixel(TextColor);
						}

					}
					if(CleaR == 0)
					{		
						if(DIGITAL == Digital)
							PixelPoint(X3+(colVar3*Size3) + Size3,Y3+(BitCounterVar3*Size3),ReNK3,0);
						else
						{
							for(bb3 = 0;bb3<Size3;bb3++)
								SendPixel(ReNK3);
						}
					}
				}
				else
				{
					
					if(GRADIENT == Gradient)
					{
						TextColor = GetPixelColor(X3,Y3+(BitCounterVar3*Size3),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
						for(bb3 = 0;bb3<Size3;bb3++)
							SendPixel(TextColor);
					}
					else
					{
						for(bb3 = 0;bb3<Size3;bb3++)
							SendPixel(RENk3);
					}
				}



			}
		}
	}  
}

//B�y�k de�i�kenler yaz�l�rken kullan�lacak
void BigOutVar(unsigned int BigAddrX,unsigned int BigAddrY,unsigned int BigEkran,unsigned char BigDigit,unsigned char BDOT,unsigned int BigPage,unsigned long BigRenk,unsigned int BigCLR)
{	
	if(BigPage == 1)
		BigAddrY = BigAddrY + 272;
	if(BigPage == 2)
		BigAddrY = BigAddrY + 544;
	if(BigDigit > 9)				//Karakterleri yazd�rmak i�in
	{
		BigVariable(BigAddrX,BigAddrY,BigDigit,BigRenk,BigCLR);
	}
	else
	{
		switch(BigDigit)
		{
			case 5:
				BigVariable(BigAddrX,BigAddrY,(int)(BigEkran / 10000),BigRenk,BigCLR);
				BigAddrX = BigAddrX + 40;
			case 4:
				BigVariable(BigAddrX,BigAddrY,(int)((BigEkran % 10000) / 1000),BigRenk,BigCLR);
				BigAddrX = BigAddrX + 40;
			case 3:
				BigVariable(BigAddrX,BigAddrY,(int)((BigEkran % 1000)/100),BigRenk,BigCLR);			
				BigAddrX = BigAddrX + 40;
			case 2:
				BigVariable(BigAddrX,BigAddrY,(int)(((BigEkran % 1000)%100)/10),BigRenk,BigCLR);
				BigAddrX = BigAddrX + 40;
				if(BDOT)
				{
					BigVariable(BigAddrX,BigAddrY,".",BigRenk,BigCLR);
					BigAddrX = BigAddrX + 40;
				}
			case 1:
				BigVariable(BigAddrX,BigAddrY,(int)(((BigEkran % 1000)%100)%10),BigRenk,BigCLR);
			break;
			default:
			break;
		}
	}
}
//B�y�k karakterleri yazmak i�in kullan�l�r.
void BigVariable(unsigned int AddrX,unsigned int AddrY,unsigned int BigVar,unsigned long BigColor1,unsigned int BigCleaR)
{
	unsigned int BigBitCount,Null_1,Null_2;
	unsigned int BigCol,BigLine,Line_1,Line_2;

	BigCol = 4;
	BigLine = 6;
	WindowSet(AddrX,(AddrX+(BigCol*8)-1),AddrY,(AddrY+(BigLine*8)-1));
	Write_Command(0x2c);
	for(Null_1=0;Null_1<(BigCol*BigLine*8);Null_1++)
	{
		Line_1 = Null_1 / 4;		//inci sat�r (y)
		Line_2 = Null_1 % 4;		//inci s�tun (x)
		
		for(BigBitCount = 0;BigBitCount<8;BigBitCount++)
		{
			if(BitCntrl(BigFont[BigVar][Null_1],(7-BigBitCount)))
			{
				if(BigCleaR == 1)
				{
					TextColor = GetPixelColor((AddrX+Line_2),(AddrY+Line_1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
					SendPixel(TextColor);
				}
				if(BigCleaR == 0)
				{	
					SendPixel(BigColor1);
				}
			}
			else
			{				
				if(GRADIENT == Gradient)
				{
					TextColor = GetPixelColor((AddrX+Line_2),(AddrY+Line_1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
					SendPixel(TextColor);
				}
				else
				{
					SendPixel(NOTGRADIENTCOLOR);
				}
			}
		}
	}	
}

void ExBigVariable(unsigned int ExAddrX,unsigned int ExAddrY,unsigned int ExBigCol,unsigned int ExBigLine,unsigned int ExBigVar,unsigned long ExBigColor1,unsigned int ExBigCleaR)
{
	unsigned int ExBigBitCount,ExNull_1,ExNull_2;
	unsigned int ExLine_1,ExLine_2;


	WindowSet(ExAddrX,(ExAddrX+(ExBigCol*8)-1),ExAddrY,(ExAddrY+(ExBigLine*8)-1));
	Write_Command(0x2c);
	for(ExNull_1=0;ExNull_1<(ExBigCol*ExBigLine*8);ExNull_1++)
	{
		ExLine_1 = ExNull_1 / ExBigCol;			//inci sat�r (y)
		ExLine_2 = ExNull_1 % ExBigLine;		//inci s�tun (x)
		
		for(ExBigBitCount = 0;ExBigBitCount<8;ExBigBitCount++)
		{
			if(BitCntrl(ExBigFont[ExBigVar][ExNull_1],(7-ExBigBitCount)))
			{
				if(ExBigCleaR == 1)
				{
					TextColor = GetPixelColor((ExAddrX+ExLine_2),(ExAddrY+ExLine_1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
					SendPixel(TextColor);
				}
				if(ExBigCleaR == 0)
				{	
					SendPixel(ExBigColor1);
				}
			}
			else
			{				
				if(GRADIENT == Gradient)
				{
					TextColor = GetPixelColor((ExAddrX+ExLine_2),(ExAddrY+ExLine_1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
					SendPixel(TextColor);
				}
				else
				{
					SendPixel(NOTGRADIENTCOLOR);
				}
			}
		}
	}	
}






/*	Optimizasyon

void SendVariable(unsigned int X1,unsigned int Y1,unsigned int Variable,unsigned int Size,unsigned long ReNK,unsigned long RENk)
{
	unsigned int colVar,BitCounterVar,sizeVar,bb;
	
	WindowSet(X1,X1+(Size*5)-1,Y1,Y1+(Size*8)-1);		
	Write_Command(0x2c);
	for(BitCounterVar = 0;BitCounterVar<8;BitCounterVar++)
	{
		for(sizeVar = 0;sizeVar<Size;sizeVar++)			
		{
			for(colVar = 0;colVar<5;colVar++)
			{
				if(BitCntrl(FONT[Variable+16][colVar],BitCounterVar))
				{
					for(bb = 0;bb<Size;bb++)	
						SendPixel(ReNK);
				}
				else
				{
					for(bb = 0;bb<Size;bb++)	
						SendPixel(RENk);
				}
			}
		}
	}  
}
*/
/*	Optimizasyon

void ClearLine(unsigned int XX12,unsigned int XX22,unsigned int YY12,unsigned int YY22,unsigned int LineColor,unsigned long LineStart,unsigned int LineGradient,unsigned int LineCounter)
{
	unsigned int PixelSayisi2,zz,yy;

		PixelSayisi2 = YY22 - YY12;
		if(XX22 > XX12)
		{
			PixelSayisi2 = XX22 - XX12;
		}
	for(yy=0;yy<LineCounter;yy++)
	{						
		for(zz = 0;zz<PixelSayisi2+1;zz++)
		{
			if(YY22 > YY12)						//�izgi a�a��dan yukar�ya
				PixelPoint(XX12+yy,(YY12+zz),0,1);
			if(XX22 > XX12)						//�izgi soldan sa�a
				PixelPoint(XX12+zz,YY12+yy,0,1);
		}
	}
}
*/
void Line(unsigned int XX1,unsigned int XX2,unsigned int YY1,unsigned int YY2,unsigned long Color,unsigned int CLEaR)
{
	unsigned int PixelSayisi,zz,i;						
	PixelSayisi = YY2 - YY1;
	if(XX2 > XX1)
	{
		PixelSayisi = XX2 - XX1;
	}
	if(CLEaR == Clear)
	{
		for(zz = 0;zz<PixelSayisi+1;zz++)
		{
			if(YY2 > YY1)						//�izgi a�a��dan yukar�ya
			{
				PixelPoint(XX1,(YY1+zz),0,1);
				if(LINEREPEAT == 2)
					PixelPoint(XX1+1,(YY1+zz),0,1);
			}
			if(XX2 > XX1)						//�izgi soldan sa�a
			{
				PixelPoint(XX1+zz,YY1,0,1);
				if(LINEREPEAT == 2)
					PixelPoint(XX1+zz,YY1+1,0,1);
			}
		}
	}
	else
	{
		WindowSet(XX1,XX2,YY1,YY2);		
		Write_Command(0x2c);
		for (i=0;i<PixelSayisi+1;i++)
		{
			SendPixel(Color);
		}
		if(LINEREPEAT == 2)
		{
			if(YY2 > YY1)
			{
				WindowSet(XX1+1,XX2+1,YY1,YY2);		
				Write_Command(0x2c);
				for (i=0;i<PixelSayisi+1;i++)
				{
					SendPixel(Color);
				}
			}
			if(XX2 > XX1)
			{	
				WindowSet(XX1,XX2,YY1+1,YY2+1);		
				Write_Command(0x2c);
				for (i=0;i<PixelSayisi+1;i++)
				{
					SendPixel(Color);
				}
			}
		}
	}
}
void CaprazHat(unsigned int Absis1,unsigned int Absis2,unsigned int Ordinat1,unsigned int Ordinat2,unsigned long CColor,unsigned int CaprazCLR)
{
	unsigned int NoktaSay,Sayac,Ord,Ab;
	Ord = Ordinat2-Ordinat1;
	if(Ordinat1>Ordinat2)
		Ord = Ordinat1-Ordinat2;
	Ab = Absis2-Absis1;
	if(Absis1>Absis2)
		Ab = Absis1-Absis2;
	Sayac = Ab;
	if(Ord>Ab)
		Sayac = Ord;
	for(NoktaSay = 0;NoktaSay<Sayac;NoktaSay++)
	{
		if(Absis2>Absis1)
			Absis1++;
		else
			Absis1--;
		if(Ordinat2>Ordinat1)
			Ordinat1++;
		else
			Ordinat1--;
		if(CaprazCLR == NotClear)
		{
			PixelPoint(Absis1,Ordinat1,CColor,0);
			if(LINEREPEAT == 2)
				PixelPoint(Absis1+1,Ordinat1,CColor,0);
		}
		else
		{
			PixelPoint(Absis1,Ordinat1,0,1);
			if(LINEREPEAT == 2)
				PixelPoint(Absis1+1,Ordinat1,0,1);
		}
	}
}
//Gradient arka plan�n koordinat�na g�re pixel rengini al�r.
unsigned long GetPixelColor(unsigned int Absis,unsigned int Oordinat,unsigned int ColoR,unsigned int Grad,unsigned long StartColoR)
{
	unsigned long GetColor;

	if(Grad == NotGradient)
	{
		GetColor = NOTGRADIENTCOLOR;		 
	}
	else
	{		
		//3.sayfa i�lemleri i�in eklendi.
		if(Oordinat > 544)					
			Oordinat = Oordinat - 272;
		//2.sayfa i�lemleri i�in eklendi.
		if(Oordinat > 272)					
			Oordinat = Oordinat - 272;
			
		if(Oordinat < 136)
			GetColor = Oordinat;
		if(Oordinat == 136)
			GetColor = 136;
		if(Oordinat > 136)
			GetColor = 272 - Oordinat;

		if(ColoR == Blue)
			GetColor = GetColor + StartColoR;
		if(ColoR == Green)
			GetColor = (GetColor<<8) + StartColoR;
		if(ColoR == Red)
			GetColor = (GetColor<<16) + StartColoR;
			
	}
	return(GetColor);
}
//Arka plan� boyamaya yarar.
void BackGround(unsigned int BackColor,unsigned int Grad,unsigned long StrtColor)
{
	static unsigned int c;
	static unsigned int d;
	static unsigned int e;
	static unsigned int f;
	static unsigned long incr = 0;

	if(Grad == 0)
	{
		FullScreen(NOTGRADIENTCOLOR); 
	}
	else
	{
		if(BackColor == Blue)
			incr = 0x000001;
		if(BackColor == Red)
			incr = 0x010000;
		if(BackColor == Green)
			incr = 0x000100;
		if(BackColor == Grey)
			incr = 0x010101;
			f=0;
		for(e=0;e<272;e++)
		{
			for(d=0;d<480;d++)
			{
				SendPixel(StrtColor);
			}
			if(e<136)
				StrtColor = StrtColor + incr;
			if(e>136)
				StrtColor = StrtColor - incr;
		
		}	
	}
}
//�stenilen koordinata istenilen renkte tek piksel yazar.
void PixelPoint(unsigned int A1,unsigned int O1,unsigned long PColor,unsigned int P_Sil)
{
	if( P_Sil == 1)
		PColor = GetPixelColor(A1,O1,GRADIENTCOLOR,GRADIENT,GRADIENTSTART);
	WindowSet(A1,A1,O1,O1);		
	Write_Command(0x2c);
	SendPixel(PColor);
}
//�eyrek,tam ,yar�m �eklinde �ember ve tam daireler �izer.
void Circle(unsigned int C_x,unsigned int C_y, unsigned int C_r,unsigned int C_dolu,unsigned int Ceyrek, unsigned long C_renk,unsigned int C_Sil)
{
	//Ceyrek = 50 olursa tam �ember yapar.
	unsigned char a,b;
	unsigned int CeyrekH,CeyrekL;
	int P;
	a = 0;
	b = C_r;
	P = 1-C_r;
	CeyrekH = Ceyrek / 10;
	CeyrekL = Ceyrek % 10;
	do
	{
		//Dolusu �al��m�yor �uan.
		if(C_dolu)
		{
			Line(C_x-a, C_x+a, C_y+b,  C_y+b, C_renk,C_Sil);
			Line(C_x-a, C_x+a, C_y-b,  C_y-b, C_renk,C_Sil);
			Line(C_x-b, C_x+b, C_y+a,  C_y+a, C_renk,C_Sil);
			Line(C_x-b, C_x+b, C_y-a,  C_y-a, C_renk,C_Sil);
		}
		else
		{
			//GetPixelColor(XX1,(zz+YY1),GRADIENTCOLOR,GRADIENT,GRADIENTSTART));
			switch(CeyrekH)
			{
				case 1:
					PixelPoint(C_x-a, C_y-b, C_renk,C_Sil);
					PixelPoint(C_x-b, C_y-a, C_renk,C_Sil);
				break;
				case 2:
					PixelPoint(b+C_x, C_y-a, C_renk,C_Sil);
					PixelPoint(a+C_x, C_y-b, C_renk,C_Sil);
				break;
				case 3:
					PixelPoint(C_x-a, b+C_y, C_renk,C_Sil);
					PixelPoint(C_x-b, a+C_y, C_renk,C_Sil);
				break;
				case 4:
					PixelPoint(a+C_x, b+C_y, C_renk,C_Sil);
					PixelPoint(b+C_x, a+C_y, C_renk,C_Sil);
				break;
				case 5:
					PixelPoint(a+C_x, b+C_y, C_renk,C_Sil);
					PixelPoint(b+C_x, a+C_y, C_renk,C_Sil);
					PixelPoint(C_x-a, b+C_y, C_renk,C_Sil);
					PixelPoint(C_x-b, a+C_y, C_renk,C_Sil);
					PixelPoint(b+C_x, C_y-a, C_renk,C_Sil);
					PixelPoint(a+C_x, C_y-b, C_renk,C_Sil);
					PixelPoint(C_x-a, C_y-b, C_renk,C_Sil);
					PixelPoint(C_x-b, C_y-a, C_renk,C_Sil);
				break;
				default:
				break;
			}
			switch(CeyrekL)
			{
				case 1:
					PixelPoint(C_x-a, C_y-b, C_renk,C_Sil);
					PixelPoint(C_x-b, C_y-a, C_renk,C_Sil);
				break;
				case 2:
					PixelPoint(b+C_x, C_y-a, C_renk,C_Sil);
					PixelPoint(a+C_x, C_y-b, C_renk,C_Sil);
				break;
				case 3:
					PixelPoint(C_x-a, b+C_y, C_renk,C_Sil);
					PixelPoint(C_x-b, a+C_y, C_renk,C_Sil);
				break;
				case 4:
					PixelPoint(a+C_x, b+C_y, C_renk,C_Sil);
					PixelPoint(b+C_x, a+C_y, C_renk,C_Sil);
				break;
				case 5:
					PixelPoint(C_x-a, C_y-b, C_renk,C_Sil);
					PixelPoint(C_x-b, C_y-a, C_renk,C_Sil);
					PixelPoint(b+C_x, C_y-a, C_renk,C_Sil);
					PixelPoint(a+C_x, C_y-b, C_renk,C_Sil);
					PixelPoint(C_x-a, b+C_y, C_renk,C_Sil);
					PixelPoint(C_x-b, a+C_y, C_renk,C_Sil);
					PixelPoint(a+C_x, b+C_y, C_renk,C_Sil);
					PixelPoint(b+C_x, a+C_y, C_renk,C_Sil);
				break;
				default:
				break;
			}
		}
		if(P < 0)
			P += 3 + 2 * a++;
		else
			P += 5 + 2 * (a++ - b--);
	}while(a <= b);
}
//Dikd�rtgen �izer.
void Dikdortgen(unsigned int Xx1,unsigned int Xx2,unsigned int Yy1,unsigned int Yy2,unsigned long Drenk,unsigned int TekCift,unsigned int Dolu,unsigned int CLEar)
{
	unsigned int f1,f2;

//	WindowSet(Xx1,Xx2-1,Yy1,Yy2-1);		
//	Write_Command(0x2c);
//	for (f1=1;f1<(Xx2-Xx1);f1++)
//	{
//		for (f2=1;f2<((Yy2-Yy1)+2);f2++)
//		{
//			if(Dolu)
//				SendPixel(Drenk);
//			else
//				PixelPoint(Xx1+f1,Yy1+f2,0,1);
//		}
//	}	
	if( Dolu == 1 )
	{
		LINEREPEAT = 1;
		for( f1=0;f1<( Yy2-Yy1 );f1++ )
			Line(Xx1,Xx2,Yy1+f1,Yy1+f1,Drenk,CLEar);
		LINEREPEAT = 2;
	}
	else
	{
		//Bo�sa
		LINEREPEAT = TekCift+1;
		Line(Xx1,Xx2,Yy1,Yy1,Drenk,CLEar);
		Line(Xx2,Xx2,Yy1,Yy2,Drenk,CLEar);
		Line(Xx1,Xx2,Yy2,Yy2,Drenk,CLEar);
		Line(Xx1,Xx1,Yy1,Yy2,Drenk,CLEar);	
		LINEREPEAT = 2;
	}
}
//Elips �izer.
void Elipse(unsigned int EXx1,unsigned int EXx2,unsigned int EYy1,unsigned int EYy2,unsigned long EDrenk,unsigned int Art,unsigned int ElipseClear)
{
	unsigned int f;

	Line(EXx1+Art,EXx2-Art,EYy1,EYy1,EDrenk,ElipseClear);
	Line(EXx1+Art,EXx2-Art,EYy2,EYy2,EDrenk,ElipseClear);
	Line(EXx2,EXx2,EYy1+Art,EYy2-Art,EDrenk,ElipseClear);
	Line(EXx1,EXx1,EYy1+Art,EYy2-Art,EDrenk,ElipseClear);

	CaprazHat(EXx1,EXx1+Art,EYy1+Art,EYy1,EDrenk,ElipseClear);
	CaprazHat(EXx2,EXx2-Art,EYy1+Art,EYy1,EDrenk,ElipseClear);
	CaprazHat(EXx2,EXx2-Art,EYy2-Art,EYy2,EDrenk,ElipseClear);
	CaprazHat(EXx1,EXx1+Art,EYy2-Art,EYy2,EDrenk,ElipseClear);
}

//Optimizasyon
////Ram de bulunan tablodaki (name[]) foto�raf bilgisini ekrana g�nderir.
//void ShowPic(void)													
//{
//	unsigned int  x;
//	unsigned int z,y;
//	unsigned long Buffer;
//
////	WindowSet(100,171,100,149);											//72 x 50
//	WindowSet(100,174,100,124);								
//	Write_Command(0x2c);	
//
///*��z�n�rl�k 2 kat d��er �ekil 2 kat b�y�r*/	
///*	for(x= 0;x<72;x++)
//	{ 
//		for(y = 0;y<2;y++)
//		{
//			for(z = x*72;z<(x+1)*72;z++)
//			{
//				SendPixel(name[z]);
//				SendPixel(name[z]);
//			}
//		}
//	}
//*/
///*Normal Boyut*/
////Piksel say�s� buraya yaz�l�r.
////	for(x= 3600;x>0;x--)												//72 x 50 = 3600
//	for(x= 1875;x>0;x--)
//	{ 
//		Buffer = 0;
//		Buffer = name[x];
////		if(Buffer > 0xc00000)
////			Buffer = 0xff0000;
//		SendPixel(Buffer);
//	}
//}
/*	Optimizasyon
//Ok ikonu vard�.Onu sa�a sola yukar� a�a�� d�nd�rmeye yarayan bir fonksiyondur.	
void ShowIcon(unsigned int Wx1,unsigned int Wx2,unsigned int Wy1,unsigned int Wy2,unsigned int Yon)			
{
	unsigned int  A,Matrix;
	unsigned int B,C;
	signed int p,g;
	unsigned long Buffer;

	A = (Wx2 - Wx1);
	B = (Wy2 - Wy1);
	Matrix = A * B;
	if(Yon == Sag)	
	{
		WindowSet(Wx1,Wx2-1,Wy1,Wy2-1);	
		Write_Command(0x2c);	
		for(p= 0;p<Matrix;p++)
		{ 
			Buffer = name[p];
//			if(Buffer > 0xc00000)				//Hatal� piksel i�in yap�lan i�lem
//				Buffer = 0xff0000;
			SendPixel(Buffer);
		}	
	}
	if(Yon == Sol)			
	{
		WindowSet(Wx1,Wx2-1,Wy1,Wy2-1);	
		Write_Command(0x2c);		
		for(p= Matrix;p>0;p--)
		{ 
			Buffer = name[p];
//			if(Buffer > 0xc00000)				//Hatal� piksel i�in yap�lan i�lem
//				Buffer = 0xff0000;
			SendPixel(Buffer);
		}	
	}
	if(Yon == Yukari)
	{
		WindowSet(Wx1,Wx1+B-1,Wy1,Wy1+A-1);	
		Write_Command(0x2c);	
		for(p=A-1;p>=0;p--)
		{
			for(g=0;g<B;g++)
			{				
				Buffer = name[p + g*A];
//				if(Buffer > 0xc00000)			//Hatal� piksel i�in yap�lan i�lem
//					Buffer = 0xff0000;
				SendPixel(Buffer);
			}			
		}
	}
	if(Yon == Asagi)
	{			
		WindowSet(Wx1,Wx1+B-1,Wy1,Wy1+A-1);	
		Write_Command(0x2c);	
		for(p=0;p<=A-1;p++)
		{
			for(g=B-1;g>=0;g--)
			{				
				Buffer = name[p + g*A];
//				if(Buffer > 0xc00000)			//Hatal� piksel i�in yap�lan i�lem
//					Buffer = 0xff0000;
				SendPixel(Buffer);
			}			
		}
	}
}
*/
void NopWait(unsigned int say)												//Nop = 25 ns 
{
	unsigned int basla;
	for(basla = 0;basla < say;basla++)
		Nop();
}		

/*	Optimizasyon

//Dikd�rtgen fonksiyonu ile ayn� i� yap�labiliyor.
void Area1963(unsigned int XXbas,unsigned int XXson,unsigned int YYbas,unsigned int YYson,unsigned long renk)
{																			//YAZI ���N istenilen b�lgeye istenilen renk yaz�l�r.
	unsigned int x,y;
	WindowSet(XXbas,XXson-1,YYbas,YYson-1);			
	Write_Command(0x2c);
	for (x=0;x<XXson-XXbas;x++)
	{
		for (y=0;y<YYson-YYbas;y++)
		{
			SendPixel(renk);
		}
	}
}
*/
