#include "p33FJ256MC710.h"

#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTVar.h"


//Timer Kesmeleri
void __attribute__((__interrupt__)) _T6Interrupt(void);
void __attribute__((__interrupt__)) _T2Interrupt(void);
void __attribute__((__interrupt__)) _T3Interrupt(void);
void __attribute__((__interrupt__)) _T5Interrupt(void);

//Can Kesmeleri
void __attribute__((__interrupt__)) _C1Interrupt(void);
void __attribute__((__interrupt__)) _DMA1Interrupt(void);

//Uart Kesmeleri
void __attribute__ ((interrupt, no_auto_psv)) _U1RXInterrupt(void);
void __attribute__ ((interrupt, no_auto_psv)) _U1TXInterrupt(void);
void __attribute__ ((interrupt, no_auto_psv)) _U2RXInterrupt(void); 
void __attribute__ ((interrupt, no_auto_psv)) _U2TXInterrupt(void);

//Spi Kesmeleri
void __attribute__((__interrupt__)) _SPI1Interrupt(void);
void __attribute__((__interrupt__)) _SPI2Interrupt(void);

//Rtc 1sn lik kesme
void __attribute__ ((interrupt, no_auto_psv)) _INT4Interrupt( void );

//Pwm LcdBacklight i�in
void __attribute__((__interrupt__)) _PWMInterrupt(void);

//Buton Kesmeleri
void __attribute__((__interrupt__)) _CNInterrupt(void);




void __attribute__((__interrupt__)) _OscillatorFail(void);
void __attribute__((__interrupt__)) _AddressError(void);
void __attribute__((__interrupt__)) _StackError(void);
void __attribute__((__interrupt__)) _MathError(void);
void __attribute__((__interrupt__)) _DMACError(void);

void __attribute__((__interrupt__)) _AltOscillatorFail(void);
void __attribute__((__interrupt__)) _AltAddressError(void);
void __attribute__((__interrupt__)) _AltStackError(void);
void __attribute__((__interrupt__)) _AltMathError(void);
void __attribute__((__interrupt__)) _AltDMACError(void);

/*
Primary Exception Vector handlers:
These routines are used if INTCON2bits.ALTIVT = 0.
All trap service routines in this file simply ensure that device
continuously executes code within the trap service routine. Users
may modify the basic framework provided here to suit to the needs
of their application.
*/
void __attribute__((interrupt, no_auto_psv)) _OscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;        //Clear the trap flag
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _AddressError(void)
{
        INTCON1bits.ADDRERR = 0;        //Clear the trap flag
        while (1);
}
void __attribute__((interrupt, no_auto_psv)) _StackError(void)
{

        INTCON1bits.STKERR = 0;         //Clear the trap flag
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _MathError(void)
{
        INTCON1bits.MATHERR = 0;        //Clear the trap flag
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _DMACError(void)
{
        INTCON1bits.DMACERR = 0;        //Clear the trap flag
        while (1);
}





/*
Alternate Exception Vector handlers:
These routines are used if INTCON2bits.ALTIVT = 1.
All trap service routines in this file simply ensure that device
continuously executes code within the trap service routine. Users
may modify the basic framework provided here to suit to the needs
of their application.
*/

void __attribute__((interrupt, no_auto_psv)) _AltOscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _AltAddressError(void)
{
        INTCON1bits.ADDRERR = 0;
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _AltStackError(void)
{
        INTCON1bits.STKERR = 0;
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _AltMathError(void)
{
        INTCON1bits.MATHERR = 0;
        while (1);
}

void __attribute__((interrupt, no_auto_psv)) _AltDMACError(void)
{
        INTCON1bits.DMACERR = 0;        //Clear the trap flag
        while (1);
}


//----------------------------------------------------------------


//Timer Kesmeleri
void __attribute__((__interrupt__)) _T6Interrupt(void)					//50 ms
{
	unsigned int Timer6_i;	
	static int EskiDakika;
	static int EskiSaniye;
	
	//Yeni Uart Problemine ba�l� olarak eklendi.
	if( U1STAbits.OERR == 1 )
	{
		U1STAbits.OERR = 0;	
		Uart1.ClrBuf[0] = *(&U1RXREG);
		Uart1.ClrBuf[1] = *(&U1RXREG + 1);
		Uart1.ClrBuf[2] = *(&U1RXREG + 2);
		Uart1.ClrBuf[3] = *(&U1RXREG + 3);								
	}
	if( U2STAbits.OERR == 1 )
	{
		U2STAbits.OERR = 0;	
		Uart2.ClrBuf[0] = *(&U2RXREG);
		Uart2.ClrBuf[1] = *(&U2RXREG + 1);
		Uart2.ClrBuf[2] = *(&U2RXREG + 2);
		Uart2.ClrBuf[3] = *(&U2RXREG + 3);
	}
		
	if( Genel.IlkAcilisAlrSayac > 4 )
	{
		if( CalismaDurumu.Bit.Bit0 == 0 )
			BuzzerKontrol();
	}
	//Eeprom Kilitlenmesin sayac�
	if( Genel.EepromKilitSayac > 0 )
		Genel.EepromKilitSayac--;
		
	if( Genel.AdcKilit > 0 )					//30.11.2012 de eklendi.
		Genel.AdcKilit--;	
		
	if( TftInitFlag == 0 )						//09.07.2013 TFT	
	{
		//Ups kapal�yken men�de dola�abilsin 1 dk sonra yine UPS kapal� yazs�n.
		if( CalismaDurumu.Bit.Bit0 == 1 )
		{
			if( Genel.UPSKapaliGeriSayac > 0 )					//23.11.2012 de eklendi.
			{
				Genel.UPSKapaliGeriSayac--;						//23.11.2012 de eklendi.
				if( Genel.UPSKapaliGeriSayac == 0 )
					UPS_Durdu_Fonk();
			}
		}	
	}
	//Buton gecikmesi i�in
	if(++Timer6.Ms50_10	> 1000)
		Timer6.Ms50_10 = 1000;
	
	if( Genel.LoginWaitButon > 0 )
		Genel.LoginWaitButon--;
		
	if( Timer6.Ilk_15sn_Sayac > 0 )
		Timer6.Ilk_15sn_Sayac--;
		
	if( Genel.EeSildenSonraAlrKayitSayac > 0 )
		Genel.EeSildenSonraAlrKayitSayac--;
	//Flip Flop lar	
	Timer.Bit.Sn0_05 = 1;
	Timer.Bit.Sn0_05__1 = 1;
	//Eeprom log silme ile alakal�
//	if( Genel.LogSilEmri == 1 )
		Timer.Bit.Sn0_05__2 = 1;
	
	//Baud rate denemelerinde geri saya� sistemi
	if( Uart1.BaudRateKontrolSayac > 0 )
		Uart1.BaudRateKontrolSayac--;
	else
		Uart1.LokalSayac = 0;
	if( Uart2.BaudRateKontrolSayac > 0 )
		Uart2.BaudRateKontrolSayac--;
	else
		Uart2.LokalSayac = 0;
	
	//Uart tan log sorusu soruluyorken yeni kay�t yap�lmas�n� engellemek i�in saya�
	if( Genel.LogSorulduSayac > 0 )
		Genel.LogSorulduSayac--;	
	
	//�stenilen s�re sonra ekran� yenile i�lemi.
	if( Menu.YenileGeriSayac > 0 )
	{
		if( Menu.YenileGeriSayac == 1 )
			Menu.Yenile = 1;
		Menu.YenileGeriSayac--;
	}
	//Uart tan kod istendi Arka arkaya istenmesin diye 30 sn bir kendini s�f�rlar
	if( Uart1.KodIslemiGeriSayac > 0 )
		Uart1.KodIslemiGeriSayac--;
	if( Uart2.KodIslemiGeriSayac > 0 )
		Uart2.KodIslemiGeriSayac--;
	//Uart tan kod istendi ve �ifre yanl�� (P ile) girildiyse 30 sn de ancak denenebilsin arka arkaya denenmesin diye
	if( Uart1.PassWordHataliGeriSayac > 0 )
		Uart1.PassWordHataliGeriSayac--;
	if( Uart2.PassWordHataliGeriSayac > 0 )
		Uart2.PassWordHataliGeriSayac--;


	//Can den ba�ka bir sorgunun cevab� beklenirken tekrar uart sorusu gelince tekrar g�nderme i�lemleri
	//Can me�gulken Uartta buffer lanan datay� tekrar 50 ms (ayarlanan) sonra g�nderir.
	if( Uart1.Tekrar > 0 )
	{
		Uart1.Tekrar--;
		if( Uart1.Tekrar == 0 )
		{	
			if( Can.ToInv.Gonderildi.Bit.U1_R )
			{
				Can.ToInv.Gonderildi.Bit.U1_R = 0; 
				U1_Gonder("RTOUT",Uart1.Dumm);
			}
			else if( Can.ToPfc.Gonderildi.Bit.U1_R )
			{
				Can.ToPfc.Gonderildi.Bit.U1_R = 0;
				U1_Gonder("RTOUT",Uart1.Dumm);
			}
			if( Can.ToInv.Gonderildi.Bit.U1_L )
			{
				Can.ToInv.Gonderildi.Bit.U1_L = 0; 
				U1_Gonder("RTOUT",Uart1.Dumm);
			}
			else if( Can.ToPfc.Gonderildi.Bit.U1_L )
			{
				Can.ToPfc.Gonderildi.Bit.U1_L = 0;
				U1_Gonder("RTOUT",Uart1.Dumm);
			}
			if( Can.ToInv.Gonderildi.Bit.U1_W )
			{
				Uart1.EmirGonderildi = 0;
				Can.ToInv.Gonderildi.Bit.U1_W = 0; 
				U1_Gonder("RTOUT",Uart1.Dumm);
			}
			else if( Can.ToPfc.Gonderildi.Bit.U1_W )
			{
				Uart1.EmirGonderildi = 0;
				Can.ToPfc.Gonderildi.Bit.U1_W = 0;
				U1_Gonder("RTOUT",Uart1.Dumm);
			}
		}
		else
		{
			if( (Can.ToInv.Gonderildi.Bit.U1_R == 1) || (Can.ToInv.Gonderildi.Bit.U1_L == 1) || (Can.ToInv.Gonderildi.Bit.U1_W == 1) )
			{
				Uart1.TekrarGondermeSayacInv++;
				if(Uart1.TekrarGondermeSayacInv > 5)
				{
					Uart1.TekrarGondermeSayacInv = 0;
				CanGonder(Can.ToInv.TekrarIcinBuff[0],Can.ToInv.TekrarIcinBuff[1],Can.ToInv.TekrarIcinBuff[2],Can.ToInv.TekrarIcinBuff[3],Can.ToInv.TekrarIcinBuff[4] );
				}
		}
		if( (Can.ToPfc.Gonderildi.Bit.U1_R == 1) || (Can.ToPfc.Gonderildi.Bit.U1_L == 1) || (Can.ToPfc.Gonderildi.Bit.U1_W == 1) )
		{
				Uart1.TekrarGondermeSayacPfc++;
				if(Uart1.TekrarGondermeSayacPfc > 5)
				{
					Uart1.TekrarGondermeSayacPfc = 0;
				CanGonder(Can.ToPfc.TekrarIcinBuff[0],Can.ToPfc.TekrarIcinBuff[1],Can.ToPfc.TekrarIcinBuff[2],Can.ToPfc.TekrarIcinBuff[3],Can.ToPfc.TekrarIcinBuff[4] );
				}
			}
		}
	}	
	if( Uart2.Tekrar > 0 )
	{
		Uart2.Tekrar--;
		if( Uart2.Tekrar == 0 )
		{	
			if( Can.ToInv.Gonderildi.Bit.U2_R )
			{
				Can.ToInv.Gonderildi.Bit.U2_R = 0; 
				U2_Gonder("RTOUT",Uart2.Dumm);
			}
			else if( Can.ToPfc.Gonderildi.Bit.U2_R )
			{
				Can.ToPfc.Gonderildi.Bit.U2_R = 0;
				U2_Gonder("RTOUT",Uart2.Dumm);
			}
			else if( Can.ToInv.Gonderildi.Bit.U2_L )
			{
				Can.ToInv.Gonderildi.Bit.U2_L = 0; 
				U2_Gonder("RTOUT",Uart2.Dumm);
			}
			else if( Can.ToPfc.Gonderildi.Bit.U2_L )
			{
				Can.ToPfc.Gonderildi.Bit.U2_L = 0;
				U2_Gonder("RTOUT",Uart2.Dumm);
			}
			else if( Can.ToInv.Gonderildi.Bit.U2_W )
			{
				Uart2.EmirGonderildi = 0;
				Can.ToInv.Gonderildi.Bit.U2_W = 0; 
				U2_Gonder("RTOUT",Uart2.Dumm);
			}
			if( Can.ToPfc.Gonderildi.Bit.U2_W )
			{
				Uart2.EmirGonderildi = 0;
				Can.ToPfc.Gonderildi.Bit.U2_W = 0;
				U2_Gonder("RTOUT",Uart2.Dumm);
			}
		}
		else
		{
			if( (Can.ToInv.Gonderildi.Bit.U2_R == 1) || (Can.ToInv.Gonderildi.Bit.U2_L == 1) || (Can.ToInv.Gonderildi.Bit.U2_W == 1) ) 
			{
				Uart2.TekrarGondermeSayacInv++;
				if(Uart2.TekrarGondermeSayacInv > 5)
				{
					Uart2.TekrarGondermeSayacInv = 0;
					CanGonder(Can.ToInv.TekrarIcinBuff[0],Can.ToInv.TekrarIcinBuff[1],Can.ToInv.TekrarIcinBuff[2],Can.ToInv.TekrarIcinBuff[3],Can.ToInv.TekrarIcinBuff[4] );
				}
			}
			if( (Can.ToPfc.Gonderildi.Bit.U2_R == 1) || (Can.ToPfc.Gonderildi.Bit.U2_L == 1) || (Can.ToPfc.Gonderildi.Bit.U2_W == 1) )
			{
				Uart2.TekrarGondermeSayacPfc++;
				if(Uart2.TekrarGondermeSayacPfc > 5)
				{
					Uart2.TekrarGondermeSayacPfc = 0;
					CanGonder(Can.ToPfc.TekrarIcinBuff[0],Can.ToPfc.TekrarIcinBuff[1],Can.ToPfc.TekrarIcinBuff[2],Can.ToPfc.TekrarIcinBuff[3],Can.ToPfc.TekrarIcinBuff[4] );
				}
			}
		}
	}
	
	
	
	if( ++Timer6.Ms50 > 1 )				//0,1 saniye
	{
		Timer6.Ms50 = 0;
		Timer.Bit.Sn0_1 ^= 1;
		
		//Mimic ��lemleri
		if( MimikDurum.MimikUpdateSayac > 0 )	
		{
			if( Menu.AnaSekme == 1 )
				MimikDurum.MimikUpdateSayac--;
			if( MimikDurum.MimikUpdateSayac == 1 )
			{
				if( Menu.AnaSekme == 1 )
					MimikDurum.MimikUpdate = 1;
			}
		}
	}	
	if( ++Timer6.Ms50_7 > 4 )			//0,25 saniye
	{
		Timer6.Ms50_7 = 0;		
		Timer.Bit.Sn0_25 = 1;
		
		if( Menu.GenInSayac > 0 )
			Menu.GenInSayac--;
		if( Menu.EmcStopSayac > 0 )
			Menu.EmcStopSayac--;
		if( Menu.BattSwSayac > 0 )
			Menu.BattSwSayac--;
		if( Menu.In2OptSayac > 0 )
			Menu.In2OptSayac--;
		if( Menu.In3OptSayac > 0 )
			Menu.In3OptSayac--;
			
//		if( Genel.GenInSayac > 0 )		//22.07.14 silindi
//			Genel.GenInSayac--;
//		if( Genel.EmcStopSayac > 0 )
//			Genel.EmcStopSayac--;
		if( Genel.BattSwSayac > 0 )		//22.07.14  0.65 sn deydi buraya getirildi.
			Genel.BattSwSayac--;
		if( Genel.BattSwSayac2 > 0 )
			Genel.BattSwSayac2--;
		if( Genel.In2OptSayac > 0 )
			Genel.In2OptSayac--;
		if( Genel.In3OptSayac > 0 )
			Genel.In3OptSayac--;
	}	

	//06.07.2015 tarihinde eklendi. Genel Alarm
	if( (Alarm.Word.Pfc1.All>0) || (Alarm.Word.Inv1.All>0) ) 
		Alarm.Word.Lcd1.Bit.GENEL_ALARM = 1;
	else
		Alarm.Word.Lcd1.Bit.GENEL_ALARM = 0;
	//50 ms de bir analaog �l��m al�r.
//	if( Genel.Th1Sayac > 19 )
//		Genel.Th1Sayac = 0;
//	if( EeKayit.LcdBacklight == 8 )
//		Genel.Th1Adc[Genel.Th1Sayac++] = AdcOku(TH1)+15;
//	else if( EeKayit.LcdBacklight == 4 )
//		Genel.Th1Adc[Genel.Th1Sayac++] = AdcOku(TH1)+5;
//	else if( EeKayit.LcdBacklight == 2 )
//		Genel.Th1Adc[Genel.Th1Sayac++] = AdcOku(TH1);
//		
//	if( Genel.Th2Sayac > 19 )
//		Genel.Th2Sayac = 0;
//	if( EeKayit.LcdBacklight == 8 )
//		Genel.Th2Adc[Genel.Th2Sayac++] = AdcOku(TH2)+15;
//	if( EeKayit.LcdBacklight == 4 )
//		Genel.Th2Adc[Genel.Th2Sayac++] = AdcOku(TH2)+5;
//	if( EeKayit.LcdBacklight == 2 )
//		Genel.Th2Adc[Genel.Th2Sayac++] = AdcOku(TH2);
	
	Genel.Besleme = AdcOku(AN12);
	Genel.BeslemeFark = Genel.Besleme - EeKayit.BeslemeIlk;
	//50 ms de bir analaog �l��m al�r.
	if( Genel.Th1Sayac > 19 )
	{
		Genel.Th1Sayac = 0;
		Genel.Th1AdcValue = 0;														//02.10.2013
		for(Genel.ThSayac = 0;Genel.ThSayac < 20;Genel.ThSayac++)
			Genel.Th1AdcValue = Genel.Th1AdcValue + Genel.Th1Adc[Genel.ThSayac];
		Genel.Th1AdcValue = Genel.Th1AdcValue / 20;
	}
	Genel.Th1Adc[Genel.Th1Sayac++] = AdcOku(TH1) - ((Genel.BeslemeFark*2)/3);
	if( Genel.Th2Sayac > 19 )
	{
		Genel.Th2Sayac = 0;
		Genel.Th2AdcValue = 0;														//02.10.2013
		for(Genel.ThSayac = 0;Genel.ThSayac < 20;Genel.ThSayac++)
			Genel.Th2AdcValue = Genel.Th2AdcValue + Genel.Th2Adc[Genel.ThSayac];
		Genel.Th2AdcValue = Genel.Th2AdcValue / 20;	
	}
	Genel.Th2Adc[Genel.Th2Sayac++] = AdcOku(TH2) - ((Genel.BeslemeFark*2)/3);
	
	if( ++Timer6.Ms50_1 > 9 )			//0,5 saniye
	{
		Timer6.Ms50_1 = 0;
		Timer.Bit.Sn0_5 ^= 1;
		Timer.Bit.Sn0_5__2 ^= 1;
		
		//RTC fonksiyonu Interrupt tan �al��t�r�lmak isteniyorsa alttaki  kald�r�l�r.		
		OkuRTC(&Date);
		Can.ToInv.Date_2.Day = Date.Day;										//23.11.2014 tarihinde eklendi
		Can.ToInv.Date_2.Hour = Date.Hour;
		Can.ToInv.Date_2.Min = Date.Min;
		Can.ToInv.Date_2.Month = Date.Month;
		Can.ToInv.Date_2.Sec = Date.Sec;	
		Can.ToInv.Date_2.Year = Date.Year;
		
		
		if( Date.Min != EskiDakika )
		{
			EskiDakika = Date.Min;
			Menu.TimeUpdate = 1;
		}
		if( Date.Sec != EskiSaniye )
		{
			EskiSaniye = Date.Sec;
			if((Menu.Sekme.All == DefAnaMenu)&&(Menu.AnaSekme==DefZamanMenu))
			{
				if( Menu.ZamanAyarIci==0 )
					Menu.YenileGeriSayac = 2;
			}
		}
		
		//S�cakl�k sensor alarmlar�
		if( EeKayit.Konfig.Bit.TermalSensor1 )
		{
//			Genel.Th1AdcValue = 0;
//			for(Genel.ThSayac = 0;Genel.ThSayac < 20;Genel.ThSayac++)
//				Genel.Th1AdcValue = Genel.Th1AdcValue + Genel.Th1Adc[Genel.ThSayac];
//			Genel.Th1AdcValue = Genel.Th1AdcValue / 20;
			
			//Sens�r a��k devre oldu�unda problemli demektir.Sensor hatas� verilir.
			if( Genel.Th1AdcValue < 960 )
			{
				if( Genel.Th1AdcValue == 0)
				{ EeKayit.TermalSensor1.Olculen = 1022;	}
				else
				{
					if( Genel.Th1AdcValue < EeKayit.TermalSensor1.Kalibrator )
						EeKayit.TermalSensor1.Olculen = 250 - (((long)((EeKayit.TermalSensor1.Kalibrator - Genel.Th1AdcValue) * 378)) / 100 );
					else
						EeKayit.TermalSensor1.Olculen = (((long)((Genel.Th1AdcValue - EeKayit.TermalSensor1.Kalibrator) * 378)) / 100 ) + 250;
				}
			}
			else
			{ EeKayit.TermalSensor1.Olculen = 1022;	}
			
			if((EeKayit.TermalSensor1.AlrDusuk < 32767)&&(EeKayit.TermalSensor1.Olculen < 32767))
			{		
				if(( EeKayit.TermalSensor1.Olculen == 1022 ))
				{	Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 1;}
				else if( EeKayit.TermalSensor1.Olculen > EeKayit.TermalSensor1.AlrYuksek )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor1Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 1;
					else
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
				}
				else if( EeKayit.TermalSensor1.Olculen < EeKayit.TermalSensor1.AlrDusuk )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor1Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 1; 
					else
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0; 
				}
				else 
				{
					Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 0;
				}
			}
			else if((EeKayit.TermalSensor1.AlrDusuk > 32767)&&(EeKayit.TermalSensor1.Olculen < 32767))
			{
				if(( EeKayit.TermalSensor1.Olculen == 1022 ))
				{	Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 1;}
				if( EeKayit.TermalSensor1.Olculen > EeKayit.TermalSensor1.AlrYuksek )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor1Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 1;
					else
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
				}
				else 
				{
					Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 0;
				}
			}
			else if((EeKayit.TermalSensor1.AlrDusuk > 32767)&&(EeKayit.TermalSensor1.Olculen > 32767))
			{
				if(( EeKayit.TermalSensor1.Olculen == 1022 ))
				{	Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 1;}
				if( EeKayit.TermalSensor1.Olculen < EeKayit.TermalSensor1.AlrDusuk )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor1Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 1; 
					else
						Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0; 
				}
				else 
				{
					Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 0;
				}
			}
			else if((EeKayit.TermalSensor1.AlrDusuk < 32767)&&(EeKayit.TermalSensor1.Olculen > 32767))
				Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 1; 
				
			if( Alarm.Word.Lcd1.Bit.TermalSensor1Ariza == 1 )
			{
				Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
				Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0;
			}
		}
		else 
		{
			//Th1 not used yap�lma durumunda Inv nin anlamas� i�in
			EeKayit.TermalSensor1.Olculen = 1023;
			Alarm.Word.Lcd1.Bit.TermalSensor1IsiYuksek = 0;
			Alarm.Word.Lcd1.Bit.TermalSensor1IsiDusuk = 0;
			Alarm.Word.Lcd1.Bit.TermalSensor1Ariza = 0;
		}
			
		if( EeKayit.Konfig.Bit.TermalSensor2 )
		{
//			Genel.Th2AdcValue = 0;
//			for(Genel.ThSayac = 0;Genel.ThSayac < 20;Genel.ThSayac++)
//				Genel.Th2AdcValue = Genel.Th2AdcValue + Genel.Th2Adc[Genel.ThSayac];
//			Genel.Th2AdcValue = Genel.Th2AdcValue / 20;			
			
			//Sens�r a��k devre oldu�unda problemli demektir.Sensor hatas� verilir.
			if( Genel.Th2AdcValue < 960 )
			{
				if( Genel.Th2AdcValue == 0)
				{ EeKayit.TermalSensor2.Olculen = 1022;	}
				else
				{
					if( Genel.Th2AdcValue < EeKayit.TermalSensor2.Kalibrator )
						EeKayit.TermalSensor2.Olculen = 250 - (((long)((EeKayit.TermalSensor2.Kalibrator - Genel.Th2AdcValue) * 378)) / 100 );
					else
						EeKayit.TermalSensor2.Olculen = (((long)((Genel.Th2AdcValue - EeKayit.TermalSensor2.Kalibrator) * 378)) / 100 ) + 250;
				}
			}	
			else
			{ EeKayit.TermalSensor2.Olculen = 1022;	}
				
			if((EeKayit.TermalSensor2.AlrDusuk < 32767)&&(EeKayit.TermalSensor2.Olculen < 32767))
			{		
				if(( EeKayit.TermalSensor2.Olculen == 1022 ))
				{	Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 1;}
				else if( EeKayit.TermalSensor2.Olculen > EeKayit.TermalSensor2.AlrYuksek )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor2Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 1;
					else
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
				}
				else if( EeKayit.TermalSensor2.Olculen < EeKayit.TermalSensor2.AlrDusuk )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor2Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 1; 
					else
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0; 
				}
				else 
				{
					Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 0;
				}
			}
			else if((EeKayit.TermalSensor2.AlrDusuk > 32767)&&(EeKayit.TermalSensor2.Olculen < 32767))
			{
				if(( EeKayit.TermalSensor2.Olculen == 1022 ))
				{	Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 1;}
				if( EeKayit.TermalSensor2.Olculen > EeKayit.TermalSensor2.AlrYuksek )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor2Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 1;
					else
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
				}
				else 
				{
					Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 0;
				}
			}
			else if((EeKayit.TermalSensor2.AlrDusuk > 32767)&&(EeKayit.TermalSensor2.Olculen > 32767))
			{
				if(( EeKayit.TermalSensor2.Olculen == 1022 ))
				{	Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 1;}
				if( EeKayit.TermalSensor2.Olculen < EeKayit.TermalSensor2.AlrDusuk )
				{	
					if(Alarm.Word.Lcd1.Bit.TermalSensor2Ariza == 0)
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 1; 
					else
						Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0; 
				}
				else 
				{
					Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0;
					Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 0;
				}
			}
			else if((EeKayit.TermalSensor2.AlrDusuk < 32767)&&(EeKayit.TermalSensor2.Olculen > 32767))
				Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 1; 
				
				
			if( Alarm.Word.Lcd1.Bit.TermalSensor2Ariza == 1 )
			{
				Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
				Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0;
			}
		}
		else 
		{
			EeKayit.TermalSensor2.Olculen = 1023;
			Alarm.Word.Lcd1.Bit.TermalSensor2IsiYuksek = 0;
			Alarm.Word.Lcd1.Bit.TermalSensor2IsiDusuk = 0;
			Alarm.Word.Lcd1.Bit.TermalSensor2Ariza = 0;
		}		
		
	}		
	
	if( ++Timer6.Ms50_9 > 12 )			//0,65 saniye
	{	
		if( Can.FromInv.PowerWatt.L1 > Can.FromInv.PowerVa.L1 )
			Can.FromInv.PowerWatt.L1 = Can.FromInv.PowerVa.L1;
		if( Can.FromInv.PowerWatt.L2 > Can.FromInv.PowerVa.L2 )
			Can.FromInv.PowerWatt.L2 = Can.FromInv.PowerVa.L2;
		if( Can.FromInv.PowerWatt.L3 > Can.FromInv.PowerVa.L3 )
			Can.FromInv.PowerWatt.L3 = Can.FromInv.PowerVa.L3;
			
		if( Can.FromInv.PowerVa.L1 > 10 )
		{
			Can.FromInv.Pf.L1 = (unsigned int)((long)((long)Can.FromInv.PowerWatt.L1*100) / Can.FromInv.PowerVa.L1);
			if( Can.FromInv.Pf.L1 > 100 )
				Can.FromInv.Pf.L1 = 100;
		}
		if( Can.FromInv.PowerVa.L2 > 10 )
		{
			Can.FromInv.Pf.L2 = (unsigned int)((long)((long)Can.FromInv.PowerWatt.L2*100) / Can.FromInv.PowerVa.L2);
			if( Can.FromInv.Pf.L2 > 100 )
				Can.FromInv.Pf.L2 = 100;
		}
		if( Can.FromInv.PowerVa.L3 > 10 )
		{
			Can.FromInv.Pf.L3 = (unsigned int)((long)((long)Can.FromInv.PowerWatt.L3*100) / Can.FromInv.PowerVa.L3);
			if( Can.FromInv.Pf.L3 > 100 )
				Can.FromInv.Pf.L3 = 100;
		}
			
		Timer6.Ms50_9 = 0;
		Timer.Bit.Sn0_65 ^= 1;		
		
	}
	if( ++Timer6.Ms50_2 > 19 )			//1 saniye
	{
		Timer6.Ms50_2 = 0;

		Timer.Bit.Sn1 ^= 1;
		Timer.Bit.Sn1__2 ^= 1;
		Timer.Bit.Sn1__3 = 1;
		Timer.Bit.Sn1__4 ^= 1;	
			
		
		if( Genel.TFTRESET > 0 )				//05.02.2015
		{
			Genel.TFTRESET--;
			if( Genel.TFTRESET == 0 )
			{
				Genel.TFTRESETFLAG = 1;
				Genel.TFTRESET = 400;
			}
		}
		
		//�lk 5 sn alarm g�sterme ve log kay�t i�lemleri yap�lmas�n diye saya�
		if(++Menu.Satir4GosterIzin > 10 )
			Menu.Satir4GosterIzin = 10;
			
		//Megatech Emirleri i�in
		if( Timer6.ShutdownTime > 0 )
		{
			Alarm.Word.Lcd2.Bit.Uykuyagirecek = 1;
			Timer6.ShutdownTime--;
			if( Timer6.ShutdownTime == 0 )				
				Alarm.Word.Lcd2.Bit.Uykuyagirecek = 0;
			if( Timer6.ShutdownTime == 1 )
			{
				Alarm.Word.Lcd2.Bit.Uykuyagirecek = 0;
				CanGonder(DefCanInv,28,'W',DefEmir_Uyu,0);
			}
		}
		else
		{
			if( Timer6.RestoreTime > 0 )
			{
				Alarm.Word.Lcd2.Bit.Uyanacak = 1;
				Timer6.RestoreTime--;
				if( Timer6.RestoreTime == 0 )	
					Alarm.Word.Lcd2.Bit.Uyanacak = 0;
				if( Timer6.RestoreTime == 1 )
				{
					Alarm.Word.Lcd2.Bit.Uyanacak = 0;
					CanGonder(DefCanInv,28,'W',DefEmir_Uyan,0);
				}
			}
			else
			{
				Alarm.Word.Lcd2.Bit.Uyanacak = 0;
				Alarm.Word.Lcd2.Bit.Uykuyagirecek = 0;
			}
			
		}
		
//		//Status Menu de kalan zaman� g�stersin ( Ge�ici )
//		if(( Menu.Koordinat == 257 ) || ( Menu.Koordinat == 258 ) || ( Menu.Koordinat == 259 ))
//		{
//			LcdFonk(StatusMenu[2][EeKayit.Dil],&Menu.AkuKalanSure,0,1,1);
//		}
	}
	if( ++Timer6.Ms50_8 > 24 )			//1,25 saniye
	{
		Timer6.Ms50_8 = 0;
		Timer.Bit.Sn1_25 ^= 1;	
	}
	if( ++Timer6.Ms50_3 > 29 )			//1,5 saniye
	{
		Timer6.Ms50_3 = 0;
		Timer.Bit.Sn1_5 ^= 1;
	}
	if( ++Timer6.Ms50_4 > 39 )			//2 saniye
	{
		Timer6.Ms50_4 = 0;
		
		if( ++TftInitBackCounter > 1800)										//09.07.2013
		{
			TftInitBackCounter = 0;
	//		TftInitFlag = 1;
			TftInitFlag = 0;
		}
		
		//R�le simulasyonu s�ras�nda bir s�reli�ine alarma ba�l� r�le �ekmesin
		if( Menu.RoleTestSayac > 0 )
			Menu.RoleTestSayac--;
		
		//E�er User PAss �ifresi i�in 15 dk l�k geri sayac
		if( Genel.UserPassGeriSayac > 0 )
		{
			Genel.UserPassGeriSayac--;
			if( Genel.UserPassGeriSayac == 1 )
			{
				//Servis login ise user login i s�f�rlama
				if( Can.FromInv.LogInDurum == 0 )
				{
					Genel.UserPassDogru15dklikIzin = 0;
					CanGonder(DefCanInv,28,'W',DefEmir_LogOut,0);
				}
			}
		}
		
		Timer.Bit.Sn2 ^= 1;	
	}
	if( ++Timer6.Ms50_5 > 39 )			//2,5 saniye
	{
		Timer6.Ms50_5 = 0;
		Timer.Bit.Sn2_5 = 1;
	}
	if( ++Timer6.Ms50_6 > 39 )			//3 saniye
	{
		Timer6.Ms50_6 = 0;
		Timer.Bit.Sn3 ^= 1;	
	}
	IFS2bits.T6IF = 0;	
}
//R3227 adresinden gelen de�er �uan i�in 500 ile 420 aras�ndaysa kabul de�ilse cihaz kalkmaz.
//Giri� DC ka�ak �rne�i al�n�yor. Sonra Can �zerinden Pfc ye g�nderiliyor.
void __attribute__((__interrupt__)) _T3Interrupt(void)					//400us
{
	static unsigned int Timer3_i = 0;
	
//	if( AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage == 1 )
//	{
		Genel.GirisDCKacakADC = AdcOku(AN10);
		Genel.GirisDcKacakVrefADC = AdcOku(AN11);
		Timer3_i++;
		if( Timer3_i > 80 )
		{
			Timer3_i = 0;
			Genel.DcGirisKacak_L = Genel.DcGirisKacak_L / 80;
			Genel.GirisDcKacakVref_L = Genel.GirisDcKacakVref_L / 80;
			Genel.GirisDcKacakVref_L = (Genel.GirisDcKacakVref_L * 393) / 100;

			Genel.GirisDcKacak = (int)((Genel.DcGirisKacak_L) - Genel.GirisDcKacakVref_L);
			Basla[7] = (Genel.GirisDCKacakAlr+(Can.FromInv.LogInDurum*2));
			
			if(( Genel.GirisDcKacak > 19 ) || ( Genel.GirisDcKacak < (-20) ))
				Genel.GirisDCKacakAlr = 1;
			else
				Genel.GirisDCKacakAlr = 0;
			Genel.DcGirisKacak_L = 0;
			Genel.GirisDcKacakVref_L = 0;
		}	
		else	
		{
			Genel.DcGirisKacak_L = Genel.DcGirisKacak_L + Genel.GirisDCKacakADC;
			Genel.GirisDcKacakVref_L = Genel.GirisDcKacakVref_L + Genel.GirisDcKacakVrefADC;
		}
//	}
//	else
//		Genel.GirisDCKacakAlr = 0;
	
	IFS0bits.T3IF = 0;	
}
//Bak�m timer' � 10 dk bir gelir.
void __attribute__((__interrupt__)) _T5Interrupt(void)									
{		
    BakimHesaplaFlag = 1;
	IFS1bits.T5IF = 0;													//Clear TIMER5 Interrupt flag			
}
void __attribute__((__interrupt__)) _T2Interrupt(void)								//25us lik timer
{
	if(TFT.TftTimer > 0)
		TFT.TftTimer--;
    if( BekleCounter > 0 )
        BekleCounter--;
    
    if( BuzzerGeriSayac > 2 )
    {
        BuzzerGeriSayac--;
        if(BuzzerGeriSayac == 2)
        {
            BuzzerGeriSayac = 1;
            Buzzer = 0;
        }
    }
	IFS0bits.T2IF = 0;	
}

//Can Kesmeleri
void __attribute__((__interrupt__))_C1Interrupt(void)
{
	C1RXFUL1 = 0;
	C1RXFUL1 = 0;
	C1RXOVF1 = 0;
	C1RXOVF1 = 0;
	IFS2bits.C1IF = 0;
	C1INTF = 0;
	C1INTFbits.TBIF = 0;
	C1INTFbits.RBIF = 0;
}
void __attribute__((__interrupt__)) _DMA1Interrupt(void)
{
	//Inv den gelen datalar.
	if (C1VECbits.ICODE == 1)												
	{
		Can.FromInv.InvGeldi = 1;
		Can.FromInv.InvBuff[0] = ecanmsgbuf[1][3];
		Can.FromInv.InvBuff[1] = ecanmsgbuf[1][4];
		Can.FromInv.InvBuff[2] = ecanmsgbuf[1][5];
		Can.FromInv.InvBuff[3] = ecanmsgbuf[1][6];	
	}
	//Pfc den gelen datalar.
	else if(C1VECbits.ICODE == 2)											
	{
		Can.FromPfc.PfcGeldi = 1;
		Can.FromPfc.PfcBuff[0] = ecanmsgbuf[2][3];
		Can.FromPfc.PfcBuff[1] = ecanmsgbuf[2][4];
		Can.FromPfc.PfcBuff[2] = ecanmsgbuf[2][5];
		Can.FromPfc.PfcBuff[3] = ecanmsgbuf[2][6];
	}
	IFS0bits.DMA1IF = 0;												//CLEAR DMA1 INTERRUPT FLAG
}
//Uart Kesmeleri
void __attribute__ ((interrupt, no_auto_psv)) _U1RXInterrupt(void) 
{
	Uart1.BaudRateKontrolSayac = 2;
	if( Uart1.LokalSayac > 16 )
	{
		Uart1.LokalSayac = 0;
		Uart1.Flag = 0;
	}
	Uart1.DataBuf[Uart1.LokalSayac++] = U1RXREG;	
	if( Uart1.DataBuf[Uart1.LokalSayac - 1] == 13 )
	{
		Uart1.GlobalSayac = Uart1.LokalSayac;
		Uart1.LokalSayac = 0;
		Uart1.Flag = 1;
		Uart1.Aktif = 1;												//Data geldi.
		Uart1.ErrSayac = 6;												//Haberle�me kontrol geri sayac�
		Uart1.AktifSayac = 12;
	}
	IFS0bits.U1RXIF = 0;										
}
void __attribute__ ((interrupt, no_auto_psv)) _U1TXInterrupt(void) 
{
	IFS0bits.U1TXIF = 0;
}
void __attribute__ ((interrupt, no_auto_psv)) _U2RXInterrupt(void) 
{
	Uart2.BaudRateKontrolSayac = 2;
	if( Uart2.LokalSayac > 16 )
	{
		Uart2.LokalSayac = 0;
		Uart2.Flag = 0;
	}
	Uart2.DataBuf[Uart2.LokalSayac++] = U2RXREG;	
	if( Uart2.DataBuf[Uart2.LokalSayac - 1] == 13 )
	{
		Uart2.GlobalSayac = Uart2.LokalSayac;
		Uart2.LokalSayac = 0;
		Uart2.Flag = 1;
		Uart2.Aktif = 1;												//Data geldi.
		Uart2.ErrSayac = 6;												//Haberle�me kontrol geri sayac�
		Uart2.AktifSayac = 12;
	}
	IFS1bits.U2RXIF = 0;
}
void __attribute__ ((interrupt, no_auto_psv)) _U2TXInterrupt(void) 
{
	IFS1bits.U2TXIF = 0;
}

//Spi Kesmeleri
void __attribute__((__interrupt__)) _SPI1Interrupt(void)				//Rtc
{ 
	IFS0bits.SPI1IF = 0;
}
void __attribute__((__interrupt__)) _SPI2Interrupt(void)				//Eeprom
{
	IFS2bits.SPI2IF = 0;  										
}
void __attribute__ ((interrupt, no_auto_psv)) _INT4Interrupt( void )	//Rtc 1sn lik kesme			
{		
	IFS3bits.INT4IF = 0;  
}
//Pwm LcdBacklight i�in
void __attribute__((__interrupt__)) _PWMInterrupt(void)
{
	IFS3bits.PWMIF = 0;														//Clear PWM Interrupt flag
}
//Buton Kesmeleri
void __attribute__((__interrupt__)) _CNInterrupt(void)
{
	if( TftInitFlag == 0 )												//09.07.2013 TFT	
	{
		//Butonlar ili�kilendirilir.
		if( Asagi == 0 )
			Menu.Buton.Bit.bYukari = 1;
		else
			Menu.Buton.Bit.bYukari = 0;
			
		if( Yukari == 0 )
			Menu.Buton.Bit.bAsagi = 1;
		else
			Menu.Buton.Bit.bAsagi = 0;
			
		if( Enter == 0 )
			Menu.Buton.Bit.bEnter = 1;
		else
			Menu.Buton.Bit.bEnter = 0;
										
		if( Sag == 0 )
			Menu.Buton.Bit.bSag = 1;
		else
			Menu.Buton.Bit.bSag = 0;
			
		if( Sol == 0 )
			Menu.Buton.Bit.bSol = 1;
		else
			Menu.Buton.Bit.bSol = 0;
			
		//Butona bas�ld���nda yap�lan i�lemler.	
		if( Menu.Buton.All != 0 )
		{
			//Bir �nceki durumda Buzzer �tm�yorsa sayac y�kle. 
			//Yoksa arka arkaya basmalarda buzzer s�rekli �t�yor.
			if( Buzzer == 0 )
				Menu.BuzzerGeriSayac = 2;	//50 ms x 2 = 100 ms i�in
			//Alarm varsa buton buzzeri �tmesin.
			if( Menu.MaskeAlarmSesAcik == 0 )// if( Menu.AlarmSesAcik == 0 )
			{
				if( DefBuzzerDurum == 1 )
					Buzzer = EeKayit.Konfig.Bit.ButonTik; 
			}
			//50ms * 5 == 250 ms i�erisinde bir daha bas�l�rsa buton i�lemi yapma.
			if( Timer6.Ms50_10 > 4 )
			{		
				Genel.UPSKapaliGeriSayac = 1200;		//Ups kapal� olma durumunda 1 dk. i�in men�leri g�sterir. 					//23.11.2012 de eklendi.								
				Menu.ButonBayrak = 1;				
		
				if(( CalismaDurumu.Bit.Bit0 == 1 ) && ( Genel.UpsKapaliButonIlkBas == 0 ))
				{
					Genel.UpsKapaliButonIlkBas = 1;
					UPS_Durdu_Fonk();
					MimikFonk(1);
				}
		
				Timer6.Ms50_10 = 0;
			}
		}
		TftInitBackCounter = 0;					//09.07.2013 TFT yeniden ba�latma i�in ar�za durumunda kullan�lacak.
	}
	IFS1bits.CNIF = 0;
}