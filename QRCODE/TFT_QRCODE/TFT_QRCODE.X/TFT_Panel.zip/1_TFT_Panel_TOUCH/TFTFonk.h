#ifndef __TFTFONK_H__
#define __TFTFONK_H__


extern void Loading(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned long ,unsigned long ,unsigned long ,unsigned int );
extern void EkranKoruyucu(void);

extern unsigned int AdcOku(unsigned int );
extern unsigned int Dig(unsigned int ,int );
extern void AyarSecenekOK(unsigned int ,unsigned int );
extern void AyarSecenekOK2(unsigned int ,unsigned int );
extern void OptimizasyonFonk1(unsigned int ,unsigned int ,unsigned int );
extern void OptimizasyonFonk2(unsigned long ,unsigned int );
extern void OptimizasyonFonk3(unsigned long ,unsigned int );
extern void OptimizasyonFonk4(unsigned int );
extern void BakimHesapla(void);
#endif