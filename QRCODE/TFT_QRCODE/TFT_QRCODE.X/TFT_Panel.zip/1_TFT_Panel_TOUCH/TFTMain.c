#include "p33FJ256MC710.h"

#include "TFTVar.h"
#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTCanPfc.h"
#include "TFTCanInv.h"
#include "TFTEeprom.h"
#include "TFTUart1.h"
#include "TFTRtc.h"
#include "BigTable.h"
#include "TFTTablo.h"
#include "TFTFonk.h"
#include <xc.h>

// FBS
#pragma config BWRP = WRPROTECT_OFF     // Boot Segment Write Protect (Boot Segment may be written)
#pragma config BSS = NO_FLASH           // Boot Segment Program Flash Code Protection (No Boot program Flash segment)
#pragma config RBS = NO_RAM             // Boot Segment RAM Protection (No Boot RAM)

// FSS
#pragma config SWRP = WRPROTECT_OFF     // Secure Segment Program Write Protect (Secure Segment may be written)
#pragma config SSS = NO_FLASH           // Secure Segment Program Flash Code Protection (No Secure Segment)
#pragma config RSS = NO_RAM             // Secure Segment Data RAM Protection (No Secure RAM)

// FGS
#pragma config GWRP = OFF               // General Code Segment Write Protect (User program memory is not write-protected)
#pragma config GSS = OFF                // General Segment Code Protection (User program memory is not code-protected)

// FOSCSEL
#pragma config FNOSC = FRCPLL           // Oscillator Mode (Internal Fast RC (FRC) w/ PLL)
#pragma config IESO = ON                // Two-speed Oscillator Start-Up Enable (Start up with FRC, then switch)

// FOSC
#pragma config POSCMD = XT              // Primary Oscillator Source (XT Oscillator Mode)
#pragma config OSCIOFNC = OFF           // OSC2 Pin Function (OSC2 pin has clock out function)
#pragma config FCKSM = CSECMD           // Clock Switching and Monitor (Clock switching is enabled, Fail-Safe Clock Monitor is disabled)

// FWDT
#pragma config WDTPOST = PS1024          // Watchdog Timer Postscaler (1:512)
#pragma config WDTPRE = PR128           // WDT Prescaler (1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF            // Watchdog Timer Enable (Watchdog timer enabled/disabled by user software)

// FPOR
#pragma config FPWRT = PWR128           // POR Timer Value (128ms)
#pragma config LPOL = ON                // Low-side PWM Output Polarity (Active High)
#pragma config HPOL = ON                // Motor Control PWM High Side Polarity bit (PWM module high side output pins have active-high output polarity)
#pragma config PWMPIN = ON              // Motor Control PWM Module Pin Mode bit (PWM module pins controlled by PORT register at device Reset)

// FICD
#pragma config ICS = PGD2               // Comm Channel Select (Communicate on PGC1/EMUC1 and PGD1/EMUD1)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG is Disabled)
//_FWDT(FWDTEN_OFF & WDTPRE_PR128 & WDTPOST_PS512);
//_FOSCSEL(FNOSC_FRCPLL);
//_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT);


void main(void) 
{ 
	unsigned int main_i,main_k = 0,main_j = 0;
	unsigned long main_z;
	
	XtOsc();
	Initiliaze();
		
	
		
	LINEREPEAT = 2;
	TRANSPARIENT = 0;
	GRADIENT = Gradient;												//Gradient olup olmad��� se�ilir.
	GRADIENTCOLOR = Blue;												//Gradient rengi se�ilir.
	GRADIENTSTART = 0x000022;											//Gradient ba�lama rengi yaz�l�r.
//	NOTGRADIENTCOLOR = 0xff0000;										//Gradient de�ilse Silme i�lemi i�in Yaz�rengi belirlenir.
	if(GRADIENTCOLOR == Red)
		NOTGRADIENTCOLOR = 0xff0000;
	if(GRADIENTCOLOR == Blue)
		NOTGRADIENTCOLOR = 0x0000ff;
	if(GRADIENTCOLOR == Green)
		NOTGRADIENTCOLOR = 0x00ff00;
	if(GRADIENTCOLOR == DarkBlue)
		NOTGRADIENTCOLOR = 0x000055;
	if(GRADIENTCOLOR == Grey)
		NOTGRADIENTCOLOR = 0x444444;
//	FullScreen(0xffffff);	
	WindowSet(0,479,0,815);												//4.3"  X  3 page
	Write_Command(0x2c);
	BackGround(GRADIENTCOLOR,GRADIENT,GRADIENTSTART);					//Colour,Gradient or NotGradient,Starting Colour
	BackGround(GRADIENTCOLOR,GRADIENT,GRADIENTSTART);	
	BackGround(GRADIENTCOLOR,GRADIENT,GRADIENTSTART);	
	
	//Saatin ilk kurulmas�
	ASendText(417,3,"~~:~~",2,0x999999,NOTGRADIENTCOLOR,NotClear);			//sn siz
	ASendText(417,(3+272),"~~:~~",2,0x999999,NOTGRADIENTCOLOR,NotClear);	//sn siz
	RtcToScreen(0);	
	RtcToScreen(1);	
	ChangePage(0); 
		
	TFT_BL = 1;
//	CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
//	CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
//	CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
	EeKayit.Konfig.Bit.UzakErisim = 1;
	
	MenuGraphic(1);
//	MeasureMenu(1,0);
	
	TFT.XAbsis = 50; TFT.YOordinat = 70; TFT.Radius = 15;
//	ASendText(TFT.XAbsis,TFT.YOordinat,"TESCOM",2,0xffffff,NOTGRADIENTCOLOR,NotClear);
	
	
    _SWDTEN = 1;
	for(;;)
	{
		asm("CLRWDT");
		TouchMenuControl();	
		
		
		if(TftInitFlag == 1)							//09.07.2013
		{
			TftInitButonSayac = 0;	
			PDC4 = 0 * 4500;			
			InitTFT();
//			Menu.Sekme.All = DefAnaMenu;
//			Menu.AnaSekme = DefDurumMenu;
//			MenuGraphic(Menu.AnaSekme);
			if( Menu.AnaSekme > 5 )
				ChangePage(1); 
			else
				ChangePage(0); 
			Menu.Yenile = 1;
			PDC4 = EeKayit.LcdBacklight * 4500;	
			TftInitFlag = 0;	
		}
		else
		{
			if( Menu.Yenile )
				MenuYenile();
			else
			{
				if( Menu.ButonBayrak )
				{
					Genel.TFTRESET = 400;							//05.02.2015
					Genel.TFTRESETFLAG = 0;							//05.02.2015
					
					ButonKontrol( 1 );
					Menu.Buton.All = 0;
				}
				else
				{
					if( Menu.TimeUpdate == 1 )
					{
						Menu.TimeUpdate = 0;			
						RtcToScreen(0);	
						RtcToScreen(1);	
					}
					else if( MimikDurum.MimikUpdate == 1 )
					{
						MimikDurum.MimikUpdate = 0;
						MimikDurum.MimikUpdateSayac = 11;
						if( Menu.AnaSekme == 1 )
						{
							if( CalismaDurumu.Bit.Bit0 == 0 )
								MimikFonk(0);
							else						
								UPS_Durdu_Fonk();
						}
					}
					else if(Genel.TFTRESETFLAG == 1)			//05.02.2015
					{	
						PDC4 = 0 * 4500;						//Touch ile eklendi
						Genel.TFTRESETFLAG = 0;				
						InitTFT();
						if( Menu.AnaSekme > 5 )					//Touch ile eklendi yoksa Tercihlere gidiyor.
							ChangePage(1); 						//Touch ile eklendi
						else									//Touch ile eklendi
							ChangePage(0);						//Touch ile eklendi	
						MenuYenile();
						PDC4 = EeKayit.LcdBacklight * 4500;		//Touch ile eklendi	
						TftInitBackCounter = 4;					//Touch ile eklendi	
					}
				}
			}
			
			if( Genel.LogSilEmri == 1 )
			{
				Genel.EeSildenSonraAlrKayitSayac = 10;		
				if( Genel.Log_m < ( DefLogLastAddr + 1 ))
				{
					EeByteYaz( Genel.Log_m,255 );
					Genel.Log_m++;
					if( Genel.Log_m < ( DefLogLastAddr + 1 ))
					{
						EeByteYaz( Genel.Log_m,255 );
						Genel.Log_m++;
						if( Genel.Log_m < ( DefLogLastAddr + 1 ))
						{
							EeByteYaz( Genel.Log_m,255 );
							Genel.Log_m++;
							if( Genel.Log_m < ( DefLogLastAddr + 1 ))
							{
								EeByteYaz( Genel.Log_m,255 );
								Genel.Log_m++;
								if( Genel.Log_m < ( DefLogLastAddr + 1 ))
								{
									EeByteYaz( Genel.Log_m,255 );
									Genel.Log_m++;
									if( Genel.Log_m < ( DefLogLastAddr + 1 ))
									{
										EeByteYaz( Genel.Log_m,255 );
										Genel.Log_m++;
									}
								}
							}
						}
					}
				}
				else
				{
					//Alarm sildikten 500 ms sonra alarm kayd�na ba�la.
					Genel.EeSildenSonraAlrKayitSayac = 10;
					Genel.Log_m = DefLogFirstAddr;
					Genel.LogSilEmri = 0;
					Genel.LogSilmeSonu = 1;
					LogIslem(DefLogSil);
				}
			}
		//	if( Timer.Bit.Sn0_25 )			//22.07.14 silindi
		//	{
				if( Timer.Bit.Sn0_05__1 )
				{
					InPinsTara();
				}
		//	}
			if( Timer.Bit.Sn2_5 )
			{
				Timer.Bit.Sn2_5 = 0;
				if( ++main_k > 1 )
					main_k = 0;
				if( ++main_j > 3 )
					main_j = 0;
	//			ExBigVariable(210,190,6,4,6+main_k,0xffffff,0);	
	//			ExBigVariable(210,100,6,4,0+main_k,0xffffff,0);	
	//			ExBigVariable(120,100,6,4,8+main_j,0xffffff,0);
			}
			if( Timer.Bit.Sn0_1 )
				ZamanaBagliIsler();	
			if( Timer.Bit.Sn0_05 )
			{
				Timer.Bit.Sn0_05 = 0;
	//			EkranKoruyucu();			
			}
			if( Can.FromPfc.PfcGeldi )
				CanPfcIslemFonk( Can.FromPfc.PfcBuff );
			if( Can.FromInv.InvGeldi )
				CanInvIslemFonk( Can.FromInv.InvBuff );
			
			//Ayar men�s�ndeyken
			if( Timer.Bit.Sn0_5 )
			{			
				Timer.Bit.Sn0_5 = 0;
				if(( Menu.Sekme.All == DefAyarAltMenu ) || ( Menu.Sekme.All == DefAyarGrupAltMenu ))
				{
					//Di�er paketler AyarAlt men�s�nde y�kleniyor.
					Can.AyarMenuDizisi[3] = 'R'; 
					//Ram in kendisinden s�rekli sordu�u adresler i�in
					Can.AyarMenuDizisi[4] = 0; 
					AyarAltMenuCanSorgu( Can.AyarMenuDizisi );
				}
				else
				{ 
					//Ayar men�s�nde de�ilse de�erler 0 da durur.
					Menu.AyarAyar = 0; 
					Menu.AyarSonuc = 0;
				}
			}	
			
            if( BakimHesaplaFlag == 1 )
            {
                BakimHesaplaFlag = 0;
                BakimHesapla();
            }
            
            
			if( ( Uart1.Aktif == 1 ) && ( Uart2.Aktif == 1 ))
			{
				if( Uart1.Flag == 1 )
				{
					if((( Can.ToPfc.Gonderildi.All == 0 ) && ( Can.ToInv.Gonderildi.All == 0 )))
						Uart1_Fonk( &Uart1.DataBuf, Uart1.GlobalSayac );
				}
				if( Uart2.Flag == 1 )
				{
					if((( Can.ToPfc.Gonderildi.All == 0 ) && ( Can.ToInv.Gonderildi.All == 0 )))
						Uart2_Fonk( &Uart2.DataBuf, Uart2.GlobalSayac );
				}
			}
			else
			{			
				if( Uart1.Flag == 1 )
					Uart1_Fonk( &Uart1.DataBuf, Uart1.GlobalSayac );
				if( Uart2.Flag == 1 )
					Uart2_Fonk( &Uart2.DataBuf, Uart2.GlobalSayac );
			}
			
					
			//Aku kalans�re hesab�
			if( Timer.Bit.Sn1__3 )
			{
				Timer.Bit.Sn1__3 = 0;
				AkuFonk();
			}
			
			
			//�lk 5 sn kayit ve g�sterme i�lemi ger�ekle�mesin
			if(  Menu.Satir4GosterIzin > 4 )
			{		
				if( Timer.Bit.Sn2 == 1 )
				{
					Timer.Bit.Sn2 = 0;
					
					//Ekranda herhangi bir uyar� yaz�s� yoksa kullan�lacak.
					if(( Genel.EkranUyariMesajiVar_AlarmGosterme == 0 ) && ( Genel.HemenEkranYenilemesin == 0 ))
					{
						//G�sterilen alarmlar� duruma g�re de�i�tirir
						GosterAlarm.Half[0] = Alarm.Half[0];	
						GosterAlarm.Half[1] = Alarm.Half[1];
						
						
						
						if( Alarm.Word.Inv2.Bit.ServisLogin == 1 )
						{
							Nop();
	//						if( GosterAlarm.Word.Pfc2.Bit.AcHigh == 1 )
	//							EeKayit.PfcUyari_1_BuzzerMaskesi = EeWordOku(&EeKayit.PfcUyari_1_BuzzerMaskesi);
	//						if( GosterAlarm.Word.Inv3.Bit.AcAkimLimit == 1 )
	//							EeKayit.InvUyari_2_BuzzerMaskesi = EeWordOku(&EeKayit.InvUyari_2_BuzzerMaskesi);
	//						if( GosterAlarm.Word.Lcd1.Bit.PfcDurumKod == 1 )
	//							EeKayit.LcdUyari_1_BuzzerMaskesi = EeWordOku(&EeKayit.LcdUyari_1_BuzzerMaskesi);						
						}
						else if(( Menu.Sekme.All == DefAlt1Menu ) && ( Menu.AnaSekme == 8 ))		//Servis men�s�ndeyken
						{
							Nop();
	//						if( GosterAlarm.Word.Pfc2.Bit.AcHigh == 1 )
	//							EeKayit.PfcUyari_1_BuzzerMaskesi = EeWordOku(&EeKayit.PfcUyari_1_BuzzerMaskesi);
	//						if( GosterAlarm.Word.Inv3.Bit.AcAkimLimit == 1 )
	//							EeKayit.InvUyari_2_BuzzerMaskesi = EeWordOku(&EeKayit.InvUyari_2_BuzzerMaskesi);
	//						if( GosterAlarm.Word.Lcd1.Bit.PfcDurumKod == 1 )
	//							EeKayit.LcdUyari_1_BuzzerMaskesi = EeWordOku(&EeKayit.LcdUyari_1_BuzzerMaskesi);
						}
						else
						{
							GosterAlarm.Word.Pfc2.Bit.AcHigh = 0;
					//		EeKayit.PfcUyari_1_BuzzerMaskesi = EeKayit.PfcUyari_1_BuzzerMaskesi & 65531;
							GosterAlarm.Word.Inv3.Bit.AcAkimLimit = 0;
					//		EeKayit.InvUyari_2_BuzzerMaskesi = EeKayit.InvUyari_2_BuzzerMaskesi & 65519;
							if( GosterAlarm.Word.Lcd1.Bit.PfcDurumKod == 1 )
							{
								if(( AlarmKod.Kod.Pfc == 1105 ) || ( AlarmKod.Kod.Pfc == 1205 ) || ( AlarmKod.Kod.Pfc == 1305 ))
								{
									GosterAlarm.Word.Lcd1.Bit.PfcDurumKod = 0;
					//				EeKayit.LcdUyari_1_BuzzerMaskesi = EeKayit.LcdUyari_1_BuzzerMaskesi & 32767;
								}
							}
						}
						
							
	/*
						if( GosterAlarm.Word.Pfc2.Bit.PfcDurakladi == 1 )
							GosterAlarm.Word.Pfc2.Bit.GirisKontaktorAcik = 0;
						if( GosterAlarm.Word.Pfc2.Bit.DcBaraBekleme== 1 )
						{
							GosterAlarm.Word.Pfc2.Bit.PfcDurakladi = 0;
							GosterAlarm.Word.Pfc2.Bit.GirisKontaktorAcik = 0;
							GosterAlarm.Word.Pfc2.Bit.BaslaGecikmesi = 0;
						}
						if( GosterAlarm.Word.Inv3.Bit.InvDcDusuk == 1 )
							GosterAlarm.Word.Inv3.Bit.InvStop = 0;
						//Ekranda Inv Reset uyar�s� g�z�kmeyecek ama kay�tlar� yap�lacak.
						GosterAlarm.Word.Inv2.Bit.InvReset = 0;
						GosterAlarm.Word.Pfc2.Bit.PfcReset = 0;
						
						//A00 varsa inv de di�erlerini g�sterme R00 varsa pfc de di�erlerini g�sterme
						if( GosterAlarm.Word.Inv1.Bit.InvFaultKod )
						{
							GosterAlarm.Word.Inv1.All &= 32768;
							GosterAlarm.Word.Inv2.All = 0;
							GosterAlarm.Word.Inv3.All = 0;
							GosterAlarm.Word.Lcd1.All = 0;
							GosterAlarm.Word.Lcd2.All = 0;
							GosterAlarm.Word.YedekAlr2.All = 0;
						}
						if( GosterAlarm.Word.Pfc1.Bit.PfcFaultKod )
						{
							GosterAlarm.Word.Pfc1.All &= 32768;
							GosterAlarm.Word.Lcd1.All = 0;
							GosterAlarm.Word.Lcd2.All = 0;
							GosterAlarm.Word.Pfc2.All = 0;
							GosterAlarm.Word.YedekAlr2.All = 0;
						}
	*/
						//Invert�r i�in g�sterilecek alarm ve uyar� ayarlar�
						if( GosterAlarm.Word.Inv1.Bit.InvFaultKod )
						{
							//Sadece Fault g�sterilecek
							GosterAlarm.Word.Inv1.All &= 32768;
							GosterAlarm.Word.Inv2.All = 0;
							GosterAlarm.Word.Inv3.All = 0;
							GosterAlarm.Word.Lcd1.All = 0;
							GosterAlarm.Word.Lcd2.All = 0;
							GosterAlarm.Word.YedekAlr2.All = 0;
						}
						else
						{
							//Alarm varsa alarm ve uyar�lar g�sterilecek
							if( GosterAlarm.Word.Inv1.All == 0 )
							{
								//Alarm yoksa Reset uyar�sana bak�lacak
								if( GosterAlarm.Word.Inv2.Bit.InvReset == 1 )
								{
									//Reset uyar�s� varsa Di�er inv ve lcd ile alakal� uyar�lar g�sterilmeyecek.
									GosterAlarm.Word.Inv2.All = 0;//GosterAlarm.Word.Inv2.All & 256;
									GosterAlarm.Word.Inv3.All = 0;
									GosterAlarm.Word.Lcd1.All = 0;
									GosterAlarm.Word.Lcd2.All = 0;
									GosterAlarm.Word.YedekAlr2.All = 0;
								}
								else
								{
									//Reset uyar�s� yoksa Inv starting uyar�s� var m� 
									if( GosterAlarm.Word.Inv3.Bit.InvStrtg == 1 )
									{
										//Inv starting uyar�s� varsa Di�er Inv ve Lcd uyar�lar� g�sterilmeyecek
										GosterAlarm.Word.Inv3.All = GosterAlarm.Word.Inv3.All & 128;
										GosterAlarm.Word.Inv2.All = 0;
										GosterAlarm.Word.Lcd1.All = 0;
										GosterAlarm.Word.Lcd2.All = 0;
										GosterAlarm.Word.YedekAlr2.All = 0;
									}
									//Inv Starting uyar�s� yoksa uyar�lar g�sterilecek
								}
							}
						}
						//Pfc i�in g�sterilecek alarm ve uyar� ayarlar�
						if( GosterAlarm.Word.Pfc1.Bit.PfcFaultKod )
						{
							//Sadece Fault g�sterilecek
							GosterAlarm.Word.Pfc1.All &= 32768;
							GosterAlarm.Word.Lcd1.All = 0;
							GosterAlarm.Word.Lcd2.All = 0;
							GosterAlarm.Word.Pfc2.All = 0;
							GosterAlarm.Word.YedekAlr2.All = 0;
						}
						else
						{
							//Alarm varsa alarm ve uyar�lar g�sterilecek
							if( GosterAlarm.Word.Pfc1.All == 0 )
							{
								if( GosterAlarm.Word.Pfc2.Bit.PfcReset == 1 )
								{
									//Reset uyar�s� varsa Di�er pfc ve lcd ile alakal� uyar�lar g�sterilmeyecek.
									GosterAlarm.Word.Pfc2.All = 0;//GosterAlarm.Word.Pfc2.All &	4096;
									GosterAlarm.Word.Lcd1.All = 0;
									GosterAlarm.Word.Lcd2.All = 0;
									GosterAlarm.Word.YedekAlr2.All = 0;
								}
								else
								{
									//Reset uyar�s� yoksa Pfc starting uyar�s� var m� 
									if( GosterAlarm.Word.Pfc2.Bit.PfcStrtg == 1 )
									{
										//Pfc starting uyar�s� varsa Di�er Pfc ve Lcd uyar�lar� g�sterilmeyecek
										GosterAlarm.Word.Pfc2.All = GosterAlarm.Word.Pfc2.All & 16384;
										GosterAlarm.Word.Lcd1.All = 0;
										GosterAlarm.Word.Lcd2.All = 0;
										GosterAlarm.Word.YedekAlr2.All = 0;
									}
									//Pfc Starting uyar�s� yoksa uyar�lar g�sterilecek
								}
							}
						}
						
						if( CalismaDurumu.Bit.Bit0 == 0 )					//23.11.2012 de eklendi.
							AlarmGoster(DefOanAlrGoster);		
					}
				}	
				if( Genel.IlkAcilisAlrSayac > 4 )
				{
					if( (Alarm.Half[0] | OldKontrolAlarm.Half[0]) != OldKontrolAlarm.Half[0] )
					{
						if( Genel.EeSildenSonraAlrKayitSayac == 0 )
							LogIslem(DefLogYaz);
					}
					else
						OldKontrolAlarm.Half[0] = Alarm.Half[0];
						
					if( (Alarm.Half[1] | OldKontrolAlarm.Half[1]) != OldKontrolAlarm.Half[1] ) 
					{
						if( Genel.EeSildenSonraAlrKayitSayac == 0 )
							LogIslem(DefLogYaz);
					}
					else
						OldKontrolAlarm.Half[1] = Alarm.Half[1];
				}
			}
		}
	}
}



	/* Scroll yapmak i�in i�lemler */
/*	ASendText(200,100,"BURASI",2,0xffffff,NOTGRADIENTCOLOR,NotClear);
	Write_Command(0x33);
	Write_Data(0);Write_Data(90);
	Write_Data(0);Write_Data(40);
	Write_Data(0);Write_Data(142);
	for(main_i=0;main_i<52;main_i++)
	{
		Write_Command(0x37);
		Write_Data(0);Write_Data(90+main_i);	
		Wait(1000);
	}	
*/
       /*    x , y , x2 ,r ,�er�eve,ba�lang��,artma   */
//	Loading(140,240,340,15,0xffffff,0x000077,0x000001);