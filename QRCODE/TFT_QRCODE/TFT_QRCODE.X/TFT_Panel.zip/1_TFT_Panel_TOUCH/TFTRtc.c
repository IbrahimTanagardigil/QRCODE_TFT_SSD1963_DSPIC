#include "p33FJ256MC710.h"

#include "TFTRtc.h"
#include "TFTVar.h"
#include "TFTDef.h"


void YazRTC(volatile struct DATE *YazLocaldate)
{
	int DummyRTC = 0,o = 0;
	
	Cs_Rtc = 0;
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x8d;												//Send special purpose register address
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x20;												//0x18---Adjust the crystal to 32kHz  0x20 1hz interupt
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
//	for (DummyRTC = 0; DummyRTC<20 ; DummyRTC++)
//		o++;
    BekleCounter = 2;
    Genel.EepromKilitSayac = 2;
    while( BekleCounter != 0 )
    {
        asm("CLRWDT");
        if( Genel.EepromKilitSayac == 0 )
            break;
    };	

	Cs_Rtc = 1;
//	for (DummyRTC = 0; DummyRTC<20 ; DummyRTC++)
//		o++;
    BekleCounter = 2;
    Genel.EepromKilitSayac = 2;
    while( BekleCounter != 0 )
    {
        asm("CLRWDT");
        if( Genel.EepromKilitSayac == 0 )
            break;
    };	
		
	Cs_Rtc = 0;

	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x80;												//Send RTC address
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;												//Send Msec
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	DummyRTC = SPI1BUF;

	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;												//Send sec
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = ((YazLocaldate->Min/10)<<4)+(YazLocaldate->Min%10);	//Send min
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = ((YazLocaldate->Hour/10)<<4)+(YazLocaldate->Hour%10);	//Send hour
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x01;												//Send day number
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = ((YazLocaldate->Day/10)<<4)+(YazLocaldate->Day%10);	//Send day
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = ((YazLocaldate->Month/10)<<4)+(YazLocaldate->Month%10);//Send month
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = ((YazLocaldate->Year/10)<<4)+(YazLocaldate->Year%10);	//Send year
	while(SPI1STATbits.SPIRBF == 0);
	DummyRTC = SPI1BUF;
	Cs_Rtc = 1;
}

void OkuRTC(volatile struct DATE *OkuLocaldate)
{
	int DummyRTC;
	Cs_Rtc = 0;

	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	DummyRTC = SPI1BUF;

	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	DummyRTC = SPI1BUF;											//read Msec

	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	OkuLocaldate->Sec = SPI1BUF;									//read seconds

	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	OkuLocaldate->Min = SPI1BUF;									//read min
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	OkuLocaldate->Hour = SPI1BUF;									//read hour
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	DummyRTC = SPI1BUF;											//read day number
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	OkuLocaldate->Day = SPI1BUF;									//read day
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	OkuLocaldate->Month = SPI1BUF;									//read month
	
	while(SPI1STATbits.SPITBF == 1);							//Wait until SPI1 transmit buffer is clear
	SPI1BUF = 0x00;
	while(SPI1STATbits.SPIRBF == 0);							//Wait until recieving data
	OkuLocaldate->Year = SPI1BUF;									//read year

	OkuLocaldate->Hour = (OkuLocaldate->Hour >> 4)*10 + (OkuLocaldate->Hour & 0x0f);    		
    OkuLocaldate->Min = (OkuLocaldate->Min >> 4)*10 + (OkuLocaldate->Min & 0x0f);   
    OkuLocaldate->Day = (OkuLocaldate->Day >> 4)*10 + (OkuLocaldate->Day & 0x0f); 
    OkuLocaldate->Month = (OkuLocaldate->Month  >> 4)*10 + (OkuLocaldate->Month & 0x0f);
    OkuLocaldate->Year = (OkuLocaldate->Year >> 4)*10 + (OkuLocaldate->Year & 0x0f); 
    OkuLocaldate->Sec = (OkuLocaldate->Sec >> 4)*10 + (OkuLocaldate->Sec & 0x0f);
    
	Cs_Rtc = 1;
}