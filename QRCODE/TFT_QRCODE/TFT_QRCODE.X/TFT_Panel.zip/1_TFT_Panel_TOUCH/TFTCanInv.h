#ifndef __TFTCANINV_H__
#define __TFTCANINV_H__


extern void CanInvIslemFonk(unsigned int *);
extern void YedekCanGonder(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned int );
extern void CanGonder(unsigned int ,unsigned int ,unsigned int ,unsigned int ,unsigned int );
#endif