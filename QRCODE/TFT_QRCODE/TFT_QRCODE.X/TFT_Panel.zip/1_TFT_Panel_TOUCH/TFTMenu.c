#include "p33FJ256MC710.h"

#include "TFTVar.h"
#include "TFTDisplay.h"
#include "TFTInit.h"
#include "TFTDef.h"
#include "TFTCanPfc.h"
#include "TFTCanInv.h"
#include "TFTEeprom.h"
#include "TFTUart1.h"
#include "TFTRtc.h"
#include "BigTable.h"
#include "TFTTablo.h"
#include "TFTFonk.h"
#include "TFTMenu.h"


void FonkAlarmMenu(unsigned int SubAlr,unsigned int AlrClr);

unsigned int for_i;

//Ekran� yeniler. 
void MenuYenile(void)
{
	Menu.Yenile = 0;	
	
	//Ara �ifre men�s�n� temizleme , Buras� �ok k�l Ara �ifre men�y� d�zenlemek 1 haftam� ald�.
	//�li�kili kelimeler :
	//1)if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
	//2)void FonkAraSifreMenu( unsigned int HangiSifre,unsigned int AraSifreSil )
	//3)Genel.AraSifreMenuIci
	if( Genel.AraSifreMenuIci == 2 )
	{
		Genel.AraSifreMenuIci = 0;
		//Merkezi kod �ifresi 
		if( Can.FromInv.SifreSistemi == 1 )
		{
			//User Password kullan�ld�ysa
			if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
				FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
			else
				FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
		}
		//Basit kod �ifresi 
		if( Can.FromInv.SifreSistemi == 2 )
		{
			//User Password kullan�ld�ysa
			if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
				FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
			else
				FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
		}
		ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
		ASendText(20,210+272,ServisMenu[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,1);
		Menu.Sekme.All = Genel.EskiMenu;			
		Menu.ExAnaSekme = Menu.AnaSekme = Genel.EskiSekme;
		MenuGraphic(Menu.AnaSekme);
	}
	
	if( Menu.Sekme.All == DefAnaMenu )
	{	
		switch(Menu.AnaSekme)
		{
			case DefDurumMenu:
			break;
			case DefOlcumMenu:
				FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
			break;
			case DefAlarmMenu:
				FonkAlarmMenu(Menu.LogSayac,0);
			break;
			case DefBilgiMenu:
				InfoMenu(Menu.Alt1Sekme,0);
			break;
			case DefTercihMenu:
				FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
			break;
			case DefEmirMenu:
				FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
			break;
			case DefZamanMenu:
				TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
			break;
			case DefServisMenu:
				FonkServisAnaMenu(Menu.ServisAnaSekme,0);
			break;
			case DefAyarMenu:
				//Merkezi kod �ifresi 
				if( Can.FromInv.SifreSistemi == 1 )
				{
					//User Password kullan�ld�ysa
					if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
						FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
					else
						FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
				}
				//Basit kod �ifresi 
				if( Can.FromInv.SifreSistemi == 2 )
				{
					//User Password kullan�ld�ysa
					if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
						FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
					else
						FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
				}
					
			break;
			case DefKalibrasyon:
			break;
			default:
			break;
		}	
	}
	else if( Menu.Sekme.All == DefOlcumAltMenu )
		FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
	else if( Menu.Sekme.All == DefTercihAltMenu )
		FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
	else if( Menu.Sekme.All == DefRoleAlarmAtama )
		FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,0 );
	else if( Menu.Sekme.All == DefEmirAltMenu )
		FonkEmirAltMenu(Menu.EmirAnaSekme,Menu.EmirAltSekme,Menu.EmirAltMenuIci,0);
	else if( Menu.Sekme.All == DefEmirRoleMenu )
		FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
	else if( Menu.Sekme.All == DefAyarAnaMenu )
		FonkAyarAnaMenu(Menu.AyarAnaSekme,0);
	else if( Menu.Sekme.All == DefAyarAltMenu )
		FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
	else if( Menu.Sekme.All == DefAyarGrupAltMenu )
		FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
}	
//Buton Fonksiyonlar�
void ButonKontrol(unsigned int Artim)
{		
	unsigned int z3,Log_i;
	
	Menu.ButonBayrak = 0;
	
	//Herhangi bir butona bas�l�nca Backlight tam parlak olsun ve dim i�lemleri yenilensin.
	EeKayit.LcdBacklight = Menu.OldLcdBacklight;
	Menu.AcikSureGeriSayac = EeKayit.AcikSure * 10;	
	Menu.YarimAydinlikSureGeriSayac = EeKayit.YarimAydinlikSure * 10;
	
	switch( Menu.Sekme.All )
	{
		case DefAnaMenu:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:	
					switch(Menu.AnaSekme)
					{
						case DefDurumMenu:
							//Pratikte denendi 3 sn i�in de�er yakla��k 9 oluyor.
							if( ++Menu.EnteraBasmaSayac > 7 )
							{
								Menu.EnteraBasmaSayac = 0;
								Menu.MaskeAlarmSesAcik = 0;
								//Hoparl�r a��k kapal�
								ExBigVariable(430,243+(GlobalSayfa*272),4,3,14-Menu.MaskeAlarmSesAcik,0xffff00,0);			//Sembol 1
								//Ses kesildi i�areti konulabilir.
								//1500 ms sonra ekran� yenile
								Menu.YenileGeriSayac = 30;						
							}	
						break;
						case DefOlcumMenu:
							Menu.OlcumMenuIci = 1;
							
							FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
						break;
						case DefAlarmMenu:
							Menu.LogSayac -= Artim;
							if(Menu.LogSayac < DefLogAltSinir)
								Menu.LogSayac = DefLogUstSinir;
							TFT.LogSayfaToggle = 0;
							FonkAlarmMenu(Menu.LogSayac,0);
						break;
						case DefBilgiMenu:
							Menu.Alt1Sekme--;
							if( Menu.Alt1Sekme < 0 )
								Menu.Alt1Sekme = DefBilgiSayfa;
							InfoMenu(Menu.Alt1Sekme,0);
						break;
						case DefTercihMenu:
							if(--Menu.TercihAnaSekme < Menu.TercihAltLimit)
								Menu.TercihAnaSekme = Menu.TercihUstLimit;
							FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
						break;
						case DefEmirMenu:
							if(--Menu.EmirAnaSekme < Menu.EmirAltLimit)
								Menu.EmirAnaSekme = Menu.EmirUstLimit;
							FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
						break;
						case DefZamanMenu:
							TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
						break;
						case DefServisMenu:
							if(--Menu.ServisAnaSekme < Menu.ServisAltLimit)
								Menu.ServisAnaSekme = Menu.ServisUstLimit;
							FonkServisAnaMenu(Menu.ServisAnaSekme,0);
						break;
						case DefAyarMenu:
							//�ifre girildi�i sayfada servis login se ekranda ilk servis login yazar ve ayarana men�ye gelir.
							//Ayar ana men�den geriye ��k�nca b�yle bir �ey olmas�n diye ama men�n�n i�erisnde bir daha butona bas�l�rsa yine ayn� �eyler olsun.
							Menu.AyarMenulerIlkGiris = 0;
							if( Menu.AyarPssswordIci == 0 )
							{
								if(--Menu.AyarOnSekme < Menu.AyarAltLimit)
									Menu.AyarOnSekme = Menu.AyarUstLimit;
								//Merkezi kod �ifresi 
								if( Can.FromInv.SifreSistemi == 1 )
								{
									//User Password kullan�ld�ysa
									if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
										FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									else
										FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
								}
								//Basit kod �ifresi 
								if( Can.FromInv.SifreSistemi == 2 )
								{
									//User Password kullan�ld�ysa
									if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
										FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									else
										FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
								}
							}
							else if( Menu.AyarPssswordIci == 1 )
							{
								if(++Menu.GolgeSifre[Menu.HaneDegistir] > 57)
									Menu.GolgeSifre[Menu.HaneDegistir] = 48;
							}
							else if( Menu.AyarPssswordIci == 2 )
							{
								if(++Menu.UserGolgeSifre[Menu.HaneDegistir] > 57)
									Menu.UserGolgeSifre[Menu.HaneDegistir] = 48;
							}
						break;
						case DefKalibrasyon:
						break;
						default:
						break;
					}
				break;
				case DefAsagiButon:		
					switch(Menu.AnaSekme)
					{
						case DefDurumMenu:
						break;
						case DefOlcumMenu:
							Menu.OlcumMenuIci = 1;
							FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);							
						break;
						case DefAlarmMenu:
							Menu.LogSayac += Artim;	
							if(Menu.LogSayac > DefLogUstSinir)
								Menu.LogSayac = DefLogAltSinir;
							TFT.LogSayfaToggle = 0;
							FonkAlarmMenu(Menu.LogSayac,0);
						break;
						case DefBilgiMenu:
							Menu.Alt1Sekme++;
							if( Menu.Alt1Sekme > DefBilgiSayfa )
								Menu.Alt1Sekme = 0;
							InfoMenu(Menu.Alt1Sekme,0);
						break;
						case DefTercihMenu:
							if(++Menu.TercihAnaSekme > Menu.TercihUstLimit)
								Menu.TercihAnaSekme = Menu.TercihAltLimit;
							FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
						break;
						case DefEmirMenu:									
							if( Menu.EmirPopUpIci == 0 )
							{
								if(++Menu.EmirAnaSekme > Menu.EmirUstLimit)
									Menu.EmirAnaSekme = Menu.EmirAltLimit;
							}
							else
							{
								if(--Menu.EmirAltMenuIci < Menu.EmirPopUpAltLimit)
									Menu.EmirAltMenuIci = Menu.EmirPopUpUstLimit;					
							}
							FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
						break;
						case DefZamanMenu:
							TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
						break;
						case DefServisMenu:
							if(++Menu.ServisAnaSekme > Menu.ServisUstLimit)
								Menu.ServisAnaSekme = Menu.ServisAltLimit;
							FonkServisAnaMenu(Menu.ServisAnaSekme,0);
						break;
						case DefAyarMenu:
							//�ifre girildi�i sayfada servis login se ekranda ilk servis login yazar ve ayarana men�ye gelir.
							//Ayar ana men�den geriye ��k�nca b�yle bir �ey olmas�n diye ama men�n�n i�erisnde bir daha butona bas�l�rsa yine ayn� �eyler olsun.
							Menu.AyarMenulerIlkGiris = 0;
							if( Menu.AyarPssswordIci == 0 )
							{
								if(++Menu.AyarOnSekme > Menu.AyarUstLimit)
									Menu.AyarOnSekme = Menu.AyarAltLimit;
								//Merkezi kod �ifresi 
								if( Can.FromInv.SifreSistemi == 1 )
								{
									//User Password kullan�ld�ysa
									if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
										FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									else
										FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
								}
								//Basit kod �ifresi 
								if( Can.FromInv.SifreSistemi == 2 )
								{
									//User Password kullan�ld�ysa
									if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
										FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									else
										FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
								}
							}
							else if( Menu.AyarPssswordIci == 1 )
							{
								if(--Menu.GolgeSifre[Menu.HaneDegistir] < 48)
									Menu.GolgeSifre[Menu.HaneDegistir] = 57;
							}
							else if( Menu.AyarPssswordIci == 2 )
							{
								if(--Menu.UserGolgeSifre[Menu.HaneDegistir] < 48)
									Menu.UserGolgeSifre[Menu.HaneDegistir] = 57;
							}
						break;
						case DefKalibrasyon:
						break;
						default:
						break;
					}
				break;
				case DefEnterButon:	
					switch(Menu.AnaSekme)
					{
						case DefDurumMenu:
						break;
						case DefOlcumMenu:
							Menu.OlcumMenuIci = 1;
							FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
						break;
						case DefAlarmMenu:
							if( Menu.ButonBasmaSure > 9 )		
							{
								Menu.ButonBasmaSure = 0;
								//Log temizle
								LogIslem(DefLogSil);
							}	
							else
							{
								TFT.LogSayfaToggle = 0;
								if( Menu.ButonBasmaSure < 2 )
									FonkAlarmMenu(Menu.LogSayac,0);
							}
						break;
						case DefBilgiMenu:
						break;
						case DefTercihMenu:	
							//Menu i�erisine girilecek kal�nt�lar� sil.			
							Menu.TercihAltSekme = 0;
							FonkTercihAnaMenu(Menu.TercihAnaSekme,1);
							Menu.TercihAltMenuIci = 0;
							FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
						break;
						case DefEmirMenu:
							switch(Menu.EmirAnaSekme)
							{
								//Enter Bypass - Inverter
								case 0:	
									if( Genel.LoginWaitButon == 0 )
									{	
										if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
										{			
											//Burada g�venlik �nlemleri konulacak
											if( Menu.EnterBypOrInv )
												CanGonder(DefCanInv,28,'W',DefEmir_Inverter,0);	
											else
												CanGonder(DefCanInv,28,'W',DefEmir_Bypass,0);									
								
										    /*  x , y , x2 ,r ,�er�eve,ba�lang��,artma   */
											Loading(300,96+272,370,7,0xffbb00,0xffbb00,0x000000,0);
											Wait(5000);
											Loading(300,96+272,370,7,0xffbb00,0xffbb00,0x000000,1);
											//250 ms sonra yenilensin.
											Menu.YenileGeriSayac = 5;
										}
										else
										{	
											//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
											Genel.AraSifre_Hangisi = 1;
											FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
										}
									}
								break;
								//Enter Boost - Stop Boost
								case 1:
									if( Genel.LoginWaitButon == 0 )
									{
										if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
										{			
											//Burada g�venlik �nlemleri konulacak
											Menu.EnterStopBoost ^= 1;
											if( Menu.EnterStopBoost )
												CanGonder(DefCanInv,28,'W',DefEmir_Boost,0);	
											else
												CanGonder(DefCanInv,28,'W',DefEmir_CancelBoost,0);
											Loading(300,116+272,370,7,0xffbb00,0xffbb00,0x000000,0);
											Wait(5000);
											Loading(300,116+272,370,7,0xffbb00,0xffbb00,0x000000,1);
											//250 ms sonra yenilensin.
											Menu.YenileGeriSayac = 5;
										}
										else
										{	
											//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
											Genel.AraSifre_Hangisi = 1;
											FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
										}
									}
								break;
								//Enter Ak� Test
								case 2:
									if( Genel.LoginWaitButon == 0 )
									{
										if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
										{			
											//Burada g�venlik �nlemleri konulacak
											Menu.EnterBattTest ^= 1;
											if( Menu.EnterBattTest )
												CanGonder(DefCanInv,28,'W',DefEmir_KisaAkuTestYap,0);	
											else
												CanGonder(DefCanInv,28,'W',DefEmir_AkuTestIptal,0);	
											Loading(300,136+272,370,7,0xffbb00,0xffbb00,0x000000,0);
											Wait(5000);
											Loading(300,136+272,370,7,0xffbb00,0xffbb00,0x000000,1);
											//250 ms sonra yenilensin.
											Menu.YenileGeriSayac = 5;
										}
										else
										{	
											//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
											Genel.AraSifre_Hangisi = 1;
											FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
										}
									}
								break;
								//R�le Test
								case 3:						
									Menu.EmirAltMenuIci = 0; 
									FonkEmirAnaMenu(Menu.EmirAnaSekme,1);
									Genel.RoleSimulasyonToggle = 0; Menu.RoleSimulasyonu = 1;
									FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
									//250 ms sonra yenilensin.
									Menu.YenileGeriSayac = 5;
								break;
								//Enter Modem Init
								case 4:
									Loading(300,176+272,370,7,0xffbb00,0xffbb00,0x000000,0);
									Wait(5000);
									Loading(300,176+272,370,7,0xffbb00,0xffbb00,0x000000,1);
									//250 ms sonra yenilensin.
									Menu.YenileGeriSayac = 5;
								break;
								//Alarm Ses A��k - Kapal�
								case 5:
									Menu.EmirAltMenuIci = 1;
									FonkEmirAltMenu(Menu.EmirAnaSekme,Menu.EmirAltSekme,Menu.EmirAltMenuIci,0);
									//250 ms sonra yenilensin.
									Menu.YenileGeriSayac = 5;
								break;
								default:
								break;
							}
						break;
						case DefZamanMenu:
							if( Genel.LoginWaitButon == 0 )
							{
								if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
								{
									Menu.ZamanAyarIci ^= 1;
									TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
								}
								else
								{	
									//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
									Genel.AraSifre_Hangisi = 1;
									FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
								}
							}
						break;
						case DefServisMenu:
							switch(Menu.ServisAnaSekme)
							{
								//Toplam Saat i�lem yok.
								case 0:
								break;
								//Max G�� de�erlerini s�f�rlar
								case 1:
									//350 ms de bir artar.BuzzerKontrol() fonk. i�erisinde
									//Buna g�re 9 x 350 ms = 3150 ms sonra s�f�rlar.
									if( Menu.ButonBasmaSure > 9 )		
									{
										Menu.ButonBasmaSure = 0;
										Loading(300,116+272,370,7,0xffbb00,0xffbb00,0x000000,0);
										Wait(5000);
										Loading(300,116+272,370,7,0xffbb00,0xffbb00,0x000000,1);
										Menu.MaxYuk.L1 = 0;
										Menu.MaxYuk.L2 = 0;
										Menu.MaxYuk.L3 = 0;
										Genel.MaxYukL1 = 0;
										Genel.MaxYukL2 = 0;
										Genel.MaxYukL3 = 0;
										FonkServisAnaMenu(Menu.ServisAnaSekme,0);
									}	
								break;
								//Enter <Hata S�f�rla>
								case 2:
									if( Genel.LoginWaitButon == 0 )
									{
										if( Can.FromInv.LogInDurum == 1 )
										{
											//Burada g�venlik �nlemleri konulacak
											Menu.EnterFaultReset = 1;
											CanGonder(DefCanInv,28,'W',DefEmir_FaultReset,0);	
											Loading(300,136+272,370,7,0xffbb00,0xffbb00,0x000000,0);
											Wait(5000);
											Loading(300,136+272,370,7,0xffbb00,0xffbb00,0x000000,1);
										}
										else
										{
											//�ifre Sayfas� gelecek
													Menu.AyarPssswordIci = 1;
											Genel.AraSifre_Hangisi = 2;
											FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
										}
									}
								break;
								//Logout
								case 6:				
										Menu.LogOutAktif = 1;
									//Can �zerinden inv ye Logout emri g�nder.							
									CanGonder(DefCanInv,28,'W',DefEmir_LogOut,0);
									Genel.UserPassDogru15dklikIzin = 0;
										Genel.UserPassGeriSayac = 0;
										Genel.UserPassDogru15dklikIzin = 0;
										Menu.LogOutAktif = 0;
									//500 ms sonra ekran� yenile
									Menu.YenileGeriSayac = 10;
									
									Menu.EmirAltMenuIci = 0; 
									Loading(300,216+272,370,7,0xffbb00,0xffbb00,0x000000,0);
									Wait(5000);
									Loading(300,216+272,370,7,0xffbb00,0xffbb00,0x000000,1);
								break;
								default:
								break;
							}
						break;
						case DefAyarMenu:		
							//�ifre girildi�i sayfada servis login se ekranda ilk servis login yazar ve ayarana men�ye gelir.
							//Ayar ana men�den geriye ��k�nca b�yle bir �ey olmas�n diye ama men�n�n i�erisnde bir daha butona bas�l�rsa yine ayn� �eyler olsun.
							Menu.AyarMenulerIlkGiris = 0;				
							//Merkezi kod �ifresi 
							if( Can.FromInv.SifreSistemi == 1 )
							{
								//User Password kullan�ld�ysa
								if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
								{					
									switch(Menu.AyarOnSekme)
									{
										case 0:
											SifreAl();
											FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										break;
										case 1:	
											if( Menu.AyarPssswordIci == 0 )
											{
												Menu.HaneDegistir = 0;
												Menu.AyarPssswordIci = 1;
												FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
											else
											{
												//�ifre do�rulama i�lemi yap�lacak																			
												Menu.SifreDogru	= SifreDogrula();											
												if( Menu.SifreDogru	)
												{
													//Can den login emri g�nderir.								
													CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
													Genel.LoginWaitButon = 80;  //4 sn sonra buton i�levi olsun.
													Menu.SifreDurum = 4;
												}
												else
												{
													Menu.SifreDurum = 5;	
												}
												FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
										break;
										case 2:	
											if( Menu.AyarPssswordIci == 0 )
											{
												Menu.HaneDegistir = 0;
												Menu.AyarPssswordIci = 2;
												FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
											else
											{
												//�ifre do�rulama i�lemi yap�lacak	
												Menu.SifreDogru	= UserSifreDogrula();										
												if( Menu.SifreDogru	)
												{
													//Can den login emri g�nderir.				
													CanGonder(DefCanInv,28,'W',DefEmir_UserLogIn,0);
					//Servis login > User Login
					Genel.UserPassDogru15dklikIzin = 1;
					//15 dk l�k geri saya� kuruldu.
					Genel.UserPassGeriSayac = 450;
					Genel.LoginWaitButon = 0;
													Menu.SifreDurum = 7;
												}
												else
												{
													Menu.SifreDurum = 8;	
												}
												FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
										break;
										default:
										break;
									}
								}
								else
								{			
									//User Password kullan�lmad�ysa				
									switch(Menu.AyarOnSekme)
									{
										case 0:
											SifreAl();
											FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										break;
										case 1:	
											if( Menu.AyarPssswordIci == 0 )
											{
												Menu.HaneDegistir = 0;
												Menu.AyarPssswordIci = 1;
												FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
											else
											{
												//�ifre do�rulama i�lemi yap�lacak																			
												Menu.SifreDogru	= SifreDogrula();											
												if( Menu.SifreDogru	)
												{
													//Can den login emri g�nderir.								
													CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
													Genel.LoginWaitButon = 80;  //4 sn sonra buton i�levi olsun.
													Menu.SifreDurum = 1;
												}
												else
												{
													Menu.SifreDurum = 2;	
												}
												FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
										break;
										default:
										break;
									}
								}
							}
							//Basit kod �ifresi 
							if( Can.FromInv.SifreSistemi == 2 )
							{
								//User Password kullan�ld�ysa
								if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
								{		
									switch(Menu.AyarOnSekme)
									{
										case 0:	
											if( Menu.AyarPssswordIci == 0 )
											{
												Menu.HaneDegistir = 0;
												Menu.AyarPssswordIci = 1;
												FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
											else
											{
												//�ifre do�rulama i�lemi yap�lacak																			
												Menu.SifreDogru	= BasitSifreDogrula();											
												if( Menu.SifreDogru	)
												{
													//Can den login emri g�nderir.								
													CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
													Genel.LoginWaitButon = 80;  //4 sn sonra buton i�levi olsun.
													Menu.SifreDurum = 10;
												}
												else
												{
													Menu.SifreDurum = 11;	
												}
												FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
										break;
										case 1:	
											if( Menu.AyarPssswordIci == 0 )
											{
												Menu.HaneDegistir = 0;
												Menu.AyarPssswordIci = 2;
												FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
											else
											{
												//�ifre do�rulama i�lemi yap�lacak	
												Menu.SifreDogru	= UserSifreDogrula();										
												if( Menu.SifreDogru	)
												{
													//Can den login emri g�nderir.				
													CanGonder(DefCanInv,28,'W',DefEmir_UserLogIn,0);
					//Servis login > User Login
					Genel.UserPassDogru15dklikIzin = 1;
					//15 dk l�k geri saya� kuruldu.
					Genel.UserPassGeriSayac = 450;
					Genel.LoginWaitButon = 0;
												Menu.SifreDurum = 13;
												}
												else
												{
													Menu.SifreDurum = 14;	
												}
												FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
										break;
										default:
										break;
									}
								}
								else
								{					
									//User Password kullan�lmad�ysa	
									switch(Menu.AyarOnSekme)
									{
										case 0:	
											if( Menu.AyarPssswordIci == 0 )
											{
												Menu.HaneDegistir = 0;
												Menu.AyarPssswordIci = 1;
												FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
											else
											{
												//�ifre do�rulama i�lemi yap�lacak																			
												Menu.SifreDogru	= BasitSifreDogrula();											
												if( Menu.SifreDogru	)
												{
													//Can den login emri g�nderir.								
													CanGonder(DefCanInv,28,'W',DefEmir_LogIn,0);
													Genel.LoginWaitButon = 80;  //4 sn sonra buton i�levi olsun.
													Menu.SifreDurum = 16;
												}
												else
												{
													Menu.SifreDurum = 17;	
												}
												FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
											}
										break;
										default:
										break;
									}
								}
							}
						break;
						case DefKalibrasyon:
						break;
						default:
						break;
					}
				break;
				case DefSagButon:
					if( Menu.AyarPssswordIci == 0 )
					{
						if( Menu.ZamanAyarIci == 0 )
						{					
							switch(Menu.ExAnaSekme)
							{
								case 1:
									MimikFonk(1);
									Menu.OlcumAltSekme = 0;
									Menu.OlcumMenuIci = 0;
									FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
								break;
								case 2:
									Menu.OlcumMenuIci = 0;
									FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,1);
									Menu.LogSayac = 0;
									TFT.LogSayfaToggle = 0;
									FonkAlarmMenu(Menu.LogSayac,0);
								break;
								case 3:
									Menu.LogSayac = 0;
									FonkAlarmMenu(Menu.LogSayac,1);
									Menu.Alt1Sekme = 0;
									InfoMenu(Menu.Alt1Sekme,0);
								break;
								case 4:
									Menu.Alt1Sekme = 0;
									InfoMenu(Menu.Alt1Sekme,1);
									Menu.TercihAnaSekme = 0;
									FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
								break;
								case 5:
									Menu.EmirAnaSekme = 0;
									FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
								break;
								case 6:
									Menu.EmirAnaSekme = 0;
									FonkEmirAnaMenu(Menu.EmirAnaSekme,1);
									Menu.ZamanAyarIci = 0;
									TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
								break;
								case 7:
									TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,1);
									Menu.ServisAnaSekme = 0;
									FonkServisAnaMenu(Menu.ServisAnaSekme,0);
								break;
								case 8:
									FonkServisAnaMenu(Menu.ServisAnaSekme,1);
									Menu.AyarMenulerIlkGiris = 1;		//Ana Men�deyken login se bile girmesin herhangi bir tu�a bas�nca girsin
									Menu.ServisAnaSekme = 0;
									Menu.AyarPssswordIci = 0; Menu.AyarOnSekme = 0;
									//Merkezi kod �ifresi 
									if( Can.FromInv.SifreSistemi == 1 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										else
											FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									}
									//Basit kod �ifresi 
									if( Can.FromInv.SifreSistemi == 2 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										else
											FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									}
								break;
								case 9:
									Menu.AyarMenulerIlkGiris = 1;
									Menu.AyarPssswordIci = 0; Menu.AyarOnSekme = 0;
									//Merkezi kod �ifresi 
									if( Can.FromInv.SifreSistemi == 1 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
										else
											FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
									}
									//Basit kod �ifresi 
									if( Can.FromInv.SifreSistemi == 2 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
										else
											FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,1);
									}
//#ifdef PAGE2_4_SEKME		Touch kald�r�ld�
//									FonkTercihAnaMenu(Menu.TercihAnaSekme,1);
//#endif
									CalibrationMenu(0);
								break;
								case 10:
									CalibrationMenu(1);
									FonkTercihAnaMenu(Menu.TercihAnaSekme,1);
								break;
								default:
								break;
							}
							
#ifdef PAGE2_5_SEKME
							if(++Menu.AnaSekme > 10)
								Menu.AnaSekme = 1;
#endif
#ifdef PAGE2_4_SEKME
							if(++Menu.AnaSekme > 9)
								Menu.AnaSekme = 1;
#endif
							MenuGraphic(Menu.AnaSekme);
						}
						else
							TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
					}
					else
					{
						Menu.AyarMenulerIlkGiris = 0;
						if( Menu.AyarPssswordIci == 1 )
						{
							if( ++Menu.HaneDegistir > 7)
								Menu.HaneDegistir = 0;
						}
						else if( Menu.AyarPssswordIci == 2 )
						{
							if( ++Menu.HaneDegistir > 3)
								Menu.HaneDegistir = 0;
						}
					}
				break;
				case DefSolButon:
					if( Menu.AyarPssswordIci == 0 )
					{	
						if( Menu.ZamanAyarIci == 0 )
						{							
							switch(Menu.ExAnaSekme)
							{
								case 1:	
									MimikFonk(1);		
									
									
#ifdef PAGE2_4_SEKME								
									Menu.AyarPssswordIci = 0; Menu.AyarOnSekme = 0;
									Menu.AyarMenulerIlkGiris = 1;		//Ana Men�deyken login se bile girmesin herhangi bir tu�a bas�nca girsin
									//Merkezi kod �ifresi 
									if( Can.FromInv.SifreSistemi == 1 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										else
											FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									}
									//Basit kod �ifresi 
									if( Can.FromInv.SifreSistemi == 2 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										else
											FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									}	
#endif
#ifdef PAGE2_5_SEKME
									CalibrationMenu(0);
#endif
								break;
								case 2:
									Menu.OlcumMenuIci = 0;
									FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,1);
								break;
								case 3:
									FonkAlarmMenu(0,1);
									Menu.OlcumAltSekme = 0;
									Menu.OlcumMenuIci = 0;
									FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);
								break;
								case 4:
									Menu.Alt1Sekme = 0;
									InfoMenu(Menu.Alt1Sekme,1);
									Menu.LogSayac = 0;
									TFT.LogSayfaToggle = 0;
									FonkAlarmMenu(Menu.LogSayac,0);
								break;
								case 5:
									Menu.TercihAnaSekme = 0;
									FonkTercihAnaMenu(Menu.TercihAnaSekme,1);
									Menu.Alt1Sekme = 0;
									InfoMenu(Menu.Alt1Sekme,0);
								break;
								case 6:
									Menu.EmirAnaSekme = 0;
									FonkEmirAnaMenu(Menu.EmirAnaSekme,1);
									Menu.TercihAnaSekme = 0;
									FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
								break;
								case 7:
									TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,1);
									Menu.EmirAnaSekme = 0;
									FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
									
								break;
								case 8:
									Menu.ServisAnaSekme = 0;
									FonkServisAnaMenu(Menu.ServisAnaSekme,1);
									Menu.ZamanAyarIci = 0;
									TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);
								break;
								case 9:
									//Touch eklendi
									//-----------------
									Navigation(1,0);
									//-----------------
									Menu.ServisAnaSekme = 0;
									FonkServisAnaMenu(Menu.ServisAnaSekme,0);
								break;
								case 10:
									CalibrationMenu(1);	
									Menu.AyarPssswordIci = 0; Menu.AyarOnSekme = 0;
									Menu.AyarMenulerIlkGiris = 1;		//Ana Men�deyken login se bile girmesin herhangi bir tu�a bas�nca girsin
									//Merkezi kod �ifresi 
									if( Can.FromInv.SifreSistemi == 1 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_2(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										else
											FonkAyaOnMenu_1(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									}
									//Basit kod �ifresi 
									if( Can.FromInv.SifreSistemi == 2 )
									{
										//User Password kullan�ld�ysa
										if( EeKayit.Konfig.Bit.UserPassKullanilsin == 1 )
											FonkAyaOnMenu_3(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
										else
											FonkAyaOnMenu_4(Menu.AyarOnSekme,Menu.AyarPssswordIci,0);
									}						
								default:
								break;
							}
							if( Menu.ZamanAyarIci == 0 )
							{					
#ifdef PAGE2_5_SEKME
								if(--Menu.AnaSekme < 1)
									Menu.AnaSekme = 10;
#endif			
#ifdef PAGE2_4_SEKME
								if(--Menu.AnaSekme < 1)
									Menu.AnaSekme = 9;
#endif
								MenuGraphic(Menu.AnaSekme);
							}		
						}
						else
							TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,0);	
					}
					else
					{
						Menu.AyarMenulerIlkGiris = 0;
						if( Menu.AyarPssswordIci == 1 )
						{
							if( --Menu.HaneDegistir < 0)
								Menu.HaneDegistir = 7;
						}
						else if( Menu.AyarPssswordIci == 2 )
						{
							if( --Menu.HaneDegistir < 0)
								Menu.HaneDegistir = 3;
						}
					}
				break;
				default:
				break;
			}		
			Menu.ExAnaSekme = Menu.AnaSekme;
		break;
		case DefOlcumAltMenu:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:
					if(--Menu.OlcumAltSekme < Menu.OlcumAltLimit)
						Menu.OlcumAltSekme = Menu.OlcumUstLimit;
					Menu.OlcumMenuIci = 1;
				break;
				case DefAsagiButon:	
					if(++Menu.OlcumAltSekme > Menu.OlcumUstLimit)
						Menu.OlcumAltSekme = Menu.OlcumAltLimit;
					Menu.OlcumMenuIci = 1;
				break;
				case DefEnterButon:	
					if( Menu.OlcumAltSekme == Menu.OlcumUstLimit )
					{
						Menu.OlcumMenuIci = 0;
						Menu.OlcumAltSekme = 0;
						//Oklar� Sil
						BigOutVar(130,125,0,OrtaNokta,0,0,0x888888,1);
						BigOutVar(130,183,0,ScrollDownOk,0,0,0x888888,1);
						BigOutVar(130,67,0,ScrollUpOk,0,0,0x888888,1);
			//			Dikdortgen(180,471,66,235,0xffff00,1,0,1);
					}
				break;
				case DefSagButon:
				break;
				case DefSolButon:
				break;
				default:
				break;
			}	
			FonkOlcumAnaMenu(Menu.OlcumAltSekme,Menu.OlcumMenuIci,0);	
		break;
		case DefTercihAltMenu:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:			
					if( Menu.TercihAltMenuIci == 0 )
					{
						if(--Menu.TercihAltSekme < Menu.TercihAltAltLimit)
							Menu.TercihAltSekme = Menu.TercihAltUstLimit;
					}
					else
					{
						if(--Menu.TercihAltMenuIci < Menu.TercihPopUpAltLimit)
							Menu.TercihAltMenuIci = Menu.TercihPopUpUstLimit;					
					}
					FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
				break;
				case DefAsagiButon:	
					if( Menu.TercihAltMenuIci == 0 )
					{
						if(++Menu.TercihAltSekme > Menu.TercihAltUstLimit)
							Menu.TercihAltSekme = Menu.TercihAltAltLimit;
					}
					else
					{
						if(++Menu.TercihAltMenuIci > Menu.TercihPopUpUstLimit)
							Menu.TercihAltMenuIci = Menu.TercihPopUpAltLimit;
					}
					FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
				break;
				case DefEnterButon:	
	//				if( Menu.TercihAltSekme == Menu.TercihAltUstLimit )
	//				{
	//					Menu.TercihAltMenuIci = 0;
	//					Menu.TercihAltSekme = 0;
	//					//Sil Alt men�den ��k�l�yor.
	//				}
					//Pop Up ��kar.
					if( Menu.TercihAltMenuIci == 0 )
					{
						//E�er Enter - Exit k�sm�ndayken enter a bas�l�rsa ana men�ye d�n.
						//De�ilse PopUp men� ��kar.			
						switch( Menu.TercihAnaSekme )
						{
							//Ekran Tercihleri
							case 0:					
									switch( Menu.TercihAltSekme )
									{
										//Language
										case 0:
											Menu.TercihAltMenuIci = EeKayit.Dil + 1;
										break;
										//Buton Ses ayar�
										case 1:
											Menu.TercihAltMenuIci = EeKayit.Konfig.Bit.ButonTik + 1;
										break;
										//Backlight ayar�
										case 2:
											Menu.TercihAltMenuIci = 1;
										break;
										//Bekleme s�resi
										case 3:
											Menu.TercihAltMenuIci = 1;
										break;
										//Karartma s�resi
										case 4:
											Menu.TercihAltMenuIci = 1;
										break;
										//Enter - Exit
										case 5:
											Menu.TercihAltMenuIci = 0;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
											FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
										break;
										default:
										break;
									}
									if( Menu.TercihAltSekme != 5 )
										FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
							break;
							//Haberle�me Tercihleri
							case 1:		
									switch( Menu.TercihAltSekme )
									{
										//Remote Control
										case 0:
											Menu.TercihAltMenuIci = EeKayit.Konfig.Bit.UzakErisim + 1;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
										break;
										//COM2
										case 1:
											Menu.TercihAltMenuIci = EeKayit.Konfig.Bit.Comm2Secim + 1;
											if( EeKayit.Konfig.Bit.Comm2Secim == DefServisPort )			//21.08.2013
												InitUART2(9600);
											if( EeKayit.Konfig.Bit.Comm2Secim == DefUserPort )
												InitUART2(2400);
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
										break;
										//SNMP
										case 2:
											Menu.TercihAltMenuIci = EeKayit.Konfig.Bit.SNMP_OnOff + 1;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
										break;
										//REPO
										case 3:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = EeKayit.REPO_OnOff + 1;				//12.03.2014
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//R�le - Alarm Atamas�
										case 4:
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
											Menu.RoleAlrRoleSec = 0;
											Menu.RoleAlrSec = 0;
											//Yaz�mla alakal� bir �ey d�zeltildi.
											FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,1 );
											FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,0 );
										break;
										//Genin logik 0 / 1
										case 5:											//12.03.2014
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = EeKayit.GENIN_NoNc + 1;				//12.03.2014
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Epo logik 0 / 1
										case 6:											//12.03.2014
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = EeKayit.EPO_NoNc + 1;				//12.03.2014
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Relay Contacts NC / NO
										case 7:											//12.03.2014
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = EeKayit.Role_NoNc + 1;				//12.03.2014
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Enter - Exit
										case 8:
											Menu.TercihAltMenuIci = 0;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
											FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
										break;
										default:
										break;
									}
									//if(( Menu.TercihAltSekme != 5 ) && ( Menu.TercihAltSekme != 4 ))
									//	FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
							break;
							//Alarm Tercihleri
							case 2:		
									switch( Menu.TercihAltSekme )
									{
										//Uyar� Aral���
										case 0:
											Menu.TercihAltMenuIci = EeKayit.UyariSesAraligi - 4;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
										break;
										//Uyar� Kay�t
										case 1:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = EeKayit.Konfig2.Bit.UyariLog+ 1;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Durum Kay�t
										case 2:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = EeKayit.Konfig2.Bit.DurumLog + 1;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Elg Basla
										case 3:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = Can.FromInv.GolgeKonfigInv.Bit.Alf + 1;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													//�ifre Sayfas� gelecek.
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Enter - Exit
										case 4:
											Menu.TercihAltMenuIci = 0;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
											FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
										break;
										default:
										break;
									}
									//if( Menu.TercihAltSekme != 4 )
									//	FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
							break;
							//Bypass Tercihleri
							case 3:		
									switch( Menu.TercihAltSekme )
									{
										//VAT Transfer
										case 0:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = Can.FromInv.GolgeKonfigInv.Bit.Vat + 1;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Jen. Bypass
										case 1:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = Can.FromInv.GolgeKonfigInv.Bit.JenBypass + 1;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Jen. Senkron
										case 2:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													Menu.TercihAltMenuIci = Can.FromInv.GolgeKonfigInv.Bit.JenSenkron + 1;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}	
										break;
										//Mod - Online , Econo falan yaz�lacak
										case 3:
											if( Genel.LoginWaitButon == 0 )
											{
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													//Tercih alt men� �a�r�lacak
													Menu.TercihAltMenuIci = 1 + Can.FromInv.GolgeCalismaModu;
													FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										//Enter - Exit
										case 4:
											Menu.TercihAltMenuIci = 0;
											FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
											FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
										break;
										default:
										break;
									}
							break;
							default:
							break;
						}
					}
					else
					{
						//PopUp se�ilmi�tir.Art�k Pop Up men�y� kald�r ve kaydet.
						FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
						
						switch( Menu.TercihAnaSekme )
						{
							//Ekran Tercihleri
							case 0:					
									switch( Menu.TercihAltSekme )
									{
										//Language
										case 0:
											EeKayit.Dil = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Dil,EeKayit.Dil);
											MenuGraphic(Menu.AnaSekme);	
										break;
										//Buton Ses ayar�
										case 1:
											EeKayit.Konfig.Bit.ButonTik = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Konfig.All,EeKayit.Konfig.All);	
										break;
										//Backlight ayar�
										case 2:
											EeKayit.LcdBacklight = *EkranTercihSigns[Menu.TercihAltMenuIci+2][EeKayit.Dil]-48;
//											Write_Command(0xbc);					//Set Post Processor
//											Write_Data(64);							//Set the contrast value - POR = 01000000 = 64
//											Write_Data(16*EeKayit.LcdBacklight);						//Set the brightness value - POR = 10000000 = 128
//											Write_Data(64);							//Set the saturation value - POR = 01000000 = 64
//											Write_Data(1);							//Post Processor Enable - POR = 0 (0-desable,1-enable)
//											Write_Command(0xbe);					//Set PWM configuration
//											Write_Data(0xff);						//Set the PWM frequency
//											Write_Data(31*EeKayit.LcdBacklight);	//Set the PWM duty cycle
//											Write_Data(0x09);						//3.bit -> 0=Pwm controlled by host , 1= Pwm controlled by DBC ; 1.bit -> 0=Pwm Disable , 1=Pwm enable
//											Write_Data(0xff);						//DBC manual brightness 
//											Write_Data(0x01);						//DBC minimum brightness
//											Write_Data(0x01);						//Brightness prescaler
//											Write_Command(0xd4);
//											Write_Data(0x00);		
//											Write_Data(0x00);		
//											Write_Data(0x00);		
//											Write_Data(0x00);		
//											Write_Data(0x00);		
//											Write_Data(0x00);		
//											Write_Data(0x00);		
//											Write_Data(0x00);
//											Write_Data(0x00);								
//											
//											Write_Command(0xd0);					//Set DBC configuration
//											Write_Data(0x0d);	
//											while(1);				

											Menu.OldLcdBacklight = EeKayit.LcdBacklight;	
											EeWordYaz(&EeKayit.LcdBacklight,EeKayit.LcdBacklight);
										break;
										//Bekleme s�resi
										case 3:
											if( Menu.TercihAltMenuIci == 1 )
												EeKayit.AcikSure = 0;
											else
												EeKayit.AcikSure = (*EkranTercihSigns[Menu.TercihAltMenuIci+6][EeKayit.Dil]-48)*10+(*(EkranTercihSigns[Menu.TercihAltMenuIci+6][EeKayit.Dil]+1)-48);
											EeWordYaz(&EeKayit.AcikSure,EeKayit.AcikSure);
										break;
										//Karartma s�resi
										case 4:
											if( Menu.TercihAltMenuIci == 1 )
												EeKayit.YarimAydinlikSure = 0;
											else
												EeKayit.YarimAydinlikSure = (*EkranTercihSigns[Menu.TercihAltMenuIci+6][EeKayit.Dil]-48)*10+(*(EkranTercihSigns[Menu.TercihAltMenuIci+6][EeKayit.Dil]+1)-48);
											EeWordYaz(&EeKayit.YarimAydinlikSure,EeKayit.YarimAydinlikSure);
										break;
										default:
										break;
									}
							break;
							//Haberle�me Tercihleri
							case 1:		
									switch( Menu.TercihAltSekme )
									{
										//Remote Control
										case 0:
											EeKayit.Konfig.Bit.UzakErisim = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Konfig.All,EeKayit.Konfig.All);	
										break;
										//COM2
										case 1:
											EeKayit.Konfig.Bit.Comm2Secim = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Konfig.All,EeKayit.Konfig.All);							
											if( EeKayit.Konfig.Bit.Comm2Secim == DefServisPort)			//21.08.2013
												InitUART2(9600);
											if( EeKayit.Konfig.Bit.Comm2Secim == DefUserPort)
												InitUART2(2400);
										break;
										//SNMP
										case 2:
											EeKayit.Konfig.Bit.SNMP_OnOff = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Konfig.All,EeKayit.Konfig.All);	
										break;
										//REPO
										case 3:
											EeKayit.REPO_OnOff = Menu.TercihAltMenuIci-1;				//12.03.2014
											EeWordYaz(&EeKayit.REPO_OnOff,EeKayit.REPO_OnOff);			//12.03.2014
										break;
										//Genin lojik 0-1
										case 5:
											EeKayit.GENIN_NoNc = Menu.TercihAltMenuIci-1;				//12.03.2014
											EeWordYaz(&EeKayit.GENIN_NoNc,EeKayit.GENIN_NoNc);			//12.03.2014
										break;
										//Repo lojik 0-1
										case 6:
											EeKayit.EPO_NoNc = Menu.TercihAltMenuIci-1;				//12.03.2014
											EeWordYaz(&EeKayit.EPO_NoNc,EeKayit.EPO_NoNc);			//12.03.2014
										break;
										//Relay NO-NC
										case 7:
											EeKayit.Role_NoNc = Menu.TercihAltMenuIci-1;				//12.03.2014
											EeWordYaz(&EeKayit.Role_NoNc,EeKayit.Role_NoNc);			//12.03.2014
										break;
										default:
										break;
									}
							break;
							//Alarm Tercihleri
							case 2:	
									switch( Menu.TercihAltSekme )
									{
										//Uyar� Aral���
										case 0:	
											EeKayit.UyariSesAraligi = Menu.TercihAltMenuIci - 1 + 5;
											EeWordYaz(&EeKayit.UyariSesAraligi,EeKayit.UyariSesAraligi);
										break;
										//Uyar� Kay�t
										case 1:
											EeKayit.Konfig2.Bit.UyariLog = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Konfig2.All,EeKayit.Konfig2.All);
										break;
										//Durum Kay�t
										case 2:
											EeKayit.Konfig2.Bit.DurumLog = Menu.TercihAltMenuIci-1;
											EeWordYaz(&EeKayit.Konfig2.All,EeKayit.Konfig2.All);
										break;
										//Elg Basla
										case 3:
											//Kullan�c� �ifresi do�ru girilmeli.
											if( Genel.LoginWaitButon == 0 )
											{
												Can.FromInv.GolgeKonfigInv.Bit.Alf = Menu.TercihAltMenuIci-1;
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													CanGonder(DefCanInv,28,'W',Can.FromInv.GolgeKonfigInv.All,46);
													Can.FromInv.EskiKonfigInv.All = Can.FromInv.GolgeKonfigInv.All;
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;		//Kullan�c� veya Servis �ifresi iste
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										default:
										break;
									}
							break;
							//Bypass Tercihleri
							case 3:		
									switch( Menu.TercihAltSekme )
									{
										//VAT Transfer
										case 0:
											if( Genel.LoginWaitButon == 0 )
											{
												Can.FromInv.GolgeKonfigInv.Bit.Vat = Menu.TercihAltMenuIci-1;
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													CanGonder(DefCanInv,28,'W',Can.FromInv.GolgeKonfigInv.All,46);
													Can.FromInv.EskiKonfigInv.All = Can.FromInv.GolgeKonfigInv.All;
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;		//Kullan�c� veya Servis �ifresi iste
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
											break;
										//Jen. Bypass
										case 1:
											if( Genel.LoginWaitButon == 0 )
											{
												Can.FromInv.GolgeKonfigInv.Bit.JenBypass = Menu.TercihAltMenuIci-1;
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													CanGonder(DefCanInv,28,'W',Can.FromInv.GolgeKonfigInv.All,46);
													Can.FromInv.EskiKonfigInv.All = Can.FromInv.GolgeKonfigInv.All;
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;		//Kullan�c� veya Servis �ifresi iste
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
											break;
										//Jen. Senkron
										case 2:		
											if( Genel.LoginWaitButon == 0 )
											{
												//Kullan�c� �ifresi do�ru girilmeli.
												Can.FromInv.GolgeKonfigInv.Bit.JenSenkron = Menu.TercihAltMenuIci-1;
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													CanGonder(DefCanInv,28,'W',Can.FromInv.GolgeKonfigInv.All,46);
													Can.FromInv.EskiKonfigInv.All = Can.FromInv.GolgeKonfigInv.All;
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;		//Kullan�c� veya Servis �ifresi iste
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}	
											}
										break;
										//Mod Ayar�
										case 3:	
											if( Genel.LoginWaitButon == 0 )
											{
												Can.FromInv.GolgeCalismaModu = Menu.TercihAltMenuIci-1;
												if(( Genel.UserPassDogru15dklikIzin == 1 ) || ( EeKayit.Konfig.Bit.UserPassKullanilsin == 0 ))
												{
													if( (Can.FromInv.GolgeCalismaModu==0)||(Can.FromInv.GolgeCalismaModu == 1) )
													{
														CanGonder(DefCanInv,30,'W',Can.FromInv.GolgeCalismaModu,100);
														//Can.FromInv.EskiCalismaModu = Can.FromInv.GolgeCalismaModu;
													}
													else
													{
														//Can.FromInv.GolgeCalismaModu = Can.FromInv.CalismaModu;
														ASendText(15,205,GenelTablo[19][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,0);
														Menu.YenileGeriSayac = 40;
													}
												}
												else
												{
													Menu.AyarPssswordIci = 2;
													Genel.AraSifre_Hangisi = 1;		//Kullan�c� veya Servis �ifresi iste
													FonkAraSifreMenu( Genel.AraSifre_Hangisi,0 );
												}
											}
										break;
										default:
										break;
									}
							break;
							default:
							break;
						}
						Menu.TercihAltMenuIci = 0;
						if( (Can.FromInv.GolgeCalismaModu==0)||(Can.FromInv.GolgeCalismaModu == 1) )			//Calisma modu 3 - 4 yani senkron ya da paralel se�ilemez uyar� verir.
							FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
						else
							Can.FromInv.GolgeCalismaModu = Can.FromInv.CalismaModu;
					}	
				break;
				case DefSagButon:
					switch( Menu.TercihAnaSekme )
					{
						//Ekran Tercihleri
						case 0:					
								switch( Menu.TercihAltSekme )
								{
									//Backlight ayar�
									case 2:
							//			if(++EeKayit.LcdBacklight > DefBackLightUstSinir)
							//				EeKayit.LcdBacklight = DefBackLightUstSinir;
									break;
									//Bekleme s�resi
									case 3:
	//									EeKayit.AcikSure++; 	
	//									if(EeKayit.AcikSure > DefAcikSureUstSinir )
	//									{
	//										EeKayit.AcikSure = 0;
	//										Menu.AcikSureAktif = 0;
	//									}	
	//									if(EeKayit.AcikSure == 1)
	//										EeKayit.AcikSure = DefAcikSureAltSinir;
									break;
									//Karartma s�resi
									case 4:
	//									EeKayit.YarimAydinlikSure++;		
	//									if(EeKayit.YarimAydinlikSure > DefYarimAydinlikSureUstSinir )
	//									{
	//										EeKayit.YarimAydinlikSure = 0;
	//										Menu.YarimAydinlikSureAktif = 0;
	//									}	
	//									if(EeKayit.YarimAydinlikSure == 1)
	//										EeKayit.YarimAydinlikSure = DefYarimAydinlikSureAltSinir;
									break;
									default:
									break;
								}
						break;
						//Haberle�me Tercihleri
						case 1:		
							/*  optimizasyon i�in
								switch( Menu.TercihAltSekme )
								{
									case 0:
									break;
									case 1:
									break;
									case 2:
									break;
									case 3:
									break;
									default:
									break;
								}
							*/
						break;
						//Alarm Tercihleri
						case 2:		
							/*  optimizasyon i�in
								switch( Menu.TercihAltSekme )
								{
									case 0:
									break;
									case 1:
									break;
									case 2:
									break;
									case 3:
									break;
									default:
									break;
								}
							*/
						break;
						//Bypass Tercihleri
						case 3:		
							/*  optimizasyon i�in
								switch( Menu.TercihAltSekme )
								{
									case 0:
									break;
									case 1:
									break;
									case 2:
									break;
									case 3:
									break;
									default:
									break;
								}
							*/
						break;
						default:
						break;
					}
					FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
				break;
				case DefSolButon:
					switch( Menu.TercihAnaSekme )
					{
						//Ekran Tercihleri
						case 0:			
							/*  optimizasyon i�in		
								switch( Menu.TercihAltSekme )
								{
									//Backlight ayar�
									case 2:
									break;
									//Bekleme s�resi
									case 3:
									break;
									//Karartma s�resi
									case 4:
									break;
									default:
									break;
								}
							*/
						break;
						//Haberle�me Tercihleri
						case 1:		
							/*  optimizasyon i�in
								switch( Menu.TercihAltSekme )
								{
									case 0:
									break;
									case 1:
									break;
									case 2:
									break;
									case 3:
									break;
									default:
									break;
								}
							*/
						break;
						//Alarm Tercihleri
						case 2:	
							/*  optimizasyon i�in	
								switch( Menu.TercihAltSekme )
								{
									case 0:
									break;
									case 1:
									break;
									case 2:
									break;
									case 3:
									break;
									default:
									break;
								}
							*/
						break;
						//Bypass Tercihleri
						case 3:		
							/*  optimizasyon i�in
								switch( Menu.TercihAltSekme )
								{
									case 0:
									break;
									case 1:
									break;
									case 2:
									break;
									case 3:
									break;
									default:
									break;
								}
							*/
						break;
						default:
						break;
					}
					FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
				break;
				default:
				break;
			}
		break;
		case DefEmirAltMenu:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:			
					if( Menu.EmirAltMenuIci == 0 )
					{
						if(--Menu.EmirAltSekme < Menu.EmirAltAltLimit)
							Menu.EmirAltSekme = Menu.EmirAltUstLimit;
					}
					else
					{
						if(--Menu.EmirAltMenuIci < Menu.EmirPopUpAltLimit)
							Menu.EmirAltMenuIci = Menu.EmirPopUpUstLimit;					
					}
					FonkEmirAltMenu(Menu.EmirAnaSekme,Menu.EmirAltSekme,Menu.EmirAltMenuIci,0);
				break;
				case DefAsagiButon:	
					if( Menu.EmirAltMenuIci == 0 )
					{
						if(++Menu.EmirAltSekme > Menu.EmirAltUstLimit)
							Menu.EmirAltSekme = Menu.EmirAltAltLimit;
					}
					else
					{
						if(++Menu.EmirAltMenuIci > Menu.EmirPopUpUstLimit)
							Menu.EmirAltMenuIci = Menu.EmirPopUpAltLimit;
					}
					FonkEmirAltMenu(Menu.EmirAnaSekme,Menu.EmirAltSekme,Menu.EmirAltMenuIci,0);
				break;
				case DefEnterButon:	
					if( Menu.EmirAltMenuIci == 0 )
					{
						//E�er Enter - Exit k�sm�ndayken enter a bas�l�rsa ana men�ye d�n.
						//De�ilse PopUp men� ��kar.			
						switch( Menu.EmirAnaSekme )
						{
							//Ekran Tercihleri
							case 5:	
											
	//								switch( Menu.EmirAltSekme )
	//								{
	//									//Language
	//									case 0:
	//										Menu.EmirAltMenuIci = EeKayit.Dil + 1;
	//									break;
	//									//Buton Ses ayar�
	//									case 1:
	//										Menu.EmirAltMenuIci = EeKayit.Konfig.Bit.ButonTik + 1;
	//									break;
	//									//Backlight ayar�
	//									case 2:
	//										Menu.TercihAltMenuIci = 1;
	//									break;
	//									//Bekleme s�resi
	//									case 3:
	//										Menu.TercihAltMenuIci = 1;
	//									break;
	//									//Karartma s�resi
	//									case 4:
	//										Menu.TercihAltMenuIci = 1;
	//									break;
	//									//Enter - Exit
	//									case 5:
	//										Menu.TercihAltMenuIci = 0;
	//										FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
	//										FonkTercihAnaMenu(Menu.TercihAnaSekme,0);
	//									break;
	//									default:
	//									break;
	//								}
	//								if( Menu.TercihAltSekme != 5 )
	//									FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,0);
							break;
		
							default:
							break;
						}
					}
					else
					{
						//PopUp se�ilmi�tir.Art�k Pop Up men�y� kald�r ve kaydet.
			//			FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
						
						switch( Menu.EmirAnaSekme )
						{
							//Alarm Ses A��k - Kapal�
							case 5:			
									Menu.MaskeAlarmSesAcik = Menu.EmirAltMenuIci-1;
											
									FonkEmirAltMenu(Menu.EmirAnaSekme,Menu.EmirAltSekme,Menu.EmirAltMenuIci,1);
									Menu.EmirAltMenuIci = 0;
									FonkEmirAnaMenu(Menu.EmirAnaSekme,0);	
							break;
							default:
							break;		
						}
					}
				break;
				default:
				break;
			}
		break;
		//Emir Men�s�nde R�le test i�in men�
		case DefEmirRoleMenu:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:
					//Opsiyon kart� (OPT03) kart� kullan�lm�yorken 4 r�le var.
					if( EeKayit.Konfig.Bit.Opt03Secim == 0 )
					{
						if(--Menu.RoleSimulasyonu < 0)
							Menu.RoleSimulasyonu = 4;
					}
					//Opsiyon kart� (OPT03) kart� kullan�l�yorken 12 adet r�le var.
					else
					{
						if(--Menu.RoleSimulasyonu < 0)
							Menu.RoleSimulasyonu = 12;
					}
					FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
				break;
				case DefAsagiButon:	
					//Opsiyon kart� (OPT03) kart� kullan�lm�yorken 4 r�le var.
					if( EeKayit.Konfig.Bit.Opt03Secim == 0 )
					{
						if(++Menu.RoleSimulasyonu > 4)
							Menu.RoleSimulasyonu = 0;
					}
					//Opsiyon kart� (OPT03) kart� kullan�l�yorken 12 adet r�le var.
					else
					{
						if(++Menu.RoleSimulasyonu > 12)
							Menu.RoleSimulasyonu = 0;
					}
					FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
				break;
				case DefEnterButon:			
			
					if( Menu.EnterExit == 1 )
					{
						FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,1);
						FonkEmirAnaMenu(Menu.EmirAnaSekme,0);
						
						Genel.RoleSimulasyonToggle = 0;
						for( z3 = 0;z3 < 12;z3++ )
							RoleIslem(z3,Genel.RoleSimulasyonToggle);
						//Simulasyon kapal� iken 4sn sonra alarmlara bakmaya ba�lar.
						Menu.RoleTestSayac = 30;
					}
					else
					{	
						// 30 x 2s = 60s alarma ba�l� role �ekmesin 
						if( Menu.RoleTestSayac == 0 )
							Genel.RoleSimulasyonToggle = 0;
						Menu.RoleTestSayac = 30;
						
						Genel.RoleSimulasyonToggle ^= 1;
						FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
					}
				break;
				case DefSagButon:
					//Opsiyon kart� (OPT03) kart� kullan�lm�yorken 4 r�le var.
					if( EeKayit.Konfig.Bit.Opt03Secim == 0 )
					{
						if(Menu.RoleSimulasyonu == 0)
						{
							Menu.RoleSimulasyonu = 1;
						}	
						else
						{
							Menu.RoleSimulasyonu += 3;
							if(Menu.RoleSimulasyonu > 4)
								Menu.RoleSimulasyonu = 0;
						}
					}
					//Opsiyon kart� (OPT03) kart� kullan�l�yorken 12 adet r�le var.
					else
					{
						if(Menu.RoleSimulasyonu == 0)
						{
							Menu.RoleSimulasyonu = 1;
						}	
						else
						{
							Menu.RoleSimulasyonu += 3;
							if(Menu.RoleSimulasyonu > 12)
								Menu.RoleSimulasyonu = 0;
						}
					}
					FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);
				break;
				case DefSolButon:
					//Opsiyon kart� (OPT03) kart� kullan�lm�yorken 4 r�le var.
					if( EeKayit.Konfig.Bit.Opt03Secim == 0 )
					{
						if(Menu.RoleSimulasyonu == 0)
						{
							Menu.RoleSimulasyonu = 1;
						}	
						else
						{
							Menu.RoleSimulasyonu -= 3;
							if(Menu.RoleSimulasyonu < 0)
								Menu.RoleSimulasyonu = 0;
						}
					}
					//Opsiyon kart� (OPT03) kart� kullan�l�yorken 12 adet r�le var.
					else
					{
						if(Menu.RoleSimulasyonu == 0)
						{
							Menu.RoleSimulasyonu = 1;
						}	
						else
						{
							Menu.RoleSimulasyonu -= 3;
							if(Menu.RoleSimulasyonu < 0)
								Menu.RoleSimulasyonu = 0;
						}
					}
					FonkEmirRoleMenu(Menu.RoleSimulasyonu,Genel.RoleSimulasyonToggle,0);	
				break;
			}
		break;		
		case DefRoleAlarmAtama:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:
					if(--Menu.RoleAlrRoleSec < Menu.AlrRoleAltLimit)
						Menu.RoleAlrRoleSec = Menu.AlrRoleUstLimit;
					FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,0 );
				break;
				case DefAsagiButon:	
					if(++Menu.RoleAlrRoleSec > Menu.AlrRoleUstLimit)
						Menu.RoleAlrRoleSec = Menu.AlrRoleAltLimit;
					FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,0 );
				break;
				case DefEnterButon:					
					if( Menu.EnterExit == 1 )
					{
						for(z3 = 0;z3 < 12;z3++)
							EeWordYaz(&EeKayit.Role[z3],EeKayit.Role[z3]);
						FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,1 );
						Menu.Sekme.All = DefTercihAltMenu;
						Menu.YenileGeriSayac = 2;
					}
					else
					{	
						//Alarm� r�leye at - eeprom kayd� yap.
						EeWordYaz(&EeKayit.Role[Menu.RoleAlrRoleSec],EeKayit.Role[Menu.RoleAlrRoleSec]);
					}
				break;
				case DefSagButon:
				
					if( Menu.RoleAlrRoleSec == 0 )                                                  
						//Menu.RoleSinir = 64;
						Menu.RoleSinir = 65;		//06.07.2015 tarihinde Genel Alarm
					else
						//Menu.RoleSinir = 63;
                        Menu.RoleSinir = 64;		//06.07.2015 tarihinde Genel Alarm
						
					if(++Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec] > Menu.RoleSinir) 
						Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec] = 0;					
					//Aralardaki alarmlardan baz�lar�n� ��karmak istendi�inde	!!!
					//if(RoleAtama[Menu.RoleAtamaDeger[Menu.TercihAltSekme-4]] == �stenilmeyen Alarm)
					//	Menu.RoleAtamaDeger[Menu.TercihAltSekme-4]++;
					//Yap�labilir.	
					Menu.OldRoleAtamaDeger[Menu.RoleAlrRoleSec] = Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec];			
					EeKayit.Role[Menu.RoleAlrRoleSec] = RoleAtama[Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec]];
					
					FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,0 );
				break;
				case DefSolButon:
					if( Menu.RoleAlrRoleSec == 0 )             
						//Menu.RoleSinir = 64;
						Menu.RoleSinir = 65;		//06.07.2015 tarihinde Genel Alarm
					else
						//Menu.RoleSinir = 63;
                        Menu.RoleSinir = 64;		//06.07.2015 tarihinde Genel Alarm
						
					if(--Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec] < 0)
						Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec] = Menu.RoleSinir;			
					//Aralardaki alarmlardan baz�lar�n� ��karmak istendi�inde		!!!
					//if(RoleAtama[Menu.RoleAtamaDeger[Menu.TercihAltSekme-4]] == �stenilmeyen Alarm)
					//	Menu.RoleAtamaDeger[Menu.TercihAltSekme-4]--;
					//Yap�labilir.		
					Menu.OldRoleAtamaDeger[Menu.RoleAlrRoleSec] = Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec];			
					EeKayit.Role[Menu.RoleAlrRoleSec] = RoleAtama[Menu.RoleAtamaDeger[Menu.RoleAlrRoleSec]];
					
					FonkRoleAlarmAtama( Menu.RoleAlrRoleSec, Menu.RoleAlrSec ,0 );	
				break;
			}
		break;	
		case DefAyarAnaMenu:
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:
					if(--Menu.AyarAnaSekme < Menu.AyarAnaAltLimit)
						Menu.AyarAnaSekme = Menu.AyarAnaUstLimit;
					FonkAyarAnaMenu(Menu.AyarAnaSekme,0);
				break;
				case DefAsagiButon:	
					if(++Menu.AyarAnaSekme > Menu.AyarAnaUstLimit)
						Menu.AyarAnaSekme = Menu.AyarAnaAltLimit;
					FonkAyarAnaMenu(Menu.AyarAnaSekme,0);
				break;
				case DefEnterButon:					
					if( Menu.EnterExit == 1 )
					{
						//�ifre girildi�i sayfada servis login se ekranda ilk servis login yazar ve ayarana men�ye gelir.
						//Ayar ana men�den geriye ��k�nca b�yle bir �ey olmas�n diye 
						Menu.AyarMenulerIlkGiris = 1;
						FonkAyarAnaMenu(Menu.AyarAnaSekme,1);
						Menu.Sekme.All = DefAnaMenu;
						Menu.YenileGeriSayac = 10;
					}
					else
					{	
						FonkAyarAnaMenu(Menu.AyarAnaSekme,1);
						Menu.AyarAltSekme = 0; Menu.AyarEtiket = 0;
						Menu.Sekme.All = DefAyarAltMenu;
						Menu.YenileGeriSayac = 5;
					}
				break;
				case DefSagButon:
				break;
				case DefSolButon:	
				break;
			}
		break;		
		case DefAyarAltMenu:
			Menu.EnSonKalinanSekme = DefAyarAltMenu;
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:
					if(--Menu.AyarAltSekme < Menu.AyarAlt_1_AltLimit)
						Menu.AyarAltSekme = Menu.AyarAlt_1_UstLimit;
					FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
				break;
				case DefAsagiButon:	
					if(++Menu.AyarAltSekme > Menu.AyarAlt_1_UstLimit)
						Menu.AyarAltSekme = Menu.AyarAlt_1_AltLimit;
					FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
				break;
				case DefEnterButon:		
					if( Menu.EnterExit )
					{
					//	LcdTemizle();
						Menu.EnterExit = 0;
						
						for( for_i=0;for_i<5;for_i++ )
						{
							//AyarAnaMenuFonk u �a�r�lacak
							ASendText(320,(90+272+(for_i*20)),">",2,0xffffff,NOTGRADIENTCOLOR,1);
							ASendText(40,(90+272+(for_i*20)),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
						}										
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
						
						FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,1);							
						Menu.Sekme.All = DefAyarAnaMenu;
						Menu.YenileGeriSayac = 5;
					}	
					else
					{
						//Menu.AyarAltSekme = 2 ve Enter - Exit olmayan yer sadece grup parametrelerinde alt sayfalar.
						if( Menu.AyarAltSekme == 2 )
						{	
							//Her Ayar Alt men�ye giri�te Ayar de�eri s�f�rlans�n
							Menu.AyarAyar = 0;
							Menu.AyarSonuc = 0;	
							//Ayar alt men�s�ne etiket,ayar,sonuc sayfas�ndan ba�la
					//		Menu.AyarGrupAltSekme = 1;
					//		FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme);
							FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,1);
					//		ASendText(50,(170+272),AyarAltMenu[32],2,0xffffff,NOTGRADIENTCOLOR,1);			//Group parametrelerini sil.
							Menu.AyarGrupAltSekme = 0;
							Menu.Sekme.All = DefAyarGrupAltMenu;
							Menu.YenileGeriSayac = 5;		
						}
						else
						{
							if( Can.FromInv.LogInDurum )
							{
								if( Menu.AyarAltSekme == 1 )
								{
									Can.FromInv.DogruDataGosterSayac = 0;
									Can.FromPfc.DogruDataGosterSayac = 0;
									//G�nderme i�lemleri yap�lacak.					
									Can.AyarMenuDizisi[3] = 'W'; 
									//Ram in kendisinden s�rekli sordu�u adresler i�in
									Can.AyarMenuDizisi[4] = 0;
									AyarAltMenuCanSorgu( Can.AyarMenuDizisi );
								}
							}
						}
					}
				break;
				case DefSagButon:			//AyarDizi[] deki etiketleri de�i�tirirken
					if( Menu.AyarAltSekme ==  0)
					{
						if(++Menu.AyarEtiket > Menu.AyarAlt_2_UstLimit)
							Menu.AyarEtiket = Menu.AyarAlt_2_AltLimit;
										
						//Ayar men�s�nde her yeni bir de�i�ken sorguland���nda ekran s�f�r g�sterir.
						//Data gelirse de�erler yazar.
						//Datalar do�ru yazs�n diye gelen ilk data de�il ikinci data yaz�l�r.
						Can.FromInv.DogruDataGosterSayac = 0;
						Can.FromPfc.DogruDataGosterSayac = 0;
						Menu.AyarAyar = 0; 
						Menu.AyarSonuc = 0;	
						
						FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
					}
					//Ayarlanan (G�nderilecek) de�eri de�i�tirir.
					if( Menu.AyarAltSekme ==  1)
					{
						Menu.AyarAyar += Artim;
						//Buralara gerekirse s�n�r konulabilir.
	//					switch( Menu.AyarEtiket )
	//					{
	//						case 1:
	//						break;
	//						default:
	//						break;
	//					}
						FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
					}
				break;
				case DefSolButon:	
					//AyarDizi[] deki etiketleri de�i�tirirken
					if( Menu.AyarAltSekme ==  0)
					{
						if(--Menu.AyarEtiket < Menu.AyarAlt_2_AltLimit)
							Menu.AyarEtiket = Menu.AyarAlt_2_UstLimit;
										
						//Ayar men�s�nde her yeni bir de�i�ken sorguland���nda ekran s�f�r g�sterir.
						//Data gelirse de�erler yazar.
						//Datalar do�ru yazs�n diye gelen ilk data de�il ikinci data yaz�l�r.
						Can.FromInv.DogruDataGosterSayac = 0;
						Can.FromPfc.DogruDataGosterSayac = 0;
						Menu.AyarAyar = 0; 
						Menu.AyarSonuc = 0;	
						FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
					}
					//Ayarlanan (G�nderilecek) de�eri de�i�tirir.
					if( Menu.AyarAltSekme ==  1)
					{
						Menu.AyarAyar -= Artim;
						//Buralara gerekirse s�n�r konulabilir.
	//					switch( Menu.AyarEtiket )
	//					{
	//						case 1:
	//						break;
	//						default:
	//						break;
	//					}
						FonkAyarAltMenuFonk(Menu.AyarAnaSekme,Menu.AyarAltSekme,0);
					}
				break;
			}
		break;
		case DefAyarGrupAltMenu:
			Menu.EnSonKalinanSekme = DefAyarGrupAltMenu;
			//Buton i�lemleri
			switch( Menu.Buton.All )
			{
				case DefYukariButon:
					if(--Menu.AyarGrupAltSekme < Menu.GrupAltLimit)
						Menu.AyarGrupAltSekme = Menu.GrupUstLimit;	
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
				break;
				case DefAsagiButon:	
					if(++Menu.AyarGrupAltSekme > Menu.GrupUstLimit)
						Menu.AyarGrupAltSekme = Menu.GrupAltLimit;
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
				break;
				case DefEnterButon:
					if( Menu.EnterExit )
					{
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,1);
						//Alt grup parametreleri her zaman ba�tan ba�las�n
						Menu.AyarGrupEtiket = 0;
						Menu.EnterExit = 0;
						//Her Ayar Alt men�ye giri�te Ayar de�eri s�f�rlans�n
						Menu.AyarAyar = 0;
						//AyarAltMenuFonk u �a�r�lacak
						Menu.Sekme.All = DefAyarAltMenu;
						Menu.YenileGeriSayac = 5;
					}	
					else
					{
						if( Can.FromInv.LogInDurum )
						{
							if(Menu.AyarGrupAltSekme == 1)
							{
								Can.FromInv.DogruDataGosterSayac = 0;
								Can.FromPfc.DogruDataGosterSayac = 0;
								//G�nderme i�lemleri yap�lacak.					
								Can.AyarMenuDizisi[3] = 'W'; 
								//Ram in kendisinden s�rekli sordu�u adresler i�in
								Can.AyarMenuDizisi[4] = 0;
								AyarAltMenuCanSorgu( Can.AyarMenuDizisi );
							}
						}
					}	
				break;
				case DefSagButon:
					//AyarDizi[] deki etiketleri de�i�tirirken
					if( Menu.AyarGrupAltSekme ==  0 )
					{
						if(++Menu.AyarGrupEtiket > Menu.AyarGrupUstLimit)
							Menu.AyarGrupEtiket = Menu.AyarGrupAltLimit;
										
						//Ayar men�s�nde her yeni bir de�i�ken sorguland���nda ekran s�f�r g�sterir.
						//Data gelirse de�erler yazar.
						//Datalar do�ru yazs�n diye gelen ilk data de�il ikinci data yaz�l�r.
						Can.FromInv.DogruDataGosterSayac = 0;
						Can.FromPfc.DogruDataGosterSayac = 0;
						Menu.AyarAyar = 0; 
						Menu.AyarSonuc = 0;	
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
					}
					//Ayarlanan (G�nderilecek) de�eri de�i�tirir.
					if( Menu.AyarGrupAltSekme ==  1)
					{
						Menu.AyarAyar += Menu.ButonArtim;
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
					}
				break;
				case DefSolButon:
					//AyarDizi[] deki etiketleri de�i�tirirken
					if( Menu.AyarGrupAltSekme ==  0)
					{
						if(--Menu.AyarGrupEtiket < Menu.AyarGrupAltLimit)
							Menu.AyarGrupEtiket = Menu.AyarGrupUstLimit;
										
						//Ayar men�s�nde her yeni bir de�i�ken sorguland���nda ekran s�f�r g�sterir.
						//Data gelirse de�erler yazar.
						//Datalar do�ru yazs�n diye gelen ilk data de�il ikinci data yaz�l�r.
						Can.FromInv.DogruDataGosterSayac = 0;
						Can.FromPfc.DogruDataGosterSayac = 0;
						Menu.AyarAyar = 0; 
						Menu.AyarSonuc = 0;	
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
					}
					//Ayarlanan (G�nderilecek) de�eri de�i�tirir.
					if( Menu.AyarGrupAltSekme ==  1)
					{
						Menu.AyarAyar -= Menu.ButonArtim;
						FonkAyarGrupAltMenu(Menu.AyarEtiket,Menu.AyarGrupAltSekme,0);
					}
				break;
			}
		break;
		default:
		break;	
	}

	
}	

//Zamana ba�l� i�ler	100 ms de bir girer.
//Devaml� yenilenecek i�lemler
void ZamanaBagliIsler(void)
{	
	static int YenileSayac = 0;
	static int YenileSayac1 = 0;
	static unsigned int EskiToplamSaat = 0;
		
	static int EskiFanBakimSure;
	static int EskiAkuBakimSure;
	static int EskiGenelBakimSure;
	
	Timer.Bit.Sn0_1 = 0;
	
	//Maximum y�k hesaplar�
	if(Can.FromInv.Load.L1 > Menu.MaxYuk.L1)
		Menu.MaxYuk.L1 = Can.FromInv.Load.L1;
	if(Can.FromInv.Load.L2 > Menu.MaxYuk.L2)
		Menu.MaxYuk.L2 = Can.FromInv.Load.L2;
	if(Can.FromInv.Load.L3 > Menu.MaxYuk.L3)
		Menu.MaxYuk.L3 = Can.FromInv.Load.L3;
			
	if( Menu.EskiAlarmSesAcik != Menu.MaskeAlarmSesAcik )
	{
		Menu.EskiAlarmSesAcik = Menu.MaskeAlarmSesAcik;
		ExBigVariable(430,243+(GlobalSayfa*272),4,3,14-Menu.MaskeAlarmSesAcik,0xffff00,0);			//Hoparl�r
	}	
	// Options\Dim & Delay s�re i�lemleri	
	if( Menu.EskiAcikSureGeriSayac != (EeKayit.AcikSure * 10) )
	{
		//100 ms x 10 x AcikSure = 1s x AcikSure
		Menu.AcikSureGeriSayac = EeKayit.AcikSure * 10; 
		Menu.YarimAydinlikSureGeriSayac = EeKayit.YarimAydinlikSure * 10;
		Menu.EskiAcikSureGeriSayac = EeKayit.AcikSure * 10;
		
		Menu.AcikSureAktif = 1;
		if(EeKayit.AcikSure > DefAcikSureUstSinir )
		{
			EeKayit.AcikSure = 0;
			Menu.AcikSureAktif = 0;
		}	
		if(EeKayit.AcikSure == 1)
			EeKayit.AcikSure = DefAcikSureAltSinir;
			
		Menu.AcikSureAktif = 1;
					
		if(EeKayit.AcikSure < 0)
			EeKayit.AcikSure = DefAcikSureUstSinir;
		if(EeKayit.AcikSure < DefAcikSureAltSinir )
		{
			EeKayit.AcikSure = 0;
			Menu.AcikSureAktif = 0;
		}	
		EeKayit.LcdBacklight = Menu.OldLcdBacklight;
	}
		
	if( Menu.EskiYarimAydinlikSureGeriSayac != (EeKayit.YarimAydinlikSure * 10) )
	{
		//100 ms x 10 x AcikSure = 1s x AcikSure
		Menu.AcikSureGeriSayac = EeKayit.AcikSure * 10; 
		Menu.YarimAydinlikSureGeriSayac = EeKayit.YarimAydinlikSure * 10;
		Menu.EskiYarimAydinlikSureGeriSayac = EeKayit.YarimAydinlikSure * 10;
		
		Menu.YarimAydinlikSureAktif = 1;
		if(EeKayit.YarimAydinlikSure > DefYarimAydinlikSureUstSinir )
		{
			EeKayit.YarimAydinlikSure = 0;
			Menu.YarimAydinlikSureAktif = 0;
		}	
		if(EeKayit.YarimAydinlikSure == 1)
			EeKayit.YarimAydinlikSure = DefYarimAydinlikSureAltSinir;
			
		Menu.YarimAydinlikSureAktif = 1;
			
		if(EeKayit.YarimAydinlikSure < 0)
			EeKayit.YarimAydinlikSure = DefYarimAydinlikSureUstSinir;
		if(EeKayit.YarimAydinlikSure < DefYarimAydinlikSureAltSinir )
		{
			EeKayit.YarimAydinlikSure = 0;
			Menu.YarimAydinlikSureAktif = 0;
		}			
		EeKayit.LcdBacklight = Menu.OldLcdBacklight;
	}
	
	if( Menu.AcikSureGeriSayac > 0 )
	{
		Menu.AcikSureGeriSayac--;
		if( Menu.AcikSureGeriSayac == 1 )
		{
			EeKayit.LcdBacklight = 4;	
			Menu.YenileGeriSayac = 4;
		}
	}	
	else
	{
		if( Menu.YarimAydinlikSureGeriSayac > 0 )
		{
			Menu.YarimAydinlikSureGeriSayac--;
			if( Menu.YarimAydinlikSureGeriSayac == 1 )
			{
				EeKayit.LcdBacklight = 2;
				Menu.YenileGeriSayac = 4;	
			}
		}
	}	
		
	//Normal �al��madurumunda Backlight konulacak, onun d���nda Ba�ka i�lemler var.
	if(( CalismaDurumu.Bit.Bit0 == 0 ) || ( Genel.UPSKapaliGeriSayac > 0 ))	
		PDC4 = EeKayit.LcdBacklight * 4500;	
	//Pfc ve Inv Comm Err kontrol
	if( Can.FromInv.DataGelmediSayac > 0 )
	{
		Alarm.Word.Lcd1.Bit.InvCommErr = 0;	
		Can.FromInv.DataGelmediSayac--;
	}
	else
	{
		//T�m alarmlar� s�f�rla , sadece can err ler aktif
		Alarm.Half[0] = 0; 
		Alarm.Word.Inv3.All = 0;
		Alarm.Word.Lcd1.All = Alarm.Word.Lcd1.All & 0b0011000000000000;
		//Measure men� de�i�kenleri temizlendi.
		Can.FromInv.BypFreq = 0; 
		Can.FromInv.CoutRMS.L1 = 0;	Can.FromInv.CoutRMS.L2 = 0;	Can.FromInv.CoutRMS.L3 = 0;		
		Can.FromInv.CrestFactor.L1 = 0;	Can.FromInv.CrestFactor.L2 = 0;	Can.FromInv.CrestFactor.L3 = 0; 
		Can.FromInv.InvDCBus.Neg = 0; Can.FromInv.InvDCBus.Pos = 0; 
		Can.FromPfc.RecDCBus.Neg = 0; Can.FromPfc.RecDCBus.Pos = 0; 
		Can.FromInv.InvFreq = 0; 
		Can.FromInv.Load.L1 = 0; Can.FromInv.Load.L2 = 0; Can.FromInv.Load.L3 = 0; 
		Can.FromInv.OutFreq = 0; 
		Can.FromInv.Pf.L1 = 0; Can.FromInv.Pf.L2 = 0;Can.FromInv.Pf.L3 = 0;
		Can.FromInv.PowerVa.L1 = 0; Can.FromInv.PowerVa.L2 = 0; Can.FromInv.PowerVa.L3 = 0;
		Can.FromInv.PowerWatt.L1 = 0; Can.FromInv.PowerWatt.L2 = 0; Can.FromInv.PowerWatt.L3 = 0; 
		Can.FromInv.VbypRMS.L1 = 0; Can.FromInv.VbypRMS.L2 = 0; Can.FromInv.VbypRMS.L3 = 0;
		Can.FromInv.VbypRMS.L1L3 = 0; Can.FromInv.VbypRMS.L2L1 = 0; Can.FromInv.VbypRMS.L3L2 = 0;
		Can.FromInv.VinvRMS.L1 = 0; Can.FromInv.VinvRMS.L2 = 0; Can.FromInv.VinvRMS.L3 = 0; 
		Can.FromInv.VinvRMS.L1L3 = 0; Can.FromInv.VinvRMS.L2L1 = 0; Can.FromInv.VinvRMS.L3L2 = 0; 
		Can.FromInv.VoutRMS.L1 = 0; Can.FromInv.VoutRMS.L2 = 0; Can.FromInv.VoutRMS.L3 = 0;
		Can.FromInv.VoutRMS.L1L3 = 0; Can.FromInv.VoutRMS.L2L1 = 0; Can.FromInv.VoutRMS.L3L2 = 0;
		//Alarm verildi.
		Alarm.Word.Lcd1.Bit.InvCommErr = 1;
	}
	if( Can.FromPfc.DataGelmediSayac > 0 )
	{		
		Alarm.Word.Lcd1.Bit.PfcCommErr = 0;
		Can.FromPfc.DataGelmediSayac--;
	}
	else
	{
		//T�m alarmlar� s�f�rla , sadece can err ler aktif
		Alarm.Half[0] = 0; Alarm.Word.Lcd1.All = Alarm.Word.Lcd1.All & 0b0011000000000000;
		//Measure menu de�i�kenleri temizlendi.
		Can.FromPfc.CbattC.Neg = 0; Can.FromPfc.CbattC.Pos = 0; 
		Can.FromPfc.CinRMS.L1 = 0; Can.FromPfc.CinRMS.L2 = 0; Can.FromPfc.CinRMS.L3 = 0; 
		Can.FromPfc.SonucDisCbattC.Neg = 0; Can.FromPfc.SonucDisCbattC.Pos = 0; 
		Can.FromPfc.RecDCBus.Neg = 0; Can.FromPfc.RecDCBus.Pos = 0;
		Can.FromPfc.VBatt.Neg = 0; Can.FromPfc.VBatt.Pos = 0;
		Can.FromPfc.RecFreq = 0; 
		Can.FromPfc.RecTemp = 0;  
		Can.FromPfc.VinRMS.L1 = 0; Can.FromPfc.VinRMS.L2 = 0; Can.FromPfc.VinRMS.L3 = 0;
		Can.FromPfc.VinRMS.L1L3 = 0; Can.FromPfc.VinRMS.L2L1 = 0; Can.FromPfc.VinRMS.L3L2 = 0;
		//Alarm verildi.
		Alarm.Word.Lcd1.Bit.PfcCommErr = 1;
	}	
	
	//Uart ile alakal� aktif ve error i�lemlerinin kontrol�
	if( Uart1.ErrSayac > 0 )
	{
		if( Uart1.ErrSayac == 1 )
		{
			Uart1.GlobalSayac = 0;
			Uart1.LokalSayac = 0;
			Uart1.Flag = 0;
		}
		Uart1.ErrSayac--;
	}
	if( Uart2.ErrSayac > 0 )
	{
		if( Uart2.ErrSayac == 1 )
		{
			Uart2.GlobalSayac = 0;
			Uart2.LokalSayac = 0;
			Uart2.Flag = 0;
		}	
		Uart2.ErrSayac--;
	}	
	if( U1STAbits.OERR == 1 )
	{
		U1STAbits.OERR = 0;	
		Uart1.ClrBuf[0] = *(&U1RXREG);
		Uart1.ClrBuf[1] = *(&U1RXREG + 1);
		Uart1.ClrBuf[2] = *(&U1RXREG + 2);
		Uart1.ClrBuf[3] = *(&U1RXREG + 3);								
	}
	if( U2STAbits.OERR == 1 )
	{
		U2STAbits.OERR = 0;	
		Uart2.ClrBuf[0] = *(&U2RXREG);
		Uart2.ClrBuf[1] = *(&U2RXREG + 1);
		Uart2.ClrBuf[2] = *(&U2RXREG + 2);
		Uart2.ClrBuf[3] = *(&U2RXREG + 3);
	}
	if( Uart1.AktifSayac > 0 )
	{
		if( Uart1.AktifSayac == 1 )
			Uart1.Aktif = 0;	
		Uart1.AktifSayac--;
	}
	if( Uart2.AktifSayac > 0 )
	{
		if( Uart2.AktifSayac == 1 )
			Uart2.Aktif = 0;
		Uart2.AktifSayac--;
	}	
	
	if( Menu.Sekme.All == DefTercihAltMenu )	
	{
		if( Can.FromInv.EskiKonfigInv.All != Can.FromInv.KonfigInv.All )
		{
			Can.FromInv.EskiKonfigInv.All = Can.FromInv.KonfigInv.All;
			Can.FromInv.GolgeKonfigInv.All = Can.FromInv.KonfigInv.All; 
			Menu.YenileGeriSayac = 40;
		}
		if( Can.FromInv.EskiCalismaModu != Can.FromInv.CalismaModu )
		{
			Can.FromInv.EskiCalismaModu = Can.FromInv.CalismaModu;
			Can.FromInv.GolgeCalismaModu = Can.FromInv.CalismaModu;
			Menu.YenileGeriSayac = 40;
		}
	}
	
	switch(Menu.AnaSekme)
	{
		case DefDurumMenu:
		break;
		case DefOlcumMenu:
			if(Timer.Bit.Sn1__2)
			{
				Timer.Bit.Sn1__2 = 0;
				if( Menu.Sekme.All == DefOlcumAltMenu )
					FonkOlcumAnaMenu(Menu.OlcumAltSekme,1,0);
			}
		break;
		case DefAlarmMenu:
		break;
		case DefBilgiMenu:
			//Alt men�deyse
//			if( ( Uart1.EskiAktif != Uart1.Aktif ) || ( Uart2.EskiAktif != Uart2.Aktif ) )
//				if( Menu.Alt1Sekme == 0 )
//					InfoMenu(Menu.Alt1Sekme,0);
//			Uart1.EskiAktif = Uart1.Aktif;
//			Uart2.EskiAktif = Uart2.Aktif;
			if( ++YenileSayac > 5 )
			{
				YenileSayac = 0;
				InfoMenu(Menu.Alt1Sekme,0);
			}
		break;
		case DefTercihMenu:
		break;
		case DefEmirMenu:
			if( Menu.Sekme.All == DefAnaMenu )
			{	
				if( Menu.RecDcBusEski != Can.FromPfc.RecDCBus.Pos )
				{
					Menu.YenileGeriSayac = 5;
					Menu.RecDcBusEski = Can.FromPfc.RecDCBus.Pos;
				}
				//Emirler men�s�nde Enter<Bypass veya Inverter> yaz�s� i�in otomatik se�im yapmas�n� sa�lar.
				if( Alarm.Word.Inv1.Bit.Bakimda || Alarm.Word.Inv1.Bit.ElleBypass || Alarm.Word.Inv2.Bit.CikisKesik || Alarm.Word.Inv2.Bit.CikisBypassta || Alarm.Word.Inv3.Bit.InvStop)
				{
					//Inv ye ge� yaz�s� ekranda yazacak �ekildi g�r�nmektedir.
					Menu.EnterBypOrInv = 1;
				}
				else
				{
					if(( Menu.EnterBypOrInv == 1 ) && ( Menu.YenileGeriSayac == 0 ))
					{
			//			if(( Genel.EkranUyariMesajiVar_AlarmGosterme == 0 ) && ( Genel.HemenEkranYenilemesin == 0 ))
						Menu.YenileGeriSayac = 5;
					}
					//Byp ye ge� yaz�s� ekranda yazacak �ekildi g�r�nmektedir.
					Menu.EnterBypOrInv = 0;
				}
			}
		break;
		case DefZamanMenu:
		break;
		case DefServisMenu:
			if( Menu.Sekme.All == DefAnaMenu )
			{	
				if( EeKayit.ToplamSaat != EskiToplamSaat )
				{
					EskiToplamSaat = EeKayit.ToplamSaat;
					//Zaten bir yenileme i�lemi yap�lacaksa yenileme
					if( Menu.YenileGeriSayac == 0 )
						Menu.YenileGeriSayac = 5;
				}
				if(( Menu.MaxYuk.L1 != Genel.MaxYukL1 ) || ( Menu.MaxYuk.L2 != Genel.MaxYukL2 ) || ( Menu.MaxYuk.L3 != Genel.MaxYukL3 ))
				{
					Genel.MaxYukL1 = Menu.MaxYuk.L1; Genel.MaxYukL2 = Menu.MaxYuk.L2; Genel.MaxYukL3 = Menu.MaxYuk.L3;
					Menu.YenileGeriSayac = 5;
				}	
				if( EeKayit.Bakim[DefFanBakim].KalanSure != EskiFanBakimSure )
				{
					Menu.YenileGeriSayac = 5;
					EskiFanBakimSure = EeKayit.Bakim[DefFanBakim].KalanSure;
				}
				if( EeKayit.Bakim[DefAkuBakim].KalanSure != EskiAkuBakimSure )
				{
					Menu.YenileGeriSayac = 5;
					EskiAkuBakimSure = EeKayit.Bakim[DefAkuBakim].KalanSure;
				}
				if( EeKayit.Bakim[DefGenelBakim].KalanSure != EskiGenelBakimSure )
				{
					Menu.YenileGeriSayac = 5;
					EskiGenelBakimSure = EeKayit.Bakim[DefGenelBakim].KalanSure;
				}
					
				if( Menu.EskiAlarmSesAcik != Menu.MaskeAlarmSesAcik )
				{
					Menu.EskiAlarmSesAcik = Menu.MaskeAlarmSesAcik;
					ExBigVariable(430,243+(GlobalSayfa*272),4,3,14-Menu.MaskeAlarmSesAcik,0xffff00,0);			//Sembol 1
					Menu.YenileGeriSayac = 5;
				}
				if( Can.FromInv.LogInDurum != Can.FromInv.EskiLogInDurum )
				{
					Can.FromInv.EskiLogInDurum = Can.FromInv.LogInDurum;
					Menu.YenileGeriSayac = 5;
				}	
			}
		break;
		case DefAyarMenu:
		break;
		case DefKalibrasyon:
		break;
		default:
		break;
	}
}	
//50 ms de bir timer6 dan �a�r�l�r.
void BuzzerKontrol(void)
{
	unsigned int Role_i;
	//Buton buzzer sesini ayarlar.
	//Her zaman sabit s�re �tmesi sa�lan�r.
    
   if(	Menu.BuzzerGeriSayac > 0 )
		Menu.BuzzerGeriSayac--;
	else
	{
		Buzzer = 0;
		Timer6.BuzzerOnSayac = 0;
		Timer6.BuzzerOffSayac = 0;
	}
    
    
//	if(	Menu.BuzzerGeriSayac > 1 )
//		Menu.BuzzerGeriSayac--;
//	else
//	{
//        if( Menu.BuzzerGeriSayac == 1 )
//		{
//            Menu.BuzzerGeriSayac = 0;
//            Buzzer = 0;
//        }
//		Timer6.BuzzerOnSayac = 0;
//		Timer6.BuzzerOffSayac = 0;
//	}
		
	//350 ms Buton i�lemleri	
	if( ++Timer6.Ms50_0 > 6 )			
	{
		Timer6.Ms50_0 = 0;
		Timer.Bit.Sn0_35 ^= 1;
		
//		if( Menu.Buton.All != 0 )
//		if( (Sol == 0) || (Sag == 0) || (Enter == 0) || (Yukari == 0) || (Asagi == 0) )		Touch i�in kapat�ld�
		if( (Sol == 0) || (Sag == 0) || (Enter == 0) || (Yukari == 0) || (Asagi == 0) || (_TouchCount > 100 ) )	//Touch i�in a��ld�
		{
			if( Asagi == 0 )
				Menu.Buton.Bit.bYukari = 1;
			else
				Menu.Buton.Bit.bYukari = 0;
				
			if( Yukari == 0 )
				Menu.Buton.Bit.bAsagi = 1;
			else
				Menu.Buton.Bit.bAsagi = 0;
				
			if( Enter == 0 )
				Menu.Buton.Bit.bEnter = 1;
			else
				Menu.Buton.Bit.bEnter = 0;
				
			if( Sag == 0 )
				Menu.Buton.Bit.bSag = 1;
			else
				Menu.Buton.Bit.bSag = 0;
				
			if( Sol == 0 )
				Menu.Buton.Bit.bSol = 1;
			else
				Menu.Buton.Bit.bSol = 0;
			//De�erlerin artma miktar�n� belirler.
			if( Timer6.Ms50_10 > 5 )
			{				
				Menu.ButonBasmaSure++;
			}
			if(Menu.ButonBasmaSure > 4)
				Menu.ButonBayrak = 1;
			if(Menu.ButonBasmaSure > 10)
				Menu.ButonArtim = 10;
			if(Menu.ButonBasmaSure > 20)
			{
				if( Menu.ButonBasmaSure > 65500 )
					Menu.ButonBasmaSure = 65530;
				Menu.ButonArtim = 100;
			}
		}	
		else
		{
			//Status tayken kullan�l�r.
			Menu.EnteraBasmaSayac = 0;
			Menu.ButonBasmaSure = 0;
			Menu.ButonArtim = 1;
		}
		if(( Yukari == 0 ) && ( Asagi == 0 ))			//09.07.2013
		{												//09.07.2013
			TftInitButonSayac++;						//09.07.2013
			if(TftInitButonSayac > 25)					//09.07.2013
			{
				TftInitButonSayac = 26;
				
				TftInitFlag = 1;
			}
		}
		else
		{
			TftInitButonSayac = 0;
		}
	}	
	//Simulasyon s�ras�nda alarma ba�l� r�le �ekme
	if( Menu.RoleTestSayac == 0 )
	{
		if( EeKayit.Role_NoNc > 1 )
			EeKayit.Role_NoNc = 0;
		if( EeKayit.Role_NoNc < 0 )
			EeKayit.Role_NoNc = 1;
			
		RoleAlarmCek.Half[0] = Alarm.Half[0];																		//12.03.2014 _ de eklendi.		
		RoleAlarmCek.Half[1] = Alarm.Half[1];																		//Genel Alarm	06.07.2015
		if( RoleAlarmCek.Word.Inv1.Bit.ElleBypass || RoleAlarmCek.Word.Inv2.Bit.CikisBypassta )						//12.03.2014 _ de eklendi.
		{
			RoleAlarmCek.Word.Inv1.Bit.ElleBypass = 1;
			RoleAlarmCek.Word.Inv2.Bit.CikisBypassta = 1;
		}
		
		//Daha h�zl� olsun diye Alarma g�re r�le i�lemleri burada yap�l�yor.
		for(Role_i = 0;Role_i < 12;Role_i++)
		{
			if( EeKayit.Role[Role_i] < 64 )				//12.03.2014
				//RoleIslem(Role_i,(( Alarm.Half[0] >> EeKayit.Role[Role_i] ) & 1));
				RoleIslem(Role_i,((( RoleAlarmCek.Half[0] >> EeKayit.Role[Role_i] ) & 1) ^ EeKayit.Role_NoNc));		//12.03.2014 _ de eklendi.
			else
			{
				//K�br�s a giden Deep Discharge 13.12.2012
				if( EeKayit.Role[0] == 74 )		//Role 1 L11 BattCb.
				{
					//Bu 500 de�eri sonra Ak� say�s�na g�re de�i�tirilecek.
					if( (Can.FromPfc.RecDCBus.Pos + Can.FromPfc.RecDCBus.Neg) < 500 )
						Relay1 = 0 ^ EeKayit.Role_NoNc;																//12.03.2014 _ de eklendi.
					else
						Relay1 = 1 ^ EeKayit.Role_NoNc;																//12.03.2014 _ de eklendi.
				}
				if( EeKayit.Role[Role_i] == 70 )		//GENEL ALARM						//06.07.2015 70 eklendi
				{
					RoleIslem(Role_i,((( RoleAlarmCek.Half[1] >> (EeKayit.Role[Role_i]-64) ) & 1)^ EeKayit.Role_NoNc));		//03.07.2015 70 eklendi
				}
			
			
				//E�er gerekirse atanan r�le alarm de�eri 63 ten b�y�kse 2. grup alarmlar (Alarm.Half[1]) i�lev g�r�r.�imdilik b�yle bir atama yok.
				//RoleIslem(Role_i,(( Alarm.Half[1] >> EeKayit.Role[Role_i] ) & 1));
			}
		}
		SnmpRelay = EeKayit.Konfig.Bit.SNMP_OnOff;
	}
	//Alarm ve uyar� buzzer leri i�in Yeni alarm durumunda bu bitler terslenir.
//	if( (Menu.AlarmSesAcik & Menu.MaskeAlarmSesAcik == 1) && (Megatech.Q.TurnBeep == 0) )
	if( (Menu.MaskeAlarmSesAcik == 1) )// && (Megatech.Q.TurnBeep == 0) )
	{
		if(( Alarm.Half[0] > 0 ) || ( Alarm.Half[1] > 0 )) 
		{
			//Alarm Buzeri �tecek
			if(( Alarm.Word.Inv1.All > 0 ) || ( Alarm.Word.Pfc1.All > 0 ))
			{
				//Buzer sesinin kesilmesini engeller. Her alarm geldi�inde 150 ms ye kuruluyor.
				Menu.BuzzerGeriSayac = 3;
				Timer6.BuzzerOnSayac++;
				if( Timer6.BuzzerOnSayac > 19 )
				{
					if( Menu.MimikSayac == 0 )
						Buzzer = 0;
					Timer6.BuzzerOnSayac = 20;
					Timer6.BuzzerOffSayac++;
					
					if(( Alarm.Word.Inv1.All == 0 ) && (( Alarm.Word.Pfc1.All == 2 )||( Alarm.Word.Pfc1.All == 64 )||( Alarm.Word.Pfc1.All == 66 )))
					{						
						if( Timer6.BuzzerOffSayac > ( (EeKayit.UyariSesAraligi*20) - 1) )
						{
							Timer6.BuzzerOnSayac = 0;
							Timer6.BuzzerOffSayac = 0;
						}					
					}
					else
					{
						if( Timer6.BuzzerOffSayac > 19 )
						{
							Timer6.BuzzerOnSayac = 0;
							Timer6.BuzzerOffSayac = 0;
						}
					}					
				}
				else
				{
					if( Menu.MimikSayac == 0 )
						Buzzer = DefBuzzerDurum;
				}
			}	
			
			//Uyar� Buzeri �tecek
			//Uyari buzzeri �tmesi i�in Inv3 kullan�lacak m�?
	//		else if(( Alarm.Word.Inv2.All > 0 ) || ( Alarm.Word.Pfc2.All > 0 ) || ( MaskedAlarm.Word.Lcd1.All > 0 ) || ( MaskedAlarm.Word.Inv3.All > 0 ))
			else if(( Alarm.Word.Inv2.All > 0 ) || ( Alarm.Word.Pfc2.All > 0 ) || ( Alarm.Word.Lcd1.All > 0 ) || ( Alarm.Word.Inv3.All > 0 ) || ( Alarm.Word.Lcd2.All > 0 ))
			{
				//Uyari buzzerlerine maske koyma i�lemi
				Genel.MaskelenmisUyarilar_Inv1 = GosterAlarm.Word.Inv2.All & EeKayit.InvUyari_1_BuzzerMaskesi;
		//		Genel.MaskelenmisUyarilar_Inv2 = MaskedAlarm.Word.Inv3.All & EeKayit.InvUyari_2_BuzzerMaskesi;
				Genel.MaskelenmisUyarilar_Inv2 = GosterAlarm.Word.Inv3.All & (EeKayit.InvUyari_2_BuzzerMaskesi & 0x9FFF);				//23.12.2014 _ MASTER UPS + LOAD ON UPS     ALARMIN G�Z�KMED��� G�B� BUZZER DE OTMEYECEK 
				Genel.MaskelenmisUyarilar_Pfc1 = GosterAlarm.Word.Pfc2.All & EeKayit.PfcUyari_1_BuzzerMaskesi;
		//		Genel.MaskelenmisUyarilar_Lcd1 = MaskedAlarm.Word.Lcd1.All & EeKayit.LcdUyari_1_BuzzerMaskesi;
				Genel.MaskelenmisUyarilar_Lcd1 = GosterAlarm.Word.Lcd1.All & EeKayit.LcdUyari_1_BuzzerMaskesi;
				Genel.MaskelenmisUyarilar_Lcd2 = GosterAlarm.Word.Lcd2.All & 32767;								//Paralel Online gibi durumlar� g�sterir. O zaman buzzer �tmesin.
				
				//Ekono mod da iken sadece A23 geliyorsa (A32 Servis Logini saym�yorum) buzzer �tmesin.
				if( Can.FromInv.CalismaModu == 1 )
				{
					Genel.MaskelenmisUyarilar_Inv1 = Genel.MaskelenmisUyarilar_Inv1 & 0x7fbf; //A23 ve A32 maskelenmi� oldu.
				}
				
				if(( Genel.MaskelenmisUyarilar_Inv1 > 0 ) || ( Genel.MaskelenmisUyarilar_Inv2 > 0 ) || ( Genel.MaskelenmisUyarilar_Pfc1 > 0 ) || ( Genel.MaskelenmisUyarilar_Lcd1 > 0 )|| ( Genel.MaskelenmisUyarilar_Lcd2 > 0 ))
				{
					//Buzer sesinin kesilmesini engeller. Her alarm geldi�inde 150 ms ye kuruluyor.
					Menu.BuzzerGeriSayac = 3;
					Timer6.BuzzerOnSayac++;
					if( Timer6.BuzzerOnSayac > 19 )
					{
						if( Menu.MimikSayac == 0 )
							Buzzer = 0;
						Timer6.BuzzerOnSayac = 20;
						Timer6.BuzzerOffSayac++;
						if( Timer6.BuzzerOffSayac > ( (EeKayit.UyariSesAraligi*20) - 1) )
						{
							Timer6.BuzzerOnSayac = 0;
							Timer6.BuzzerOffSayac = 0;
						}
					}
					else
					{
						if( Menu.MimikSayac == 0 )
							Buzzer = DefBuzzerDurum;
					}
				}
				else
					Menu.AlarmSesAcik = 0;
			}
			else
				Menu.AlarmSesAcik = 0;
		}
		else
			Menu.AlarmSesAcik = 0;
	}		
}

void MenuGraphic(unsigned int Sekme)
{
	static unsigned int EskiSayfa = 0;
	unsigned int Sayfa;
	
	if( Sekme > 5 )
		Sayfa = 1;
	else
		Sayfa = 0;
	
	GlobalSayfa = Sayfa;
	//Eski men� yaz�lar� siliniyor.
//	ASendText(20,80, "INPUT",2,0x888888,NOTGRADIENTCOLOR,Clear);
//	ASendText(20,105,"BYPASS",2,0x888888,NOTGRADIENTCOLOR,Clear);
//	ASendText(20,130,"INVERTER",2,0x888888,NOTGRADIENTCOLOR,Clear);
//	ASendText(20,155,"OUTPUT",2,0x888888,NOTGRADIENTCOLOR,Clear);
//	ASendText(20,180,"DC",2,0x888888,NOTGRADIENTCOLOR,Clear);
//	ASendText(20,205,"GENERAL",2,0x888888,NOTGRADIENTCOLOR,Clear);
	
	//Hoparl�r
	ExBigVariable(430,243+(GlobalSayfa*272),4,3,14-Menu.MaskeAlarmSesAcik,0xffff00,0);			//Sembol 1
	if( Sayfa == 0 )
	{
		//Menu kontrol�n dinamik yap�s�.
		Xstart = 5;			//Sol ba�
		Ystart = 40;		//Sol ba�
		Xend = 475;			//Sa� alt
		Yend = 240;			//Sa� alt
		Sekme1 = 94;		//
		Sekme2 = 188;		//O-N aras�
		Sekme3 = 282;		//L-K aras�
		Sekme4 = 376;		//H-G aras�
		Sekme5 = 470;		//E-D aras�
		SekmeHeight = 62;	//Sekme alt� �izginin Y koordinat�
		NameY = 47;			//�simlerin yaz�ld��� Y koordinat�
		NameEk = 9;			//�simin ne kadar Y yukar�ya ��kt���n� g�sterir.
	
		//Men� �er�evesi
		Line(Xstart,Xstart,Ystart,Yend,0xffffff,NotClear);						//A
		CaprazHat(Xstart,Xstart+5,Ystart,Ystart-5,0xffffff,NotClear);			//T
		Line(Xstart+5,Sekme1,Ystart-5,Ystart-5,0xffffff,NotClear);				//�
		CaprazHat(Sekme1,Sekme1+5,Ystart-5,Ystart,0xffffff,NotClear);			//S
		CaprazHat(Sekme1+5,Sekme1+10,Ystart,Ystart-5,0xffffff,NotClear);		//P
		Line(Sekme1+10,Sekme2,Ystart-5,Ystart-5,0xffffff,NotClear);				//O
		CaprazHat(Sekme2,Sekme2+5,Ystart-5,Ystart,0xffffff,NotClear);			//N
		CaprazHat(Sekme2+5,Sekme2+10,Ystart,Ystart-5,0xffffff,NotClear);		//M
		Line(Sekme2+10,Sekme3,Ystart-5,Ystart-5,0xffffff,NotClear);				//L
		CaprazHat(Sekme3,Sekme3+5,Ystart-5,Ystart,0xffffff,NotClear);			//K
		CaprazHat(Sekme3+5,Sekme3+10,Ystart,Ystart-5,0xffffff,NotClear);		//J
		Line(Sekme3+10,Sekme4,Ystart-5,Ystart-5,0xffffff,NotClear);				//H
		CaprazHat(Sekme4,Sekme4+5,Ystart-5,Ystart,0xffffff,NotClear);			//G
		CaprazHat(Sekme4+5,Sekme4+10,Ystart,Ystart-5,0xffffff,NotClear);		//F
		Line(Sekme4+10,Sekme5,Ystart-5,Ystart-5,0xffffff,NotClear);				//E
		CaprazHat(Sekme5,Sekme5+5,Ystart-5,Ystart,0xffffff,NotClear);			//D
		Line(Sekme5+5,Sekme5+5,Ystart,Yend,0xffffff,NotClear);					//C
		Line(Xstart,Sekme5+5,Yend,Yend,0xffffff,NotClear);						//B
		//Tek �izgi �izilmesi i�in
		LINEREPEAT = 1;
		Line(Xstart,Sekme5+5,SekmeHeight,SekmeHeight,0xffffff,NotClear);		//X
		LINEREPEAT = 2;
		
		Line(Xstart,Xstart,Ystart-10,Ystart,0xffffff,Clear);					//Yenisini �iz.
		CaprazHat(Xstart,Xstart+5,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Xstart+5,Sekme1,Ystart-15,Ystart-15,0xffffff,Clear);		
		CaprazHat(Sekme1,Sekme1+5,Ystart-15,Ystart-10,0xffffff,Clear);	
		Line(Sekme1+5,Sekme1+5,Ystart-10,Ystart,0xffffff,Clear);	
		Line(Sekme1+5,Sekme1+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme1+5,Sekme1+10,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Sekme1+10,Sekme2,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme2,Sekme2+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme2+5,Sekme2+5,Ystart-10,Ystart,0xffffff,Clear);
		Line(Sekme2+5,Sekme2+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme2+5,Sekme2+10,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Sekme2+10,Sekme3,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme3,Sekme3+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme3+5,Sekme3+5,Ystart-10,Ystart,0xffffff,Clear);	
		Line(Sekme3+5,Sekme3+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme3+5,Sekme3+10,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Sekme3+10,Sekme4,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme4,Sekme4+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme4+5,Sekme4+5,Ystart-10,Ystart,0xffffff,Clear);	
		Line(Sekme4+5,Sekme4+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme4+5,Sekme4+10,Ystart-10,Ystart-15,0xffffff,Clear);	
		Line(Sekme4+10,Sekme5,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme5,Sekme5+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme5+5,Sekme5+5,Ystart-10,Ystart,0xffffff,Clear);	
	
		Line(Xstart,Xstart,Ystart-1,SekmeHeight,0xffffff,NotClear);				//0
		Line(Sekme1+5,Sekme1+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//1
		Line(Sekme2+5,Sekme2+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//2
		Line(Sekme3+5,Sekme3+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//3
		Line(Sekme4+5,Sekme4+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//4
		Line(Xend,Xend,Ystart-1,SekmeHeight,0xffffff,NotClear);					//5
	
		//Men� isimlerinin Yukar�ya yaz�lan� siliyor.
		OptimizasyonFonk1(NameY-NameEk,0,Clear);
/*
		ASendText(30,NameY-NameEk,AnaMenu[EeKayit.Dil][0],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(104,NameY-NameEk,AnaMenu[EeKayit.Dil][1],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(202,NameY-NameEk,AnaMenu[EeKayit.Dil][2],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(292,NameY-NameEk,AnaMenu[EeKayit.Dil][3],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(395,NameY-NameEk,AnaMenu[EeKayit.Dil][4],1,0xffffff,NOTGRADIENTCOLOR,Clear);
*/
	
		//Men� isimlerinin Normal yerine yaz�yor.
		OptimizasyonFonk1(NameY,0,NotClear);
/*
		ASendText(30,NameY,AnaMenu[EeKayit.Dil][0],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(104,NameY,AnaMenu[EeKayit.Dil][1],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(202,NameY,AnaMenu[EeKayit.Dil][2],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(292,NameY,AnaMenu[EeKayit.Dil][3],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(395,NameY,AnaMenu[EeKayit.Dil][4],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
*/	
	
		if(Sekme == 1)
		{
			ASendText(30,NameY-NameEk,AnaMenu[EeKayit.Dil][0],1,0xffffff,NOTGRADIENTCOLOR,NotClear);	//Sekme se�ilince men� yaz�s�n� yukar�ya yaz�yor.
			ASendText(30,NameY,AnaMenu[EeKayit.Dil][0],1,0xffffff,NOTGRADIENTCOLOR,Clear);				//Men�n�n normal yerini siliyor.
			
				MimikFonk(0);
//			ASendText(5,3,UstKelime[0][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	//		ASendText(5,3,"STATUS               ",2,0x999999,NOTGRADIENTCOLOR,NotClear);	//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			LINEREPEAT = 1;
			Line(Xstart,Sekme1+5,SekmeHeight,SekmeHeight,0xffffff,Clear);					//Eskisini sil.
			LINEREPEAT = 2;
			CaprazHat(Xstart,Xstart+5,Ystart,Ystart-5,0xffffff,Clear);						
			Line(Xstart+5,Sekme1,Ystart-5,Ystart-5,0xffffff,Clear);	
			CaprazHat(Sekme1,Sekme1+5,Ystart-5,Ystart,0xffffff,Clear);
	
			
			Line(Xstart,Xstart,Ystart-10,SekmeHeight,0xffffff,NotClear);					//Yenisini �iz.
			CaprazHat(Xstart,Xstart+5,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Xstart+5,Sekme1,Ystart-15,Ystart-15,0xffffff,NotClear);		
			CaprazHat(Sekme1,Sekme1+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme1+5,Sekme1+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}	
		if(Sekme == 2)
		{		
			ASendText(104,NameY-NameEk,AnaMenu[EeKayit.Dil][1],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(104,NameY,AnaMenu[EeKayit.Dil][1],1,0xffffff,NOTGRADIENTCOLOR,Clear);
			
	
	//		ASendText(5,3,"MEASUREMENTS",2,0x999999,NOTGRADIENTCOLOR,NotClear);				//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme1+5,Sekme1+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.	
			Line(Sekme1+10,Sekme2,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme2,Sekme2+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme1+5,Sekme2+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme1+5,Sekme1+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.	
			CaprazHat(Sekme1+5,Sekme1+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme1+10,Sekme2,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme2,Sekme2+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme2+5,Sekme2+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
		if(Sekme == 3)
		{		
			ASendText(202,NameY-NameEk,AnaMenu[EeKayit.Dil][2],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(202,NameY,AnaMenu[EeKayit.Dil][2],1,0xffffff,NOTGRADIENTCOLOR,Clear);			
	
	//		ASendText(5,3,"ALARM LOGS               ",2,0x999999,NOTGRADIENTCOLOR,NotClear);//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme2+5,Sekme2+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.		
			Line(Sekme2+10,Sekme3,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme3,Sekme3+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme2+5,Sekme3+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme2+5,Sekme2+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.	
			CaprazHat(Sekme2+5,Sekme2+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme2+10,Sekme3,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme3,Sekme3+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme3+5,Sekme3+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
		if(Sekme == 4)
		{		
			ASendText(292,NameY-NameEk,AnaMenu[EeKayit.Dil][3],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(292,NameY,AnaMenu[EeKayit.Dil][3],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		
	
	//		ASendText(5,3,"INFORMATION ",2,0x999999,NOTGRADIENTCOLOR,NotClear);				//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme3+5,Sekme3+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.		
			Line(Sekme3+10,Sekme4,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme4,Sekme4+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme3+5,Sekme4+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme3+5,Sekme3+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.	
			CaprazHat(Sekme3+5,Sekme3+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme3+10,Sekme4,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme4,Sekme4+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme4+5,Sekme4+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
		if(Sekme == 5)
		{		
			ASendText(395,NameY-NameEk,AnaMenu[EeKayit.Dil][4],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(395,NameY,AnaMenu[EeKayit.Dil][4],1,0xffffff,NOTGRADIENTCOLOR,Clear);
			
	
	//		ASendText(5,3,"OPTIONS     ",2,0x999999,NOTGRADIENTCOLOR,NotClear);				//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme4+5,Sekme4+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.		
			Line(Sekme4+10,Sekme5,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme5,Sekme5+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme4+5,Sekme5+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme4+5,Sekme4+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.
			CaprazHat(Sekme4+5,Sekme4+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme4+10,Sekme5,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme5,Sekme5+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme5+5,Sekme5+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
	}		
	if( Sayfa == 1 )
	{
		//Menu kontrol�n dinamik yap�s�.
		Xstart = 5;			//Sol ba�
		Ystart = 40+272;		//Sol ba�
		Xend = 475;			//Sa� alt
		Yend = 240+272;			//Sa� alt
		
#ifdef PAGE2_5_SEKME
		Sekme1 = 94;		//
		Sekme2 = 188;		//O-N aras�
		Sekme3 = 282;		//L-K aras�
		Sekme4 = 376;		//H-G aras�
		Sekme5 = 470;		//E-D aras�
#endif
#ifdef PAGE2_4_SEKME
		Sekme1 = 118;		//
		Sekme2 = 235;		//O-N aras�
		Sekme3 = 353;		//L-K aras�
		Sekme4 = 470;		//H-G aras�
		Sekme5 = 470;		//E-D aras�
#endif
		SekmeHeight = 62+272;	//Sekme alt� �izginin Y koordinat�
		NameY = 47+272;			//�simlerin yaz�ld��� Y koordinat�
		NameEk = 9;			//�simin ne kadar Y yukar�ya ��kt���n� g�sterir.
		//Men� �er�evesi
		Line(Xstart,Xstart,Ystart,Yend,0xffffff,NotClear);						//A
		CaprazHat(Xstart,Xstart+5,Ystart,Ystart-5,0xffffff,NotClear);			//T
		Line(Xstart+5,Sekme1,Ystart-5,Ystart-5,0xffffff,NotClear);				//�
		CaprazHat(Sekme1,Sekme1+5,Ystart-5,Ystart,0xffffff,NotClear);			//S
		CaprazHat(Sekme1+5,Sekme1+10,Ystart,Ystart-5,0xffffff,NotClear);		//P
		Line(Sekme1+10,Sekme2,Ystart-5,Ystart-5,0xffffff,NotClear);				//O
		CaprazHat(Sekme2,Sekme2+5,Ystart-5,Ystart,0xffffff,NotClear);			//N
		CaprazHat(Sekme2+5,Sekme2+10,Ystart,Ystart-5,0xffffff,NotClear);		//M
		Line(Sekme2+10,Sekme3,Ystart-5,Ystart-5,0xffffff,NotClear);				//L
		CaprazHat(Sekme3,Sekme3+5,Ystart-5,Ystart,0xffffff,NotClear);			//K
		CaprazHat(Sekme3+5,Sekme3+10,Ystart,Ystart-5,0xffffff,NotClear);		//J
		Line(Sekme3+10,Sekme4,Ystart-5,Ystart-5,0xffffff,NotClear);				//H
		CaprazHat(Sekme4,Sekme4+5,Ystart-5,Ystart,0xffffff,NotClear);			//G
		
#ifdef PAGE2_5_SEKME
		CaprazHat(Sekme4+5,Sekme4+10,Ystart,Ystart-5,0xffffff,NotClear);		//F
		Line(Sekme4+10,Sekme5,Ystart-5,Ystart-5,0xffffff,NotClear);				//E
		CaprazHat(Sekme5,Sekme5+5,Ystart-5,Ystart,0xffffff,NotClear);			//D
#endif

		Line(Sekme5+5,Sekme5+5,Ystart,Yend,0xffffff,NotClear);					//C
		Line(Xstart,Sekme5+5,Yend,Yend,0xffffff,NotClear);						//B
		LINEREPEAT = 1;
		Line(Xstart,Sekme5+5,SekmeHeight,SekmeHeight,0xffffff,NotClear);		//X
		LINEREPEAT = 2;
	
		Line(Xstart,Xstart,Ystart-10,Ystart,0xffffff,Clear);					//Yenisini �iz.
		CaprazHat(Xstart,Xstart+5,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Xstart+5,Sekme1,Ystart-15,Ystart-15,0xffffff,Clear);		
		CaprazHat(Sekme1,Sekme1+5,Ystart-15,Ystart-10,0xffffff,Clear);	
		Line(Sekme1+5,Sekme1+5,Ystart-10,Ystart,0xffffff,Clear);	
		Line(Sekme1+5,Sekme1+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme1+5,Sekme1+10,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Sekme1+10,Sekme2,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme2,Sekme2+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme2+5,Sekme2+5,Ystart-10,Ystart,0xffffff,Clear);
		Line(Sekme2+5,Sekme2+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme2+5,Sekme2+10,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Sekme2+10,Sekme3,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme3,Sekme3+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme3+5,Sekme3+5,Ystart-10,Ystart,0xffffff,Clear);	
		Line(Sekme3+5,Sekme3+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.				
		CaprazHat(Sekme3+5,Sekme3+10,Ystart-10,Ystart-15,0xffffff,Clear);
		Line(Sekme3+10,Sekme4,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme4,Sekme4+5,Ystart-15,Ystart-10,0xffffff,Clear);
		Line(Sekme4+5,Sekme4+5,Ystart-10,Ystart,0xffffff,Clear);	
		Line(Sekme4+5,Sekme4+5,Ystart-10,Ystart,0xffffff,Clear);				//Yenisini �iz.	
#ifdef PAGE2_5_SEKME			
		CaprazHat(Sekme4+5,Sekme4+10,Ystart-10,Ystart-15,0xffffff,Clear);	
		Line(Sekme4+10,Sekme5,Ystart-15,Ystart-15,0xffffff,Clear);			
		CaprazHat(Sekme5,Sekme5+5,Ystart-15,Ystart-10,0xffffff,Clear);
#endif
		Line(Sekme5+5,Sekme5+5,Ystart-10,Ystart,0xffffff,Clear);	
	
		Line(Xstart,Xstart,Ystart-1,SekmeHeight,0xffffff,NotClear);				//0
		Line(Sekme1+5,Sekme1+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//1
		Line(Sekme2+5,Sekme2+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//2
		Line(Sekme3+5,Sekme3+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//3
		Line(Sekme4+5,Sekme4+5,Ystart-2,SekmeHeight,0xffffff,NotClear);			//4
		Line(Xend,Xend,Ystart-1,SekmeHeight,0xffffff,NotClear);					//5

#ifdef PAGE2_5_SEKME	
		//Men� isimlerinin Yukar�ya yaz�lan� siliyor.
		OptimizasyonFonk1(NameY-NameEk,5,Clear);
//		ASendText(30,(NameY-NameEk),AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,Clear);
//		ASendText(104,(NameY-NameEk),AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,Clear);
//		ASendText(202,(NameY-NameEk),AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,Clear);
//		ASendText(292,(NameY-NameEk),AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,Clear);
//		ASendText(395,(NameY-NameEk),AnaMenu[EeKayit.Dil][9],1,0xffffff,NOTGRADIENTCOLOR,Clear);
	
		//Men� isimlerinin Normal yerine yaz�yor.
		OptimizasyonFonk1(NameY,5,NotClear);
//		ASendText(30,NameY,AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
//		ASendText(104,NameY,AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
//		ASendText(202,NameY,AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
//		ASendText(292,NameY,AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
//		ASendText(395,NameY,AnaMenu[EeKayit.Dil][9],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
#endif
#ifdef PAGE2_4_SEKME	
		//Men� isimlerinin Yukar�ya yaz�lan� siliyor.
		ASendText(38,(NameY-NameEk),AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(140,(NameY-NameEk),AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(263,(NameY-NameEk),AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,Clear);
		ASendText(376,(NameY-NameEk),AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,Clear);
	
		//Men� isimlerinin Normal yerine yaz�yor.
		ASendText(38,NameY,AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(140,NameY,AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(263,NameY,AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
		ASendText(376,NameY,AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
#endif
	
		if(Sekme == 6)
		{		
#ifdef PAGE2_5_SEKME
			ASendText(30,(NameY-NameEk),AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,NotClear);	//Sekme se�ilince men� yaz�s�n� yukar�ya yaz�yor.
			ASendText(30,NameY,AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,Clear);				//Men�n�n normal yerini siliyor.
#endif
#ifdef PAGE2_4_SEKME
			ASendText(38,(NameY-NameEk),AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,NotClear);	//Sekme se�ilince men� yaz�s�n� yukar�ya yaz�yor.
			ASendText(38,NameY,AnaMenu[EeKayit.Dil][5],1,0xffffff,NOTGRADIENTCOLOR,Clear);				//Men�n�n normal yerini siliyor.
#endif
		//	ASendText(5,(3+272),"COMMAND      ",2,0x999999,NOTGRADIENTCOLOR,NotClear);			//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			LINEREPEAT = 1;
			Line(Xstart,Sekme1+5,SekmeHeight,SekmeHeight,0xffffff,Clear);				//Eskisini sil.
			LINEREPEAT = 2;
			CaprazHat(Xstart,Xstart+5,Ystart,Ystart-5,0xffffff,Clear);						
			Line(Xstart+5,Sekme1,Ystart-5,Ystart-5,0xffffff,Clear);	
			CaprazHat(Sekme1,Sekme1+5,Ystart-5,Ystart,0xffffff,Clear);
	
			
			Line(Xstart,Xstart,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.
			CaprazHat(Xstart,Xstart+5,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Xstart+5,Sekme1,Ystart-15,Ystart-15,0xffffff,NotClear);		
			CaprazHat(Sekme1,Sekme1+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme1+5,Sekme1+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}	
		if(Sekme == 7)
		{		
#ifdef PAGE2_5_SEKME
			ASendText(104,(NameY-NameEk),AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(104,NameY,AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,Clear);
#endif	
#ifdef PAGE2_4_SEKME
			ASendText(140,(NameY-NameEk),AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(140,NameY,AnaMenu[EeKayit.Dil][6],1,0xffffff,NOTGRADIENTCOLOR,Clear);
#endif
	
		//	ASendText(5,(3+272),"TIME      ",2,0x999999,NOTGRADIENTCOLOR,NotClear);			//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme1+5,Sekme1+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.	
			Line(Sekme1+10,Sekme2,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme2,Sekme2+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme1+5,Sekme2+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme1+5,Sekme1+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.	
			CaprazHat(Sekme1+5,Sekme1+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme1+10,Sekme2,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme2,Sekme2+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme2+5,Sekme2+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
		if(Sekme == 8)
		{		
#ifdef PAGE2_5_SEKME
			ASendText(202,(NameY-NameEk),AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(202,NameY,AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,Clear);
#endif		
#ifdef PAGE2_4_SEKME
			ASendText(263,(NameY-NameEk),AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(263,NameY,AnaMenu[EeKayit.Dil][7],1,0xffffff,NOTGRADIENTCOLOR,Clear);
#endif
			
	
	//		ASendText(5,(3+272),"SERVICE    ",2,0x999999,NOTGRADIENTCOLOR,NotClear);		//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme2+5,Sekme2+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.		
			Line(Sekme2+10,Sekme3,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme3,Sekme3+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme2+5,Sekme3+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme2+5,Sekme2+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.	
			CaprazHat(Sekme2+5,Sekme2+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme2+10,Sekme3,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme3,Sekme3+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme3+5,Sekme3+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
		if(Sekme == 9)
		{		
#ifdef PAGE2_5_SEKME
			ASendText(292,(NameY-NameEk),AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(292,NameY,AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,Clear);
#endif			
#ifdef PAGE2_4_SEKME
			ASendText(376,(NameY-NameEk),AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(376,NameY,AnaMenu[EeKayit.Dil][8],1,0xffffff,NOTGRADIENTCOLOR,Clear);
#endif		
	
	//		ASendText(5,(3+272),"ADJUST    ",2,0x999999,NOTGRADIENTCOLOR,NotClear);			//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme3+5,Sekme3+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.		
			Line(Sekme3+10,Sekme4,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme4,Sekme4+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme3+5,Sekme4+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme3+5,Sekme3+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.	
			CaprazHat(Sekme3+5,Sekme3+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme3+10,Sekme4,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme4,Sekme4+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme4+5,Sekme4+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
#ifdef PAGE2_5_SEKME
		if(Sekme == 10)
		{		
			ASendText(395,(NameY-NameEk),AnaMenu[EeKayit.Dil][9],1,0xffffff,NOTGRADIENTCOLOR,NotClear);
			ASendText(395,NameY,AnaMenu[EeKayit.Dil][9],1,0xffffff,NOTGRADIENTCOLOR,Clear);			
	
//			ASendText(5,3+272,UstKelime[31][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	//		ASendText(5,(3+272),"GRAPHICS    ",2,0x999999,NOTGRADIENTCOLOR,NotClear);		//Men� Ba�l��� Sol �st
			//Men� y�kselmelerine yar�yor.
			CaprazHat(Sekme4+5,Sekme4+10,Ystart,Ystart-5,0xffffff,Clear);					//Eskisini sil.		
			Line(Sekme4+10,Sekme5,Ystart-5,Ystart-5,0xffffff,Clear);			
			CaprazHat(Sekme5,Sekme5+5,Ystart-5,Ystart,0xffffff,Clear);
			LINEREPEAT = 1;
			Line(Sekme4+5,Sekme5+5,SekmeHeight,SekmeHeight,0xffffff,Clear);	
			LINEREPEAT = 2;
	
			Line(Sekme4+5,Sekme4+5,Ystart-10,SekmeHeight,0xffffff,NotClear);				//Yenisini �iz.
			CaprazHat(Sekme4+5,Sekme4+10,Ystart-10,Ystart-15,0xffffff,NotClear);
			Line(Sekme4+10,Sekme5,Ystart-15,Ystart-15,0xffffff,NotClear);			
			CaprazHat(Sekme5,Sekme5+5,Ystart-15,Ystart-10,0xffffff,NotClear);
			Line(Sekme5+5,Sekme5+5,Ystart-10,SekmeHeight,0xffffff,NotClear);
		}
#endif		

	}
	if( (EskiSayfa == 0) && (Sayfa == 1) )
		ChangePage(1);
	if( (EskiSayfa == 1) && (Sayfa == 0) )
		ChangePage(0);	
	EskiSayfa = Sayfa;
}
void RtcToScreen(unsigned int PaGe)
{
	unsigned int H,M,S,D,Mn,Y;
//	H = 380;M = H+37;S = M+39;D = 195;Mn = 230;Y = 293;		//sn li
	H = 417;M = H+37;S = M+39;D = 195;Mn = 230;Y = 293;		//sn siz
	OkuRTC(&Date);
	DIGITAL = NotDigital;
	OutVariable(H,(3+(PaGe*272)),Date.Hour,2,0,2,0x999999,NOTGRADIENTCOLOR,NotClear);
	OutVariable(M,(3+(PaGe*272)),Date.Min,2,0,2,0x999999,NOTGRADIENTCOLOR,NotClear);
//	OutVariable(S,(3+(PaGe*272)),((Date.Sec >> 4) * 10 + (Date.Sec & 0x0f)),2,0,2,0x999999,NOTGRADIENTCOLOR,NotClear);

//	OutVariable(D,3,((Date.Day >> 4) * 10 + (Date.Day & 0x0f)),2,0,2,0xffffff,NOTGRADIENTCOLOR,NotClear);
//	OutVariable(Mn,3,((Date.Month >> 4) * 10 + (Date.Month & 0x0f)),2,0,2,0xffffff,NOTGRADIENTCOLOR,NotClear);
//	OutVariable(Y,3,((Date.Year >> 4) * 10 + (Date.Year & 0x0f)),2,0,2,0xffffff,NOTGRADIENTCOLOR,NotClear);
}
unsigned char dec2bcd(unsigned char dec)							// ----- convert bcd to ascii and send to sci ----
{
/*  optimizasyon i�in
    return( ((dec/10)<<4)+(dec%10) );
*/
}


/*


void StatusMenu(unsigned int StatusClr)
{
	ASendText(5,3,"STATUS               ",2,0x999999,NOTGRADIENTCOLOR,StatusClr);	

	ExBigVariable(55,135,5,5,PfcS,0xffffff,StatusClr);
	ExBigVariable(127,96,5,5,BypassS,0xffffff,StatusClr);
	ExBigVariable(207,135,5,5,InverterS,0xffffff,StatusClr);
	ExBigVariable(295,135,5,5,TristorS,0xffffff,StatusClr);
	ExBigVariable(250,190,5,5,AkuS,0xffffff,StatusClr);
	ExBigVariable(210,190,5,5,KAnahtarS,0xffffff,StatusClr);	//Battery 
	ExBigVariable(350,135,5,5,KAnahtarS,0xffffff,StatusClr);	//��k��
	ExBigVariable(207,65,5,5,AAnahtarS,0xffffff,StatusClr);		//Maintenance

	Dikdortgen(20,53,153,156,0x00ff00,1,StatusClr);				//bas - pfc 				ok
	Dikdortgen(95,205,153,156,0x00ff00,1,StatusClr);			//pfc - inverter			ok
	Dikdortgen(247,293,153,156,0x00ff00,1,StatusClr);			//inverter - tristor 		ok
	Dikdortgen(335,348,153,156,0x00ff00,1,StatusClr);			//tristor - c�k�s			ok
	Dikdortgen(180,210,208,211,0x00ff00,1,StatusClr);			//Battery - bosluk			ok
	Dikdortgen(180,183,153,208,0x00ff00,1,StatusClr);			//bosluk - inverter			ok
	Line(182,182,153,208,0x00ff00,StatusClr);					//bosluk - inverter			ok
	Dikdortgen(40,205,83,86,0xaaaaaa,1,StatusClr);				//Bas - maintance			ok
	Dikdortgen(247,410,83,86,0xaaaaaa,1,StatusClr);				//maintance - bosluk	
	Dikdortgen(410,413,85,156,0xaaaaaa,1,StatusClr);			//bosluk - c�k�s	
	Line(412,412,85,156,0xaaaaaa,StatusClr);					//bosluk - c�k�s	
	
	Dikdortgen(40,125,114,117,0xaaaaaa,1,StatusClr);			//Bas - bypass
	Dikdortgen(40,44,83,114,0xaaaaaa,1,StatusClr);				//Mainta - bypass
	Line(42,42,83,114,0xaaaaaa,StatusClr);						//Mainta - bypass
	Dikdortgen(20,44,98,102,0xaaaaaa,1,StatusClr);				//bas - (Mainta - bypass)
	Dikdortgen(166,348,114,117,0xaaaaaa,1,StatusClr);			//bypass - bosluk
	Dikdortgen(348,351,115,152,0xaaaaaa,1,StatusClr);			//bosluk - c�k�s
	Line(350,350,115,152,0xaaaaaa,StatusClr);					//bosluk - c�k�s
	Dikdortgen(390,430,153,156,0x00ff00,1,StatusClr);			//c�k�s anahtar - c�k�s

	ASendText(410,170,"LOAD",2,0x00ff00,NOTGRADIENTCOLOR,StatusClr);
	if(StatusClr == Clear)
	{	
		for(i=152;i<156;i++)
		{
			Line(10,450,i,i,0,Clear);
		}
		for(i=82;i<87;i++)
		{
			Line(10,450,i,i,0,Clear);
		}
		for(i=207;i<212;i++)
		{
			Line(10,450,i,i,0,Clear);
		}
		for(i=113;i<118;i++)
		{
			Line(10,450,i,i,0,Clear);
		}
		for(i=97;i<103;i++)
		{
			Line(10,100,i,i,0,Clear);
		}
	}
}		


*/





void FonkOlcumAnaMenu(unsigned int OlcumSekme,unsigned int MenuIci,unsigned int OlcumSil)
{
	static unsigned int a;	
	static unsigned int ExOlcumSekme = 1;
	static unsigned int OutputPage = 1,ExOutputPage = 1;
	int zz;
	
	Menu.OlcumAltLimit = 0;
	Menu.OlcumAra1Limit = 1;
	Menu.OlcumAra2Limit = 5;
	Menu.OlcumUstLimit = 6;
	Menu.Sekme.All = DefAnaMenu;
	
	if( OlcumSekme < Menu.OlcumAra1Limit )
		a = 0;
	if( OlcumSekme > Menu.OlcumAra2Limit )
		a = 25;
	
	if( a == 25 )
		ASendText(20,205,OlcumAnaMenu[EeKayit.Dil][6],2,0x888888,NOTGRADIENTCOLOR,OlcumSil);
	else
		ASendText(20,80,OlcumAnaMenu[EeKayit.Dil][0],2,0x888888,NOTGRADIENTCOLOR,OlcumSil);
	
	if( Uart2.NumOfPhaseOut != 1 )				//14.07.14
		Uart2.NumOfPhaseOut = 3;
	//Yaz�lar�n hepsini gri yazar.
	for( for_i=0;for_i<5;for_i++ )
		ASendText(20,(105-a+for_i*25),OlcumAnaMenu[EeKayit.Dil][for_i+1],2,0x888888,NOTGRADIENTCOLOR,OlcumSil);
	
	if( MenuIci == 1 )
	{
	//	Dikdortgen(180,471,66,235,0xffff00,1,0,0);
		//Men�n�n i�erisinde olundu�unu g�sterir.
		Menu.Sekme.All = DefOlcumAltMenu;
		ASendText(20,(80 + (25*OlcumSekme))-a,OlcumAnaMenu[EeKayit.Dil][OlcumSekme],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
//		ASendText(5,3,UstKelime[2+OlcumSekme][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
		
		if(ExOlcumSekme > OlcumSekme)
			BigOutVar(130,67,0,ScrollUpOk,0,0,0xffffff,OlcumSil);
		else
			BigOutVar(130,67,0,ScrollUpOk,0,0,0x888888,OlcumSil);
			
		if(ExOlcumSekme < OlcumSekme)
			BigOutVar(130,183,0,ScrollDownOk,0,0,0xffffff,OlcumSil);
		else
			BigOutVar(130,183,0,ScrollDownOk,0,0,0x888888,OlcumSil);
		
		switch(OlcumSekme)
		{
			case Input:
	//			if(OlcumSil == 0)
	//				ASendText(5,3,"MEASUREMENTS>INPUT   ",2,0x999999,NOTGRADIENTCOLOR,OlcumSil);
				//Write
				ASendText(195,85,OlcumAltMenu[0][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(Can.FromPfc.VinRMS.L1,Can.FromPfc.VinRMS.L2,Can.FromPfc.VinRMS.L3,0xffbb00);
			    ASendText(195,105,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(Can.FromPfc.CinRMS.L1,Can.FromPfc.CinRMS.L2,Can.FromPfc.CinRMS.L3,0xffbb00);
			    ASendText(195,125,"I    �  �  �  A",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				ASendText(195,145,OlcumAltMenu[1][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(Can.FromPfc.VinRMS.L1L3,Can.FromPfc.VinRMS.L2L1,Can.FromPfc.VinRMS.L3L2,0xffbb00);
			    ASendText(195,165,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(Can.FromPfc.RecFreq,0,0,0xffbb00);
			    ASendText(195,185,OlcumAltMenu[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			break;
			case Bypass:
				if( EeKayit.Konfig.Bit.BypassVarYok != 0 )				//21.07.14
				{	
			//		if(OlcumSil == 0)
			//			ASendText(5,3,"MEASUREMENTS>BYPASS  ",2,0x999999,NOTGRADIENTCOLOR,OlcumSil);
					//Write
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
						ASendText(195,85,OlcumAltMenu[0][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
						ASendText(195,85,OlcumAltMenu[14][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					BufferedText(Can.FromInv.VbypRMS.L1,Can.FromInv.VbypRMS.L2,Can.FromInv.VbypRMS.L3,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				  	  	ASendText(195,105,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				  	 	ASendText(195,105,"V    �            V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				    
					TextBufferLong[0] = 0xffbb00;
					if( Can.FromInv.BypStatus.Bit.R )
					{ TextBuffer[0] = '-';	TextBuffer[1] = '-'; }
					else
					{ TextBuffer[0] = 'O';	TextBuffer[1] = 'K'; }
						
					if( Can.FromInv.BypStatus.Bit.S )
						{ TextBuffer[2] = '-';	TextBuffer[3] = '-'; }
					else
						{ TextBuffer[2] = 'O';	TextBuffer[3] = 'K'; }
						
					if( Can.FromInv.BypStatus.Bit.T )
						{ TextBuffer[4] = '-';	TextBuffer[5] = '-'; }
					else
						{ TextBuffer[4] = 'O';	TextBuffer[5] = 'K'; } 
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,125,"     ��   ��   ��    ",2,0xffbb00,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				    	ASendText(195,125,"     ��              ",2,0xffbb00,NOTGRADIENTCOLOR,OlcumSil);
				    
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
						ASendText(195,145,OlcumAltMenu[1][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					BufferedText(Can.FromInv.VbypRMS.L1L3,Can.FromInv.VbypRMS.L2L1,Can.FromInv.VbypRMS.L3L2,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				   		ASendText(195,165,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				    
					BufferedText(Can.FromInv.BypFreq,0,0,0xffbb00);
				    if( Alarm.Word.Inv2.Bit.BypassFrekans )
						{ TextBuffer[1] = 'T'; TextBuffer[2] = 'O'; TextBuffer[3] = 'L';}
					else
						{ TextBuffer[1] = 'O'; TextBuffer[2] = 'K'; TextBuffer[3] = ' '; }
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,185,OlcumAltMenu[13][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
					{
				    	ASendText(195,145,OlcumAltMenu[13][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				   		ASendText(195,165,"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				   		ASendText(195,185,"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					}
				}
				else
				{
					for(zz=85;zz<200;zz=zz+20)
				   		ASendText(195,zz,"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				}
				//Alarm durumuna g�re yazacaklar� belirler.
			break;
			case Inverter:
				if( ExOlcumSekme != OlcumSekme )
					BigOutVar(130,125,0,SagSolOK,0,0,0x888888,Clear);	
				OutputPage = 1;
		//		if(OlcumSil == 0)
		//			ASendText(5,3,"MEASUREMENTS>INVERTER",2,0x999999,NOTGRADIENTCOLOR,OlcumSil);
				//ReWrite
				if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
					ASendText(195,85,OlcumAltMenu[0][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
					ASendText(195,85,OlcumAltMenu[14][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(Can.FromInv.VinvRMS.L1,Can.FromInv.VinvRMS.L2,Can.FromInv.VinvRMS.L3,0xffbb00);
				if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
			   		ASendText(195,105,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
			   		ASendText(195,105,"V    �            V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(Can.FromInv.InvFreq,0,0,0xffbb00);
			    ASendText(195,125,OlcumAltMenu[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			    for( for_i=0;for_i<4;for_i++ )
			   		ASendText(195,(145+for_i*20),"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			break;
			case Output:
		//		if(OlcumSil == 0)
		//			ASendText(5,3,"MEASUREMENTS>OUTPUT  ",2,0x999999,NOTGRADIENTCOLOR,OlcumSil);
				//Page Selection
				if(( Menu.Buton.All == DefSagButon) ||( Menu.Buton.All == DefSolButon))
				{
					OutputPage++;
					if(OutputPage > 2)
						OutputPage = 1;
					BigOutVar(130,125,0,SagSolOK,0,0,0xffffff,OlcumSil);
				}
				else
				{
					BigOutVar(130,125,0,SagSolOK,0,0,0x888888,OlcumSil);
				}
				//Write
				if(OutputPage == 1)
				{
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
						ASendText(195,85,OlcumAltMenu[0][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
						ASendText(195,85,OlcumAltMenu[14][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
						BufferedText(Can.FromInv.VoutRMS.L1,Can.FromInv.VoutRMS.L2,Can.FromInv.VoutRMS.L3,0xffbb00);
					else
						BufferedText(0,0,0,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,105,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				    	ASendText(195,105,"V    �            V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				    
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
						BufferedText(Can.FromInv.CoutRMS.L1,Can.FromInv.CoutRMS.L2,Can.FromInv.CoutRMS.L3,0xffbb00);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
						BufferedText(Can.FromInv.CoutRMS.L1+Can.FromInv.CoutRMS.L2+Can.FromInv.CoutRMS.L3,0,0,0xffbb00);
					if( Can.FromInv.Digit == 0 )
					{
						if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
					  		ASendText(195,125,"I    �  �  �  A",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
						if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
					  		ASendText(195,125,"I    �            A",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					}
					if( Can.FromInv.Digit == 1 )
					{
						if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				  			ASendText(195,125,"I    ^ ^ ^ A",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
						if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				  			ASendText(195,125,"I    ^           A",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				 	}   
				    
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
						ASendText(195,145,OlcumAltMenu[1][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
						BufferedText(Can.FromInv.VinvRMS.L1L3,Can.FromInv.VinvRMS.L2L1,Can.FromInv.VinvRMS.L3L2,0xffbb00);
					else
						BufferedText(0,0,0,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,165,"V    �  �  �  V",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					BufferedText(Can.FromInv.OutFreq,0,0,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				   		ASendText(195,185,OlcumAltMenu[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				   		ASendText(195,145,OlcumAltMenu[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			   		ASendText(195,205,"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				}
				if(OutputPage == 2)
				{
					//Write
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
						ASendText(195,85,"     L1   L2   L3",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
						ASendText(195,85,"     L           ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					BufferedText(Can.FromInv.Load.L1,Can.FromInv.Load.L2,Can.FromInv.Load.L3,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,105,OlcumAltMenu[2][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				    	ASendText(195,105,OlcumAltMenu[15][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				    
//					BufferedText(Can.FromInv.PowerWatt.L1,Can.FromInv.PowerWatt.L2,Can.FromInv.PowerWatt.L3,0xffbb00);
//					if( Can.FromInv.Digit == 1 )
//				   		ASendText(195,125,"KW  � � �",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
//					if( Can.FromInv.Digit == 0 )
//				    	ASendText(195,125,"KW  � � �",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
//				    
//					BufferedText(Can.FromInv.PowerVa.L1,Can.FromInv.PowerVa.L2,Can.FromInv.PowerVa.L3,0xffbb00);
//					if( Can.FromInv.Digit == 1 )
//				   		ASendText(195,145,"VA  � � �",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
//					if( Can.FromInv.Digit == 0 )
//				   		ASendText(195,145,"VA  � � �",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);




						//Yeni eklendi.				20.09.2013   8:19
				//----------------------------------------------------------------------------------------------------	
		
						if( Can.FromInv.PowerWatt.L1 > Can.FromInv.PowerVa.L1 )
							Can.FromInv.PowerWatt.L1 = Can.FromInv.PowerVa.L1;
						if( Can.FromInv.PowerWatt.L2 > Can.FromInv.PowerVa.L2 )
							Can.FromInv.PowerWatt.L2 = Can.FromInv.PowerVa.L2;
						if( Can.FromInv.PowerWatt.L3 > Can.FromInv.PowerVa.L3 )
							Can.FromInv.PowerWatt.L3 = Can.FromInv.PowerVa.L3;		
						
						if( Uart2.NumOfPhaseOut == 1 )									//14.07.14
						{
							GucAraHesap = Can.FromInv.PowerWatt.L1 + Can.FromInv.PowerWatt.L2 + Can.FromInv.PowerWatt.L3;
							if( GucAraHesap > 9999 )
							{					
								//Optimizasyon i�in 17.02.2014
								TextBuffer[0] = Dig(GucAraHesap,1);//(((Can.FromInv.PowerWatt.L1 % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(GucAraHesap,2);//((((Can.FromInv.PowerWatt.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = Dig(GucAraHesap,3);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[3] = '.'; 
								TextBuffer[4] = Dig(GucAraHesap,4);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[0] = Dig(GucAraHesap,2);//(((Can.FromInv.PowerWatt.L1 % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(GucAraHesap,3);//((((Can.FromInv.PowerWatt.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = '.';	
								TextBuffer[3] = Dig(GucAraHesap,4);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[4] = Dig(GucAraHesap,5);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
						}
						if( Uart2.NumOfPhaseOut == 3 )									//14.07.14
						{
							if( Can.FromInv.PowerWatt.L1 > 9999 )
							{					
								//Optimizasyon i�in 17.02.2014
								TextBuffer[0] = Dig(Can.FromInv.PowerWatt.L1,1);//(((Can.FromInv.PowerWatt.L1 % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(Can.FromInv.PowerWatt.L1,2);//((((Can.FromInv.PowerWatt.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = Dig(Can.FromInv.PowerWatt.L1,3);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[3] = '.'; 
								TextBuffer[4] = Dig(Can.FromInv.PowerWatt.L1,4);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[0] = Dig(Can.FromInv.PowerWatt.L1,2);//(((Can.FromInv.PowerWatt.L1 % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(Can.FromInv.PowerWatt.L1,3);//((((Can.FromInv.PowerWatt.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = '.';	
								TextBuffer[3] = Dig(Can.FromInv.PowerWatt.L1,4);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[4] = Dig(Can.FromInv.PowerWatt.L1,5);//(((((Can.FromInv.PowerWatt.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
							if( Can.FromInv.PowerWatt.L2 > 9999 )
							{
								TextBuffer[5] = Dig(Can.FromInv.PowerWatt.L2,1);//(((Can.FromInv.PowerWatt.L2 % 10000)/1000) + 48);	
								TextBuffer[6] = Dig(Can.FromInv.PowerWatt.L2,2);//((((Can.FromInv.PowerWatt.L2 % 10000) % 1000)/100) + 48); 
								TextBuffer[7] = Dig(Can.FromInv.PowerWatt.L2,3);//(((((Can.FromInv.PowerWatt.L2 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[8] = '.'; 
								TextBuffer[9] = Dig(Can.FromInv.PowerWatt.L2,4);//(((((Can.FromInv.PowerWatt.L2 % 10000) % 1000) % 100) % 10) + 48 );
							
							}
							else
							{
								TextBuffer[5] = Dig(Can.FromInv.PowerWatt.L2,2);//(((Can.FromInv.PowerWatt.L2 % 10000)/1000) + 48);	
								TextBuffer[6] = Dig(Can.FromInv.PowerWatt.L2,3);//((((Can.FromInv.PowerWatt.L2 % 10000) % 1000)/100) + 48); 
								TextBuffer[7] = '.';	
								TextBuffer[8] = Dig(Can.FromInv.PowerWatt.L2,4);//(((((Can.FromInv.PowerWatt.L2 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[9] = Dig(Can.FromInv.PowerWatt.L2,5);//(((((Can.FromInv.PowerWatt.L2 % 10000) % 1000) % 100) % 10) + 48 );
							}
							if( Can.FromInv.PowerWatt.L3 > 9999 )
							{
								TextBuffer[10] = Dig(Can.FromInv.PowerWatt.L3,1);//(((Can.FromInv.PowerWatt.L3 % 10000)/1000) + 48);	
								TextBuffer[11] = Dig(Can.FromInv.PowerWatt.L3,2);//((((Can.FromInv.PowerWatt.L3 % 10000) % 1000)/100) + 48); 
								TextBuffer[12] = Dig(Can.FromInv.PowerWatt.L3,3);//(((((Can.FromInv.PowerWatt.L3 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[13] = '.'; 
								TextBuffer[14] = Dig(Can.FromInv.PowerWatt.L3,4);//(((((Can.FromInv.PowerWatt.L3 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[10] = Dig(Can.FromInv.PowerWatt.L3,2);//(((Can.FromInv.PowerWatt.L3 % 10000)/1000) + 48);	
								TextBuffer[11] = Dig(Can.FromInv.PowerWatt.L3,3);//((((Can.FromInv.PowerWatt.L3 % 10000) % 1000)/100) + 48); 
								TextBuffer[12] = '.';	
								TextBuffer[13] = Dig(Can.FromInv.PowerWatt.L3,4);//(((((Can.FromInv.PowerWatt.L3 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[14] = Dig(Can.FromInv.PowerWatt.L3,5);//(((((Can.FromInv.PowerWatt.L3 % 10000) % 1000) % 100) % 10) + 48 );
							}	
						}
						if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
					   		ASendText(195,125,"KW  ����� ����� �����",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
						if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
					   		ASendText(195,125,"KW   �����           ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
						
						if( Uart2.NumOfPhaseOut == 1 )									//14.07.14
						{
							GucAraHesap = Can.FromInv.PowerVa.L1 + Can.FromInv.PowerVa.L2 + Can.FromInv.PowerVa.L3;
							if( Can.FromInv.PowerVa.L1 > 9999 )
							{
								TextBuffer[0] = Dig(GucAraHesap,1);//(((GucAraHesap % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(GucAraHesap,2);//((((GucAraHesap % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = Dig(GucAraHesap,3);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[3] = '.'; 
								TextBuffer[4] = Dig(GucAraHesap,4);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[0] = Dig(GucAraHesap,2);//(((GucAraHesap % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(GucAraHesap,3);//((((Can.FromInv.PowerVa.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = '.';	
								TextBuffer[3] = Dig(GucAraHesap,4);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[4] = Dig(GucAraHesap,5);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
						}
						if( Uart2.NumOfPhaseOut == 3 )									//14.07.14
						{
							if( Can.FromInv.PowerVa.L1 > 9999 )
							{
								TextBuffer[0] = Dig(Can.FromInv.PowerVa.L1,1);//(((Can.FromInv.PowerVa.L1 % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(Can.FromInv.PowerVa.L1,2);//((((Can.FromInv.PowerVa.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = Dig(Can.FromInv.PowerVa.L1,3);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[3] = '.'; 
								TextBuffer[4] = Dig(Can.FromInv.PowerVa.L1,4);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[0] = Dig(Can.FromInv.PowerVa.L1,2);//(((Can.FromInv.PowerVa.L1 % 10000)/1000) + 48);	
								TextBuffer[1] = Dig(Can.FromInv.PowerVa.L1,3);//((((Can.FromInv.PowerVa.L1 % 10000) % 1000)/100) + 48); 
								TextBuffer[2] = '.';	
								TextBuffer[3] = Dig(Can.FromInv.PowerVa.L1,4);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[4] = Dig(Can.FromInv.PowerVa.L1,5);//(((((Can.FromInv.PowerVa.L1 % 10000) % 1000) % 100) % 10) + 48 );
							}
							if( Can.FromInv.PowerVa.L2 > 9999 )
							{
								TextBuffer[5] = Dig(Can.FromInv.PowerVa.L2,1);//(((Can.FromInv.PowerVa.L2 % 10000)/1000) + 48);	
								TextBuffer[6] = Dig(Can.FromInv.PowerVa.L2,2);//((((Can.FromInv.PowerVa.L2 % 10000) % 1000)/100) + 48); 
								TextBuffer[7] = Dig(Can.FromInv.PowerVa.L2,3);//(((((Can.FromInv.PowerVa.L2 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[8] = '.'; 
								TextBuffer[9] = Dig(Can.FromInv.PowerVa.L2,4);//(((((Can.FromInv.PowerVa.L2 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[5] = Dig(Can.FromInv.PowerVa.L2,2);//(((Can.FromInv.PowerVa.L2 % 10000)/1000) + 48);	
								TextBuffer[6] = Dig(Can.FromInv.PowerVa.L2,3);//((((Can.FromInv.PowerVa.L2 % 10000) % 1000)/100) + 48); 
								TextBuffer[7] = '.';	
								TextBuffer[8] = Dig(Can.FromInv.PowerVa.L2,4);//(((((Can.FromInv.PowerVa.L2 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[9] = Dig(Can.FromInv.PowerVa.L2,5);//(((((Can.FromInv.PowerVa.L2 % 10000) % 1000) % 100) % 10) + 48 );
							}
							if( Can.FromInv.PowerVa.L3 > 9999 )
							{
								TextBuffer[10] = Dig(Can.FromInv.PowerVa.L3,1);//(((Can.FromInv.PowerVa.L3 % 10000)/1000) + 48);	
								TextBuffer[11] = Dig(Can.FromInv.PowerVa.L3,2);//((((Can.FromInv.PowerVa.L3 % 10000) % 1000)/100) + 48); 
								TextBuffer[12] = Dig(Can.FromInv.PowerVa.L3,3);//(((((Can.FromInv.PowerVa.L3 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[13] = '.'; 
								TextBuffer[14] = Dig(Can.FromInv.PowerVa.L3,4);//(((((Can.FromInv.PowerVa.L3 % 10000) % 1000) % 100) % 10) + 48 );
							}
							else
							{
								TextBuffer[10] = Dig(Can.FromInv.PowerVa.L3,2);//(((Can.FromInv.PowerVa.L3 % 10000)/1000) + 48);	
								TextBuffer[11] = Dig(Can.FromInv.PowerVa.L3,3);//((((Can.FromInv.PowerVa.L3 % 10000) % 1000)/100) + 48); 
								TextBuffer[12] = '.';	
								TextBuffer[13] = Dig(Can.FromInv.PowerVa.L3,4);//(((((Can.FromInv.PowerVa.L3 % 10000) % 1000) % 100) / 10) + 48);	
								TextBuffer[14] = Dig(Can.FromInv.PowerVa.L3,5);//(((((Can.FromInv.PowerVa.L3 % 10000) % 1000) % 100) % 10) + 48 );
							}	
						}	
						if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				   			ASendText(195,145,"VA  ����� ����� �����",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
						if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				   			ASendText(195,145,"VA   �����           ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
						
				//----------------------------------------------------------------------------------------------------					
		
					TextBufferLong[0] = 0xffbb00;
					if( Can.FromInv.PowerVa.L1 > 10 )
					{
						TextBuffer[0] = Dig(Can.FromInv.Pf.L1,3);//(((Can.FromInv.Pf.L1 % 1000)/100) + 48); 
						TextBuffer[1] = '.'; 
						TextBuffer[2] = Dig(Can.FromInv.Pf.L1,4);//(((Can.FromInv.Pf.L1 %100)/10) + 48);
						TextBuffer[3] = Dig(Can.FromInv.Pf.L1,5);//((Can.FromInv.Pf.L1 % 10) + 48);
					}
					else
						{ TextBuffer[0] = '-'; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = '-'; }
					if( Can.FromInv.PowerVa.L2 > 10 )
					{
						TextBuffer[4] = Dig(Can.FromInv.Pf.L2,3);//(((Can.FromInv.Pf.L2 % 1000)/100) + 48); 
						TextBuffer[5] = '.'; 
						TextBuffer[6] = Dig(Can.FromInv.Pf.L2,4);//(((Can.FromInv.Pf.L2 %100)/10) + 48);
						TextBuffer[7] = Dig(Can.FromInv.Pf.L2,5);//((Can.FromInv.Pf.L2 % 10) + 48);
					}
					else
						{ TextBuffer[4] = '-'; TextBuffer[5] = '-'; TextBuffer[6] = '-'; TextBuffer[7] = '-'; }
					if( Can.FromInv.PowerVa.L3 > 10 )
					{
						TextBuffer[8] = Dig(Can.FromInv.Pf.L3,3);//(((Can.FromInv.Pf.L3 % 1000)/100) + 48); 
						TextBuffer[9] = '.'; 
						TextBuffer[10] = Dig(Can.FromInv.Pf.L3,4);//(((Can.FromInv.Pf.L3 %100)/10) + 48);
						TextBuffer[11] = Dig(Can.FromInv.Pf.L3,5);//((Can.FromInv.Pf.L3 % 10) + 48);
					}
					else
						{ TextBuffer[8] = '-'; TextBuffer[9] = '-'; TextBuffer[10] = '-'; TextBuffer[11] = '-'; }
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,165,"PF  ����  ����  ���� ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				    	ASendText(195,165,"PF   ����            ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				    
					BufferedText(Can.FromInv.CrestFactor.L1,Can.FromInv.CrestFactor.L2,Can.FromInv.CrestFactor.L3,0xffbb00);
					if( Uart2.NumOfPhaseOut == 3 )									//14.07.14	
				    	ASendText(195,185,"C.F  |   |   | ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					if( Uart2.NumOfPhaseOut == 1 )									//14.07.14	
				    	ASendText(195,185,"C.F  |             ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			   		ASendText(195,205,"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				}
				ExOutputPage = OutputPage;
			break;
			case DC:
				OutputPage = 1;
				if( ExOlcumSekme != OlcumSekme )
					BigOutVar(130,125,0,SagSolOK,0,0,0x888888,Clear);	
		//		if(OlcumSil == 0)
		//			ASendText(5,3,"MEASUREMENTS>DC      ",2,0x999999,NOTGRADIENTCOLOR,OlcumSil);
				//Write
				BufferedText(Can.FromPfc.RecDCBus.Pos,Can.FromPfc.RecDCBus.Neg,0,0xffbb00);
				if(Can.FromPfc.RecDCBus.Neg == 0)
					ASendText(195,85,OlcumAltMenu[3][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				else
					ASendText(195,85,OlcumAltMenu[4][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					
				BufferedText(Can.FromPfc.CbattC.Pos,Can.FromPfc.CbattC.Neg,0,0xffbb00);
				ASendText(195,105,OlcumAltMenu[5][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				
				//De�arj ak�m�nda 10 A �zerinde 0011 A gibi bir de�eri 0114 A g�steriyor.03.04.2014 tarihinde 
				/*
				BufferedText(Can.FromPfc.SonucDisCbattC.Pos,Can.FromPfc.SonucDisCbattC.Neg,0,0xffbb00);
				if(( Can.FromPfc.SonucDisCbattC.Pos > 99 ) || ( Can.FromPfc.SonucDisCbattC.Neg > 99 ) )
					ASendText(195,125,OlcumAltMenu[6][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				else
					ASendText(195,125,OlcumAltMenu[7][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				*/	
				
				if(( Can.FromPfc.SonucDisCbattC.Pos > 99 ) || ( Can.FromPfc.SonucDisCbattC.Neg > 99 ) )
				{
					BufferedText(Can.FromPfc.SonucDisCbattC.Pos / 10 ,Can.FromPfc.SonucDisCbattC.Neg / 10 ,0,0xffbb00);	
					ASendText(195,125,OlcumAltMenu[6][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				}
				else
				{
					BufferedText(Can.FromPfc.SonucDisCbattC.Pos,Can.FromPfc.SonucDisCbattC.Neg,0,0xffbb00);	
					ASendText(195,125,OlcumAltMenu[7][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				}
						
				BufferedText(Can.FromInv.AkuSayisi,0,0,0xffbb00);
				ASendText(195,145,OlcumAltMenu[8][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(EeKayit.AkuKolSayisi,0,0,0xffbb00);
				ASendText(195,165,OlcumAltMenu[9][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				BufferedText(EeKayit.AkuAh,0,0,0xffbb00);
				ASendText(195,185,OlcumAltMenu[10][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				
				TextBufferLong[0] = 0xffbb00;
				//�ebeke kesik alarm� yoksa ve ilk dakika ge�mediyse g�sterme---- halinde g�sterilecek.
				if(( Alarm.Word.Pfc1.Bit.SebekeKesik == 1 ) && (AkuKapasite.IlkDakikaGecti == 1))
				{
					TextBuffer[0] = Dig(Menu.AkuKalanSure,2);//(Menu.AkuKalanSure / 1000) + 48; 
					TextBuffer[1] = Dig(Menu.AkuKalanSure,3);//(( Menu.AkuKalanSure % 1000 ) / 100) + 48;
					TextBuffer[2] = Dig(Menu.AkuKalanSure,4);//(( ( Menu.AkuKalanSure % 1000 ) % 100 ) / 10) + 48;
					TextBuffer[3] = Dig(Menu.AkuKalanSure,5);//( ( ( Menu.AkuKalanSure % 1000 ) % 100 ) % 10 ) + 48;
				}
				else
				{
					TextBuffer[0] = '-'; TextBuffer[1] = '-'; 
					TextBuffer[2] = '-'; TextBuffer[3] = '-';
				}
				ASendText(195,205,OlcumAltMenu[11][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			break;
			case General:
		//		if(OlcumSil == 0)	
		//			ASendText(5,3,"MEASUREMENTS>GENERAL ",2,0x999999,NOTGRADIENTCOLOR,OlcumSil);
			   	
			   	
				TextBufferLong[0] = 0xffbb00;
	   			//Termal sens�r1 TH1 aktifse �l��m yazar.
				if( EeKayit.Konfig.Bit.TermalSensor1 )
				{
					TextBuffer[0] = ' ';
					Genel.Th1AraDeger = EeKayit.TermalSensor1.Olculen;
					if( Genel.Th1AraDeger > 32767 )
					{
						Genel.Th1AraDeger = 65536 - Genel.Th1AraDeger;
						TextBuffer[0] = '-';
					}
					TextBuffer[1] = Dig(Genel.Th1AraDeger,3);//(((Genel.Th1AraDeger % 10000) % 1000) / 100) + 48;
					TextBuffer[2] = Dig(Genel.Th1AraDeger,4);//((((Genel.Th1AraDeger % 10000) % 1000) % 100) / 10) + 48;
					TextBuffer[3] = '.';
					TextBuffer[4] = Dig(Genel.Th1AraDeger,5);//((((Genel.Th1AraDeger % 10000) % 1000) % 100) % 10) + 48;
					//Sens�r ar�zas� ( K�sa devre veya a��k devre ) olu�tu�unda ekranda �izgi �izgi g�z�ks�n
					if( Alarm.Word.Lcd1.Bit.TermalSensor1Ariza )
					{ TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; }
				}
				else
				{
					TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; 
				}	
				ASendText(195,85,"TH1   �����  �C      ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				//Termal sens�r2 TH2 aktifse �l��m yazar.
				if( EeKayit.Konfig.Bit.TermalSensor2 )
				{
					Genel.Th2AraDeger = EeKayit.TermalSensor2.Olculen;
					TextBuffer[0] = ' ';
					if( Genel.Th2AraDeger > 32767 )
					{
						Genel.Th2AraDeger = 65536 - Genel.Th2AraDeger;
						TextBuffer[0] = '-';
					}
					TextBuffer[1] = Dig(Genel.Th2AraDeger,3);//(((Genel.Th2AraDeger % 10000) % 1000) / 100) + 48;
					TextBuffer[2] = Dig(Genel.Th2AraDeger,4);//((((Genel.Th2AraDeger % 10000) % 1000) % 100) / 10) + 48;
					TextBuffer[3] = '.';
					TextBuffer[4] = Dig(Genel.Th2AraDeger,5);//((((Genel.Th2AraDeger % 10000) % 1000) % 100) % 10) + 48;	
					//Sens�r ar�zas� ( K�sa devre veya a��k devre ) olu�tu�unda ekranda �izgi �izgi g�z�ks�n
					if( Alarm.Word.Lcd1.Bit.TermalSensor2Ariza )
					{ TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' ';  }
				}
				else
				{
					TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; 
				}	
				ASendText(195,105,"TH2   �����  �C      ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				
				//Ak� Is� sens�r ar�zas� varsa ---- g�z�kecek.
				if( (Alarm.Word.Pfc2.Bit.AkuIsiSensoru == 0) && (AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp == 1) )
				{
					Genel.Th3AraDeger = Can.FromPfc.RecTemp;							
					TextBuffer[0] = ' ';
					if( Genel.Th3AraDeger > 32767 )
					{
						Genel.Th3AraDeger = 65536 - Genel.Th3AraDeger;
						TextBuffer[0] = '-';
					}
					TextBuffer[1] = Dig(Genel.Th3AraDeger,3);//(((Genel.Th3AraDeger % 1000)/100) + 48);
					TextBuffer[2] = Dig(Genel.Th3AraDeger,4);//(((Genel.Th3AraDeger %100)/10) + 48);
					TextBuffer[3] = '.';
					TextBuffer[4] = Dig(Genel.Th3AraDeger,5);//((Genel.Th3AraDeger % 10) + 48);
				}
				else
				{
					TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; 
				}	
				ASendText(195,125,"TH3   �����  �C      ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
				for( for_i=0;for_i<4;for_i++ )
			    	ASendText(195,(145+for_i*20),"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
			break;
			//Enter_Exit
			case 6:
				if( ExOlcumSekme != OlcumSekme )
				{
					if(ExOlcumSekme == 5)
					{
						for( for_i=0;for_i<3;for_i++ )
							ASendText(195,(85+for_i*20),"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					}
					else if(ExOlcumSekme == 0)
					{
						for( for_i=0;for_i<7;for_i++ )
					   		ASendText(195,(85+for_i*20),"                     ",2,0xffffff,NOTGRADIENTCOLOR,OlcumSil);
					}
		//			Dikdortgen(180,471,66,235,0xffff00,1,0,1);
				}
				if( Menu.Buton.All == DefEnterButon)
					BigOutVar(130,125,0,OrtaNokta,0,0,0xffffff,OlcumSil);
				else
					BigOutVar(130,125,0,OrtaNokta,0,0,0x888888,OlcumSil);
					
			break;
			default:
			break;
		}	
		if( ExOlcumSekme != OlcumSekme )
		{
			if(ExOlcumSekme == 6)	//Enter_Exit
				BigOutVar(130,125,0,OrtaNokta,0,0,0x888888,1);
		}	
		if(ExOlcumSekme > OlcumSekme)
			BigOutVar(130,67,0,ScrollUpOk,0,0,0x888888,OlcumSil);
			
		if(ExOlcumSekme < OlcumSekme)
			BigOutVar(130,183,0,ScrollDownOk,0,0,0x888888,OlcumSil);
				
		if(OlcumSekme == Output)
			BigOutVar(130,125,0,SagSolOK,0,0,0x888888,OlcumSil);
		ExOlcumSekme = OlcumSekme;
	}
	else
	{
//		ASendText(5,3,UstKelime[1][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	}
}

//--------------------------------------------------------------------
//1sn de bir �a�r�l�r.O an ki alarmlar� veya log kay�t alarmlar�n� g�sterir.
void AlarmGoster(unsigned int Oan_Log)
{
	//Buffer lar�n say�s� alarm say�s�n� belirler.
	static int AlarmRing[2] = {0,0};
	static int Alr_i = 0,Alr_z = 0;
	static int EskiInvStrtgBit = 0;;
	
	
	/*              YENI  DENENECEK               */
	//Fault kod mu Status Kod mu o ayr��t�r�l�r.Yanl��l�klara �nlem al�r.		
	if( Alarm.Word.Pfc1.Bit.PfcFaultKod )
	{						
		Alarm.Word.Lcd1.Bit.PfcDurumKod = 0;
		//Can �zerinden yanl�� bir �ekilde kod = 0 ve fault var g�r�nmesin diye
		if(( AlarmKod.Kod.Pfc == 1000 ) || ( AlarmKod.Kod.Pfc == 0 ))
			Alarm.Word.Pfc1.Bit.PfcFaultKod = 0;
	}
	else
	{
		if(( AlarmKod.Kod.Pfc == 1000 ) || ( AlarmKod.Kod.Pfc == 0 ))
			Alarm.Word.Lcd1.Bit.PfcDurumKod = 0;
		else
			Alarm.Word.Lcd1.Bit.PfcDurumKod = 1;							
	}		
	//Fault kod mu Status Kod mu o ayr��t�r�l�r.Yanl��l�klara �nlem al�r.	
	if( Alarm.Word.Inv1.Bit.InvFaultKod )
	{						
		Alarm.Word.Lcd1.Bit.InvDurumKod = 0;
		//Can �zerinden yanl�� bir �ekilde kod = 0 ve fault var g�r�nmesin diye
		if( AlarmKod.Kod.Inv == 0 )
			Alarm.Word.Inv1.Bit.InvFaultKod = 0;
	}
	else
	{
		if( AlarmKod.Kod.Inv == 0 )
			Alarm.Word.Lcd1.Bit.InvDurumKod = 0;
		else
			Alarm.Word.Lcd1.Bit.InvDurumKod = 1;							
	}	

	//O an alarmlar�n� g�stermesi i�in
	if( Oan_Log == 0 )
	{
		if( Genel.AlarmGosterilmesinBiti == 0 )
		{
			if( GosterAlarm.Half[Alr_i] > 0 )
			{
				while( (( GosterAlarm.Half[Alr_i] >> AlarmRing[Alr_i] ) & 1) == 0 )
				{
					if( GosterAlarm.Word.Inv3.Bit.InvStrtg != EskiInvStrtgBit )
					{
						//Hemen Inv ba�l�yor uyar�s�n�n s�ras� �ne gelsin diye.
						Alr_i = 1;
						AlarmRing[Alr_i] = 22;
						EskiInvStrtgBit = GosterAlarm.Word.Inv3.Bit.InvStrtg;
					}
					//4(63) ve 2 (31) olmak �zere alarm gruplar� dengesizdir o y�zden ��kartma �arpma i�lemleri var.
					if( ++AlarmRing[Alr_i] > ( 63 - (Alr_i * 16) ))
					{
						AlarmRing[Alr_i] = 0; 
						//Her bir Alr_i de�eri i�in 64 alarm vard�r.
						if( ++Alr_i > 1 )
							Alr_i = 0;
					}
				}
				if( ( GosterAlarm.Half[0] != 0 ) || ( GosterAlarm.Half[1] != 0 ) )
				{
					//Alarm kodlar | status kodlar i�in b�yle 
					if( Alr_i == 0 )
					{
						if( AlarmRing[Alr_i] == 15 )
						{
							if(( AlarmKod.Kod.Inv != 0 ) || ( AlarmKod.Kod.Inv != 1000 ))
							{
								BufferedText(AlarmKod.Kod.Inv,0,0,0xff0000);
								ASendText(10,250+(272*GlobalSayfa),Alarms[ AlarmRing[Alr_i] ][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250,"-@-",2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250+272,"-@-",2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								OptimizasyonFonk2(0xff0000,NotClear);
							}
							else
							{
								//ASendText(320,250,"-@-",2,0xff0000,NOTGRADIENTCOLOR,1);
								//ASendText(320,250+272,"-@-",2,0xff0000,NOTGRADIENTCOLOR,1);
								OptimizasyonFonk2(0xff0000,1);
							}
						}
						else if( AlarmRing[Alr_i] == 47 )
						{
							if(( AlarmKod.Kod.Pfc != 1000 ) || ( AlarmKod.Kod.Pfc != 0 ))
							{
								BufferedText(AlarmKod.Kod.Pfc,0,0,0xff0000);
								ASendText(10,250+(272*GlobalSayfa),Alarms[ AlarmRing[Alr_i] ][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250,"-@-",2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250+272,"-@-",2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								OptimizasyonFonk2(0xff0000,NotClear);
							}
							else
							{
								//ASendText(320,250,"-@-",2,0xff0000,NOTGRADIENTCOLOR,1);
								//ASendText(320,250+272,"-@-",2,0xff0000,NOTGRADIENTCOLOR,1);
								OptimizasyonFonk2(0xff0000,1);
							}
						}
						else
						{
							//En alt sat�r kod lar var sa yaz s�rekli yaz.
							if((( AlarmKod.Kod.Pfc == 1000 ) || ( AlarmKod.Kod.Pfc == 0 )) && (( AlarmKod.Kod.Inv == 0 ) || ( AlarmKod.Kod.Inv == 1000 )))
							{
								//ASendText(320,250,"-@-",2,0xff0000,NOTGRADIENTCOLOR,1);
								//ASendText(320,250+272,"-@-",2,0xff0000,NOTGRADIENTCOLOR,1);
								OptimizasyonFonk2(0xff0000,1);
							}
							//E�er g�sterilecek olan alarm ise k�rm�z�, uyar� ise sar� g�sterilecek.
							if( (Alr_i==0) && ((AlarmRing[Alr_i] < 16 ) || (( AlarmRing[Alr_i] > 31 ) && ( AlarmRing[Alr_i] < 48 ))) )
								ASendText(10,250+(272*GlobalSayfa),Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,NotClear);
							else
								ASendText(10,250+(272*GlobalSayfa),Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],2,0xffff00,NOTGRADIENTCOLOR,NotClear);
						}
					}
					if( Alr_i == 1 )
					{
						if( (AlarmRing[Alr_i] + Alr_i * 64 ) == 78 )
						{
							if(( AlarmKod.Kod.Inv != 0 ) || ( AlarmKod.Kod.Inv != 1000 ))
							{
								BufferedText(AlarmKod.Kod.Inv,0,0,0xffff00);
								ASendText(10,250+(272*GlobalSayfa),Alarms[ (AlarmRing[Alr_i] + Alr_i * 64 ) ][EeKayit.Dil],2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								OptimizasyonFonk2(0xffff00,NotClear);
							}
							else
							{
								//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
								//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
								OptimizasyonFonk2(0xffff00,1);
							}
						}
						else if( (AlarmRing[Alr_i] + Alr_i * 64 ) == 79 )
						{
							if(( AlarmKod.Kod.Pfc != 1000 ) || ( AlarmKod.Kod.Pfc != 0 ))
							{
								BufferedText(AlarmKod.Kod.Pfc,0,0,0xffff00);
								ASendText(10,250+(272*GlobalSayfa),Alarms[ (AlarmRing[Alr_i] + Alr_i * 64 ) ][EeKayit.Dil],2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								OptimizasyonFonk2(0xffff00,NotClear);
							}
							else
							{
								//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
								//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
								OptimizasyonFonk2(0xffff00,1);
							}
						}
						else if( (AlarmRing[Alr_i] + Alr_i * 64 ) == 111 )
						{
							//Bu konu ile alakal� bilgi gelince durumu g�stersin
							if( Can.FromInv.CalismaModuSayac > 3 )
							{
								for( Alr_z=0;Alr_z<20;Alr_z++ )
									TextBuffer[Alr_z] = *(ParalelMenu[Can.FromInv.CalismaModu][EeKayit.Dil] + Alr_z);
									
								if( Can.FromInv.CalismaModu == 3 )		//Paralel mod
								{
									if( Paralel.Bit.Bit7 == 1 )
									{
										TextBuffer[18] = 'M';
										TextBuffer[19] = 'S';
									}
									else
									{
										if( Paralel.Bit.Bit6 == 1 )
										{
											TextBuffer[18] = 'S';
											TextBuffer[19] = 'L';
										}
										else
										{
											TextBuffer[18] = 's';
											TextBuffer[19] = 'l';
										}
									}
								}				
								TextBufferLong[0] = 0xffff00;				
						//		LcdFonk(Alarms[ (AlarmRing[Alr_i] + Alr_i * 64 ) ][EeKayit.Dil],Genel.ParalelAlr,0,1,4);
								ASendText(10,250+(272*GlobalSayfa),Alarms[ (AlarmRing[Alr_i] + Alr_i * 64 ) ][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,NotClear);
								//Online mod gibi mod durumlar�n� sabit olarak sadece ana men�de bulunuyor.
							}
							//En alt sat�r kod lar var sa yaz s�rekli yaz.
							if((( AlarmKod.Kod.Pfc == 1000 ) || ( AlarmKod.Kod.Pfc == 0 )) && (( AlarmKod.Kod.Inv == 0 ) || ( AlarmKod.Kod.Inv == 1000 )))
							{
								//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
								//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
								OptimizasyonFonk2(0xffff00,1);
							}
						}
						else
						{
							//�lk 15 sn i�erisinde ise
							if( Timer6.Ilk_15sn_Sayac > 0 )
							{	
								//A35 Inv Stop yerine Invert�r Ba�l�yor yaz�lacak. 
								if( (AlarmRing[Alr_i] + Alr_i * 64 ) == 82 )
								{
									ASendText(10,250+(272*GlobalSayfa),GenelTablo[10][EeKayit.Dil],2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								}
								else
								{
									//En alt sat�r kod lar var sa yaz s�rekli yaz.
									if((( AlarmKod.Kod.Pfc == 1000 ) || ( AlarmKod.Kod.Pfc == 0 )) && (( AlarmKod.Kod.Inv == 0 ) || ( AlarmKod.Kod.Inv == 1000 )))
									{
										//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
										//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
										OptimizasyonFonk2(0xffff00,1);
									}
									//E�er g�sterilecek olan alarm ise k�rm�z�, uyar� ise sar� g�sterilecek.
									ASendText(10,250+(272*GlobalSayfa),Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],2,0xffff00,NOTGRADIENTCOLOR,NotClear);
								}
							}	
							else
							{
								//En alt sat�r kod lar var sa yaz s�rekli yaz.
								if((( AlarmKod.Kod.Pfc == 1000 ) || ( AlarmKod.Kod.Pfc == 0 )) && (( AlarmKod.Kod.Inv == 0 ) || ( AlarmKod.Kod.Inv == 1000 )))
								{
									//ASendText(320,250,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
									//ASendText(320,250+272,"-@-",2,0xffff00,NOTGRADIENTCOLOR,1);
									OptimizasyonFonk2(0xffff00,1);
								}
								//E�er g�sterilecek olan alarm ise k�rm�z�, uyar� ise sar� g�sterilecek.
								ASendText(10,250+(272*GlobalSayfa),Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],2,0xffff00,NOTGRADIENTCOLOR,NotClear);
							}
						}
					}					
				}
				//4(63) ve 2(31) olmak �zere alarm gruplar� dengesizdir o y�zden ��kartma �arpma i�lemleri var.
				if( ++AlarmRing[Alr_i] > ( 63 - (Alr_i * 16) ))
				{
					AlarmRing[Alr_i] = 0;
					if( ++Alr_i > 1 )
						Alr_i = 0;
				}
			}
			else
			{
				//Di�er 64 bitlik Alarm grubu i�in
				if( ++Alr_i > 1 )
					Alr_i = 0;
			}
		}
		//Hi� bir alarm yoksa 4.sat�r� sil.
		if( ( GosterAlarm.Half[0] == 0 ) && ( GosterAlarm.Half[1] == 0 ) )
		{
			if( GlobalSayfa == 0 )
				ASendText(10,250,"                    ",2,0xff0000,NOTGRADIENTCOLOR,NotClear);
			if( GlobalSayfa == 1 )
				ASendText(10,250+272,"                    ",2,0xff0000,NOTGRADIENTCOLOR,NotClear);
		}
	}
	//Log alarmlar�n� g�stermesi i�in
	if( Oan_Log == 1 )
	{
//		//A00 varsa inv de di�erlerini g�sterme R00 varsa pfc de di�erlerini g�sterme
//		if( LogAlarm.Word.Inv1.Bit.InvFaultKod )
//		{
//			LogAlarm.Word.Inv1.All &= 32768;
//			LogAlarm.Word.Inv2.All = 0;
//			LogAlarm.Word.Inv3.All = 0;
//			LogAlarm.Word.Lcd1.All = 0;
//			LogAlarm.Word.Lcd2.All = 0;
//			LogAlarm.Word.YedekAlr2.All = 0;
//		}
//		if( LogAlarm.Word.Pfc1.Bit.PfcFaultKod )
//		{
//			LogAlarm.Word.Pfc1.All &= 32768;
//			LogAlarm.Word.Lcd1.All = 0;
//			LogAlarm.Word.Lcd2.All = 0;
//			LogAlarm.Word.Pfc2.All = 0;
//			LogAlarm.Word.YedekAlr2.All = 0;
//		}	
//		if( LogAlarm.Half[Alr_i] > 0 )
//		{
//			while( (( LogAlarm.Half[Alr_i] >> AlarmRing[Alr_i] ) & 1) == 0 )
//			{
//				//4(63) ve 2(31) olmak �zere alarm gruplar� dengesizdir o y�zden 
//				if( ++AlarmRing[Alr_i] > ( 63 - (Alr_i * 32) ))
//				{
//					AlarmRing[Alr_i] = 0; 
//					//Her bir Alr_i de�eri i�in 64 alarm vard�r.
//					if( ++Alr_i > 1 )
//						Alr_i = 0;
//				}
//			}				
//			if( ( LogAlarm.Half[0] != 0 ) || ( LogAlarm.Half[1] != 0 ) )
//			{
//				if(( (AlarmRing[Alr_i] + Alr_i * 64 ) == 15 ) || ((AlarmRing[Alr_i] + Alr_i * 64 ) == 78 ))
//					LcdFonk(Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],&LogAlarmKod.Kod.Inv,0,1,4);
//				else if(( (AlarmRing[Alr_i] + Alr_i * 64 ) == 47 ) || ((AlarmRing[Alr_i] + Alr_i * 64 ) == 79 ))
//					LcdFonk(Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],&LogAlarmKod.Kod.Pfc,0,1,4);
//				else
//					LcdFonk(Alarms[ AlarmRing[Alr_i] + Alr_i * 64 ][EeKayit.Dil],&Menu.aDummy,0,1,4);
//			}
//			//4(63) ve 2(31) olmak �zere alarm gruplar� dengesizdir o y�zden
//			if( ++AlarmRing[Alr_i] > ( 63 - (Alr_i * 32) ))
//			{
//				AlarmRing[Alr_i] = 0;
//				if( ++Alr_i > 1 )
//					Alr_i = 0;
//			}
//		}
//		else
//		{
//			//Di�er 64 bitlik Alarm grubu i�in
//			if( ++Alr_i > 1 )
//				Alr_i = 0;
//		}
//		//Hi� bir Log alarm kayd� yoksa 4.sat�r� sil.
//		if( ( LogAlarm.Half[0] == 0 ) && ( LogAlarm.Half[1] == 0 ) )
//			LcdFonk("                    ",&Menu.aDummy,0,1,4);
	}
	//Oan_Log de�eri 2 gelirse hi�bir i�lem yap�lmaz.
}



















void LogIslem(unsigned int LogIslemi)
{
	unsigned int Log_i;
	unsigned int EeLogIslemDeger;
	unsigned int KayitIslem;
	unsigned int h;
	//Log lar� silme i�lemi
//	if( LogIslemi == 0 )
//	{
//		if(( Menu.Sekme.All == DefAnaMenu ) && ( Menu.AnaSekme == DefAlarmMenu ))
//		{
//			//K�rm�z� dikd�rtgen �izili alan� temizle.
//			ASendText(65,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(65,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(65,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(65,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(65,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(65,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		
//			ASendText(255,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(255,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(255,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(255,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(255,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(255,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//			ASendText(442,140,"1/[",1,0x00ffff,NOTGRADIENTCOLOR,1);
//	
//	//		ASendText(15,218,"  ---Logs Clearing......      ---  ",2,0xff0000,NOTGRADIENTCOLOR,0);
//			ASendText(15,222,GenelTablo[12][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,0);
//		}
//		
//		for(Log_i = DefLogFirstAddr;Log_i < ( DefLogLastAddr + 1 );Log_i++)
//			EeByteYaz( Log_i,255 );
//		OkuRTC(&Date);	
//		Alarm.Half[0] = 0; Alarm.Half[1] = 0;
//		OldAlarm.Half[0] = 0; OldAlarm.Half[1] = 0;		
//		OldKontrolAlarm.Half[0] = 0; OldKontrolAlarm.Half[1] = 0;								
//		EeAlarmYaz(&Date,0);						
//		EeWordYaz( 0,65534 );							
//		Menu.LogSayac = 0; EeKayit.LogSayac = 1; LogSayisiToInv = 0;
//		EeWordYaz( &EeKayit.LogSayac,EeKayit.LogSayac );
//	}
	if( LogIslemi == 0 )
	{
		if( Genel.LogSilmeSonu == 1 )
		{
			Genel.LogSilmeSonu = 0;
			OkuRTC(&Date);	
	//		Alarm.Half[0] = 0; Alarm.Half[1] = 0;
			OldAlarm.Half[0] = 0; OldAlarm.Half[1] = 0;		
			OldKontrolAlarm.Half[0] = 0; OldKontrolAlarm.Half[1] = 0;								
			EeAlarmYaz(&Date,DefLogFirstAddr);						
			EeWordYaz( DefLogFirstAddr,65534 );							
			Menu.LogSayac = 0; EeKayit.LogSayac = 1; LogSayisiToInv = 0;
			EeKayit.LogCounterPage = 0;
			EeWordYaz( &EeKayit.LogCounterPage,EeKayit.LogCounterPage );
			EeWordYaz( &EeKayit.LogSayac,EeKayit.LogSayac );
			//Log temizleme i�lemi bu adreste kay�tl�
			//LcdFonk(AlarmMenu[DefLogSilindi][EeKayit.Dil],Menu.Alr,0,1,4);
		}	
		else
		{
			//LcdFonk(AlarmMenu[DefLogSiliniyor][EeKayit.Dil],Menu.Alr,0,1,4);	
			if(( Menu.Sekme.All == DefAnaMenu ) && ( Menu.AnaSekme == DefAlarmMenu ))
			{
				//K�rm�z� dikd�rtgen �izili alan� temizle.
				for(h=135;h<205;h=h+13)
					ASendText(65,h,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(65,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(65,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(65,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(65,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(65,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(65,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
			
				for(h=135;h<205;h=h+13)
					ASendText(255,h,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(255,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(255,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(255,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(255,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(255,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//				ASendText(255,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
				ASendText(442,140,"1/[",1,0x00ffff,NOTGRADIENTCOLOR,1);
		
		//		ASendText(15,218,"  ---Logs Clearing......      ---  ",2,0xff0000,NOTGRADIENTCOLOR,0);
				ASendText(15,222,GenelTablo[12][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,0);
			}
			if( Genel.LogSilEmri == 0 )
				Genel.Log_m = DefLogFirstAddr;
			Genel.LogSilEmri = 1;
		}
		
	}
	//Log lar� okuma i�lemi - Men�n�n i�erisinde yap�l�yor.

//	//Log lar� yazma i�lemi
//	if( LogIslemi == 2 )
//	{	
//
//		//E�er test modunda de�ilse yeni alarm durumunda buzzer tetiklenir.
//		if( ( Alarm.Word.Inv3.Bit.TestModu == 0 ) && ( Alarm.Word.Inv3.Bit.AdimModu == 0 ) )
//		{
//			//Alarm bitlerinden en az bir tanesi de�i�ti.Buzer �tebilir.			
//			Menu.AlarmSesAcik = 1; Megatech.Q.TurnBeep = 0;	Menu.MaskeAlarmSesAcik = 1;		
//		}
//			
//		KayitIslem = 0;	
//		//Uyar� kayd�na izin veriliyorsa kay�t kontrol i�lemleri
//		if( EeKayit.Konfig2.Bit.UyariLog )
//		{
//			MaskedAlarm.Word.Lcd1.All = Alarm.Word.Lcd1.All & EeKayit.LcdLogMaske;
//			//StatusKod kayd�na izin veriliyorsa kay�t kontrol i�lemleri			
//			if( EeKayit.Konfig2.Bit.DurumLog == 0)
//			{
//				MaskedAlarm.Word.Lcd1.Bit.InvDurumKod = 0;
//				MaskedAlarm.Word.Lcd1.Bit.PfcDurumKod = 0;
//			}
//			if( (MaskedAlarm.Word.Lcd1.All | OldAlarm.Word.Lcd1.All) != OldAlarm.Word.Lcd1.All )
//				KayitIslem = 1;
//			if( (MaskedAlarm.Word.Inv2.All | OldAlarm.Word.Inv2.All) != OldAlarm.Word.Inv2.All )
//				KayitIslem = 1;
//			if( (MaskedAlarm.Word.Pfc2.All | OldAlarm.Word.Pfc2.All) != OldAlarm.Word.Pfc2.All )
//				KayitIslem = 1;		
//				
//			OldAlarm.Word.Lcd1.All = MaskedAlarm.Word.Lcd1.All;
//			OldAlarm.Word.Inv2.All = MaskedAlarm.Word.Inv2.All;
//			OldAlarm.Word.Pfc2.All = MaskedAlarm.Word.Pfc2.All;	
//		}
//		if( ((Alarm.Word.Inv1.All | OldAlarm.Word.Inv1.All) != OldAlarm.Word.Inv1.All) )
//			KayitIslem = 1;
//		if( ((Alarm.Word.Pfc1.All | OldAlarm.Word.Pfc1.All) != OldAlarm.Word.Pfc1.All) )
//			KayitIslem = 1;
//		
//		OldAlarm.Word.Inv1.All = Alarm.Word.Inv1.All;
//		OldAlarm.Word.Pfc1.All = Alarm.Word.Pfc1.All;		
//		if( KayitIslem == 1 )
//		{
//			OldAlarm.Word.Lcd1.All = MaskedAlarm.Word.Lcd1.All;
//			OldAlarm.Word.Inv2.All = MaskedAlarm.Word.Inv2.All;
//			OldAlarm.Word.Pfc2.All = MaskedAlarm.Word.Pfc2.All;
//			OldAlarm.Word.Inv1.All = Alarm.Word.Inv1.All;
//			OldAlarm.Word.Pfc1.All = Alarm.Word.Pfc1.All;
//			
//			OkuRTC(&Date);	
//			//Log soruluyorken yeni kay�t yap�lmas�n
//			if( Genel.LogSorulduSayac == 0 )
//				EeAlarmYaz(&Date,( EeKayit.LogSayac * 16 + DefLogFirstAddr));
//			//Kayitl� log say�s� her alarm oldu�unda artt�r�l�yor.
//			EeKayit.LogSayac++;
//			//Kayit dolarda Hesaplanan ( �imdi 191 ) de�erden b�y�kse adres ba�a d�ner
//			if( EeKayit.LogSayac > (DefLogCount-1) )
//			{	EeKayit.LogSayac = 0;}	
//			EeWordYaz( &EeKayit.LogSayac,EeKayit.LogSayac );
//			
//			if( EeKayit.LogSayac > 1 )
//				LogSayisiToInv = EeKayit.LogSayac - 2;
//			else
//				LogSayisiToInv = 0;
//				
//			//250 ms sonra ekran� yenile
//			Menu.YenileGeriSayac = 5;	
//		}				
//		//�lk 64 bitlik alarm� e�itler
//		OldKontrolAlarm.Half[0] = Alarm.Half[0];
//		//Son 64 bitlik alarm� e�itler
//		OldKontrolAlarm.Half[1] = Alarm.Half[1];
//	}
	//Log lar� yazma i�lemi
	if( LogIslemi == 2 )
	{	
		//E�er test modunda de�ilse yeni alarm durumunda buzzer tetiklenir.
		if( ( Alarm.Word.Inv3.Bit.TestModu == 0 ) && ( Alarm.Word.Inv3.Bit.AdimModu == 0 ) )
		{
			//Alarm bitlerinden en az bir tanesi de�i�ti.Buzer �tebilir.			
			Menu.AlarmSesAcik = 1; Megatech.Q.TurnBeep = 0;	Menu.MaskeAlarmSesAcik = 1;	
			//Hoparl�r
			ExBigVariable(430,243+(GlobalSayfa*272),4,3,14-Menu.MaskeAlarmSesAcik,0xffff00,0);			//Sembol 1	
		}
			
		KayitIslem = 0;	
		//Uyar� kayd�na izin veriliyorsa kay�t kontrol i�lemleri
		if( EeKayit.Konfig2.Bit.UyariLog )
		{
			MaskedAlarm.Word.Lcd1.All = Alarm.Word.Lcd1.All & EeKayit.LcdLogMaske;
			//StatusKod kayd�na izin veriliyorsa kay�t kontrol i�lemleri			
			if( EeKayit.Konfig2.Bit.DurumLog == 0)
			{
				MaskedAlarm.Word.Lcd1.Bit.InvDurumKod = 0;
				MaskedAlarm.Word.Lcd1.Bit.PfcDurumKod = 0;
			}
			if( (MaskedAlarm.Word.Lcd1.All | OldAlarm.Word.Lcd1.All) != OldAlarm.Word.Lcd1.All )
				KayitIslem = 1;
			if( (MaskedAlarm.Word.Inv2.All | OldAlarm.Word.Inv2.All) != OldAlarm.Word.Inv2.All )
				KayitIslem = 1;
			if( (MaskedAlarm.Word.Inv3.Bit.MasterUPS | OldAlarm.Word.Inv3.Bit.MasterUPS) != OldAlarm.Word.Inv3.Bit.MasterUPS )				//23.12.2014
				KayitIslem = 1;		
			if( (MaskedAlarm.Word.Pfc2.All | OldAlarm.Word.Pfc2.All) != OldAlarm.Word.Pfc2.All )
				KayitIslem = 1;		
				
			if( Genel.LogSorulduSayac == 0 )																	//23.12.2014
			{
				OldAlarm.Word.Lcd1.All = MaskedAlarm.Word.Lcd1.All;
				OldAlarm.Word.Inv2.All = MaskedAlarm.Word.Inv2.All;
				OldAlarm.Word.Inv3.All = MaskedAlarm.Word.Inv3.All;												//23.12.2014
				OldAlarm.Word.Pfc2.All = MaskedAlarm.Word.Pfc2.All;	
			}
//			OldAlarm.Word.Lcd1.All = MaskedAlarm.Word.Lcd1.All;
//			OldAlarm.Word.Inv2.All = MaskedAlarm.Word.Inv2.All;
//			OldAlarm.Word.Pfc2.All = MaskedAlarm.Word.Pfc2.All;	
		}
		if( ((Alarm.Word.Inv1.All | OldAlarm.Word.Inv1.All) != OldAlarm.Word.Inv1.All) )
			KayitIslem = 1;
		if( ((Alarm.Word.Pfc1.All | OldAlarm.Word.Pfc1.All) != OldAlarm.Word.Pfc1.All) )
			KayitIslem = 1;
		
		OldAlarm.Word.Inv1.All = Alarm.Word.Inv1.All;
		OldAlarm.Word.Pfc1.All = Alarm.Word.Pfc1.All;		
		if( KayitIslem == 1 )
		{
			OldAlarm.Word.Lcd1.All = MaskedAlarm.Word.Lcd1.All;
			OldAlarm.Word.Inv2.All = MaskedAlarm.Word.Inv2.All;
			OldAlarm.Word.Inv3.All = MaskedAlarm.Word.Inv3.All;												//23.12.2014
			OldAlarm.Word.Pfc2.All = MaskedAlarm.Word.Pfc2.All;
			OldAlarm.Word.Inv1.All = Alarm.Word.Inv1.All;
			OldAlarm.Word.Pfc1.All = Alarm.Word.Pfc1.All;
			

			//Log soruluyorken yeni kay�t yap�lmas�n.
			if( Genel.LogSorulduSayac == 0 )
			{
				//for(EeKayit.LogSayac=1;EeKayit.LogSayac<508;EeKayit.LogSayac++)
				//{
				OkuRTC(&Date);	
				//Kayitl� log say�s� her alarm oldu�unda artt�r�l�yor.
				EeKayit.LogSayac++;
				//Kayit dolarda Hesaplanan ( �imdi 192 ) de�erden b�y�kse adres ba�a d�ner
				if( EeKayit.LogSayac > DefLogCount )
				{	
					EeKayit.LogSayac = 1;
					EeKayit.LogCounterPage = 1;
				}	
				EeWordYaz( &EeKayit.LogCounterPage,EeKayit.LogCounterPage );
				EeWordYaz( &EeKayit.LogSayac,EeKayit.LogSayac );
				EeAlarmYaz(&Date,( EeKayit.LogSayac * 16 + DefLogFirstAddr - 16));
				if( EeKayit.LogCounterPage > 0 )
					LogSayisiToInv = DefLogUstSinir;
				else
					LogSayisiToInv = EeKayit.LogSayac;	
			//	}
			}
				
			//250 ms sonra ekran� yenile
			Menu.YenileGeriSayac = 5;	
		}				
		//�lk 64 bitlik alarm� e�itler
		OldKontrolAlarm.Half[0] = Alarm.Half[0];
		//Son 64 bitlik alarm� e�itler
		OldKontrolAlarm.Half[1] = Alarm.Half[1];
	}
}










void FonkAlarmMenu(unsigned int SubAlr,unsigned int AlrClr)
{
	static unsigned int ExSubAlr = 1;
	unsigned int EeLogIslemDeger;
	int LogBuff[4],SayacLogBuff;
	unsigned int z,z1,AlarmRing[2];
	static int EkranaYazilan = 0;
	static int Z;
	int hh;
	
	Menu.Sekme.All = DefAnaMenu;
	
	Elipse(10,470,130,211,0xff0000,5,AlrClr);
	if( Genel.LogSilEmri == 0 )
		ASendText(15,222,GenelTablo[11][EeKayit.Dil],1,0x999999,NOTGRADIENTCOLOR,AlrClr);
	if( Genel.LogSilEmri == 1 )
		ASendText(15,222,GenelTablo[12][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,AlrClr);

	BigOutVar(40,70,0,ScrollUpOk,0,0,0x888888,AlrClr);
	BigOutVar(420,70,0,ScrollDownOk,0,0,0x888888,AlrClr);
	
	if(( ExSubAlr == DefLogUstSinir ) && ( SubAlr == DefLogAltSinir ))
		BigOutVar(420,70,0,ScrollDownOk,0,0,0xffffff,AlrClr);
	else if(( ExSubAlr == DefLogAltSinir ) && ( SubAlr == DefLogUstSinir ))	
		BigOutVar(40,70,0,ScrollUpOk,0,0,0xffffff,AlrClr);
	else if( ExSubAlr > SubAlr )
		BigOutVar(40,70,0,ScrollUpOk,0,0,0xffffff,AlrClr);		
	else if( ExSubAlr < SubAlr )
		BigOutVar(420,70,0,ScrollDownOk,0,0,0xffffff,AlrClr);
	
	if( ExSubAlr != SubAlr )
		TFT.LogSayfaToggle = 0;
	//Men� Ba�l��� Sol �st	
//	ASendText(5,3,UstKelime[9][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						

	if( AlrClr == 1 )
	{		
		//K�rm�z� dikd�rtgen �izili alan� temizle.
		ASendText(65,161,"                             ",2,0x999999,NOTGRADIENTCOLOR,1);
		for(hh=135;hh<204;hh=hh+13)
			ASendText(65,hh,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(65,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(65,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(65,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(65,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(65,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(65,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
		ASendText(90,70,">�>].].@ ]:]:]",2,0xffffff,NOTGRADIENTCOLOR,1);

		for(hh=135;hh<204;hh=hh+13)
			ASendText(255,hh,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
	
//		ASendText(255,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(255,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(255,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(255,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(255,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//		ASendText(255,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);

		ASendText(90,90,">�>].].@ ]:]:]",2,0xffffff,NOTGRADIENTCOLOR,1);
		ASendText(90,110,">�>].].@ ]:]:]",2,0xffffff,NOTGRADIENTCOLOR,1);
		ASendText(442,140,"1/[",1,0x00ffff,NOTGRADIENTCOLOR,1);
	}
	else
	{
		LogBuff[3] = SubAlr;
		for( SayacLogBuff = 0; SayacLogBuff < 3; SayacLogBuff++ )
		{		
			//Log lar� okuma i�lemi	
			if( SayacLogBuff == 0 )
				SubAlr--;
			if( SayacLogBuff == 1 )
				SubAlr++;
			if( SayacLogBuff == 2 )
				SubAlr++;	
				
			if( SubAlr == 65535 )
				SubAlr = DefLogUstSinir;	
			else if(SubAlr < DefLogAltSinir)
				SubAlr = DefLogUstSinir;	
			else if(SubAlr > DefLogUstSinir)
				SubAlr = DefLogAltSinir;	
						
			
			if(SubAlr > (EeKayit.LogSayac - 1))
			//	LogBuff[SayacLogBuff] = (((( DefLogLastAddr + 1 ) / 16) + ( EeKayit.LogSayac - 1 ) - SubAlr ) * 16) + DefLogFirstAddr;	
				LogBuff[SayacLogBuff] = ((DefLogCount + ( EeKayit.LogSayac - 1 ) - SubAlr ) * 16) + DefLogFirstAddr;	
			else
				LogBuff[SayacLogBuff] = ((( EeKayit.LogSayac - 1 ) - SubAlr ) * 16 ) + DefLogFirstAddr;
				
			EeLogIslemDeger = EeWordOku(LogBuff[SayacLogBuff]);
		
		
			//Bo� ise 65535 dir.
			if( EeLogIslemDeger == 65535 )	
			{					
				if( SayacLogBuff == 1 )	
				{
					BufferedText(SubAlr,0,0,0xffcc00);
		//			ASendText(90,(70 + (SayacLogBuff*20)) ,">�>       EMPTY       ",2,0xffffff,NOTGRADIENTCOLOR,AlrClr);
					ASendText(90,(70 + (SayacLogBuff*20)),GenelTablo[14][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,AlrClr);
					
					for(hh=135;hh<204;hh=hh+13)
						ASendText(65,hh,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
				
//					ASendText(65,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(65,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(65,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(65,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(65,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(65,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
				
					for(hh=135;hh<204;hh=hh+13)
						ASendText(255,hh,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
			
//					ASendText(255,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(255,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(255,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(255,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(255,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//					ASendText(255,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);

			//		ASendText(65,161,"         --EMPTY--       ",2,0x999999,NOTGRADIENTCOLOR,AlrClr);
					ASendText(65,161,GenelTablo[15][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,AlrClr);
					ASendText(442,140,"1/[",1,0x00ffff,NOTGRADIENTCOLOR,1);
					EkranaYazilan = 1;
				}
				else
				{				
					BufferedText(SubAlr,0,0,0x664400);
			//		ASendText(90,(70 + (SayacLogBuff*20)) ,">�>       EMPTY       ",2,0x888888,NOTGRADIENTCOLOR,AlrClr);
					ASendText(90,(70 + (SayacLogBuff*20)),GenelTablo[14][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,AlrClr);
				}
			}
			else												
			{					
				EeAlarmOku(&Date6,LogBuff[SayacLogBuff]); 			
				TextBuffer[0] = SubAlr;
				if( SayacLogBuff == 1 )	
				{
					TextBufferLong[0] = 0xffcc00;
					ASendText(90,(70 + (SayacLogBuff*20)) ,">�>",2,0xffffff,NOTGRADIENTCOLOR,AlrClr);
			//		ASendText(90,(70 + (SayacLogBuff*20)),GenelTablo[14][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,AlrClr);			//Yeni sildim
				}
				else					
				{
					TextBufferLong[0] = 0x664400;
					ASendText(90,(70 + (SayacLogBuff*20)) ,">�>",2,0x888888,NOTGRADIENTCOLOR,AlrClr);
				}
					
				TextBuffer[0] = Date6.Day; TextBuffer[1] = Date6.Month;
				TextBuffer[2] = Date6.Year+2000; TextBuffer[3] = Date6.Hour; TextBuffer[4] = Date6.Min;
				TextBuffer[5] = Date6.Sec;	
				
				if( SayacLogBuff == 1 )	
				{
					TextBufferLong[0] = 0xffffff;
					ASendText(90,(70 + (SayacLogBuff*20)) ,"~~~~~].].@ ]:]:]",2,0xffffff,NOTGRADIENTCOLOR,AlrClr);
				}
				else
				{		
					TextBufferLong[0] = 0x888888;			
					ASendText(90,(70 + (SayacLogBuff*20)) ,"~~~~~].].@ ]:]:]",2,0x888888,NOTGRADIENTCOLOR,AlrClr);
				}
					
				//Adreste 65534 kay�l� ise log temizlendi g�z�k�r.
				if( EeLogIslemDeger == 65534 )
				{
					if( SayacLogBuff == 1 )	
					{
						//Log temizleme i�lemi bu adreste kay�tl�		
						for(hh=135;hh<204;hh=hh+13)
							ASendText(65,hh,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
							
//						ASendText(65,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(65,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(65,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(65,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(65,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(65,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
					
						for(hh=135;hh<204;hh=hh+13)
							ASendText(255,hh,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);	
							
//						ASendText(255,135,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(255,148,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(255,161,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(255,174,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(255,187,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
//						ASendText(255,200,Alarms[9][0],1,0x00ffff,NOTGRADIENTCOLOR,1);
						
			//			ASendText(65,161,"      --LOG CLEARED--    ",2,0x999999,NOTGRADIENTCOLOR,AlrClr);
						ASendText(65,161,GenelTablo[13][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,AlrClr);
						ASendText(442,140,"1/[",1,0x00ffff,NOTGRADIENTCOLOR,1);
						EkranaYazilan = 2;
					}
				}
				else
				{	
					if( SayacLogBuff == 1 )
					{						
						TFT.AlarmSay = 0;
						for(z=0;z<2;z++)
						{
							AlarmRing[0] = 0;
							AlarmRing[1] = 0;
							if( z == 0 )
								z1 = 64;
							else
								z1 = 48;
								
							for( AlarmRing[z] = 0; AlarmRing[z] < z1; AlarmRing[z]++)
							{
								if( (LogAlarm.Half[z] >> AlarmRing[z]) & 1 == 1 )
								{
									TFT.AlarmBuff[TFT.AlarmSay] = AlarmRing[z] + ( z*64 );
														//Deneniyor.
														if(( TFT.AlarmBuff[TFT.AlarmSay] == 15 ) || (TFT.AlarmBuff[TFT.AlarmSay] == 78 ))
														{
															if( LogAlarmKod.Kod.Inv == 0 )
																TFT.AlarmSay--;
														}
														if(( TFT.AlarmBuff[TFT.AlarmSay] == 47 ) || (TFT.AlarmBuff[TFT.AlarmSay] == 79 ))
														{
															if( LogAlarmKod.Kod.Pfc == 0 )
																TFT.AlarmSay--;
														}
									TFT.AlarmSay++;
								}	
							}				
						}
						if( TFT.AlarmSay > 23 ) 
							TFT.AlarmSayfaSayisi = 3;
						if( TFT.AlarmSay > 11 ) 
							TFT.AlarmSayfaSayisi = 2;
						else 
							TFT.AlarmSayfaSayisi = 1;
									
						if( TFT.AlarmSayfaSayisi > 1 )
						{
							Menu.YenileGeriSayac = 50;
							TFT.LogSayfaToggle++;
							if( TFT.LogSayfaToggle > TFT.AlarmSayfaSayisi)
								TFT.LogSayfaToggle = 1;
							Z = TFT.LogSayfaToggle * 12 - 12;
						}
						else
						{
							Z = 0;
							TFT.LogSayfaToggle = 1;
							Menu.YenileGeriSayac = 0;
						}
						BufferedText(TFT.LogSayfaToggle,TFT.AlarmSayfaSayisi,0,0x55ffff);
						ASendText(442,140,"[/[",1,0x00ffff,NOTGRADIENTCOLOR,AlrClr);
						
						if( EkranaYazilan != 0 )
							ASendText(65,161,GenelTablo[13][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,1);
							
						for(z=0;z<12;z++)
						{
							if( z > (TFT.AlarmSay-1-Z) )
								AlrClr = 1;
							else
								AlrClr = 0;
								
							if( z < 6 )
							{
								if( ( LogAlarm.Half[0] != 0 ) || ( LogAlarm.Half[1] != 0 ) )
								{
									if(( TFT.AlarmBuff[z+Z] == 15 ) || (TFT.AlarmBuff[z+Z] == 78 ))
										BufferedText(LogAlarmKod.Kod.Inv,0,0,0x55ffff);
									else if(( TFT.AlarmBuff[z+Z] == 47 ) || (TFT.AlarmBuff[z+Z] == 79 ))
										BufferedText(LogAlarmKod.Kod.Pfc,0,0,0x55ffff);
								}
								ASendText(65,(135+(13*z)),Alarms[TFT.AlarmBuff[z+Z]][EeKayit.Dil],1,0x00ffff,NOTGRADIENTCOLOR,AlrClr);
							}
							else
							{
								if( ( LogAlarm.Half[0] != 0 ) || ( LogAlarm.Half[1] != 0 ) )
								{
									if(( TFT.AlarmBuff[z+Z] == 15 ) || (TFT.AlarmBuff[z+Z] == 78 ))
										BufferedText(LogAlarmKod.Kod.Inv,0,0,0x55ffff);
									else if(( TFT.AlarmBuff[z+Z] == 47 ) || (TFT.AlarmBuff[z+Z] == 79 ))
										BufferedText(LogAlarmKod.Kod.Pfc,0,0,0x55ffff);
								}		
								ASendText(255,(135+(13*(z-6))),Alarms[TFT.AlarmBuff[z+Z]][EeKayit.Dil],1,0x00ffff,NOTGRADIENTCOLOR,AlrClr);
							}
							EkranaYazilan = 0;
							AlrClr = 0;
						}
					}
				}
			}
		}
		//Ilk hali
		SubAlr = LogBuff[3];	
		ExSubAlr = SubAlr;
	}	
	BigOutVar(40,70,0,ScrollUpOk,0,0,0x888888,AlrClr);
	BigOutVar(420,70,0,ScrollDownOk,0,0,0x888888,AlrClr);
}
void InfoMenu(unsigned int InfoSayfa,unsigned int InfClr)
{
	static int ExInfoSayfa = 0;
	int z2;
	
//	ASendText(5,3,UstKelime[10][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(420,150,0,ScrollDownOk,0,0,0xffffff,InfClr);
	else
		BigOutVar(420,150,0,ScrollDownOk,0,0,0x888888,InfClr);
		
	
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(420,90,0,ScrollUpOk,0,0,0xffffff,InfClr);
	else
		BigOutVar(420,90,0,ScrollUpOk,0,0,0x888888,InfClr);
		
	if( InfoSayfa == 0 )
	{
		TextBufferLong[0] = 0xffbb00;
		//Haberle�menin olup olmad���n� g�sterir.
		if( Uart1.Aktif )
		{ TextBuffer[0] = 'O'; TextBuffer[1] = 'K'; }
		else
		{ TextBuffer[0] = '-'; TextBuffer[1] = '-'; }		
						
		ASendText(20,80,BilgiAnaMenu[0][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
		
		if( Uart2.Aktif )
		{ TextBuffer[0] = 'O'; TextBuffer[1] = 'K'; }
		else
		{ TextBuffer[0] = '-'; TextBuffer[1] = '-'; }		
		ASendText(20,100,BilgiAnaMenu[1][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
	
		TextBufferLong[0] = 0xffbb00;
		for(z2 = 0;z2 < 6;z2++)								
			TextBuffer[z2] = Label.OutputPower[z2];
		ASendText(20,120,BilgiAnaMenu[2][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
		
		for(z2 = 0;z2 < 8;z2++)								
			TextBuffer[z2] = Label.NominalVoltage[z2];							
		for(z2 = 16;z2 < 23;z2++)									
			TextBuffer[z2-9] = Label.NominalVoltage[z2];
		TextBufferLong[0] = 0xffbb00;	
		ASendText(20,140,BilgiAnaMenu[3][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
	
		BufferedText(Can.FromInv.InvVersiyon,0,0,0xffbb00);
		ASendText(20,160,BilgiAnaMenu[4][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
		
		BufferedText(Can.FromPfc.PfcVersiyon,0,0,0xffbb00);
		ASendText(20,180,BilgiAnaMenu[5][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
		
		BufferedText(TftVersiyon,0,0,0xffbb00);
		ASendText(20,200,BilgiAnaMenu[6][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
	
		TextBufferLong[0] = 0xffbb00;
		for(z2 = 0;z2 < 6;z2++)								
			TextBuffer[z2] = Label.Model[z2];
		ASendText(20,220,BilgiAnaMenu[7][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
	}
	else if( InfoSayfa == 1 )
	{
		TextBufferLong[0] = 0xffbb00;
		for(z2 = 0;z2 < 10;z2++)								
			TextBuffer[z2] = UartProtokol[z2];
		ASendText(20,80,BilgiAnaMenu[8][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
		
		for(z2 = 0;z2 < 10;z2++)								
			TextBuffer[z2] = Label.SaseNo[z2];
		ASendText(20,100,BilgiAnaMenu[9][EeKayit.Dil],2,0xbbbbbb,NOTGRADIENTCOLOR,InfClr);
		
		for(z2 = 0;z2 < 6;z2++)	
			ASendText(20,120+z2*20,"                              ",2,0xffffff,NOTGRADIENTCOLOR,1);	
	}	
	
	BufferedText(InfoSayfa+1,DefBilgiSayfa+1,0,0xffbb00);
	ASendText(445,222,"[/[",1,0xffbb00,NOTGRADIENTCOLOR,InfClr);	
	
	if(ExInfoSayfa > InfoSayfa)
		BigOutVar(420,90,0,ScrollUpOk,0,0,0x888888,InfClr);
		
	if(ExInfoSayfa < InfoSayfa)
		BigOutVar(420,150,0,ScrollDownOk,0,0,0x888888,InfClr);
				
	ExInfoSayfa = InfoSayfa;
}

void FonkTercihAnaMenu(unsigned int TercihSekme,unsigned int TercihSil)
{
	static unsigned int a1;	
	static unsigned int ExTercihSekme = 1;
	static unsigned int OutputPage = 1,ExOutputPage = 1;
	
	Menu.TercihAltLimit = 0;
	Menu.TercihAra1Limit = 0;
	Menu.TercihAra2Limit = 3;
	Menu.TercihUstLimit = 3;
	Menu.Sekme.All = DefAnaMenu;
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183,0,ScrollDownOk,0,0,0xffffff,TercihSil);
	else
		BigOutVar(415,183,0,ScrollDownOk,0,0,0x888888,TercihSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67,0,ScrollUpOk,0,0,0xffffff,TercihSil);
	else
		BigOutVar(415,67,0,ScrollUpOk,0,0,0x888888,TercihSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125,0,OrtaNokta,0,0,0xffffff,TercihSil);
	else
		BigOutVar(415,125,0,OrtaNokta,0,0,0x888888,TercihSil);
	
	
//	if( TercihSekme < Menu.TercihAra1Limit )
//		a1 = 0;
//	if( TercihSekme > Menu.TercihAra2Limit )
//		a1 = 25;

//	if( a1 == 25 )
//		ASendText(20,205,TercihAnaMenu[EeKayit.Dil][6],2,0x888888,NOTGRADIENTCOLOR,TercihSil);
//	else
//		ASendText(20,80,TercihAnaMenu[EeKayit.Dil][0],2,0x888888,NOTGRADIENTCOLOR,TercihSil);
	 
	a1 = 0;
	//Yaz�lar�n hepsini gri yazar.	
	ASendText(20,105-a1,TercihAnaMenu[EeKayit.Dil][0],2,0x888888,NOTGRADIENTCOLOR,TercihSil);
	ASendText(20,130-a1,TercihAnaMenu[EeKayit.Dil][1],2,0x888888,NOTGRADIENTCOLOR,TercihSil);
	ASendText(20,155-a1,TercihAnaMenu[EeKayit.Dil][2],2,0x888888,NOTGRADIENTCOLOR,TercihSil);
	ASendText(20,180-a1,TercihAnaMenu[EeKayit.Dil][3],2,0x888888,NOTGRADIENTCOLOR,TercihSil);
	
	ASendText(20,(105 + (25*TercihSekme))-a1,TercihAnaMenu[EeKayit.Dil][TercihSekme],2,0xffffff,NOTGRADIENTCOLOR,TercihSil);
//	ASendText(5,3,UstKelime[11][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	
	BigOutVar(415,183,0,ScrollDownOk,0,0,0x888888,TercihSil);
	BigOutVar(415,67,0,ScrollUpOk,0,0,0x888888,TercihSil);
	BigOutVar(415,125,0,OrtaNokta,0,0,0x888888,TercihSil);
}

void FonkTercihAltMenu(unsigned int TercihAnaSekme,unsigned int TercihAltSekme,unsigned int PopUp,unsigned int TercihAltSil)
{
	static int a2,z3,z4,ExPopUp=0,ExTercihAltSekme=0;
	int Limit[5] = {5,2,9,2,2};
	
	Menu.Sekme.All = DefTercihAltMenu;
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183,0,ScrollDownOk,0,0,0xffffff,TercihAltSil);
	else
		BigOutVar(415,183,0,ScrollDownOk,0,0,0x888888,TercihAltSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67,0,ScrollUpOk,0,0,0xffffff,TercihAltSil);
	else
		BigOutVar(415,67,0,ScrollUpOk,0,0,0x888888,TercihAltSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125,0,OrtaNokta,0,0,0xffffff,TercihAltSil);
	else
		BigOutVar(415,125,0,OrtaNokta,0,0,0x888888,TercihAltSil);
	
//	ASendText(5,3,UstKelime[12+TercihAnaSekme][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	//Pop up men� ��kmam�� durumda
	if( PopUp == 0 )
	{	
		//AltMen�n�n i�erikleri yaz�lacak
		switch( TercihAnaSekme )
		{
			//Ekran Tercihleri
			case 0:
				Menu.TercihAltUstLimit = 5;
				Menu.TercihAltAltLimit = 0;
				
				a2 = 0;
				//Dil
				TextBufferLong[0] = 0x664400;
				for(z3 = 0;z3 < 7;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[0][EeKayit.Dil]+z3);				
				ASendText(20,105-a2,EkranTercih[0][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Buton Sesi
				for(z3 = 0;z3 < 6;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[1+EeKayit.Konfig.Bit.ButonTik][EeKayit.Dil]+z3);
				ASendText(20,125-a2,EkranTercih[1][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Ayd�nl�k
				BufferedText(EeKayit.LcdBacklight,0,0,0x664400);
				ASendText(20,145-a2,EkranTercih[2][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Bekleme
				if( EeKayit.AcikSure == 0 )
					ASendText(20,165-a2,EkranTercih[5][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);	
				else
				{
					BufferedText(EeKayit.AcikSure,0,0,0x664400);
					ASendText(20,165-a2,EkranTercih[3][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);	
				}	
				//Karartma
				if( EeKayit.YarimAydinlikSure == 0 )
					ASendText(20,185-a2,EkranTercih[6][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				else
				{
					BufferedText(EeKayit.YarimAydinlikSure,0,0,0x664400);
					ASendText(20,185-a2,EkranTercih[4][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);	
				}	
				ASendText(20,205-a2,EkranTercih[7][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				TextBufferLong[0] = 0xffbb00;
				switch( TercihAltSekme )
				{
					case 0:
						for(z3 = 0;z3 < 7;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[TercihAltSekme][EeKayit.Dil]+z3);
						ASendText(20,(105 + (20*TercihAltSekme))-a2,EkranTercih[TercihAltSekme][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 1:
						for(z3 = 0;z3 < 6;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[1+EeKayit.Konfig.Bit.ButonTik][EeKayit.Dil]+z3);
						ASendText(20,(105 + (20*TercihAltSekme))-a2,EkranTercih[TercihAltSekme][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 2:
						BufferedText(EeKayit.LcdBacklight,0,0,0xffbb00);
						ASendText(20,(105 + (20*TercihAltSekme))-a2,EkranTercih[TercihAltSekme][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 3:
						if( EeKayit.AcikSure == 0 )
							ASendText(20,165-a2,EkranTercih[5][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);	
						else
						{
							BufferedText(EeKayit.AcikSure,0,0,0xffbb00);
							ASendText(20,165-a2,EkranTercih[3][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);	
						}	
					break;
					case 4:
						if( EeKayit.YarimAydinlikSure == 0 )
							ASendText(20,185-a2,EkranTercih[6][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
						else
						{
							BufferedText(EeKayit.YarimAydinlikSure,0,0,0xffbb00);
							ASendText(20,185-a2,EkranTercih[4][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);	
						}	
					break;
					case 5:
						ASendText(20,205-a2,EkranTercih[7][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					default:
					break;
				}	
			break;
			//Haberle�me Tercihleri
			case 1:
				Menu.TercihAltUstLimit = 8;
				Menu.TercihAltAltLimit = 0;
				
				if( TercihAltSekme < 5 )
				{
					a2 = 0;
					//Remote Control
					TextBufferLong[0] = 0x664400;
					for(z3 = 0;z3 < 6;z3++)								
						TextBuffer[z3] = *(EkranTercihSigns[1+EeKayit.Konfig.Bit.UzakErisim][EeKayit.Dil]+z3);				
					ASendText(20,105-a2,EkranTercih[8][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//COM2
					for(z3 = 0;z3 < 9;z3++)								
						TextBuffer[z3] = *(EkranTercihSigns[12+EeKayit.Konfig.Bit.Comm2Secim][EeKayit.Dil]+z3);
					ASendText(20,125-a2,EkranTercih[9][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//SNMP
					for(z3 = 0;z3 < 8;z3++)								
						TextBuffer[z3] = *(EkranTercihSigns[14+EeKayit.Konfig.Bit.SNMP_OnOff][EeKayit.Dil]+z3);
					ASendText(20,145-a2,EkranTercih[10][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//REPO
					for(z3 = 0;z3 < 8;z3++)
						TextBuffer[z3] = *(EkranTercihSigns[1+EeKayit.REPO_OnOff][EeKayit.Dil]+z3);					//12.03.2014  repo adresi
					ASendText(20,165-a2,EkranTercih[11][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//R�le Alarm Atamas�
					ASendText(20,185-a2,EkranTercih[32][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				}
				else if( TercihAltSekme > 4 )
				{
					//Genin
					TextBufferLong[0] = 0x664400;
					for(z3 = 0;z3 < 7;z3++)							
						TextBuffer[z3] = *(EkranTercihSigns[32+EeKayit.GENIN_NoNc][EeKayit.Dil]+z3);				
					ASendText(20,105-a2,EkranTercih[34][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//Repo
					for(z3 = 0;z3 < 9;z3++)								
						TextBuffer[z3] = *(EkranTercihSigns[32+EeKayit.EPO_NoNc][EeKayit.Dil]+z3);
					ASendText(20,125-a2,EkranTercih[35][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//Relay contacts
					for(z3 = 0;z3 < 8;z3++)								
						TextBuffer[z3] = *(EkranTercihSigns[34+EeKayit.Role_NoNc][EeKayit.Dil]+z3);
					ASendText(20,145-a2,EkranTercih[36][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
					//Enter - Exit
					ASendText(20,165-a2,EkranTercih[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
							
					ASendText(20,185-a2,"                              ",2,0xffffff,NOTGRADIENTCOLOR,1);	
				}
				TextBufferLong[0] = 0xffbb00;
				switch( TercihAltSekme )
				{
					case 0:
						for(z3 = 0;z3 < 6;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[1+EeKayit.Konfig.Bit.UzakErisim][EeKayit.Dil]+z3);				
						ASendText(20,105-a2,EkranTercih[8][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 1:
						for(z3 = 0;z3 < 9;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[12+EeKayit.Konfig.Bit.Comm2Secim][EeKayit.Dil]+z3);
						ASendText(20,125-a2,EkranTercih[9][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 2:
						for(z3 = 0;z3 < 8;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[14+EeKayit.Konfig.Bit.SNMP_OnOff][EeKayit.Dil]+z3);
						ASendText(20,145-a2,EkranTercih[10][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 3:
						for(z3 = 0;z3 < 8;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[1+EeKayit.REPO_OnOff][EeKayit.Dil]+z3);								//12.03.2014  repo adresi
						ASendText(20,165-a2,EkranTercih[11][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 4:
						ASendText(20,185-a2,EkranTercih[32][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 5:
						for(z3 = 0;z3 < 7;z3++)							
							TextBuffer[z3] = *(EkranTercihSigns[32+EeKayit.GENIN_NoNc][EeKayit.Dil]+z3);				
						ASendText(20,105-a2,EkranTercih[34][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 6:
						for(z3 = 0;z3 < 9;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[32+EeKayit.EPO_NoNc][EeKayit.Dil]+z3);
						ASendText(20,125-a2,EkranTercih[35][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 7:
						for(z3 = 0;z3 < 8;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[34+EeKayit.Role_NoNc][EeKayit.Dil]+z3);
						ASendText(20,145-a2,EkranTercih[36][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 8:
						ASendText(20,165-a2,EkranTercih[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					default:
					break;
				}	
			break;
			//Alarm Tercihleri
			case 2:					
				Menu.TercihAltUstLimit = 4;
				Menu.TercihAltAltLimit = 0;
				
				a2 = 0;
				//Uyar� Aral���
				TextBufferLong[0] = 0x664400;
				for(z3 = 0;z3 < 5;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[11 + EeKayit.UyariSesAraligi][EeKayit.Dil]+z3);			
				ASendText(20,105-a2,EkranTercih[25][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Uyar� Kay�t
				for(z3 = 0;z3 < 6;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[1+ EeKayit.Konfig2.Bit.UyariLog][EeKayit.Dil]+z3);
				ASendText(20,125-a2,EkranTercih[26][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Durum Kay�t
				for(z3 = 0;z3 < 6;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[1+ EeKayit.Konfig2.Bit.DurumLog][EeKayit.Dil]+z3);
				ASendText(20,145-a2,EkranTercih[27][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Elg Basla
				for(z3 = 0;z3 < 9;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[22+ Can.FromInv.GolgeKonfigInv.Bit.Alf][EeKayit.Dil]+z3);
				ASendText(20,165-a2,EkranTercih[28][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Enter - Exit
				ASendText(20,185-a2,EkranTercih[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				
				TextBufferLong[0] = 0xffbb00;
				switch( TercihAltSekme )
				{
					case 0:
						for(z3 = 0;z3 < 5;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[11 + EeKayit.UyariSesAraligi][EeKayit.Dil]+z3);	
						ASendText(20,105-a2,EkranTercih[25][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 1:
						for(z3 = 0;z3 < 6;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[1+ EeKayit.Konfig2.Bit.UyariLog][EeKayit.Dil]+z3);
						ASendText(20,125-a2,EkranTercih[26][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 2:
						for(z3 = 0;z3 < 6;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[1+ EeKayit.Konfig2.Bit.DurumLog][EeKayit.Dil]+z3);
						ASendText(20,145-a2,EkranTercih[27][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 3:
						for(z3 = 0;z3 < 9;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[22+ Can.FromInv.GolgeKonfigInv.Bit.Alf][EeKayit.Dil]+z3);
						ASendText(20,165-a2,EkranTercih[28][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 4:
						ASendText(20,185-a2,EkranTercih[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					default:
					break;
				}	
			break;
			//Bypass Tercihleri
			case 3:				
				Menu.TercihAltUstLimit = 4;
				Menu.TercihAltAltLimit = 0;
				
				a2 = 0;
				//VAT Transfer
				TextBufferLong[0] = 0x664400;
				for(z3 = 0;z3 < 6;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[1+Can.FromInv.GolgeKonfigInv.Bit.Vat][EeKayit.Dil]+z3);				
				ASendText(20,95-a2,EkranTercih[29][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Jen. Bypass
				for(z3 = 0;z3 < 9;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[24+Can.FromInv.GolgeKonfigInv.Bit.JenBypass][EeKayit.Dil]+z3);
				ASendText(20,115-a2,EkranTercih[30][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				//Jen. Senkron
				for(z3 = 0;z3 < 4;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[26+Can.FromInv.GolgeKonfigInv.Bit.JenSenkron][EeKayit.Dil]+z3);
				ASendText(20,135-a2,EkranTercih[31][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				
				//26.09.12 Mod ayar� eklentisi
				for(z3 = 0;z3 < 8;z3++)								
					TextBuffer[z3] = *(EkranTercihSigns[28 + Can.FromInv.GolgeCalismaModu ][EeKayit.Dil]+z3);
				ASendText(20,155-a2,EkranTercih[33][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				
				//Enter - Exit
				ASendText(20,175-a2,EkranTercih[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,TercihAltSil);
				
				//Forbidden yaz�s�n� silmek i�in
				ASendText(15,205-a2,GenelTablo[19][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,1);
				
				TextBufferLong[0] = 0xffbb00;
				switch( TercihAltSekme )
				{
					case 0:
						for(z3 = 0;z3 < 6;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[1+Can.FromInv.GolgeKonfigInv.Bit.Vat][EeKayit.Dil]+z3);				
						ASendText(20,95-a2,EkranTercih[29][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 1:
						for(z3 = 0;z3 < 9;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[24+Can.FromInv.GolgeKonfigInv.Bit.JenBypass][EeKayit.Dil]+z3);
						ASendText(20,115-a2,EkranTercih[30][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 2:
						for(z3 = 0;z3 < 4;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[26+Can.FromInv.GolgeKonfigInv.Bit.JenSenkron][EeKayit.Dil]+z3);
						ASendText(20,135-a2,EkranTercih[31][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 3:
						//26.09.12 Mod ayar� eklentisi
						for(z3 = 0;z3 < 8;z3++)								
							TextBuffer[z3] = *(EkranTercihSigns[28 + Can.FromInv.GolgeCalismaModu ][EeKayit.Dil]+z3);
						ASendText(20,155-a2,EkranTercih[33][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					case 4:
						ASendText(20,175-a2,EkranTercih[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,TercihAltSil);
					break;
					default:
					break;
				}	
			break;
			default:
			break;
		}
	}
	//Pop Up men�s� ��k�nca
	else
	{			
		switch( TercihAnaSekme )
		{
			//Ekran Tercihleri
			case 0:					
					switch( TercihAltSekme )
					{
						//Language
						case 0:
							Menu.TercihPopUpAltLimit = 1;
						//	Menu.TercihPopUpUstLimit = 5;		//5 dil
						//	Menu.TercihPopUpUstLimit = 2;		//2 dil
							Menu.TercihPopUpUstLimit = 3;		//2 dil			//12.11.2013 tarihind �talyanca ekleniyor.
							Menu.TercihPopUpUstLimit = 5;		//5 dil			//18.02.2014 tarihind ispanyolca ve leh�e
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16),EkranTercihSigns[0][PopUp-1],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < (Menu.TercihPopUpUstLimit-1);z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16),EkranTercihSigns[0][z4],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;							

							Elipse(300,380,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Buton Ses ayar�
						case 1:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+1][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Backlight seviyesi
						case 2:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 4;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,329,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,329,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+2][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 3;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+3][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,330,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,330,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Bekleme s�resi
						case 3:
						//Karartma s�resi
						case 4:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 5;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,369,( 121+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit)+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16),( 137+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit)+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16),0xffffff,1,1,1);
							Dikdortgen(302,369,( 121+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit)+((PopUp-1)*16),( 137+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit)+((PopUp-1)*16),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,( 126+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit)+((PopUp-1)*16),EkranTercihSigns[PopUp+6][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 4;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,( 126+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit)+((z4)*16),EkranTercihSigns[z4+7][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,370,(119+(TercihAltSekme*20)-16*Menu.TercihPopUpUstLimit),121+(TercihAltSekme*20),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,370,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						default:
						break;
					}
			break;
			//Haberle�me Tercihleri
			case 1:		
					switch( TercihAltSekme )
					{
						//Remote Control
						case 0:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+1][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//COM2
						case 1:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,384,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,384,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+11][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+12][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,385,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//SNMP
						case 2:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,374,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,374,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+13][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+14][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,375,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//REPO
						case 3:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+1][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Genin logic 0-1
						case 5:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+((TercihAltSekme-4)*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+((TercihAltSekme-4)*20),0xffffff,1,1,1);
							Dikdortgen(302,379,124+((PopUp-1)*16)+((TercihAltSekme-4)*20),140+((PopUp-1)*16)+((TercihAltSekme-4)*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+((TercihAltSekme-4)*20),EkranTercihSigns[PopUp+31][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+((TercihAltSekme-4)*20),EkranTercihSigns[z4+32][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,122+((TercihAltSekme-4)*20),( 122+((TercihAltSekme-4)*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+((TercihAltSekme-4)*20),122+((TercihAltSekme-4)*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Repo logic 0-1
						case 6:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,384,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+((TercihAltSekme-4)*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+((TercihAltSekme-4)*20),0xffffff,1,1,1);
							Dikdortgen(302,384,124+((PopUp-1)*16)+((TercihAltSekme-4)*20),140+((PopUp-1)*16)+((TercihAltSekme-4)*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+((TercihAltSekme-4)*20),EkranTercihSigns[PopUp+31][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+((TercihAltSekme-4)*20),EkranTercihSigns[z4+32][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,385,122+((TercihAltSekme-4)*20),( 122+((TercihAltSekme-4)*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+((TercihAltSekme-4)*20),122+((TercihAltSekme-4)*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Relay NO-NC
						case 7:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,374,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+((TercihAltSekme-4)*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+((TercihAltSekme-4)*20),0xffffff,1,1,1);
							Dikdortgen(302,374,124+((PopUp-1)*16)+((TercihAltSekme-4)*20),140+((PopUp-1)*16)+((TercihAltSekme-4)*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,129+((PopUp-1)*16)+((TercihAltSekme-4)*20),EkranTercihSigns[PopUp+33][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,129+((z4)*16)+((TercihAltSekme-4)*20),EkranTercihSigns[z4+34][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,375,122+((TercihAltSekme-4)*20),( 122+((TercihAltSekme-4)*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+((TercihAltSekme-4)*20),122+((TercihAltSekme-4)*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						default:
						break;
					}
			break;
			//Alarm Tercihleri
			case 2:		
					switch( TercihAltSekme )
					{
						//Uyar� Aral���
						case 0:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 6;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(322,389,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(322,389,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(342,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+15][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 5;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(342,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+16][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(320,390,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Uyar� Kay�t
						case 1:
						//Durum Kay�t
						case 2:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(322,399,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(322,399,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(332,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(332,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+1][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(320,400,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						//Elg Basla
						case 3:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(322,406,124+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),140+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(322,406,124+((PopUp-1)*16)+(TercihAltSekme*20),140+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(332,129+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+21][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(332,129+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+22][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(320,407,122+(TercihAltSekme*20),( 122+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,122+(TercihAltSekme*20),122+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						default:
						break;
					}
			break;
			//Bypass Tercihleri
			case 3:		
					switch( TercihAltSekme )
					{
						case 0:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,114+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),130+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,114+((PopUp-1)*16)+(TercihAltSekme*20),130+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,119+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,119+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+1][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,112+(TercihAltSekme*20),( 112+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,112+(TercihAltSekme*20),112+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						case 1:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,114+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),130+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,114+((PopUp-1)*16)+(TercihAltSekme*20),130+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,119+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+23][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,119+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+24][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,112+(TercihAltSekme*20),( 112+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,112+(TercihAltSekme*20),112+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						case 2:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 2;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,114+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),130+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,114+((PopUp-1)*16)+(TercihAltSekme*20),130+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,119+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+25][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 1;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,119+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+26][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,112+(TercihAltSekme*20),( 112+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,112+(TercihAltSekme*20),112+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						case 3:
							Menu.TercihPopUpAltLimit = 1;
							Menu.TercihPopUpUstLimit = 4;
							
							//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
							Dikdortgen(302,379,114+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),130+(((ExPopUp-1)%Menu.TercihPopUpUstLimit)*16)+(TercihAltSekme*20),0xffffff,1,1,1);
							Dikdortgen(302,379,114+((PopUp-1)*16)+(TercihAltSekme*20),130+((PopUp-1)*16)+(TercihAltSekme*20),0xffffff,1,1,TercihAltSil);
							//GRADIENT = NotGradient;	
							GRADIENT = TercihAltSil;	//Yukar�dakinle ayn� yazarken
							ASendText(312,119+((PopUp-1)*16)+(TercihAltSekme*20),EkranTercihSigns[PopUp+27][EeKayit.Dil],1,0x000000,0xffffff,TercihAltSil);
							GRADIENT = Gradient;						
							for(z3 = 0;z3 < 3;z3++)	
							{
								z4 = (PopUp + z3)%Menu.TercihPopUpUstLimit;
								ASendText(312,119+((z4)*16)+(TercihAltSekme*20),EkranTercihSigns[z4+28][EeKayit.Dil],1,0xee9900,0xffffff,TercihAltSil);
							}
							ExPopUp = PopUp;
							Elipse(300,380,112+(TercihAltSekme*20),( 112+(TercihAltSekme*20)+16*Menu.TercihPopUpUstLimit),0xff0000,0,TercihAltSil);			
							LINEREPEAT = 1;
							Line(32,350,112+(TercihAltSekme*20),112+(TercihAltSekme*20),0xff0000,TercihAltSil);	
							LINEREPEAT = 2;
						break;
						default:
						break;
					}
			break;
			default:
			break;
		}
	}	
	BigOutVar(415,183,0,ScrollDownOk,0,0,0x888888,TercihAltSil);
	BigOutVar(415,67,0,ScrollUpOk,0,0,0x888888,TercihAltSil);
	BigOutVar(415,125,0,OrtaNokta,0,0,0x888888,TercihAltSil);
}
//2.sayfadakiler-------------------------------------------------------------------------------------
void FonkEmirAnaMenu(unsigned int EmirSekme,unsigned int EmirSil)
{
	static unsigned int a1;	
	static unsigned int ExEmirSekme = 1;
	static unsigned int OutputPage = 1,ExOutputPage = 1;
	unsigned int *MenuAdresPtr;
	
	Menu.EmirAltLimit = 0;
	Menu.EmirUstLimit = 5;
//	Menu.EmirAra1Limit = 0;
//	Menu.EmirAra2Limit = 3;
	Menu.Sekme.All = DefAnaMenu;
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,EmirSil);
	else
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,EmirSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,EmirSil);
	else
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,EmirSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,EmirSil);
	else
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,EmirSil);
	
	
//	if( EmirSekme < Menu.TercihAra1Limit )
//		a1 = 0;
//	if( EmirSekme > Menu.TercihAra2Limit )
//		a1 = 25;

//	if( a1 == 25 )
//		ASendText(20,205,TercihAnaMenu[EeKayit.Dil][6],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
//	else
//		ASendText(20,80,TercihAnaMenu[EeKayit.Dil][0],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	 
	Menu.EnterBypOrInv = Alarm.Word.Inv2.Bit.CikisBypassta;
	Menu.EnterStopBoost = Alarm.Word.Pfc2.Bit.BoostSarj;
	Menu.EnterBattTest = Alarm.Word.Pfc2.Bit.AkuTesti;
	
	a1 = 0;
	MenuAdresPtr = EmirMenuOrg[EmirSekme][1];
		
		TextBufferLong[0] = 0x664400;
	TextBuffer[0] = Can.FromPfc.RecDCBus.Pos;
	ASendText(20,90-a1+272,EmirMenu[0+Menu.EnterBypOrInv][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	ASendText(20,110-a1+272,EmirMenu[2+Menu.EnterStopBoost][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	//Yaz�lar�n hepsini gri yazar.
	if( EmirSekme == 2 )	
		TextBufferLong[0] = 0xffbb00;
	else	
		TextBufferLong[0] = 0x664400;
		
	TextBuffer[0] = Can.FromPfc.RecDCBus.Pos;
	ASendText(20,130-a1+272,EmirMenu[4+Menu.EnterBattTest][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	ASendText(20,150-a1+272,EmirMenu[6+Menu.RoleSimulasyonu][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	ASendText(20,170-a1+272,EmirMenu[8+Menu.ModemInitEt][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	ASendText(20,190-a1+272,EmirMenu[10+Menu.MaskeAlarmSesAcik][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,EmirSil);
	
//	ASendText(20,(90 + (20*EmirSekme)+272)-a1,EmirMenu[EmirSekme][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,EmirSil);
	ASendText(20,(90 + (20*EmirSekme)+272)-a1,EmirMenu[EmirMenuOrg[EmirSekme][0] + *MenuAdresPtr][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,EmirSil);
//	ASendText(5,3+272,UstKelime[16][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
		
//	BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,EmirSil);
//	BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,EmirSil);
//	BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,EmirSil);
//	for(yy=0;yy<3;yy++)
//	{
		OptimizasyonFonk4(EmirSil);
//	}
}

void FonkRoleAlarmAtama( int LokalRoleSec, int LokalAlrSec, int LokalSil )
{
	int g1,g2;
	int Sayfa2;
	unsigned long RL_Renk[13],ALR_Renk[13];
	unsigned int AlrKarakterSayisi[13];
		
	Menu.AlrRoleAltLimit = 0;
	Menu.AlrRoleUstLimit = 12;
	
	Menu.Sekme.All = DefRoleAlarmAtama;
	
					
	for(g1 = 0;g1 < 12;g1++)
	{
		Menu.RoleAtamaDeger[g1] = Menu.OldRoleAtamaDeger[g1];
		//Renk i�lemleri
		RL_Renk[g1] = 0x888888;
		ALR_Renk[g1] = 0x664400;
		
		//A00 INV HATASI = @ gibi yazan yaz�lar� A00 INV HATASI diye yazmak i�in  
		AlrKarakterSayisi[g1] = 20;
		if( Menu.RoleAtamaDeger[g1] == 15 )
			AlrKarakterSayisi[g1] = 14;
		if( Menu.RoleAtamaDeger[g1] == 47 )
			AlrKarakterSayisi[g1] = 14;
	} 
	RL_Renk[12] = 0x888888;
	ALR_Renk[12] = 0x664400;
	if( LokalRoleSec != 12 )
	{
		RL_Renk[LokalRoleSec] = 0xffffff;
		ALR_Renk[LokalRoleSec] = 0xff0000;
	}
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183,0,ScrollDownOk,0,0,0xffffff,LokalSil);
	else
		BigOutVar(415,183,0,ScrollDownOk,0,0,0x888888,LokalSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67,0,ScrollUpOk,0,0,0xffffff,LokalSil);
	else
		BigOutVar(415,67,0,ScrollUpOk,0,0,0x888888,LokalSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125,0,OrtaNokta,0,0,0xffffff,LokalSil);
	else
		BigOutVar(415,125,0,OrtaNokta,0,0,0x888888,LokalSil);
		
		
		
		
		
		
		
	Menu.EnterExit = 0;
	if( LokalRoleSec < 6 )	
	{
		Sayfa2 = 0;
		ASendText(20,200,EkranTercih[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,1);
	}
	else
	{
		Sayfa2 = 6;
		ASendText(20,200,EkranTercih[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,LokalSil);
		if( LokalRoleSec == 12 )
		{
			Menu.EnterExit = 1;
			ASendText(20,200,EkranTercih[12][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,LokalSil);
		}
	}	
	
		
	for(g2 = 0;g2 < 6;g2++)
	{
		TextBufferLong[0] = ALR_Renk[g2+Sayfa2];
		for(g1 = 0;g1 < AlrKarakterSayisi[g2+Sayfa2];g1++)								
			TextBuffer[g1] = *(Alarms[EeKayit.Role[g2+Sayfa2]][EeKayit.Dil]+g1);				
		ASendText(20,80+(g2*20),EkranTercih[13+g2+Sayfa2][0],2,RL_Renk[g2+Sayfa2],NOTGRADIENTCOLOR,LokalSil);
	}
		
	if( LokalRoleSec != 12 )
	{
		ASendText(382,80+((LokalRoleSec-Sayfa2)*20),">",2,0xffffff,NOTGRADIENTCOLOR,LokalSil);
		ASendText(111,80+((LokalRoleSec-Sayfa2)*20),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalSil);
	}	
		
		
		
		
	
		
	
	ASendText(15,222,GenelTablo[16][EeKayit.Dil],1,0xffff00,NOTGRADIENTCOLOR,LokalSil);
	
	BigOutVar(415,183,0,ScrollDownOk,0,0,0x888888,LokalSil);
	BigOutVar(415,67,0,ScrollUpOk,0,0,0x888888,LokalSil);
	BigOutVar(415,125,0,OrtaNokta,0,0,0x888888,LokalSil);	
}






void FonkEmirAltMenu(unsigned int EmirAnaSekme,unsigned int EmirAltSekme,unsigned int EmirPopUp,unsigned int EmirAltSil)
{
	static int a2,z3,z4,EmirExPopUp=0,ExEmirAltSekme=0;
	int Limit[5] = {5,2,9,2,2};
	
	Menu.Sekme.All = DefEmirAltMenu;
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,EmirAltSil);
	else
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,EmirAltSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,EmirAltSil);
	else
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,EmirAltSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,EmirAltSil);
	else
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,EmirAltSil);
	
	//Pop up men� ��kmam�� durumda
	if( EmirPopUp == 0 )
	{	
		//AltMen�n�n i�erikleri yaz�lacak
		switch( EmirAnaSekme )
		{
			default:
			break;
		}

	}
	//Pop Up men�s� ��k�nca
	else
	{			
		switch( EmirAnaSekme )
		{
			//Alarm Ses A��k - Kapal�
			case 5:				
				Menu.EmirPopUpAltLimit = 1;
				Menu.EmirPopUpUstLimit = 2;
				
				//PopUp pencere ��k�yor ve men� elemanlar� ��k�yor.				
				Dikdortgen(302,379,176+(((EmirExPopUp-1)%Menu.EmirPopUpUstLimit)*16)+(EmirAltSekme*20)+272,192+(((EmirExPopUp-1)%Menu.EmirPopUpUstLimit)*16)+(EmirAltSekme*20)+272,0xffffff,1,1,1);
				Dikdortgen(302,379,176+((EmirPopUp-1)*16)+(EmirAltSekme*20)+272,192+((EmirPopUp-1)*16)+(EmirAltSekme*20)+272,0xffffff,1,1,EmirAltSil);
				//GRADIENT = NotGradient;	
				GRADIENT = EmirAltSil;	//Yukar�dakinle ayn� yazarken
				ASendText(312,181+272+((EmirPopUp-1)*16)+(EmirAltSekme*20),EkranTercihSigns[EmirPopUp][EeKayit.Dil],1,0x000000,0xffffff,EmirAltSil);
				GRADIENT = Gradient;						
				for(z3 = 0;z3 < 1;z3++)	
				{
					z4 = (EmirPopUp + z3)%Menu.EmirPopUpUstLimit;
					ASendText(312,181+272+((z4)*16)+(EmirAltSekme*20),EkranTercihSigns[z4+1][EeKayit.Dil],1,0xee9900,0xffffff,EmirAltSil);
				}
				EmirExPopUp = EmirPopUp;
				Elipse(300,380,174+272+(EmirAltSekme*20),( 174+(EmirAltSekme*20)+16*Menu.EmirPopUpUstLimit)+272,0xff0000,0,EmirAltSil);			
				LINEREPEAT = 1;
				Line(32,350,207+272+(EmirAltSekme*20),194+272+(EmirAltSekme*20),0xff0000,EmirAltSil);	
				LINEREPEAT = 2;
				break;
			default:
			break;
		}
	}	
	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,EmirAltSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,EmirAltSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,EmirAltSil);
	OptimizasyonFonk4(EmirAltSil);
}
void FonkEmirRoleMenu(unsigned int RoleEmirAnaSekme,unsigned int RoleDurum,unsigned int EmirAltSil)
{
	static unsigned int Role_x[12],Role__x[12],Role_y[12],Yaricap[12],EskiRoleEmirAnaSekme;
	static unsigned int RoleHal[12] = {0,0,0,0,0,0,0,0,0,0,0,0};
	int Role_z;
	
	
	Menu.Sekme.All = DefEmirRoleMenu;	
	Menu.EnterExit = 0;
	
//	ASendText(5,3+272,UstKelime[17][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	//Kontak Yerleri
	//soldan ilk x; toplam geni�lik;�stten y pixel i   ; kontak �emberleri
	//1.s�tun
	Role_x[0] = 34; Role__x[0] = 67; Role_y[0] = 98+272; Yaricap[0] = 5;
	Role_x[1] = 34; Role__x[1] = 67; Role_y[1] = 155+272; Yaricap[1] = 5;
	Role_x[2] = 34; Role__x[2] = 67; Role_y[2] = 212+272; Yaricap[2] = 5;
	//2.s�tun
	Role_x[3] = 129; Role__x[3] = 67; Role_y[3] = 98+272; Yaricap[3] = 5;
	Role_x[4] = 129; Role__x[4] = 67; Role_y[4] = 155+272; Yaricap[4] = 5;	
	Role_x[5] = 129; Role__x[5] = 67; Role_y[5] = 212+272; Yaricap[5] = 5;
	//3.s�tun
	Role_x[6] = 224; Role__x[6] = 67; Role_y[6] = 98+272; Yaricap[6] = 5;
	Role_x[7] = 224; Role__x[7] = 67; Role_y[7] = 155+272; Yaricap[7] = 5;
	Role_x[8] = 224; Role__x[8] = 67; Role_y[8] = 212+272; Yaricap[8] = 5;
	//4.s�tun
	Role_x[9] = 319; Role__x[9] = 67; Role_y[9] = 98+272; Yaricap[9] = 5;
	Role_x[10] = 319; Role__x[10] = 67; Role_y[10] = 155+272; Yaricap[10] = 5;
	Role_x[11] = 319; Role__x[11] = 67; Role_y[11] = 212+272; Yaricap[11] = 5;


	//Role 1 den role 2 ye ya da di�erlerine ge�ip enter a bas�nca toggle 0 lans�n diye.
	if( RoleEmirAnaSekme != EskiRoleEmirAnaSekme )
		RoleDurum = RoleHal[RoleEmirAnaSekme-1];					
	Genel.RoleSimulasyonToggle = RoleDurum;							
	EskiRoleEmirAnaSekme = RoleEmirAnaSekme;

	RoleHal[RoleEmirAnaSekme-1] = RoleDurum;
	for(Role_z=0;Role_z<12;Role_z++)
	{
		if( RoleHal[Role_z] == 0 )
		{
			Line((Role_x[Role_z]+15+Yaricap[Role_z]+1),(Role_x[Role_z]+15+Yaricap[Role_z]+1+25),(Role_y[Role_z]-Yaricap[Role_z]-1),(Role_y[Role_z]-Yaricap[Role_z]-1),0x999999,1);
			CaprazHat((Role_x[Role_z]+15+Yaricap[Role_z]+1),(Role_x[Role_z]+15+Yaricap[Role_z]+1+17),(Role_y[Role_z]-Yaricap[Role_z]),(Role_y[Role_z]-Yaricap[Role_z]-17),0x999999,EmirAltSil);
		}
		if( RoleHal[Role_z] == 1 )	
		{
			CaprazHat((Role_x[Role_z]+15+Yaricap[Role_z]+1),(Role_x[Role_z]+15+Yaricap[Role_z]+1+17),(Role_y[Role_z]-Yaricap[Role_z]),(Role_y[Role_z]-Yaricap[Role_z]-17),0x999999,1);
			Line((Role_x[Role_z]+15+Yaricap[Role_z]+1),(Role_x[Role_z]+15+Yaricap[Role_z]+1+25),(Role_y[Role_z]-Yaricap[Role_z]-1),(Role_y[Role_z]-Yaricap[Role_z]-1),0x999999,EmirAltSil);
		}
		Line(Role_x[Role_z],Role_x[Role_z]+15,Role_y[Role_z],Role_y[Role_z],0x999999,EmirAltSil);
		Circle((Role_x[Role_z]+15+Yaricap[Role_z]+1),Role_y[Role_z],Yaricap[Role_z],0,5,0x999999,EmirAltSil);
		Circle((Role_x[Role_z]+15+Yaricap[Role_z]+1+25),Role_y[Role_z],Yaricap[Role_z],0,5,0x999999,EmirAltSil);
		Line((Role_x[Role_z]+15+Yaricap[Role_z]+1+25+Yaricap[0]+1),(Role_x[Role_z]+Role__x[Role_z]),Role_y[Role_z],Role_y[Role_z],0x999999,EmirAltSil);
		
		TextBufferLong[0] = 0x550000;
		TextBuffer[0] = Role_z+1;
		ASendText(Role_x[Role_z]-13,Role_y[Role_z]-10,"RL]",1,0x999999,NOTGRADIENTCOLOR,EmirAltSil);
	
	}

	if( RoleEmirAnaSekme == 0 )
	{
		Menu.EnterExit = 1;
		Elipse(404,454,80+272,222+272,0xffffff,5,EmirAltSil);
//		ASendText(425,272+100,"E",2,0xff0000,NOTGRADIENTCOLOR,EmirAltSil);
//		ASendText(425,272+130,"X",2,0xff0000,NOTGRADIENTCOLOR,EmirAltSil);
//		ASendText(425,272+160,"I",2,0xff0000,NOTGRADIENTCOLOR,EmirAltSil);
//		ASendText(425,272+190,"T",2,0xff0000,NOTGRADIENTCOLOR,EmirAltSil);
		OptimizasyonFonk3(0xff0000,EmirAltSil);
	}
	else
	{
		Elipse(404,454,80+272,222+272,0x999999,5,EmirAltSil);
//		ASendText(425,272+100,"E",2,0x550000,NOTGRADIENTCOLOR,EmirAltSil);
//		ASendText(425,272+130,"X",2,0x550000,NOTGRADIENTCOLOR,EmirAltSil);
//		ASendText(425,272+160,"I",2,0x550000,NOTGRADIENTCOLOR,EmirAltSil);
//		ASendText(425,272+190,"T",2,0x550000,NOTGRADIENTCOLOR,EmirAltSil);
		OptimizasyonFonk3(0x550000,EmirAltSil);
		
		if( RoleHal[RoleEmirAnaSekme-1] == 0 )
		{
			Line((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1),(Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1+25),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]-1),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]-1),0xffffff,1);
			CaprazHat((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1),(Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1+17),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]-17),0xffffff,EmirAltSil);
		}
		if( RoleHal[RoleEmirAnaSekme-1] == 1 )	
		{
			CaprazHat((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1),(Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1+17),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]-17),0xffffff,1);
			Line((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1),(Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1+25),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]-1),(Role_y[RoleEmirAnaSekme-1]-Yaricap[RoleEmirAnaSekme-1]-1),0xffffff,EmirAltSil);
		}
		
		RoleIslem((RoleEmirAnaSekme-1),RoleHal[RoleEmirAnaSekme-1]);
		
		Line(Role_x[RoleEmirAnaSekme-1],Role_x[RoleEmirAnaSekme-1]+15,Role_y[RoleEmirAnaSekme-1],Role_y[RoleEmirAnaSekme-1],0xffffff,EmirAltSil);
		Circle((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1),Role_y[RoleEmirAnaSekme-1],Yaricap[RoleEmirAnaSekme-1],0,5,0xffffff,EmirAltSil);
		Circle((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1+25),Role_y[RoleEmirAnaSekme-1],Yaricap[RoleEmirAnaSekme-1],0,5,0xffffff,EmirAltSil);
		Line((Role_x[RoleEmirAnaSekme-1]+15+Yaricap[RoleEmirAnaSekme-1]+1+25+Yaricap[0]+1),(Role_x[RoleEmirAnaSekme-1]+Role__x[RoleEmirAnaSekme-1]),Role_y[RoleEmirAnaSekme-1],Role_y[RoleEmirAnaSekme-1],0xffffff,EmirAltSil);
		
		TextBufferLong[0] = 0xff0000;
		TextBuffer[0] = RoleEmirAnaSekme;
		ASendText(Role_x[RoleEmirAnaSekme-1]-13,Role_y[RoleEmirAnaSekme-1]-10,"RL]",1,0xffffff,NOTGRADIENTCOLOR,EmirAltSil);	
	
	}
	
/*	
	if( RoleDurum == 0 )
	{
		Line(41,66,272+92,272+92,0xffffff,1);
		CaprazHat(41,58,93+272,76+272,0xffffff,EmirAltSil);
	}
	if( RoleDurum == 1 )	
	{
		CaprazHat(41,58,93+272,76+272,0xffffff,1);
		Line(41,66,272+92,272+92,0xffffff,EmirAltSil);
	}
	
	RoleIslem((Menu.RoleSimulasyonu),RoleDurum);
	
	Line(20,35,272+98,272+98,0xffffff,EmirAltSil);
	Circle(41,272+98,5,0,5,0xffffff,EmirAltSil);
	Circle(66,272+98,5,0,5,0xffffff,EmirAltSil);
	Line(72,87,272+98,272+98,0xffffff,EmirAltSil);
	ASendText(15,272+88,"RL1",1,0xffffff,NOTGRADIENTCOLOR,EmirAltSil);
*/
}
void TimeMenu(unsigned int AyarButon,unsigned int AyarIci,unsigned int TimeClr)
{
	unsigned int Str1;
	static unsigned int AyarSekme = 1;
	static int IkiNoktaYanSon = 0;

	Str1 = 150;
	if( IkiNoktaYanSon == 0 )
		IkiNoktaYanSon = 1;
	else
		IkiNoktaYanSon = 0;
	if( TimeClr == 1 )
		IkiNoktaYanSon = 1;
	if( AyarIci == 1 )
		IkiNoktaYanSon = 0;
	
//	ASendText(5,3+272,UstKelime[18][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	//G�r�nt� ayarda de�il
	if(AyarButon == DefEnterButon)
	{
		if(AyarIci == 1)
			BigOutVar(65,(115+272),0,OrtaNokta,0,0,0xffffff,TimeClr);
		if(AyarIci == 0)
		{
			Date5.Sec = 0;
			YazRTC(&Date5);
			RtcToScreen(0);			//kay�t bittikten sonra saati g�ster
			RtcToScreen(1);			//kay�t bittikten sonra saati g�ster
			OkuRTC(&Date5);	
			BigOutVar(65,(115+272),0,OrtaNokta,0,0,0x888888,TimeClr);
		}
	}
	else
	{
		if( AyarIci == 0 )
		{
			OkuRTC(&Date5);
		}
	}
	DIGITAL = NotDigital;	

	BigOutVar(65,(70+272),0,YukariOk,0,0,0x888888,TimeClr);
	BigOutVar(65,(165+272),0,AsagiOk,0,0,0x888888,TimeClr);	
	BigOutVar(15,(115+272),0,SolOk,0,0,0x888888,TimeClr);	
	BigOutVar(115,(115+272),0,SagOk,0,0,0x888888,TimeClr);	
	BigOutVar(65,(115+272),0,OrtaNokta,0,0,0x888888,TimeClr);

	BigOutVar(Str1+50,(80+272),Date5.Hour,2,0,0,0xffffff,TimeClr);
	BigOutVar((Str1+130),(80+272),0,ikiNokta,0,0,0xffffff,IkiNoktaYanSon);	
	BigOutVar((Str1+165),(80+272),Date5.Min,2,0,0,0xffffff,TimeClr);
//	BigOutVar((Str1+190),(80+272),0,ikiNokta,0,0,0xffffff,TimeClr);	
//	BigOutVar((Str1+230),(80+272),sec,2,0,0,0xffffff,TimeClr);	

	BigOutVar(Str1,(160+272),Date5.Day,2,0,0,0xffffff,TimeClr);
	BigOutVar((Str1+80),(160+272),0,Nokta,0,0,0xffffff,TimeClr);	
	BigOutVar((Str1+115),(160+272),Date5.Month,2,0,0,0xffffff,TimeClr);
	BigOutVar((Str1+190),(160+272),0,Nokta,0,0,0xffffff,TimeClr);	
	BigOutVar((Str1+230),(160+272),Date5.Year,2,0,0,0xffffff,TimeClr);
	
	
	//Ok e bas�l�nca ayar yap�labilir.
	if( AyarIci == 1 )		
	{
		BigOutVar(65,(115+272),0,OrtaNokta,0,0,0xffffff,TimeClr);
		if(AyarButon == DefSolButon)
		{	
			AyarSekme--;
			if(AyarSekme < 1)
				AyarSekme = 5;
			BigOutVar(15,(115+272),0,SolOk,0,0,0xffffff,TimeClr);
		}
		if(AyarButon == DefSagButon)
		{	
			AyarSekme++;
			if(AyarSekme > 5)
				AyarSekme = 1;
			BigOutVar(115,(115+272),0,SagOk,0,0,0xffffff,TimeClr);
		}
		if( AyarButon == DefEnterButon )
		{
			AyarSekme = 1;
		}
		switch(AyarSekme)
		{
			case 1:
				if(AyarButon == DefYukariButon)
				{
					Date5.Hour++;
					if(Date5.Hour > 23)
						Date5.Hour = 0;
					BigOutVar(65,(70+272),0,YukariOk,0,0,0xffffff,TimeClr);
				}
				if(AyarButon == DefAsagiButon)
				{
					Date5.Hour--;
					if(Date5.Hour < 0)
						Date5.Hour = 23;
					BigOutVar(65,(165+272),0,AsagiOk,0,0,0xffffff,TimeClr);	
				}
				BigOutVar(Str1+50,(80+272),Date5.Hour,2,0,0,0xff0000,TimeClr);
			break;
			case 2:
				if(AyarButon == DefYukariButon)
				{
					Date5.Min++;
					if(Date5.Min > 59)
						Date5.Min = 0;
					BigOutVar(65,(70+272),0,YukariOk,0,0,0xffffff,TimeClr);
				}
				if(AyarButon == DefAsagiButon)
				{
					Date5.Min--;
					if(Date5.Min < 0)
						Date5.Min = 59;
					BigOutVar(65,(165+272),0,AsagiOk,0,0,0xffffff,TimeClr);	
				}
				BigOutVar((Str1+165),(80+272),Date5.Min,2,0,0,0xff0000,TimeClr);
			break;
			case 3:
				if(AyarButon == DefYukariButon)
				{
					Date5.Day++;
					if(Date5.Day > 31)
						Date5.Day = 1;
					BigOutVar(65,(70+272),0,YukariOk,0,0,0xffffff,TimeClr);
				}
				if(AyarButon == DefAsagiButon)
				{
					Date5.Day--;
					if(Date5.Day < 1)
						Date5.Day = 31;
					BigOutVar(65,(165+272),0,AsagiOk,0,0,0xffffff,TimeClr);	
				}
				BigOutVar(Str1,(160+272),Date5.Day,2,0,0,0xff0000,TimeClr);
			break;
			case 4:	
				if(AyarButon == DefYukariButon)
				{
					Date5.Month++;
					if(Date5.Month > 12)
						Date5.Month = 1;
					BigOutVar(65,(70+272),0,YukariOk,0,0,0xffffff,TimeClr);
				}
				if(AyarButon == DefAsagiButon)
				{
					Date5.Month--;
					if(Date5.Month < 1)
						Date5.Month = 12;
					BigOutVar(65,(165+272),0,AsagiOk,0,0,0xffffff,TimeClr);	
				}
				BigOutVar((Str1+115),(160+272),Date5.Month,2,0,0,0xff0000,TimeClr);
			break;
			case 5:
				if(AyarButon == DefYukariButon)
				{
					Date5.Year++;
					if(Date5.Year > 99)
						Date5.Year = 0;
					BigOutVar(65,(70+272),0,YukariOk,0,0,0xffffff,TimeClr);
				}
				if(AyarButon == DefAsagiButon)
				{
					Date5.Year--;
					if(Date5.Year < 0)
						Date5.Year = 99;
					BigOutVar(65,(165+272),0,AsagiOk,0,0,0xffffff,TimeClr);	
				}
				BigOutVar((Str1+230),(160+272),Date5.Year,2,0,0,0xff0000,TimeClr);
			break;
			default:
			break;
		}	
	}

	Wait(10000);
	BigOutVar(65,(70+272),0,YukariOk,0,0,0x888888,TimeClr);
	BigOutVar(65,(165+272),0,AsagiOk,0,0,0x888888,TimeClr);	
	BigOutVar(15,(115+272),0,SolOk,0,0,0x888888,TimeClr);	
	BigOutVar(115,(115+272),0,SagOk,0,0,0x888888,TimeClr);		
}

void FonkServisAnaMenu(unsigned int ServisSekme,unsigned int ServisSil)
{
	static unsigned int a2;	
	static unsigned int ExServisSekme = 1;
	unsigned int *MenuAdresPtr;
	
	Menu.ServisAltLimit = 0;
	Menu.ServisUstLimit = 6;
	Menu.Sekme.All = DefAnaMenu;
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,ServisSil);
	else
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,ServisSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,ServisSil);
	else
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,ServisSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,ServisSil);
	else
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,ServisSil);
	
//	ASendText(5,3+272,UstKelime[19][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	 	
	a2 = 0;
	MenuAdresPtr = ServisMenuOrg[ServisSekme][1];
		
	TextBufferLong[0] = 0x664400;
	TextBuffer[0] = EeKayit.ToplamSaat;
	ASendText(20,90-a2+272,ServisMenu[0][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);
	TextBuffer[0] = Menu.MaxYuk.L1; TextBuffer[1] = Menu.MaxYuk.L2; TextBuffer[2] = Menu.MaxYuk.L3;
	ASendText(20,110-a2+272,ServisMenu[1][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);
	ASendText(20,130-a2+272,ServisMenu[2][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);

	//Cancel yazar
	if( EeKayit.Bakim[DefFanBakim].AyarlananSure == 0 )
		Menu.FanBakimAktif = 0;
	else
	{
		//Normal de�er yazar
		if( EeKayit.Bakim[DefFanBakim].AyarlananSure < EeKayit.Bakim[DefFanBakim].GecenSure )
			Menu.FanBakimAktif = 2;
		//- de�er yazar
		else 
			Menu.FanBakimAktif = 1;
	}
	
	
	//Cancel yazar
	if( EeKayit.Bakim[DefAkuBakim].AyarlananSure == 0 )
		Menu.AkuBakimAktif = 0;
	else
	{
		//Normal de�er yazar
		if( EeKayit.Bakim[DefAkuBakim].AyarlananSure < EeKayit.Bakim[DefAkuBakim].GecenSure )
			Menu.AkuBakimAktif = 2;
		//- de�er yazar
		else 
			Menu.AkuBakimAktif = 1;
	}
	
	
	//Cancel yazar
	if( EeKayit.Bakim[DefGenelBakim].AyarlananSure == 0 )
		Menu.GenelBakimAktif = 0;
	else
	{
		//Normal de�er yazar
		if( EeKayit.Bakim[DefGenelBakim].AyarlananSure < EeKayit.Bakim[DefGenelBakim].GecenSure )
			Menu.GenelBakimAktif = 2;
		//- de�er yazar
		else 
			Menu.GenelBakimAktif = 1;
	}			
	TextBuffer[0] = EeKayit.Bakim[DefFanBakim].KalanSure;	
	ASendText(20,150-a2+272,ServisMenu[3+Menu.FanBakimAktif][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);
	TextBuffer[0] = EeKayit.Bakim[DefAkuBakim].KalanSure;	
	ASendText(20,170-a2+272,ServisMenu[6+Menu.AkuBakimAktif][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);
	TextBuffer[0] = EeKayit.Bakim[DefGenelBakim].KalanSure;	
	ASendText(20,190-a2+272,ServisMenu[9+Menu.GenelBakimAktif][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);

	//Inverter den gelen durum 1 ise login dir.
	if(( Can.FromInv.LogInDurum == 1) || (Genel.UserPassDogru15dklikIzin == 1))	
	{ TextBuffer[0] = '-';TextBuffer[1] = '-'; }
	else
	{ TextBuffer[0] = 'O';TextBuffer[1] = 'K'; }	
	ASendText(20,210-a2+272,ServisMenu[12][EeKayit.Dil],2,0x888888,NOTGRADIENTCOLOR,ServisSil);
	

	switch(ServisSekme)
	{
		case 0:
			TextBufferLong[0] = 0xffbb00;
			TextBuffer[0] = EeKayit.ToplamSaat;
		break;
		case 1:
			TextBufferLong[0] = 0xffbb00;
			TextBuffer[0] = Menu.MaxYuk.L1; TextBuffer[1] = Menu.MaxYuk.L2; TextBuffer[2] = Menu.MaxYuk.L3;
		break;
		case 2:
			TextBufferLong[0] = 0x664400;
		break;
		case 3:
			TextBufferLong[0] = 0xffbb00;
			TextBuffer[0] = EeKayit.Bakim[DefFanBakim].KalanSure;	
		break;
		case 4:
			TextBufferLong[0] = 0xffbb00;
			TextBuffer[0] = EeKayit.Bakim[DefAkuBakim].KalanSure;	
		break;
		case 5:
			TextBufferLong[0] = 0xffbb00;
			TextBuffer[0] = EeKayit.Bakim[DefGenelBakim].KalanSure;	
		break;
		case 6:
			TextBufferLong[0] = 0xffbb00;
			if(( Can.FromInv.LogInDurum == 1) || (Genel.UserPassDogru15dklikIzin == 1))	
			{ TextBuffer[0] = '-';TextBuffer[1] = '-'; }
			else
			{ TextBuffer[0] = 'O';TextBuffer[1] = 'K'; }
		break;
		default:
		break;
	}
	ASendText(20,(90 + (20*ServisSekme)+272)-a2,ServisMenu[ServisMenuOrg[ServisSekme][0] + *MenuAdresPtr][EeKayit.Dil],2,0xffffff,NOTGRADIENTCOLOR,ServisSil);
	
	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,ServisSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,ServisSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,ServisSil);
	OptimizasyonFonk4(ServisSil);
}


unsigned long AyarSatir_0_Color[3][2]	__attribute__((far)) =
{
	{0xffffff,0xffbb00},
	{0x888888,0x664400},
	{0x888888,0x664400}
};
unsigned long AyarSatir_1_Color[3][2]	__attribute__((far)) =
{
	{0x888888,0x664400},
	{0xffffff,0xffbb00},
	{0x888888,0x664400}
};
unsigned long AyarSatir_2_Color[3][2]	__attribute__((far)) =
{
	{0x888888,0x664400},
	{0x888888,0x664400},
	{0xffffff,0xffbb00}
};
//Touch eklendi
void Navigation(unsigned int _Sil,int Gri)
{
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(350,(82+272),0,YukariOk,0,0,0xffffff,_Sil);
	else
		BigOutVar(350,(82+272),0,YukariOk,0,0,0x888888,_Sil);
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(350,(177+272),0,AsagiOk,0,0,0xffffff,_Sil);
	else
		BigOutVar(350,(177+272),0,AsagiOk,0,0,0x888888,_Sil);	
	if( Menu.Buton.Bit.bSol )
		BigOutVar(300,(127+272),0,SolOk,0,0,0xffffff,_Sil);
	else
		BigOutVar(300,(127+272),0,SolOk,0,0,0x888888,_Sil);
	if( Menu.Buton.Bit.bSag )	
		BigOutVar(400,(127+272),0,SagOk,0,0,0xffffff,_Sil);
	else
		BigOutVar(400,(127+272),0,SagOk,0,0,0x888888,_Sil);
	if( Menu.Buton.Bit.bEnter )	
		BigOutVar(350,(127+272),0,OrtaNokta,0,0,0xffffff,_Sil);
	else
		BigOutVar(350,(127+272),0,OrtaNokta,0,0,0x888888,_Sil);
	
	if((Gri == 1) || ( _Sil == 1 ))
	{
		BigOutVar(350,(82+272),0,YukariOk,0,0,0x888888,_Sil);
		BigOutVar(350,(177+272),0,AsagiOk,0,0,0x888888,_Sil);
		BigOutVar(300,(127+272),0,SolOk,0,0,0x888888,_Sil);
		BigOutVar(400,(127+272),0,SagOk,0,0,0x888888,_Sil);
		BigOutVar(350,(127+272),0,OrtaNokta,0,0,0x888888,_Sil);
	}
}
void FonkAyaOnMenu_1(unsigned int AyarSekme,unsigned int AyarSekmeIci,unsigned int AyarSil)
{
	static unsigned int a3,SifreDogru = 0;	
	static unsigned int ExAyarSekme = 1;
	static int Pass_Toggle = 0;
	unsigned int *MenuAdresPtr,Ayar_i;
	
	Menu.AyarAltLimit = 0;
	Menu.AyarUstLimit = 1;
	Menu.Sekme.All = DefAnaMenu;
	
	//Touch kald�r�ld�.
//	if( Menu.Buton.Bit.bAsagi )
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bYukari )
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bEnter )
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);

	//Touch konduldu.
	Navigation(AyarSil,0);
	
//	ASendText(5,3+272,UstKelime[20][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	a3 = 0;
	TextBufferLong[0] = AyarSatir_0_Color[AyarSekme][1];
	TextBuffer[0] = Menu.ServisKodH; TextBuffer[1] = Menu.ServisKodL;
	ASendText(20,110-a3+272,AyarOnMenu_1[0][EeKayit.Dil],2,AyarSatir_0_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);

	for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
		TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i];

	if(AyarSekmeIci == 1) 
	{
		if(( Menu.SifreDurum == 1 ) || ( Menu.SifreDurum == 2 ) || ( Menu.SifreDurum == 3 ))
		{
			Pass_Toggle = 1;
			//�ifre do�ru
			if( Menu.SifreDurum == 1 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[1][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[2][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);			
				Menu.SifreDurum = 3;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 1;
			}
			else if( Menu.SifreDurum == 2 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[0][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 3;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 0;
			}
			else if( Menu.SifreDurum == 3 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 0; AyarSekmeIci = 0;Menu.AyarPssswordIci = 0;

				for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
					TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i] = 48;
					
				if( SifreDogru == 1 )
				{
					NavigasyonuSil = 1;				//Touch
					//AyarMenus�nden
					if( Genel.AraSifreMenuIci == 0 )
					{
						//Yeni men� i�in i�lem yap.
						ASendText(20,110-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
						ASendText(20,130-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
						ASendText(20,150-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
						Menu.Sekme.All == DefAyarAnaMenu;
						Menu.AyarAnaSekme = 0;
						Menu.YenileGeriSayac = 15;
					}
					else
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
				}
				else
				{
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
					//Bu men�de kal.
				}
			}
		}	
		else
			Menu.YenileGeriSayac = 5;
			
		if( Pass_Toggle == 0 )
		{
			Pass_Toggle = 1;
			TextBuffer[Menu.HaneDegistir] = ' ';
		}
		else
		{
			Pass_Toggle = 0;
			TextBuffer[Menu.HaneDegistir] = Menu.GolgeSifre[Menu.HaneDegistir];
		}
	}	
	TextBufferLong[0] = AyarSatir_1_Color[AyarSekme][1];
	ASendText(20,130-a3+272,AyarOnMenu_1[1][EeKayit.Dil],2,AyarSatir_1_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);
	
	if(( Can.FromInv.LogInDurum == 1 ) && ( Menu.AyarMenulerIlkGiris == 0 ))
	{
		Menu.AyarPssswordIci = AyarSekmeIci = 0;
		Pass_Toggle = 1;
		Menu.AyarMenulerIlkGiris = 1;
		ASendText(20,190-a3+272,AyarOnMenu_Cevap[6][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);		
		Menu.AyarAnaSekme = 0;
		Menu.Sekme.All = DefAyarAnaMenu;
		Menu.YenileGeriSayac = 15;
		AyarSil = 1;
	}
	
	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);
	//OptimizasyonFonk4(AyarSil); Touch kald�r�ld�
	Navigation(AyarSil,1);		//Touch konuldu
	
}

void FonkAyaOnMenu_2(unsigned int AyarSekme,unsigned int AyarSekmeIci,unsigned int AyarSil)
{
	static unsigned int a3,SifreDogru = 0;	
	static unsigned int ExAyarSekme = 1;
	static int Pass_Toggle = 0;
	unsigned int *MenuAdresPtr,Ayar_i;
	
	
	Menu.AyarAltLimit = 0;
	Menu.AyarUstLimit = 2;
	Menu.Sekme.All = DefAnaMenu;

	//Touch kald�r�ld�.
//	if( Menu.Buton.Bit.bAsagi )
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bYukari )
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bEnter )
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);

	//Touch konduldu.
	Navigation(AyarSil,0);
	
	
//	ASendText(5,3+272,UstKelime[20][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	 
	//1000 ms de bir bu sayfa yenilensin.
//	Menu.YenileGeriSayac = 20;
	
	a3 = 0;
//	MenuAdresPtr = ServisMenuOrg[ServisSekme][1];

		
	TextBufferLong[0] = AyarSatir_0_Color[AyarSekme][1];
	TextBuffer[0] = Menu.ServisKodH; TextBuffer[1] = Menu.ServisKodL;
	ASendText(20,110-a3+272,AyarOnMenu_2[0][EeKayit.Dil],2,AyarSatir_0_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);

	for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
		TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i];

	if(AyarSekmeIci == 1) 
	{
		if(( Menu.SifreDurum == 4 ) || ( Menu.SifreDurum == 5 ) || ( Menu.SifreDurum == 6 ))
		{
			Pass_Toggle = 1;
			//�ifre do�ru
			if( Menu.SifreDurum == 4 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[1][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[2][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);			
				Menu.SifreDurum = 6;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 1;
			}
			else if( Menu.SifreDurum == 5 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[0][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 6;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 0;
			}
			else if( Menu.SifreDurum == 6 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 0; AyarSekmeIci = 0;Menu.AyarPssswordIci = 0;

				for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
					TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i] = 48;
					
				if( SifreDogru == 1 )
				{
					NavigasyonuSil = 1;				//Touch
					//Yeni men� i�in i�lem yap.
					ASendText(20,110-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
					ASendText(20,130-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
					ASendText(20,150-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
					Menu.Sekme.All == DefAyarAnaMenu;
					Menu.AyarAnaSekme = 0;
					Menu.YenileGeriSayac = 15;
				}
				else
				{
					//Bu men�de kal.
				}
			}
		}	
		else
			Menu.YenileGeriSayac = 5;
			
		if( Pass_Toggle == 0 )
		{
			Pass_Toggle = 1;
			TextBuffer[Menu.HaneDegistir] = ' ';
		}
		else
		{
			Pass_Toggle = 0;
			TextBuffer[Menu.HaneDegistir] = Menu.GolgeSifre[Menu.HaneDegistir];
		}
	}	
	TextBufferLong[0] = AyarSatir_1_Color[AyarSekme][1];
	ASendText(20,130-a3+272,AyarOnMenu_2[1][EeKayit.Dil],2,AyarSatir_1_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);


	for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
		TextBuffer[Ayar_i] = Menu.UserGolgeSifre[Ayar_i];

	if(AyarSekmeIci == 2) 
	{
		if(( Menu.SifreDurum == 7 ) || ( Menu.SifreDurum == 8 ) || ( Menu.SifreDurum == 9 ))
		{
			Pass_Toggle = 1;
			//�ifre do�ru
			if( Menu.SifreDurum == 7 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[4][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);	
				Menu.SifreDurum = 9;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 1;
			}
			else if( Menu.SifreDurum == 8 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[3][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 9;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 0;
			}
			else if( Menu.SifreDurum == 9 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 0; AyarSekmeIci = 0;Menu.AyarPssswordIci = 0;

				for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
					TextBuffer[Ayar_i] = Menu.UserGolgeSifre[Ayar_i] = 48;
					
				if( SifreDogru == 1 )
				{
					NavigasyonuSil = 1;				//Touch
					//User password okey olacak bu men�de kal�nacak.
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
				}
				else
				{
					//Bu men�de kal.
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
				}
			}
		}	
		else
			Menu.YenileGeriSayac = 5;
			
		if( Pass_Toggle == 0 )
		{
			Pass_Toggle = 1;
			TextBuffer[Menu.HaneDegistir] = ' ';
		}
		else
		{
			Pass_Toggle = 0;
			TextBuffer[Menu.HaneDegistir] = Menu.UserGolgeSifre[Menu.HaneDegistir];
		}
	}	
	TextBufferLong[0] = AyarSatir_2_Color[AyarSekme][1];
	ASendText(20,150-a3+272,AyarOnMenu_2[2][EeKayit.Dil],2,AyarSatir_2_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);

	if(( Can.FromInv.LogInDurum == 1 ) && ( Menu.AyarMenulerIlkGiris == 0 ))
	{
		Menu.AyarPssswordIci = AyarSekmeIci = 0;
		Pass_Toggle = 1;
		Menu.AyarMenulerIlkGiris = 1;
		ASendText(20,190-a3+272,AyarOnMenu_Cevap[6][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);		
		Menu.AyarAnaSekme = 0;
		Menu.Sekme.All = DefAyarAnaMenu;
		Menu.YenileGeriSayac = 15;
		AyarSil = 1;
	}

	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);
	//OptimizasyonFonk4(AyarSil); Touch kald�r�ld�
	Navigation(AyarSil,1);		//Touch konuldu
	
}

void FonkAyaOnMenu_3(unsigned int AyarSekme,unsigned int AyarSekmeIci,unsigned int AyarSil)
{
	static unsigned int a3,SifreDogru = 0;	
	static unsigned int ExAyarSekme = 1;
	static int Pass_Toggle = 0;
	unsigned int *MenuAdresPtr,Ayar_i;
	
	
	Menu.AyarAltLimit = 0;
	Menu.AyarUstLimit = 1;
	Menu.Sekme.All = DefAnaMenu;
	
	//Touch kald�r�ld�.
//	if( Menu.Buton.Bit.bAsagi )
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bYukari )
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bEnter )
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);

	//Touch konduldu.
	Navigation(AyarSil,0);
	
//	ASendText(5,3+272,UstKelime[20][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st

	a3 = 0;

	for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
		TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i];

	if(AyarSekmeIci == 1) 
	{
		if(( Menu.SifreDurum == 10 ) || ( Menu.SifreDurum == 11 ) || ( Menu.SifreDurum == 12 ))
		{
			Pass_Toggle = 1;
			//�ifre do�ru
			if( Menu.SifreDurum == 10 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[1][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[2][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);			
				Menu.SifreDurum = 12;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 1;
			}
			else if( Menu.SifreDurum == 11 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[0][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 12;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 0;
			}
			else if( Menu.SifreDurum == 12 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 0; AyarSekmeIci = 0;Menu.AyarPssswordIci = 0;

				for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
					TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i] = 48;
					
				if( SifreDogru == 1 )
				{
					NavigasyonuSil = 1;				//Touch
					//AyarMenus�nden
					if( Genel.AraSifreMenuIci == 0 )
					{
						//Yeni men� i�in i�lem yap.
						ASendText(20,110-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
						ASendText(20,130-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
						ASendText(20,150-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
						Menu.Sekme.All = DefAyarAnaMenu;
						Menu.AyarAnaSekme = 0;
						Menu.YenileGeriSayac = 15;
					}
					else
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
				}
				else
				{
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
					//Bu men�de kal.
				}
			}
		}	
		else
			Menu.YenileGeriSayac = 5;
			
		if( Pass_Toggle == 0 )
		{
			Pass_Toggle = 1;
			TextBuffer[Menu.HaneDegistir] = ' ';
		}
		else
		{
			Pass_Toggle = 0;
			TextBuffer[Menu.HaneDegistir] = Menu.GolgeSifre[Menu.HaneDegistir];
		}
	}	
	TextBufferLong[0] = AyarSatir_0_Color[AyarSekme][1];
	ASendText(20,110-a3+272,AyarOnMenu_3[0][EeKayit.Dil],2,AyarSatir_0_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);


	for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
		TextBuffer[Ayar_i] = Menu.UserGolgeSifre[Ayar_i];

	if(AyarSekmeIci == 2) 
	{
		if(( Menu.SifreDurum == 13 ) || ( Menu.SifreDurum == 14 ) || ( Menu.SifreDurum == 15 ))
		{
			Pass_Toggle = 1;
			//�ifre do�ru
			if( Menu.SifreDurum == 13 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[4][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);	
				Menu.SifreDurum = 15;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 1;
			}
			else if( Menu.SifreDurum == 14 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[3][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 15;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 0;
			}
			else if( Menu.SifreDurum == 15 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 0; AyarSekmeIci = 0;Menu.AyarPssswordIci = 0;

				for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
					TextBuffer[Ayar_i] = Menu.UserGolgeSifre[Ayar_i] = 48;
					
				if( SifreDogru == 1 )
				{
					NavigasyonuSil = 1;				//Touch
					//Ara �ifre den geldi
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
					//User PAssword do�ru bununla alakal� i�lem varsa yap�lacak ve bu men�de kal�nacak.
				}
				else
				{
					//Ara �ifre den geldi
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 5;
					}
					//Bu men�de kal.
				}
			}
		}	
		else
			Menu.YenileGeriSayac = 5;
			
		if( Pass_Toggle == 0 )
		{
			Pass_Toggle = 1;
			TextBuffer[Menu.HaneDegistir] = ' ';
		}
		else
		{
			Pass_Toggle = 0;
			TextBuffer[Menu.HaneDegistir] = Menu.UserGolgeSifre[Menu.HaneDegistir];
		}
	}	
	TextBufferLong[0] = AyarSatir_1_Color[AyarSekme][1];
	ASendText(20,130-a3+272,AyarOnMenu_3[1][EeKayit.Dil],2,AyarSatir_1_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);

	if(( Can.FromInv.LogInDurum == 1 ) && ( Menu.AyarMenulerIlkGiris == 0 ))
	{
		Menu.AyarPssswordIci = AyarSekmeIci = 0;
		Pass_Toggle = 1;
		Menu.AyarMenulerIlkGiris = 1;
		ASendText(20,190-a3+272,AyarOnMenu_Cevap[6][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);	
		Menu.Sekme.All = DefAyarAnaMenu;	
		Menu.AyarAnaSekme = 0;
		Menu.YenileGeriSayac = 15;
		AyarSil = 1;
	}

	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);
	//OptimizasyonFonk4(AyarSil); Touch kald�r�ld�
	Navigation(AyarSil,1);		//Touch konuldu
	
}


void FonkAyaOnMenu_4(unsigned int AyarSekme,unsigned int AyarSekmeIci,unsigned int AyarSil)
{
	static unsigned int a3,SifreDogru = 0;	
	static unsigned int ExAyarSekme = 1;
	static int Pass_Toggle = 0;
	unsigned int *MenuAdresPtr,Ayar_i;
	
		
	Menu.AyarAltLimit = 0;
	Menu.AyarUstLimit = 0;
	Menu.Sekme.All = DefAnaMenu;
	
	//Touch kald�r�ld�.
//	if( Menu.Buton.Bit.bAsagi )
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bYukari )
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
//	if( Menu.Buton.Bit.bEnter )
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,AyarSil);
//	else
//		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);

	//Touch konduldu.
	Navigation(AyarSil,0);
	
//	ASendText(5,3+272,UstKelime[20][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	a3 = 0;

	for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
		TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i];

	if(AyarSekmeIci == 1) 
	{
		if(( Menu.SifreDurum == 16 ) || ( Menu.SifreDurum == 17 ) || ( Menu.SifreDurum == 18 ))
		{
			Pass_Toggle = 1;
			//�ifre do�ru
			if( Menu.SifreDurum == 16 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[1][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[2][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);			
				Menu.SifreDurum = 18;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 1;
			}
			else if( Menu.SifreDurum == 17 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[0][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 18;
				Menu.YenileGeriSayac = 15;
				SifreDogru = 0;
			}
			else if( Menu.SifreDurum == 18 )
			{
				ASendText(20,170-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				ASendText(20,190-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);
				Menu.SifreDurum = 0; AyarSekmeIci = 0;Menu.AyarPssswordIci = 0;

				for( Ayar_i=0;Ayar_i<8;Ayar_i++ )
					TextBuffer[Ayar_i] = Menu.GolgeSifre[Ayar_i] = 48;
					
				if( SifreDogru == 1 )
				{
					NavigasyonuSil = 1;				//Touch
					//AyarMenus�nden
					if( Genel.AraSifreMenuIci == 0 )
					{
						//Yeni men� i�in i�lem yap.
						ASendText(20,110-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,1);
						ASendText(20,130-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,1);
						ASendText(20,150-a3+272,AyarOnMenu_Cevap[5][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,1);
						Menu.Sekme.All = DefAyarAnaMenu;
						Menu.YenileGeriSayac = 15;
						Menu.AyarAnaSekme = 0;
					}
					else
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
				}
				else
				{
					if( Genel.AraSifreMenuIci == 1 )
					{
						ASendText(15,222+272,GenelTablo[16+ Genel.AraSifre_Hangisi][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,1);
						Genel.AraSifreMenuIci = 2;
//						Menu.Sekme.All = Genel.EskiMenu;
//						Menu.AnaSekme = Genel.EskiSekme;
//						MenuGraphic(Menu.AnaSekme);
//						Genel.EskiMenu = 0;
						Menu.YenileGeriSayac = 15;
					}
					//Bu men�de kal.
				}
			}
		}	
		else
			Menu.YenileGeriSayac = 5;
			
		if( Pass_Toggle == 0 )
		{
			Pass_Toggle = 1;
			TextBuffer[Menu.HaneDegistir] = ' ';
		}
		else
		{
			Pass_Toggle = 0;
			TextBuffer[Menu.HaneDegistir] = Menu.GolgeSifre[Menu.HaneDegistir];
		}
	}	
	TextBufferLong[0] = AyarSatir_0_Color[AyarSekme][1];
	ASendText(20,110-a3+272,AyarOnMenu_4[0][EeKayit.Dil],2,AyarSatir_0_Color[AyarSekme][0],NOTGRADIENTCOLOR,AyarSil);

	if(( Can.FromInv.LogInDurum == 1 ) && ( Menu.AyarMenulerIlkGiris == 0 ))
	{
		Menu.AyarPssswordIci = AyarSekmeIci = 0;
		Pass_Toggle = 1;
		Menu.AyarMenulerIlkGiris = 1;
		ASendText(20,190-a3+272,AyarOnMenu_Cevap[6][EeKayit.Dil],2,0x00ff00,NOTGRADIENTCOLOR,AyarSil);	
		Menu.AyarAnaSekme = 0;
		Menu.Sekme.All = DefAyarAnaMenu;
		Menu.YenileGeriSayac = 15;
		AyarSil = 1;
	}
	
//	BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarSil);
//	BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarSil);
//	BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarSil);
	//OptimizasyonFonk4(AyarSil); Touch kald�r�ld�
	Navigation(AyarSil,1);		//Touch konuldu
	
}

void FonkAyarAnaMenu(unsigned int LokalAyarAnaMenu,unsigned int AyarAnaSil)
{
	static int a4,EskiLokalAyarAnaMenu;
	int Sat;
	
	
	if( NavigasyonuSil == 1 )
	{
		NavigasyonuSil = 2;
		//Touch eklendi
		//-----------------
		Navigation(1,0);
		//-----------------
	}
	
	Menu.AyarAnaAltLimit = 0;
	Menu.AyarAnaUstLimit = 9;
	Menu.Sekme.All = DefAyarAnaMenu;
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,AyarAnaSil);
	else
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarAnaSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,AyarAnaSil);
	else
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarAnaSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,AyarAnaSil);
	else
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarAnaSil);
		
//	ASendText(5,3+272,UstKelime[21+LokalAyarAnaMenu][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	
	Menu.EnterExit = 0;
	if((( EskiLokalAyarAnaMenu == 6 ) && ( LokalAyarAnaMenu == 7 )) || (( EskiLokalAyarAnaMenu == Menu.AyarAnaAltLimit ) && ( LokalAyarAnaMenu == Menu.AyarAnaUstLimit )) )
	{
		Menu.AyarAnaMenuSayfa = 2;
		for(Sat=3;Sat<7;Sat++)
			ASendText(20,(90+(Sat*20)+272),AyarAnaMenu[Sat],2,0x888888,NOTGRADIENTCOLOR,1);
	}		 
	if( LokalAyarAnaMenu < 7 )
	{		
		Menu.AyarAnaMenuSayfa = 1;
		for(Sat=0;Sat<7;Sat++)
			ASendText(20,(90+(Sat*20)+272),AyarAnaMenu[Sat],2,0x888888,NOTGRADIENTCOLOR,AyarAnaSil);
		ASendText(20,(90+(LokalAyarAnaMenu*20)+272),AyarAnaMenu[LokalAyarAnaMenu],2,0xffffff,NOTGRADIENTCOLOR,AyarAnaSil);	
	}	
	else	
	{		
		for(Sat=7;Sat<11;Sat++)
			ASendText(20,(90+((Sat-7)*20)+272),AyarAnaMenu[Sat],2,0x888888,NOTGRADIENTCOLOR,AyarAnaSil);
		ASendText(20,(90+((LokalAyarAnaMenu-7)*20)+272),AyarAnaMenu[LokalAyarAnaMenu],2,0xffffff,NOTGRADIENTCOLOR,AyarAnaSil);	
		
		if( LokalAyarAnaMenu == Menu.AyarAnaUstLimit )
			Menu.EnterExit = 1;
	}		
	EskiLokalAyarAnaMenu = LokalAyarAnaMenu;	
	
	BufferedText(Menu.AyarAnaMenuSayfa,2,0,0xffbb00);
	ASendText(370,210+272,"[/[",1,0xffbb00,NOTGRADIENTCOLOR,AyarAnaSil);	
			
//	BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,AyarAnaSil);
//	BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,AyarAnaSil);
//	BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,AyarAnaSil);
	OptimizasyonFonk4(AyarAnaSil);
}

unsigned long AyarAltMenulerRenk[3][2]	__attribute__((far)) =
{
	{0xffffff,0x888888},
	{0xff0000,0x664400},
	{0xffff00,0x888888}
};
void FonkAyarAltMenuFonk(unsigned int LokalAyarAltAnaMenu,unsigned int LokalAyarAltMenu,unsigned int LokalAyarAltSil)
{
	//Panel options ta kullan�l�yor.
	unsigned int *TftRamAddr;
	unsigned int *TftEeAddr;
	unsigned int z4,i4;
	i4 = 0;
	
	//Ayar men�s� alt men�de oldunu g�sterir.
	Menu.Sekme.All = DefAyarAltMenu;
	//Sadece Enter - Exit men�s� g�sterilirken 1 olur.
	Menu.EnterExit = 0;
	//Menu Limitleri
	Menu.AyarAlt_1_AltLimit = 0;
	Menu.AyarAlt_1_UstLimit = 2;


	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,LokalAyarAltSil);
	else
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,LokalAyarAltSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,LokalAyarAltSil);
	else
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,LokalAyarAltSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,LokalAyarAltSil);
	else
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,LokalAyarAltSil);
	
//	ASendText(5,3+272,UstKelime[21+LokalAyarAltAnaMenu][EeKayit.Dil],2,0x999999,NOTGRADIENTCOLOR,0);						//Men� Ba�l��� Sol �st
	if(LokalAyarAltMenu == 2)
		Menu.EnterExit = 1;
	else 
		Menu.EnterExit = 0;
//	TextBufferLong[0] = 0xff0000;
	TextBufferLong[0] = AyarAltMenulerRenk[1][Menu.EnterExit];
	switch(LokalAyarAltAnaMenu)
	{
		case DefGrupParametre:
				//Sadece grup parametrelerinde 4 sat�r var 3. s� enter.
				if(LokalAyarAltMenu == 3)
					Menu.EnterExit = 1;
				else
					Menu.EnterExit = 0;
			//	TextBufferLong[0] = 0xff0000;
				TextBufferLong[0] = AyarAltMenulerRenk[1][Menu.EnterExit];
				
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 9;
				
				//Menu Limitleri
				Menu.AyarAlt_1_AltLimit = 0;
				Menu.AyarAlt_1_UstLimit = 3;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_GrupAdj[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(90+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj[Menu.AyarEtiket][1] + 128; 
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj[Menu.AyarEtiket][2]; 
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(110+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				
				TextBuffer[1] = *(Ayar_GrupAdj[Menu.AyarEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 2);						
				//O/P VOLT RANGE
				if(( Ayar_GrupAdj[Menu.AyarEtiket][2] == 1187 ) || ( Ayar_GrupAdj[Menu.AyarEtiket][2] == 2185 ))			//220,230,240
				{															
					if(Menu.AyarAyar == 219)
						Menu.AyarAyar = 240;
					if(Menu.AyarAyar < 220 || Menu.AyarAyar > 240 || Menu.AyarAyar == 229)	
						Menu.AyarAyar = 220;
					if((Menu.AyarAyar > 220 && Menu.AyarAyar < 231) || Menu.AyarAyar == 239)
						Menu.AyarAyar = 230;
					if((Menu.AyarAyar > 230 && Menu.AyarAyar < 241) || Menu.AyarAyar == 65535)
						Menu.AyarAyar = 240; 
						
					Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;						
			//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
					ASendText(50,(110+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_GrupAdj[Menu.AyarEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(130+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}	
				//O/P FREQ RANGE
				else if(( Ayar_GrupAdj[Menu.AyarEtiket][2] == 1136 ) || ( Ayar_GrupAdj[Menu.AyarEtiket][2] == 2142 ))			//50,60
				{			
					if( LokalAyarAltMenu == 1 )
					{
						if(Menu.AyarAyar > 60)
							Menu.AyarAyar = 60;
					}	
					if(Menu.AyarAyar == 49)
						Menu.AyarAyar = 60;
					if(Menu.AyarAyar < 50 || Menu.AyarAyar > 60 || Menu.AyarAyar == 59)	
						Menu.AyarAyar = 50;
					if(Menu.AyarAyar > 50 && Menu.AyarAyar < 60)
						Menu.AyarAyar = 60; 
					Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;						
			//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);	
					ASendText(50,(110+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
					
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_GrupAdj[Menu.AyarEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);		
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(130+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);				
				}
				else
				{
					Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;						
			//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
					ASendText(50,(110+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_GrupAdj[Menu.AyarEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj[Menu.AyarEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);	
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(130+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}		
			//	LcdFonk(AyarAltMenu[32],Menu.AyarAlt,0,1,4);
				ASendText(50,(150+272),AyarAltMenu[32],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				
				AyarSecenekOK(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in		
			//	LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
						
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(90+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(90+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
				switch(LokalAyarAltMenu)
				{
					case 0:
					//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(90+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(90+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 3:
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefInvFabrika:
				if(LokalAyarAltMenu == 2)
					Menu.EnterExit = 1;
				else 
					Menu.EnterExit = 0;
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				//Menu.AyarAlt_2_UstLimit = 15;
				Menu.AyarAlt_2_UstLimit = 16;		//14.07.14
		
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_InvFactOpt[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_InvFactOpt[Menu.AyarEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_InvFactOpt[Menu.AyarEtiket][2];

				if( Ayar_InvFactOpt[Menu.AyarEtiket][2] == 1171 )	
				{
					//Birinci sat�rdayken gelen datay� al�r.Bitleri incelenir.
					if( LokalAyarAltMenu == 0 )
					{
						AyarBitAnlam.InvFactOpt.All = Menu.AyarSonuc;
					}
					//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.
					if( LokalAyarAltMenu == 1 )
						Menu.AyarAyar = Menu.AyarAyar & 1;
						
					switch(Menu.AyarEtiket)
					{
						case 0:	
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[18 + AyarBitAnlam.InvFactOpt.Bit.O_P_Switch],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[18 + AyarBitAnlam.InvFactOpt.Bit.O_P_Switch],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}	
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.O_P_Switch;
							AyarBitAnlam.InvFactOpt.Bit.O_P_Switch = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[4 + AyarBitAnlam.InvFactOpt.Bit.O_P_Switch],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[4 + AyarBitAnlam.InvFactOpt.Bit.O_P_Switch],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						break;
						case 1:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[18 + AyarBitAnlam.InvFactOpt.Bit.TempSensor],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[18 + AyarBitAnlam.InvFactOpt.Bit.TempSensor],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.TempSensor;
							AyarBitAnlam.InvFactOpt.Bit.TempSensor = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[4 + AyarBitAnlam.InvFactOpt.Bit.TempSensor],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[4 + AyarBitAnlam.InvFactOpt.Bit.TempSensor],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						break;
						case 2:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.O_P_CBSense],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.O_P_CBSense],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.O_P_CBSense;
							AyarBitAnlam.InvFactOpt.Bit.O_P_CBSense = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.O_P_CBSense],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.O_P_CBSense],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						break;
						case 3:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.ScrFault],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.ScrFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								 Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.ScrFault;
							AyarBitAnlam.InvFactOpt.Bit.ScrFault = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.ScrFault],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.ScrFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 4:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.InvEeFault],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.InvEeFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.InvEeFault;
							AyarBitAnlam.InvFactOpt.Bit.InvEeFault = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.InvEeFault],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.InvEeFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 5:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[20 + AyarBitAnlam.InvFactOpt.Bit.O_P_ModulType],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[20 + AyarBitAnlam.InvFactOpt.Bit.O_P_ModulType],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.O_P_ModulType;
							AyarBitAnlam.InvFactOpt.Bit.O_P_ModulType = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[6 + AyarBitAnlam.InvFactOpt.Bit.O_P_ModulType],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[6 + AyarBitAnlam.InvFactOpt.Bit.O_P_ModulType],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 6:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[18 + AyarBitAnlam.InvFactOpt.Bit.PfcSystem],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[18 + AyarBitAnlam.InvFactOpt.Bit.PfcSystem],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.PfcSystem;
							AyarBitAnlam.InvFactOpt.Bit.PfcSystem = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[4 + AyarBitAnlam.InvFactOpt.Bit.PfcSystem],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[4 + AyarBitAnlam.InvFactOpt.Bit.PfcSystem],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 7:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.DcBalanceFault],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.DcBalanceFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.DcBalanceFault;
							AyarBitAnlam.InvFactOpt.Bit.DcBalanceFault = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.DcBalanceFault],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.DcBalanceFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 8:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[22 + AyarBitAnlam.InvFactOpt.Bit.BypassSekron],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[22 + AyarBitAnlam.InvFactOpt.Bit.BypassSekron],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.BypassSekron;
							AyarBitAnlam.InvFactOpt.Bit.BypassSekron = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[8 + AyarBitAnlam.InvFactOpt.Bit.BypassSekron],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[8 + AyarBitAnlam.InvFactOpt.Bit.BypassSekron],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						case 9:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[26 + AyarBitAnlam.InvFactOpt.Bit.ShortCircuitPh],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[26 + AyarBitAnlam.InvFactOpt.Bit.ShortCircuitPh],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.ShortCircuitPh;
							AyarBitAnlam.InvFactOpt.Bit.ShortCircuitPh = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[12 + AyarBitAnlam.InvFactOpt.Bit.ShortCircuitPh],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[12 + AyarBitAnlam.InvFactOpt.Bit.ShortCircuitPh],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 10:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.BypShortCircuit],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.BypShortCircuit],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.BypShortCircuit;
							AyarBitAnlam.InvFactOpt.Bit.BypShortCircuit = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.BypShortCircuit],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.BypShortCircuit],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						case 11:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.BypLkgCurr],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.InvFactOpt.Bit.BypLkgCurr],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.BypLkgCurr;
							AyarBitAnlam.InvFactOpt.Bit.BypLkgCurr = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.BypLkgCurr],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.InvFactOpt.Bit.BypLkgCurr],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 12:
							if(( Can.FromInv.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromInv.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[37 + AyarBitAnlam.InvFactOpt.Bit.BypCurrTrf],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[37 + AyarBitAnlam.InvFactOpt.Bit.BypCurrTrf],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.InvFactOpt.Bit.BypCurrTrf;
							AyarBitAnlam.InvFactOpt.Bit.BypCurrTrf = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[39 + AyarBitAnlam.InvFactOpt.Bit.BypCurrTrf],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[39 + AyarBitAnlam.InvFactOpt.Bit.BypCurrTrf],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						default:
						break;
					}
					//Yazarken 16 bit birden yazar.
					Can.AyarMenuDizisi[2] = AyarBitAnlam.InvFactOpt.All;
				}
				//Mode se�imi
				//else if( Ayar_InvFactOpt[Menu.AyarEtiket][2] == 1228 )
				//Operating mode
				else if( Can.AyarMenuDizisi[1] == 1228 )	
				{							
					Menu.AyarAyar = Menu.AyarAyar & 3;	
					Can.AyarMenuDizisi[2] = Menu.AyarAyar;		
			//		LcdFonk(AyarAltMenu[14 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
					ASendText(50,(130+272),AyarAltMenu[14 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
			//		LcdFonk(AyarAltMenu[28 + Menu.AyarSonuc],Menu.AyarAlt,0,1,3);	
					ASendText(50,(150+272),AyarAltMenu[28 + Menu.AyarSonuc],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);								
				}
				//Ups no su
				else if( Can.AyarMenuDizisi[1] == 1229 )	
				{							
					Menu.AyarAyar = Menu.AyarAyar & 7;	
					Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;						
			//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
					ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_InvFactOpt[Menu.AyarEtiket][3]);
					TextBuffer[2] = *(Ayar_InvFactOpt[Menu.AyarEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_InvFactOpt[Menu.AyarEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);	
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);										
				}
				else
				{
					Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;						
			//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
					ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_InvFactOpt[Menu.AyarEtiket][3]);
					TextBuffer[2] = *(Ayar_InvFactOpt[Menu.AyarEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_InvFactOpt[Menu.AyarEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);	
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}						
				
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
				
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefPfcFabrika:
				if(LokalAyarAltMenu == 2)
					Menu.EnterExit = 1;
				else 
					Menu.EnterExit = 0;
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 11;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_PfcFactOpt[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_PfcFactOpt[Menu.AyarEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_PfcFactOpt[Menu.AyarEtiket][2];

				//Bit i�lemleri
				if( Ayar_PfcFactOpt[Menu.AyarEtiket][2] == 2160 )	
				{
					//Birinci sat�rdayken gelen datay� al�r.Bitleri incelenir.
					if( LokalAyarAltMenu == 0 )
					{
						AyarBitAnlam.PfcFactOpt.All = Menu.AyarSonuc;
					}
					//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.
					if( LokalAyarAltMenu == 1 )
						Menu.AyarAyar = Menu.AyarAyar & 1;
						
					//Yeni bit ayar� eklendi�inde 
					// 1. AyarBitAnlam.PfcFactOpt.Bit leri de�i�tirilecek
					// 2. yukar�daki Menu.AyarAlt_2_UstLimit de�i�tirilecek.
					// 3. Tablo.c de yeni etiketler ve value , ayar de�erleri eklenecek.
					if(LokalAyarAltMenu == 2)
						Menu.EnterExit = 1;
					else 
						Menu.EnterExit = 0;
					switch(Menu.AyarEtiket)
					{
						case 0:	
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[20 + AyarBitAnlam.PfcFactOpt.Bit.I_P_ModulType],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[20 + AyarBitAnlam.PfcFactOpt.Bit.I_P_ModulType],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}	
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.I_P_ModulType;
							AyarBitAnlam.PfcFactOpt.Bit.I_P_ModulType = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[6 + AyarBitAnlam.PfcFactOpt.Bit.I_P_ModulType],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[6 + AyarBitAnlam.PfcFactOpt.Bit.I_P_ModulType],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						break;
						case 1:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp;
							AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.BtTempKomp],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						break;
						case 2:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.PfcEeFault],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.PfcEeFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.PfcEeFault;
							AyarBitAnlam.PfcFactOpt.Bit.PfcEeFault = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.PfcEeFault],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.PfcEeFault],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						case 3:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.BoostCharge],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.BoostCharge],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								 Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.BoostCharge;
							AyarBitAnlam.PfcFactOpt.Bit.BoostCharge = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.BoostCharge],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.BoostCharge],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);				
						break;
//								case 4:
//									if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ))
//									{
//										Can.FromPfc.BitIslemDatasiGeldi = 0;
//										LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CurrProtect],Menu.AyarAlt,0,1,3);
//									}
//									if( LokalAyarAltMenu == 0 )	
//										Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.I_P_CurrProtect;
//									AyarBitAnlam.PfcFactOpt.Bit.I_P_CurrProtect = Menu.AyarAyar;
//									LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CurrProtect],Menu.AyarAlt,0,1,2);		
//								break;
						case 4:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CBSense],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CBSense],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.I_P_CBSense;
							AyarBitAnlam.PfcFactOpt.Bit.I_P_CBSense = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CBSense],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CBSense],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 5:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CurTransAlr],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CurTransAlr],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.I_P_CurTransAlr;
							AyarBitAnlam.PfcFactOpt.Bit.I_P_CurTransAlr = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CurTransAlr],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_CurTransAlr],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);				
						break;
						case 6:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.AcInputTest],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.AcInputTest],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.AcInputTest;
							AyarBitAnlam.PfcFactOpt.Bit.AcInputTest = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.AcInputTest],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.AcInputTest],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 7:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
						//		LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.PfcTermalProtect],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.PfcTermalProtect],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.PfcTermalProtect;
							AyarBitAnlam.PfcFactOpt.Bit.PfcTermalProtect = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.PfcTermalProtect],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.PfcTermalProtect],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						case 8:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))	
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
						//		LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_RegenSystem],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.I_P_RegenSystem],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.I_P_RegenSystem;
							AyarBitAnlam.PfcFactOpt.Bit.I_P_RegenSystem = Menu.AyarAyar;
						//	LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_RegenSystem],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.I_P_RegenSystem],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						case 9:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
						//		LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.AutomaticBattTest],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.AutomaticBattTest],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.AutomaticBattTest;
							AyarBitAnlam.PfcFactOpt.Bit.AutomaticBattTest = Menu.AyarAyar;
						//	LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.AutomaticBattTest],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.AutomaticBattTest],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 10:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
						//		LcdFonk(AyarAltMenu[44 + AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[44 + AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1;
							AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1 = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[42 + AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1],Menu.AyarAlt,0,1,2);
							ASendText(50,(130+272),AyarAltMenu[42 + AyarBitAnlam.PfcFactOpt.Bit.UseSensorTH3_1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);			
						break;
						case 11:
							if(( Can.FromPfc.BitIslemDatasiGeldi ) || ( LokalAyarAltMenu == 0 ) || ( LokalAyarAltMenu == 2 ))
							{
								Can.FromPfc.BitIslemDatasiGeldi = 0;
					//			LcdFonk(AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage],Menu.AyarAlt,0,1,3);
								ASendText(50,(150+272),AyarAltMenu[33 + AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
							}
							if( LokalAyarAltMenu == 0 )	
								Menu.AyarAyar = AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage;
							AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage = Menu.AyarAyar;
					//		LcdFonk(AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage],Menu.AyarAlt,0,1,2);	
							ASendText(50,(130+272),AyarAltMenu[35 + AyarBitAnlam.PfcFactOpt.Bit.PfcDcLeakage],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						break;
						default:
						break;
					}
					//Yazarken 16 bit birden yazar.
					Can.AyarMenuDizisi[2] = AyarBitAnlam.PfcFactOpt.All;
				}
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
			//	OkGoster(1,LokalAyarAltMenu);
			//	LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefPanelSecenek:
					
				Menu.YenileGeriSayac = 30;
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
			//	Menu.AyarAlt_2_UstLimit = 12;
			//	Menu.AyarAlt_2_UstLimit = 13;			//21.07.14 
			//	Menu.AyarAlt_2_UstLimit = 15;			//22.07.14
			//	Menu.AyarAlt_2_UstLimit = 18;			//26.11.2014		Bak�m saya�lar� ayarlamak i�in 26.11.14
				Menu.AyarAlt_2_UstLimit = 19;			//24.06.2015		Touch panel var yok se�imi
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_PanelOpt[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_PanelOpt[Menu.AyarEtiket][1];
				Can.AyarMenuDizisi[1] = Ayar_PanelOpt[Menu.AyarEtiket][2];
				
				if( Can.AyarMenuDizisi[1] == 3415 )
				{
					z4 = Ayar_PanelOpt[Menu.AyarEtiket][2];
					TftRamAddr = ((z4-3000) << 1) + 2560;
					EeKayit.Konfig.All = *TftRamAddr;							
					
					//Opt03 kart se�imi
					if( Menu.AyarEtiket == 0 )
					{							
				//		LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.Opt03Secim],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.Opt03Secim],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.Opt03Secim;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
				//		LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.Opt03Secim = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//Termik Sensor1 kullan�m�
					if( Menu.AyarEtiket == 2 )
					{
				//		LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.TermalSensor1],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.TermalSensor1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.TermalSensor1;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
				//		LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.TermalSensor1 = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//Termik Sensor2 kullan�m�
					if( Menu.AyarEtiket == 6 )
					{
				//		LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.TermalSensor2],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.TermalSensor2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.TermalSensor2;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
				//		LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.TermalSensor2 = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//User Password kullan�m�
					if( Menu.AyarEtiket == 1 )
					{
				//		LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.UserPassKullanilsin],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.UserPassKullanilsin],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.UserPassKullanilsin;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
				//		LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);		
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.UserPassKullanilsin = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//Freq Converter kullan�m�
					if( Menu.AyarEtiket == 13 )			//21.07.14
					{
					//	LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.BypassVarYok],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.BypassVarYok],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.BypassVarYok;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
						//LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.BypassVarYok = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//Epo Var Yok kullan�m�
					if( Menu.AyarEtiket == 14 )			//22.07.14
					{
					//	LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.BypassVarYok],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.EpoVarYok],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.EpoVarYok;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
						//LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.EpoVarYok = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//Genin Var Yok kullan�m�
					if( Menu.AyarEtiket == 15 )			//22.07.14
					{
					//	LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.BypassVarYok],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.JeneratorVarYok],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.JeneratorVarYok;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
						//LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.JeneratorVarYok = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
					//Touch screen Var Yok kullan�m�
					if( Menu.AyarEtiket == 19 )			//24.06.15
					{
					//	LcdFonk(AyarAltMenu[18 + EeKayit.Konfig.Bit.BypassVarYok],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[18 + EeKayit.Konfig.Bit.TouchScreenOffOn],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
						{							
							Menu.BitIslemDatasiGeldi = 0;	
							Menu.AyarAyar = EeKayit.Konfig.Bit.TouchScreenOffOn;	
						}
						//Ayar yaparken bit i�lemi yap�ld��� i�in de�erler 0 ya da 1 olur.	
						Menu.AyarAyar = Menu.AyarAyar & 1;							
						//LcdFonk(AyarAltMenu[4 + Menu.AyarAyar],Menu.AyarAlt,0,1,2);
						ASendText(50,(130+272),AyarAltMenu[4 + Menu.AyarAyar],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
						if( Can.FromInv.LogInDurum )
							Genel.YedekKonfig.Bit.TouchScreenOffOn = Menu.AyarAyar;
						Can.AyarMenuDizisi[2] = Genel.YedekKonfig.All;
					}
				}
				else
				{					
					if(( LokalAyarAltMenu == 0 ) || ( Menu.BitIslemDatasiGeldi == 1 ))
					{							
						Menu.BitIslemDatasiGeldi = 0;	
						z4 = Ayar_PanelOpt[Menu.AyarEtiket][1];
						TftEeAddr = ((z4-3000) << 1) + 2560;
						Menu.AyarAyar = *TftEeAddr;
					}
					Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar; 							
			//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
					ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					
					z4 = Ayar_PanelOpt[Menu.AyarEtiket][2];
					TftRamAddr = ((z4-3000) << 1) + 2560;
					
					TextBuffer[0] = *TftRamAddr;
					TextBuffer[1] = *(Ayar_PanelOpt[Menu.AyarEtiket][3]);
					TextBuffer[2] = *(Ayar_PanelOpt[Menu.AyarEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_PanelOpt[Menu.AyarEtiket][3] + 2);
					//Noktal� yani 12.5 gibi veya normal 125 gibi ayr�m�n� yapmak i�in adresler soruluyor.
					if((z4 == 3428) || (z4 == 3427) || (z4 == 3426)||(z4 == 3376) || (z4 == 3381) || (z4 == 3386))		//26.11.2014 te eklendi 3376,3381,3386 adresleri
			//			LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					else
					{	
						if( z4 == 3419 )
						{			
							//Termal sens�r1 TH1 aktifse �l��m yazar.
							if( EeKayit.Konfig.Bit.TermalSensor1 )
							{
								TextBuffer[0] = ' ';
								Genel.Th1AraDeger = EeKayit.TermalSensor1.Olculen;
								if( Genel.Th1AraDeger > 32767 )
								{
									Genel.Th1AraDeger = 65536 - Genel.Th1AraDeger;
									TextBuffer[0] = '-';
								}
								TextBuffer[1] = Dig(Genel.Th1AraDeger,3);//(((Genel.Th1AraDeger % 10000) % 1000) / 100) + 48;
								TextBuffer[2] = Dig(Genel.Th1AraDeger,4);//((((Genel.Th1AraDeger % 10000) % 1000) % 100) / 10) + 48;
								TextBuffer[3] = '.';
								TextBuffer[4] = Dig(Genel.Th1AraDeger,5);//((((Genel.Th1AraDeger % 10000) % 1000) % 100) % 10) + 48;
								//Sens�r ar�zas� ( K�sa devre veya a��k devre ) olu�tu�unda ekranda �izgi �izgi g�z�ks�n
								if( Alarm.Word.Lcd1.Bit.TermalSensor1Ariza )
								{ TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; }
							}
							else
							{
								TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; 
							}	
							TextBuffer[5] = *(Ayar_PanelOpt[Menu.AyarEtiket][3]);
							TextBuffer[6] = *(Ayar_PanelOpt[Menu.AyarEtiket][3] + 1);
							TextBuffer[7] = *(Ayar_PanelOpt[Menu.AyarEtiket][3] + 2);
				//			LcdFonk(AyarAltMenu[48],Menu.AyarAlt,0,1,3);
							ASendText(50,(150+272),AyarAltMenu[48],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						}
						else if( z4 == 3423 )
						{		
							//Termal sens�r2 TH2 aktifse �l��m yazar.
							if( EeKayit.Konfig.Bit.TermalSensor2 )
							{
								Genel.Th2AraDeger = EeKayit.TermalSensor2.Olculen;
								TextBuffer[0] = ' ';
								if( Genel.Th2AraDeger > 32767 )
								{
									Genel.Th2AraDeger = 65536 - Genel.Th2AraDeger;
									TextBuffer[0] = '-';
								}
								TextBuffer[1] = Dig(Genel.Th2AraDeger,3);//(((Genel.Th2AraDeger % 10000) % 1000) / 100) + 48;
								TextBuffer[2] = Dig(Genel.Th2AraDeger,4);//((((Genel.Th2AraDeger % 10000) % 1000) % 100) / 10) + 48;
								TextBuffer[3] = '.';
								TextBuffer[4] = Dig(Genel.Th2AraDeger,5);//((((Genel.Th2AraDeger % 10000) % 1000) % 100) % 10) + 48;	
								//Sens�r ar�zas� ( K�sa devre veya a��k devre ) olu�tu�unda ekranda �izgi �izgi g�z�ks�n
								if( Alarm.Word.Lcd1.Bit.TermalSensor2Ariza )
								{ TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' ';  }
							}
							else
							{
								TextBuffer[0] = ' '; TextBuffer[1] = '-'; TextBuffer[2] = '-'; TextBuffer[3] = ' '; TextBuffer[4] = ' '; 
							}
							TextBuffer[5] = *(Ayar_PanelOpt[Menu.AyarEtiket][3]);
							TextBuffer[6] = *(Ayar_PanelOpt[Menu.AyarEtiket][3] + 1);
							TextBuffer[7] = *(Ayar_PanelOpt[Menu.AyarEtiket][3] + 2);
				//			LcdFonk(AyarAltMenu[48],Menu.AyarAlt,0,1,3);
							ASendText(50,(150+272),AyarAltMenu[48],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						}
						else
						{
				//			LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
							TextBuffer[0] = UPS_IO_OPTIONS(Ayar_PanelOpt[Menu.AyarEtiket][4],TextBuffer[0]);
							ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
						}
					}
				}
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
		//		OkGoster(1,LokalAyarAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break; 
		case DefAcGiris:	
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 12;
				
	
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_AcInput[Menu.AyarEtiket][0] + z4); 
			//	LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_AcInput[Menu.AyarEtiket][1] + 128; 
				Can.AyarMenuDizisi[1] = Ayar_AcInput[Menu.AyarEtiket][2]; 
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
			//	LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				TextBuffer[1] = *(Ayar_AcInput[Menu.AyarEtiket][3]);
				TextBuffer[2] = *(Ayar_AcInput[Menu.AyarEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_AcInput[Menu.AyarEtiket][3] + 2);	
				
				if(( Can.AyarMenuDizisi[1] == 2019) || ( Can.AyarMenuDizisi[1] == 2020) || ( Can.AyarMenuDizisi[1] == 2021))
				{
					TextBuffer[0] = Menu.AyarSonuc;
			//		LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcInput[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}	
				else if(( Can.AyarMenuDizisi[1] == 2283) || ( Can.AyarMenuDizisi[1] == 2284) || ( Can.AyarMenuDizisi[1] == 2285))
				{
					TextBuffer[0] = Menu.AyarSonuc;
					// - de�er yazd�rmak i�in konuldu.
					if( Menu.AyarSonuc > 32767 )
					{
						TextBuffer[0] = 65536 - TextBuffer[0];
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcInput[Menu.AyarEtiket][4],TextBuffer[0]);
			//			LcdFonk(AyarAltMenu[46],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[46],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					}			
					else				
					{	
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcInput[Menu.AyarEtiket][4],TextBuffer[0]);
			//			LcdFonk(AyarAltMenu[47],Menu.AyarAlt,0,1,3); 
						ASendText(50,(150+272),AyarAltMenu[47],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					}
				}	
				else if(( Can.AyarMenuDizisi[1] == 2014) || ( Can.AyarMenuDizisi[1] == 2015) || ( Can.AyarMenuDizisi[1] == 2016))
				{
					TextBuffer[0] = Menu.AyarSonuc;
					// - de�er yazd�rmak i�in konuldu.
					if( Menu.AyarSonuc > 32767 )
					{
						TextBuffer[0] = 65536 - TextBuffer[0];
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcInput[Menu.AyarEtiket][4],TextBuffer[0]);
			//			LcdFonk(AyarAltMenu[46],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[46],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					}				
					else				
					{	
			//			LcdFonk(AyarAltMenu[47],Menu.AyarAlt,0,1,3); 
						ASendText(50,(150+272),AyarAltMenu[47],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					}
				}
				else
				{
					TextBuffer[0] = Menu.AyarSonuc;
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcInput[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
			//	OkGoster(1,LokalAyarAltMenu);
			//	LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);	
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefAcBypass:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 5;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_AcBypass[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_AcBypass[Menu.AyarEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_AcBypass[Menu.AyarEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_AcBypass[Menu.AyarEtiket][3]);
				TextBuffer[2] = *(Ayar_AcBypass[Menu.AyarEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_AcBypass[Menu.AyarEtiket][3] + 2);	
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcBypass[Menu.AyarEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
		
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in			
		//		OkGoster(1,LokalAyarAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefAcCikis:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 11;
		
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_AcOutput[Menu.AyarEtiket][0] + z4); 							
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_AcOutput[Menu.AyarEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_AcOutput[Menu.AyarEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;						
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_AcOutput[Menu.AyarEtiket][3]);
				TextBuffer[2] = *(Ayar_AcOutput[Menu.AyarEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_AcOutput[Menu.AyarEtiket][3] + 2);	
				
				if(( Can.AyarMenuDizisi[1] == 1050) || ( Can.AyarMenuDizisi[1] == 1051) || ( Can.AyarMenuDizisi[1] == 1052))
				{
					TextBuffer[0] = Menu.AyarSonuc;
					// - de�er yazd�rmak i�in konuldu.
					if( Menu.AyarSonuc > 32767 )
					{
						TextBuffer[0] = 65536 - TextBuffer[0];
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcOutput[Menu.AyarEtiket][4],TextBuffer[0]);
				//		LcdFonk(AyarAltMenu[46],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[46],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
					}			
					else				
					{
				//		LcdFonk(AyarAltMenu[47],Menu.AyarAlt,0,1,3);
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcOutput[Menu.AyarEtiket][4],TextBuffer[0]);
						ASendText(50,(150+272),AyarAltMenu[47],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
					}
				}
				else
				{
					TextBuffer[0] = Menu.AyarSonuc;
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_AcOutput[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
			//	OkGoster(1,LokalAyarAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;				
		case DefDcAyar:		
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 12;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_DcAdj[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_DcAdj[Menu.AyarEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_DcAdj[Menu.AyarEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);			
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);						
						
				TextBuffer[1] = *(Ayar_DcAdj[Menu.AyarEtiket][3]);
				TextBuffer[2] = *(Ayar_DcAdj[Menu.AyarEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_DcAdj[Menu.AyarEtiket][3] + 2);
				
				if(( Can.AyarMenuDizisi[1] == 2169) || ( Can.AyarMenuDizisi[1] == 2032) || ( Can.AyarMenuDizisi[1] == 2033))
				{
					TextBuffer[0] = Menu.AyarSonuc;
		//			LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_DcAdj[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}	
				else if(( Can.AyarMenuDizisi[1] == 2040) || ( Can.AyarMenuDizisi[1] == 2041))
				{
					TextBuffer[0] = Menu.AyarSonuc;
					// - de�er yazd�rmak i�in konuldu.
					if( Menu.AyarSonuc > 32767 )
					{
						TextBuffer[0] = 65536 - TextBuffer[0];
			//			LcdFonk(AyarAltMenu[46],Menu.AyarAlt,0,1,3);
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_DcAdj[Menu.AyarEtiket][4],TextBuffer[0]);
						ASendText(50,(150+272),AyarAltMenu[46],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					}			
					else				
					{	
			//			LcdFonk(AyarAltMenu[47],Menu.AyarAlt,0,1,3); 
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_DcAdj[Menu.AyarEtiket][4],TextBuffer[0]);
						ASendText(50,(150+272),AyarAltMenu[47],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
					}
				}
				else if( Can.AyarMenuDizisi[1] == 2034)
				{
					TextBuffer[0] = Menu.AyarSonuc;
			//		LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_DcAdj[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}	
				else
				{
					TextBuffer[0] = Menu.AyarSonuc;
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_DcAdj[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				}
				
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
			//	OkGoster(1,LokalAyarAltMenu);
			//	LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;							
		case DefGucSecenek:			
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarAlt_2_AltLimit = 0;
				Menu.AyarAlt_2_UstLimit = 25;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z4 = 0;z4 < 20;z4++)
					TextBuffer[z4] =  *(Ayar_Power[Menu.AyarEtiket][0] + z4); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_Power[Menu.AyarEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_Power[Menu.AyarEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);	
				
				TextBuffer[1] = *(Ayar_Power[Menu.AyarEtiket][3]);
				TextBuffer[2] = *(Ayar_Power[Menu.AyarEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_Power[Menu.AyarEtiket][3] + 2);

				if(( Can.AyarMenuDizisi[1] == 1118) || ( Can.AyarMenuDizisi[1] == 1119) || ( Can.AyarMenuDizisi[1] == 1120))
				{
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
					if( Can.FromInv.Digit == 1 )
				//		LcdFonk(AyarAltMenu[41],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[41],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
					if( Can.FromInv.Digit == 0 )
				//		LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				}	
				else if(( Can.AyarMenuDizisi[1] == 1167))
				{
					TextBuffer[0] = Menu.AyarSonuc * 10;
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				}
				else if(( Can.AyarMenuDizisi[1] == 1231))
				{
					TextBuffer[0] = (long)((Menu.AyarSonuc * 33) / 10 );
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				}
				else if(( Can.AyarMenuDizisi[1] == 1204))
				{
					//TextBuffer[0] = (Menu.AyarSonuc / 100);
					TextBuffer[0] = (Menu.AyarSonuc / 10);				//10.01.2013 tarihinde H�seyin Abi taraf�ndan de�i�tirtildi.
			//		LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				}
				else if(( Can.AyarMenuDizisi[1] == 1206))
				{
					TextBuffer[0] = (Menu.AyarSonuc * 60);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				}	
				else if(( Can.AyarMenuDizisi[1] == 1418) || ( Can.AyarMenuDizisi[1] == 1419) || ( Can.AyarMenuDizisi[1] == 1420))
				{
					TextBuffer[0] = Menu.AyarSonuc;
					// - de�er yazd�rmak i�in konuldu.
					if( Menu.AyarSonuc > 32767 )
					{
						TextBuffer[0] = 65536 - TextBuffer[0];
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
			//			LcdFonk(AyarAltMenu[46],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[46],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
					}			
					else				
					{	
						TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
			//			LcdFonk(AyarAltMenu[47],Menu.AyarAlt,0,1,3);
						ASendText(50,(150+272),AyarAltMenu[47],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil); 
					}
				}
				else
				{
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_Power[Menu.AyarEtiket][4],TextBuffer[0]);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarAltSil);
				}
				AyarSecenekOK2(LokalAyarAltMenu,LokalAyarAltSil);

/*		Optimizasyon i�in
			//	OkGoster(1,LokalAyarAltMenu);
			//	LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;			
		default:
		break;
	}	
	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,LokalAyarAltSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,LokalAyarAltSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,LokalAyarAltSil);
	OptimizasyonFonk4(LokalAyarAltSil);
}

void FonkAyarGrupAltMenu(unsigned int LokalAyarGrupAnaMenu,unsigned int LokalAyarGrupAltMenu,unsigned int LokalAyarGrupAltSil)
{
	unsigned int z6,i6,z7;
	
	//4.Sat�rda alarmlar g�r�nmesin.
//	Genel.AlarmGosterilmesinBiti = 1;
	
	//Ayar men�s� grup alt men�s�nde oldu�unu g�sterir.
	Menu.Sekme.All = DefAyarGrupAltMenu;		
	//Sadece Enter - Exit men�s� g�sterilirken 1 olur.
	Menu.EnterExit = 0;
	
	//Menu Limitleri
	Menu.GrupAltLimit = 0;
	Menu.GrupUstLimit = 2;
//	LcdFonk("                    ",&Menu.aDummy,0,1,4);
	
	if( Menu.Buton.Bit.bAsagi )
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0xffffff,LokalAyarGrupAltSil);
	else
		BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,LokalAyarGrupAltSil);
	if( Menu.Buton.Bit.bYukari )
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0xffffff,LokalAyarGrupAltSil);
	else
		BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,LokalAyarGrupAltSil);
	if( Menu.Buton.Bit.bEnter )
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0xffffff,LokalAyarGrupAltSil);
	else
		BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,LokalAyarGrupAltSil);
		
		
	if( LokalAyarGrupAltMenu == 2 )
		Menu.EnterExit = 1;
	else
		Menu.EnterExit = 0;
	//Hangi Grubun alt�nda oldu�unu bir �st sat�rda Beyaz yazs�n.	
	TextBufferLong[0] = AyarAltMenulerRenk[2][Menu.EnterExit];
	for(z7 = 0;z7 < 20;z7++)
		TextBuffer[z7] =  *(Ayar_GrupAdj[LokalAyarGrupAnaMenu][0] + z7); 
	ASendText(50,(80+272),AyarAltMenu[50],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
	
	TextBufferLong[0] = AyarAltMenulerRenk[1][Menu.EnterExit];
	switch(LokalAyarGrupAnaMenu)
	{
		case DefGrup_2192:	
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 14;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[1] = *(Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][3] + 2);						
				
				if( Can.AyarMenuDizisi[1] == 2211)
				{
					TextBuffer[0] = Menu.AyarSonuc;
		//			LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}	
				else
				{
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2192[Menu.AyarGrupEtiket][4],TextBuffer[0]);
		//			LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_2193:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 1;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][3] + 2);
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2193[Menu.AyarGrupEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
				
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in	
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_2194:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 1;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][3] + 2);
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2194[Menu.AyarGrupEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
				
				
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in	
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_2185:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 3;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][3] + 2);
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2185[Menu.AyarGrupEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
				
				
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in	
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_2142:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 1;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
										
										
				//Frekanslar� g�sterirken ki i�lemler
				if(( Can.AyarMenuDizisi[1] == 2144 ) || ( Can.AyarMenuDizisi[1] == 2143 ))
				{
					if( Menu.AyarSonuc > 0 )
						TextBuffer[0] = (long)( 780500 / Menu.AyarSonuc );
					else
						TextBuffer[0] = Menu.AyarSonuc;								
					
					TextBuffer[1] = *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][3] + 2);
		//			LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				else
				{
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][3] + 2);
		//			LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2142[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_1187:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 10;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][3] + 2);
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1187[Menu.AyarGrupEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
	
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in			
				
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_1136:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 7;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);	
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				//Frekanslar� g�sterirken ki i�lemler
				if(( Can.AyarMenuDizisi[1] == 1140) || ( Can.AyarMenuDizisi[1] == 1141 ))
				{
					if( Menu.AyarSonuc > 0 )
						TextBuffer[0] = (long)( 3129000 / Menu.AyarSonuc );
					else
						TextBuffer[0] = Menu.AyarSonuc;									
									
					TextBuffer[1] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				//Frekanslar� g�sterirken ki i�lemler
				else if(( Can.AyarMenuDizisi[1] == 1137))
				{
					if( Menu.AyarSonuc > 0 )
						TextBuffer[0] = (long)( 3129000 / Menu.AyarSonuc );
					else
						TextBuffer[0] = Menu.AyarSonuc;							
									
					TextBuffer[1] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[3],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[3],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				else
				{											
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][3] + 2);
			//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1136[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in
			//	OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		case DefGrup_1181:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				//Menu.AyarGrupUstLimit = 7;
				Menu.AyarGrupUstLimit = 6;			//07.04.2014
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				if(( Can.AyarMenuDizisi[1] == 1221))
				{
					TextBuffer[0] = Menu.AyarSonuc * 2;
					
					TextBuffer[1] = *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][3] + 2);
		//			LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}	
				else
				{							
					TextBuffer[0] = Menu.AyarSonuc;
					TextBuffer[1] = *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][3]);
					TextBuffer[2] = *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][3] + 1);
					TextBuffer[3] = *(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][3] + 2);
		//			LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
					TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1181[Menu.AyarGrupEtiket][4],TextBuffer[0]);
					ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				}
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;	
		case DefGrup_2233:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 2;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][3] + 2);
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_2233[Menu.AyarGrupEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;	
		case DefGrup_1233:
				//AltMen� Limitleri (Etiket limitleri)
				Menu.AyarGrupAltLimit = 0;
				Menu.AyarGrupUstLimit = 2;
				
				//Ekrana gerekli doneleri yazd�rma i�lemleri
				for(z6 = 0;z6 < 20;z6++)
					TextBuffer[z6] =  *(Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][0] + z6); 
		//		LcdFonk(AyarAltMenu[0],Menu.AyarAlt,0,1,1);
				ASendText(50,(110+272),AyarAltMenu[0],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				Can.AyarMenuDizisi[0] = TextBuffer[0] = Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][1] + 128;
				Can.AyarMenuDizisi[1] = Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][2];
				Can.AyarMenuDizisi[2] = TextBuffer[1] = Menu.AyarAyar;
		//		LcdFonk(AyarAltMenu[1],Menu.AyarAlt,0,1,2);
				ASendText(50,(130+272),AyarAltMenu[1],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				TextBuffer[0] = Menu.AyarSonuc;
				TextBuffer[1] = *(Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][3]);
				TextBuffer[2] = *(Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][3] + 1);
				TextBuffer[3] = *(Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][3] + 2);
		//		LcdFonk(AyarAltMenu[2],Menu.AyarAlt,0,1,3);
				TextBuffer[0] = UPS_IO_OPTIONS(Ayar_GrupAdj_1233[Menu.AyarGrupEtiket][4],TextBuffer[0]);
				ASendText(50,(150+272),AyarAltMenu[2],2,AyarAltMenulerRenk[0][Menu.EnterExit],NOTGRADIENTCOLOR,LokalAyarGrupAltSil);	
				
				
				AyarSecenekOK2(LokalAyarGrupAltMenu,LokalAyarGrupAltSil);

/*		Optimizasyon i�in
		//		OkGoster(1,LokalAyarGrupAltMenu);
		//		LcdFonk(AyarAltMenu[48],&Menu.aDummy,1,1,1);
				ASendText(50,(190+272),AyarAltMenu[49],2,0x888888,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
			//	ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(150+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(150+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(150+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(170+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(320,(170+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(170+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
								
			//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,1);
				ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,1);
				switch(LokalAyarGrupAltMenu)
				{
					case 0:
				//		ASendText(300,(110+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(110+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(110+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 1:
					//	ASendText(300,(130+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(320,(130+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(130+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
					break;
					case 2:
					//	ASendText(300,(190+272),"<>",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(260,(190+272),">",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(40,(190+272),"<",2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						ASendText(50,(190+272),AyarAltMenu[49],2,0xffffff,NOTGRADIENTCOLOR,LokalAyarGrupAltSil);
						Menu.EnterExit = 1;
					break;
					default:
					break;
				}	
*/
		break;
		default:
		break;
	}
	//BigOutVar(415,183+272,0,ScrollDownOk,0,0,0x888888,LokalAyarGrupAltSil);
	//BigOutVar(415,67+272,0,ScrollUpOk,0,0,0x888888,LokalAyarGrupAltSil);
	//BigOutVar(415,125+272,0,OrtaNokta,0,0,0x888888,LokalAyarGrupAltSil);
	OptimizasyonFonk4(LokalAyarGrupAltSil);
}

//Bak�m alarmlar� kontrol
void BakimAlarmKontrol(unsigned int Bakim_i)
{	
	//Ge�en s�re ayarlanan s�reye e�itse alarm verilir.Fakat Ge�en s�re b�y�kse s�re ge�meye devam eder ekranda - yaz�l�r.
	if( EeKayit.Bakim[Bakim_i].Iptal == 0 )
	{
		if( EeKayit.Bakim[Bakim_i].AyarlananSure <= EeKayit.Bakim[Bakim_i].GecenSure )
		{
			//if( Bakim_i == DefYedekBakim )
			//	Alarm.Word.Lcd1.Bit.OpsiyonBakimZamani = 1;
			if( Bakim_i == DefFanBakim )
				Alarm.Word.Lcd1.Bit.FanBakimZamani = 1;
			if( Bakim_i == DefAkuBakim )
				Alarm.Word.Lcd1.Bit.AkuBakimZamani = 1;
			if( Bakim_i == DefGenelBakim )
				Alarm.Word.Lcd1.Bit.GenelBakimZamani = 1;
			EeKayit.Bakim[Bakim_i].KalanSure = EeKayit.Bakim[Bakim_i].GecenSure - EeKayit.Bakim[Bakim_i].AyarlananSure;
		}				
		else
		{
			//if( Bakim_i == DefYedekBakim )
			//	Alarm.Word.Lcd1.Bit.OpsiyonBakimZamani = 0;
			if( Bakim_i == DefFanBakim )
				Alarm.Word.Lcd1.Bit.FanBakimZamani = 0;
			if( Bakim_i == DefAkuBakim )
				Alarm.Word.Lcd1.Bit.AkuBakimZamani = 0;
			if( Bakim_i == DefGenelBakim )
				Alarm.Word.Lcd1.Bit.GenelBakimZamani = 0;
			EeKayit.Bakim[Bakim_i].KalanSure = EeKayit.Bakim[Bakim_i].AyarlananSure - EeKayit.Bakim[Bakim_i].GecenSure;
		}
		EeWordYaz( &EeKayit.Bakim[Bakim_i].KalanSure , EeKayit.Bakim[Bakim_i].KalanSure );
	}
}

void AkuFonk(void)
{
	//AkuBuffer[] dizisi Ak� Kalan s�re hesap program� i�in kullan�l�yor.
	AkuBuffer[6] = (Can.FromInv.AkuSayisi*10);
	AkuBuffer[7] = EeKayit.AkuAh;
	AkuBuffer[9] = EeKayit.AkuKolSayisi;
	AkuBuffer[11] = Can.FromInv.AkuSayisi;
	AkuBuffer[15] = 100;									//Sanal Fault say�s�
	AkuBuffer[12] = (int)((int)(8 * Alarm.Word.Pfc1.Bit.SebekeKesik) + ( Alarm.Word.Inv1.Bit.AkuZayifKes ));  
	
	if( ( Alarm.Word.Pfc1.Bit.SebekeKesik == 1 ) && ( Alarm.Word.Inv1.Bit.AkuZayifKes == 0 ) )
 	{
		AkuKapasite.OrnSay++;		
		AkuBuffer[16] = AkuKapasite.OrnSay;
		
		if(AkuKapasite.OrnSay > 59)
		{
			//Ortalama d�zg�n ��kmas� i�in 60 �rnek tamamlans�n diye.
			AkuKapasite.I_AkuTopOrt = AkuKapasite.I_AkuTopOrt + Can.FromPfc.SonucDisCbattC.Pos + Can.FromPfc.SonucDisCbattC.Neg;	
			
			AkuKapasite.OrnSay = 0;
			//AkuKapasite.I_AkuTopOrt unsigned int ---> unsigned long yap�ld� aksilik durumunda �nce buras� bak�lacak.
			AkuKapasite.I_SonDakika	= AkuKapasite.I_AkuTopOrt / 1200;
			
			AkuBuffer[2] = AkuKapasite.I_SonDakika;

			AkuKapasite.I_AkuTopOrt = 0;
			if( EeKayit.AkuAh > 0 )												//30.11.2012 tarihinde yenilendi.
				AkuKapasite.YuzdeI_SonDakika = ( AkuKolDizi[EeKayit.AkuKolSayisi] * AkuKapasite.I_SonDakika ) / EeKayit.AkuAh;
			
			AkuBuffer[3] = AkuKapasite.YuzdeI_SonDakika;

			if( AkuKapasite.YuzdeI_SonDakika < 420 )							//30.11.2012 tarihinde yenilendi.
				AkuKapasite.Sure_SonDakika = (EeKayit.AkuAh * 100) / Peukert[AkuKapasite.YuzdeI_SonDakika];
			
			AkuBuffer[10] = Peukert[AkuKapasite.YuzdeI_SonDakika];

			//Hangi ak� grubu d���kse o se�ilir.
			if( Can.FromPfc.RecDCBus.Pos > Can.FromPfc.RecDCBus.Neg )
				AkuKapasite.AkuVolt = Can.FromPfc.RecDCBus.Neg;
			else
				AkuKapasite.AkuVolt = Can.FromPfc.RecDCBus.Pos;
				
			AkuBuffer[4] = Can.FromPfc.RecDCBus.Pos;
			AkuBuffer[5] = Can.FromPfc.RecDCBus.Neg;

			if( AkuKapasite.AkuVolt > (Can.FromInv.AkuSayisi*10) )				//30.11.2012 tarihinde yenilendi.
				AkuKapasite.x = AkuKapasite.AkuVolt - (Can.FromInv.AkuSayisi*10);
			
			if( AkuKapasite.x < 151 )											//30.11.2012 tarihinde yenilendi.
			{
				if(Can.FromInv.AkuSayisi == 26)
					AkuKapasite.KalanAkuKap = AkuYuzdeKapasite[0][AkuKapasite.x];
				if(Can.FromInv.AkuSayisi == 30)
					AkuKapasite.KalanAkuKap = AkuYuzdeKapasite[1][AkuKapasite.x];			
				AkuKapasite.KalanAkuKap = AkuKapasite.KalanAkuKap / 10;	
			}
			
			AkuBuffer[8] = AkuKapasite.KalanAkuKap;

//			AkuKapasite.KalanTopEnerji = AkuKapasite.KalanAkuKap * EeKayit.AkuAh;
//			AkuKapasite.HarcananTopEnerji = AkuKapasite.TopEnerji - AkuKapasite.KalanTopEnerji;
//			AkuKapasite.TopEnerji = AkuKapasite.KalanTopEnerji;

//			AkuKapasite.KalanTopEnerji = AkuKapasite.KalanAkuKap * EeKayit.AkuAh;
//			AkuKapasite.HarcananTopEnerji = ( 100 - AkuKapasite.KalanAkuKap ) * EeKayit.AkuAh;
//			AkuKapasite.TopEnerji = AkuKapasite.KalanTopEnerji;


			AkuKapasite.KalanTopEnerji = AkuKapasite.KalanAkuKap * EeKayit.AkuAh;
			AkuKapasite.TopEnerji = AkuKapasite.KalanTopEnerji;
			
			

			

			if(AkuKapasite.Sure_SonDakika != 0)
				AkuKapasite.KalanSure = AkuKapasite.TopEnerji / AkuKapasite.Sure_SonDakika;
				
			Menu.AkuKalanSure = AkuKapasite.KalanSure;
			
			AkuBuffer[0] = AkuKapasite.KalanSure;
			
			//Yeni
			if( AkuKapasite.KalanSure != 0 )
				AkuKapasite.HarcananTopEnerji = AkuKapasite.TopEnerji / AkuKapasite.KalanSure;
			
			AkuBuffer[13] = AkuKapasite.KalanTopEnerji;
			AkuBuffer[14] = AkuKapasite.HarcananTopEnerji;	
			AkuKapasite.IlkDakikaGecti = 1;		
			
		}
		else
		{			
			AkuBuffer[1] = Can.FromPfc.SonucDisCbattC.Pos + Can.FromPfc.SonucDisCbattC.Neg;
			AkuKapasite.I_AkuTopOrt = AkuKapasite.I_AkuTopOrt + Can.FromPfc.SonucDisCbattC.Pos + Can.FromPfc.SonucDisCbattC.Neg;	
		}
	}
	else
	{
		AkuKapasite.IlkDakikaGecti = 0;	
		if( Alarm.Word.Inv1.Bit.AkuZayifKes == 0 )
		{
			AkuKapasite.I_AkuTopOrt = 0;
			AkuKapasite.OrnSay = 0;
			AkuKapasite.KalanSure = 0;
			AkuKapasite.TopEnerji = 100 * EeKayit.AkuAh;
			
			//DENENECEK
			//Ak� kapasite i�leminin cevab� Megatech G1 de kullan�l�yor.
			if( Can.FromPfc.RecDCBus.Pos > Can.FromPfc.RecDCBus.Neg )
				AkuKapasite.AkuVolt = Can.FromPfc.RecDCBus.Neg;
			else
				AkuKapasite.AkuVolt = Can.FromPfc.RecDCBus.Pos;
				
			AkuBuffer[4] = Can.FromPfc.RecDCBus.Pos;
			AkuBuffer[5] = Can.FromPfc.RecDCBus.Neg;


			if( AkuKapasite.AkuVolt > (Can.FromInv.AkuSayisi*10) )				//30.11.2012 tarihinde yenilendi.
				AkuKapasite.x = AkuKapasite.AkuVolt - (Can.FromInv.AkuSayisi*10);
			
			if( AkuKapasite.x < 151 )											//30.11.2012 tarihinde yenilendi.
			{
				if(Can.FromInv.AkuSayisi == 26)
					AkuKapasite.KalanAkuKap = AkuYuzdeKapasite[0][AkuKapasite.x];
				if(Can.FromInv.AkuSayisi == 30)
					AkuKapasite.KalanAkuKap = AkuYuzdeKapasite[1][AkuKapasite.x];			
			}
			AkuKapasite.KalanAkuKap = AkuKapasite.KalanAkuKap / 10;	
			AkuKapasite.KalanTopEnerji = AkuKapasite.KalanAkuKap * EeKayit.AkuAh;
			AkuKapasite.KalanSure = AkuKapasite.KalanTopEnerji / 1;
			if( AkuKapasite.KalanAkuKap == 83 )
				AkuKapasite.KalanAkuKap = 100;			
			
		}
	}
}

void MimikFonk(unsigned int  MimikSil)
{
    Menu.Sekme.All = DefAnaMenu;        //19.06.15 touch eklendi.
/*		
		//Mimik status ekran�		
		ExBigVariable(358,72,6,4,DefAnahtarPasif,0x888888,MimikSil);
		ExBigVariable(207,103,6,4,DefTrisorPasif,0x888888,MimikSil);
		
		ExBigVariable(63,152,6,4,DefAnahtarPasif,0x888888,MimikSil);
		ExBigVariable(156,152,6,4,DefPfcPasif,0x888888,MimikSil);
		ExBigVariable(259,152,6,4,DefInvPasif,0x888888,MimikSil);
		ExBigVariable(358,152,6,4,DefAnahtarPasif,0x888888,MimikSil);
		
		ExBigVariable(259,200,6,4,DefAnahtarPasif,0x888888,MimikSil);
		ExBigVariable(330,200,6,4,DefAkuBos,0x888888,MimikSil); 
		
		//Yatay �izgiler
		Line(36,357,87,87,0x888888,MimikSil);				//Giri� - Anahtar 		(Bak�m bypass)
		Line(406,432,87,87,0x888888,MimikSil);				//Anahtar - ��k�� 		(Bak�m bypass)
		
		Line(41,205,118,118,0x888888,MimikSil);				//Giri� - Trist�r		(Bypass)
		Line(255,331,118,118,0x888888,MimikSil);			//Trist�r - ��k��		(Bypass)

		Line(15,32,167,167,0x888888,MimikSil);				//Giri� - Ba�lant� Noktas�
		Line(41,62,167,167,0x888888,MimikSil);				//Ba�lant� Noktas� - Anahtar
		Line(110,155,167,167,0x888888,MimikSil);			//Anahtar - Pfc

		Line(204,226,167,167,0x888888,MimikSil);			//Pfc - Ba�lant� Noktas�	
		Line(236,258,167,167,0x888888,MimikSil);			//Ba�lant� Noktas� - Inv	

		Line(307,326,167,167,0x888888,MimikSil);			//Inv - Ba�lant� Noktas�
		Line(336,357,167,167,0x888888,MimikSil);			//Ba�lant� Noktas� - Anahtar

		Line(406,427,167,167,0x888888,MimikSil);			//Anahtar - Ba�lant� noktas�
		Line(437,452,167,167,0x888888,MimikSil);			//Ba�lant� noktasu - ��k��		
		
		Line(231,258,215,215,0x888888,MimikSil);			//Ba�lant� - Anahtar
		Line(307,330,215,215,0x888888,MimikSil);			//Anahtar - Ak�
		
		//Dikey �izgiler
		Line(36,36,87,113,0x888888,MimikSil);				//Giri�	- trist�r hizas�
		Line(36,36,123,162,0x888888,MimikSil);				//Trist�r hizas� - bak�m hizas�		
		Line(432,432,87,162,0x888888,MimikSil);				//��k��		
		Line(331,331,118,162,0x888888,MimikSil);			//Trist�r'den A�a��
		Line(231,231,162,215,0x888888,MimikSil);			//Ak� Anahtardan Yukar�
		
		//Ba�lant� noktalar�
		Circle(36,167,5,1,5,0x888888,MimikSil);				//Giri� alt
		Circle(36,118,5,1,5,0x888888,MimikSil);				//Giri� �st 
		Circle(231,167,5,1,5,0x888888,MimikSil);			//Ak� Anahtar ile Inv_Pfc aras� 
		Circle(331,167,5,1,5,0x888888,MimikSil);			//Trist�r ile Inv_Anahtar aras�
		Circle(432,167,5,1,5,0x888888,MimikSil);			//��k��
*/
	if( CalismaDurumu.Bit.Bit0 == 0 )	
	{
		//Giri�
		TextBufferLong[0] = 0x00ff00;
		TextBuffer[0] = Can.FromPfc.VinRMS.L1;
		ASendText(19,179,"� V",1,0x00ff00,NOTGRADIENTCOLOR,MimikSil);
		TextBufferLong[0] = 0xffff00;
		TextBuffer[0] = Can.FromPfc.VinRMS.L2;
		ASendText(19,189,"� V",1,0xffff00,NOTGRADIENTCOLOR,MimikSil);
		TextBufferLong[0] = 0xffffff;
		TextBuffer[0] = Can.FromPfc.VinRMS.L3;
		ASendText(19,199,"� V",1,0xffffff,NOTGRADIENTCOLOR,MimikSil);
		//��k��
		if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
			TextBuffer[0] = Can.FromInv.VoutRMS.L1;
		else if( Alarm.Word.Inv1.Bit.Bakimda )
			TextBuffer[0] = Can.FromInv.VbypRMS.L1;
		else
			TextBuffer[0] = 0;						
		TextBufferLong[0] = 0x00ff00;
		ASendText(413,179,"� V",1,0x00ff00,NOTGRADIENTCOLOR,MimikSil);
		
		if( Uart2.NumOfPhaseOut == 3 )
		{				
			TextBufferLong[0] = 0xffff00;
			if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
				TextBuffer[0] = Can.FromInv.VoutRMS.L2;
			else if( Alarm.Word.Inv1.Bit.Bakimda )
				TextBuffer[0] = Can.FromInv.VbypRMS.L2;
			else
				TextBuffer[0] = 0;
			ASendText(413,189,"� V",1,0xffff00,NOTGRADIENTCOLOR,MimikSil);
			TextBufferLong[0] = 0xffffff;
			if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
				TextBuffer[0] = Can.FromInv.VoutRMS.L3;
			else if( Alarm.Word.Inv1.Bit.Bakimda )
				TextBuffer[0] = Can.FromInv.VbypRMS.L3;
			else
				TextBuffer[0] = 0;
			ASendText(413,199,"� V",1,0xffffff,NOTGRADIENTCOLOR,MimikSil);
		}
		//DC
		TextBuffer[0] = Can.FromPfc.RecDCBus.Pos;
		TextBufferLong[0] = 0x00ff00;
		ASendText(180,206," � V",1,0x00ff00,NOTGRADIENTCOLOR,MimikSil);
		TextBuffer[0] = Can.FromPfc.RecDCBus.Neg;
		TextBufferLong[0] = 0xffff00;
		if( Can.FromPfc.RecDCBus.Neg == 0 )
			ASendText(180,216," � V",1,0xffff00,NOTGRADIENTCOLOR,MimikSil);
		else
			ASendText(180,216,"-� V",1,0xffff00,NOTGRADIENTCOLOR,MimikSil);
		
		ASendText(19,227,"L1",1,0x00ff00,NOTGRADIENTCOLOR,MimikSil);
		ASendText(49,227,"L2",1,0xffff00,NOTGRADIENTCOLOR,MimikSil);
		ASendText(79,227,"L3",1,0xffffff,NOTGRADIENTCOLOR,MimikSil);	
	//------------------------------------------------------------------------------------------------
	
	//	MimikDurum.Yatay.All = 1431655765;
	//	MimikDurum.Dikey.All = 341;
	//	MimikDurum.Bag.All = 341;
	//	MimikDurum.Sembol.All = 87381;	
	//	
	//	MimikDurum.Sembol.Bit.Nesne_10 = 1;
	//	MimikDurum.Sembol.Bit.Nesne_25 = 2;
	//	MimikDurum.Sembol.Bit.Nesne_26 = 2;	
	
		MimikDurum.Yatay.All = 1431655765;
		MimikDurum.Dikey.All = 341;
		MimikDurum.Bag.All = 341;
		MimikDurum.Sembol.All = 0x00001555000A555F;
		
			
		//Main Ok Ledi
		if( Alarm.Word.Pfc1.Bit.FrekansTol )
		{
			MimikDurum.Sembol.Bit.Nesne_9 = DefSari;
			MimikDurum.Sembol.Bit.Nesne_25 = DefAktif;
		}
		else if( Alarm.Word.Pfc1.Bit.AcGirisYuksek || Alarm.Word.Pfc1.Bit.SebekeKesik || Alarm.Word.Pfc1.Bit.BlackOut )	
		{
			MimikDurum.Yatay.Bit.Nesne_6 = DefGri;
		}
		
		if( Alarm.Word.Inv2.Bit.BypassKesik )
		{Can.FromInv.BypFreq = 0;}
		
		//Giri� Anahtar
		if( Alarm.Word.Pfc2.Bit.GirisKontaktorAcik )
		{
			MimikDurum.Sembol.Bit.Nesne_3 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_19 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_7 = DefGri;	
		}
		
		if( Alarm.Word.Pfc2.Bit.PfcDurakladi )	
		{
			MimikDurum.Sembol.Bit.Nesne_4 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_20 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_8 = DefGri;
		}
			
		if( Alarm.Word.Inv1.Bit.Bakimda || Alarm.Word.Inv1.Bit.ElleBypass || Alarm.Word.Inv2.Bit.CikisKesik || Alarm.Word.Inv2.Bit.CikisBypassta || Alarm.Word.Inv1.Bit.AcilKapatma || Alarm.Word.Inv3.Bit.InvStop)	
		{
			MimikDurum.Sembol.Bit.Nesne_5 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_21 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_10 = DefGri;
		}	
		
		//Out Switch	
		if(Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma)
		{
			MimikDurum.Sembol.Bit.Nesne_6 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_22 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_12 = DefGri;
		}
		
		if( Alarm.Word.Lcd1.Bit.AkuKontaktorAcik == 1 )	
		{
			MimikDurum.Sembol.Bit.Nesne_7 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_23 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_15 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_8 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_24 = DefPasif;
		}
		
		//Static Byp Ledi
		if( Alarm.Word.Inv2.Bit.BypassFrekans || Alarm.Word.Inv2.Bit.BypassVolt || Alarm.Word.Inv3.Bit.BypFazCevir )
		{
			MimikDurum.Sembol.Bit.Nesne_10 = DefSari;
			MimikDurum.Sembol.Bit.Nesne_26 = DefAktif;
		}
		else if( Alarm.Word.Inv2.Bit.BypassKesik )
		{
			MimikDurum.Sembol.Bit.Nesne_10 = DefSari;
			MimikDurum.Sembol.Bit.Nesne_26 = DefAktif;
			MimikDurum.Sembol.Bit.Nesne_2 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_18 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_3 = DefGri;
			MimikDurum.Yatay.Bit.Nesne_4 = DefGri;
			MimikDurum.Dikey.Bit.Nesne_4 = DefGri;
		}
		else if( Alarm.Word.Inv2.Bit.CikisKesik )
		{
			MimikDurum.Sembol.Bit.Nesne_2 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_18 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_4 = DefGri;
			MimikDurum.Dikey.Bit.Nesne_4 = DefGri;
		}
		else if(( Alarm.Word.Inv1.Bit.Bakimda == 0 ) && ( Alarm.Word.Inv1.Bit.ElleBypass == 0 ) && ( Alarm.Word.Inv2.Bit.CikisKesik == 0) && ( Alarm.Word.Inv2.Bit.CikisBypassta == 0 ) )
		{
			MimikDurum.Sembol.Bit.Nesne_2 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_18 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_4 = DefGri;
			MimikDurum.Dikey.Bit.Nesne_4 = DefGri;
		}
	
		//Maint. Byp.
		if( Alarm.Word.Inv1.Bit.Bakimda == 0 )
		{
			MimikDurum.Sembol.Bit.Nesne_1 = DefGri;
			MimikDurum.Sembol.Bit.Nesne_17 = DefPasif;
			MimikDurum.Yatay.Bit.Nesne_2 = DefGri;
			MimikDurum.Dikey.Bit.Nesne_3 = DefGri;
		}
		
		
		//Alarmlara ba�l� olmayanlar birbirlerine ba�l� olanlar.
		if( (MimikDurum.Yatay.Bit.Nesne_10 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_4 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_11 = DefGri;
			MimikDurum.Bag.Bit.Nesne_3 = DefGri;
		}
		if( MimikDurum.Yatay.Bit.Nesne_11 == DefGri )
		{
			MimikDurum.Yatay.Bit.Nesne_12 = DefGri;	
			MimikDurum.Sembol.Bit.Nesne_6 = DefGri;
		}
		if( MimikDurum.Yatay.Bit.Nesne_6 == DefGri )
		{
			MimikDurum.Yatay.Bit.Nesne_7 = DefGri;	
			MimikDurum.Sembol.Bit.Nesne_3 = DefGri;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_6 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_4 == DefGri))
		{
			MimikDurum.Yatay.Bit.Nesne_1 = DefGri;
			MimikDurum.Yatay.Bit.Nesne_3 = DefGri;
			MimikDurum.Yatay.Bit.Nesne_5 = DefGri;
			MimikDurum.Bag.Bit.Nesne_1 = DefGri;
			MimikDurum.Bag.Bit.Nesne_2 = DefGri;
		} 
		if( (MimikDurum.Yatay.Bit.Nesne_12 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_2 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_13 = DefGri;
			MimikDurum.Bag.Bit.Nesne_4 = DefGri;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_8 == DefGri) && (MimikDurum.Sembol.Bit.Nesne_7 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_9 = DefGri;
			MimikDurum.Bag.Bit.Nesne_5 = DefGri;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_2 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_12 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_13 = DefGri;
			MimikDurum.Bag.Bit.Nesne_4 = DefGri;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_10 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_4 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_11 = DefGri;
			MimikDurum.Bag.Bit.Nesne_3 = DefGri;
		}
		if( MimikDurum.Yatay.Bit.Nesne_11 == DefGri )
		{
			MimikDurum.Yatay.Bit.Nesne_12 = DefGri;	
			MimikDurum.Sembol.Bit.Nesne_6 = DefGri;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_6 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_4 == DefGri))
		{
			MimikDurum.Yatay.Bit.Nesne_1 = DefGri;
			MimikDurum.Yatay.Bit.Nesne_3 = DefGri;
			MimikDurum.Yatay.Bit.Nesne_5 = DefGri;
			MimikDurum.Bag.Bit.Nesne_1 = DefGri;
			MimikDurum.Bag.Bit.Nesne_2 = DefGri;
		} 
		if( (MimikDurum.Sembol.Bit.Nesne_4 == DefGri) && (MimikDurum.Sembol.Bit.Nesne_7 != DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_14 = DefSari;
			MimikDurum.Yatay.Bit.Nesne_15 = DefSari;
			MimikDurum.Bag.Bit.Nesne_5 = DefSari;
			MimikDurum.Dikey.Bit.Nesne_5 = DefSari;
			MimikDurum.Sembol.Bit.Nesne_7 = DefSari;
			MimikDurum.Sembol.Bit.Nesne_8 = DefSari;
			MimikDurum.Yatay.Bit.Nesne_9 = DefSari;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_8 == DefGri) && (MimikDurum.Sembol.Bit.Nesne_7 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_14 = DefGri;
			MimikDurum.Bag.Bit.Nesne_5 = DefGri;
			MimikDurum.Dikey.Bit.Nesne_5 = DefGri;
		}
		if( (MimikDurum.Yatay.Bit.Nesne_12 == DefGri) && (MimikDurum.Yatay.Bit.Nesne_2 == DefGri) )
		{
			MimikDurum.Yatay.Bit.Nesne_13 = DefGri;
			MimikDurum.Bag.Bit.Nesne_4 = DefGri;
		}
		
		FonkYatayCizgi(MimikSil);
		FonkDikeyCizgi(MimikSil);
		FonkNokta(MimikSil);
		FonkSembol(MimikSil);
	}
	
	if(( CalismaDurumu.Bit.Bit0 == 1 ) && ( Genel.UPSKapaliGeriSayac > 0 ))	
	{
		FonkYatayCizgi(1);
		FonkDikeyCizgi(1);
		FonkNokta(1);
		FonkSembol(1);
		//ASendText(90,136,GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,0);
		//Giri�
		TextBufferLong[0] = 0x00ff00;
		TextBuffer[0] = Can.FromPfc.VinRMS.L1;
		ASendText(19,179,"� V",1,0x00ff00,NOTGRADIENTCOLOR,1);
		TextBufferLong[0] = 0xffff00;
		TextBuffer[0] = Can.FromPfc.VinRMS.L2;
		ASendText(19,189,"� V",1,0xffff00,NOTGRADIENTCOLOR,1);
		TextBufferLong[0] = 0xffffff;
		TextBuffer[0] = Can.FromPfc.VinRMS.L3;
		ASendText(19,199,"� V",1,0xffffff,NOTGRADIENTCOLOR,1);
		//��k��
		if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
			TextBuffer[0] = Can.FromInv.VoutRMS.L1;
		else if( Alarm.Word.Inv1.Bit.Bakimda )
			TextBuffer[0] = Can.FromInv.VbypRMS.L1;
		else
			TextBuffer[0] = 0;						
		TextBufferLong[0] = 0x00ff00;
		ASendText(413,179,"� V",1,0x00ff00,NOTGRADIENTCOLOR,1);
		
		if( Uart2.NumOfPhaseOut == 3 )
		{
			TextBufferLong[0] = 0xffff00;
			if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
				TextBuffer[0] = Can.FromInv.VoutRMS.L2;
			else if( Alarm.Word.Inv1.Bit.Bakimda )
				TextBuffer[0] = Can.FromInv.VbypRMS.L2;
			else
				TextBuffer[0] = 0;
			ASendText(413,189,"� V",1,0xffff00,NOTGRADIENTCOLOR,1);
			TextBufferLong[0] = 0xffffff;
			if( (Alarm.Word.Inv2.Bit.CikisSalteri || Alarm.Word.Inv1.Bit.AcilKapatma) == 0 )
				TextBuffer[0] = Can.FromInv.VoutRMS.L3;
			else if( Alarm.Word.Inv1.Bit.Bakimda )
				TextBuffer[0] = Can.FromInv.VbypRMS.L3;
			else
				TextBuffer[0] = 0;
			ASendText(413,199,"� V",1,0xffffff,NOTGRADIENTCOLOR,1);
		}
		//DC
		TextBuffer[0] = Can.FromPfc.RecDCBus.Pos;
		TextBufferLong[0] = 0x00ff00;
		ASendText(180,206," � V",1,0x00ff00,NOTGRADIENTCOLOR,1);
		TextBuffer[0] = Can.FromPfc.RecDCBus.Neg;
		TextBufferLong[0] = 0xffff00;
		if( Can.FromPfc.RecDCBus.Neg == 0 )
			ASendText(180,216," � V",1,0xffff00,NOTGRADIENTCOLOR,1);
		else
			ASendText(180,216,"-� V",1,0xffff00,NOTGRADIENTCOLOR,1);
		
		ASendText(19,227,"L1",1,0x00ff00,NOTGRADIENTCOLOR,1);
		ASendText(49,227,"L2",1,0xffff00,NOTGRADIENTCOLOR,1);
		ASendText(79,227,"L3",1,0xffffff,NOTGRADIENTCOLOR,1);
	}
}




void FonkYatayCizgi(unsigned int yMimikSil)
{
	unsigned long YatayCizgiRenk[4] = { 0x888888,0x00ff00,0xffff00,0xff0000 };
	
	Line(36,357,87,87,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_1 ],yMimikSil);			//Yatay �izgi 1		Giri� - Anahtar 			(Bak�m bypass)
	Line(406,432,87,87,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_2 ],yMimikSil);			//Yatay �izgi 2		Anahtar - ��k�� 			(Bak�m bypass)
	Line(41,205,118,118,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_3 ],yMimikSil);			//Yatay �izgi 3		Giri� - Trist�r				(Bypass)
	Line(255,331,118,118,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_4 ],yMimikSil);			//Yatay �izgi 4		Trist�r - ��k��				(Bypass)
	Line(15,32,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_5 ],yMimikSil);			//Yatay �izgi 5		Giri� - Ba�lant� Noktas�	(Pfc - Inv)
	Line(41,62,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_6 ],yMimikSil);			//Yatay �izgi 6		Ba�lant� Noktas� - Anahtar	(Pfc - Inv)
	Line(110,155,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_7 ],yMimikSil);			//Yatay �izgi 7		Anahtar - Pfc				(Pfc - Inv)
	Line(204,226,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_8 ],yMimikSil);			//Yatay �izgi 8		Pfc - Ba�lant� Noktas�		(Pfc - Inv)
	Line(236,258,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_9 ],yMimikSil);			//Yatay �izgi 9		Ba�lant� Noktas� - Inv		(Pfc - Inv)
	Line(307,326,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_10 ],yMimikSil);		//Yatay �izgi 10	Inv - Ba�lant� Noktas�		(Pfc - Inv)
	Line(336,357,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_11 ],yMimikSil);		//Yatay �izgi 11	Ba�lant� Noktas� - Anahtar	(Pfc - Inv)
	Line(406,427,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_12 ],yMimikSil);		//Yatay �izgi 12	Anahtar - Ba�lant� noktas�	(Pfc - Inv)
	Line(437,452,167,167,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_13 ],yMimikSil);		//Yatay �izgi 13	Ba�lant� noktasu - ��k��	(Pfc - Inv)	
	Line(231,258,215,215,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_14 ],yMimikSil);		//Yatay �izgi 14	Ba�lant� - Anahtar			(Ak�)
	Line(307,330,215,215,YatayCizgiRenk[ MimikDurum.Yatay.Bit.Nesne_15 ],yMimikSil);		//Yatay �izgi 15	Anahtar - Ak�				(Ak�)
}

void FonkDikeyCizgi(unsigned int dMimikSil)
{	
	unsigned long DikeyCizgiRenk[4] = { 0x888888,0x00ff00,0xffff00,0xff0000 };
	
	Line(36,36,123,162,DikeyCizgiRenk[ MimikDurum.Dikey.Bit.Nesne_1 ],dMimikSil);			//Dikey �izgi 1		Trist�r hizas� - bak�m hizas�	
	Line(36,36,87,113,DikeyCizgiRenk[ MimikDurum.Dikey.Bit.Nesne_2 ],dMimikSil);			//Dikey �izgi 2		Giri�	- trist�r hizas�	
	Line(432,432,87,162,DikeyCizgiRenk[ MimikDurum.Dikey.Bit.Nesne_3 ],dMimikSil);			//Dikey �izgi 3		��k��		
	Line(331,331,118,162,DikeyCizgiRenk[ MimikDurum.Dikey.Bit.Nesne_4 ],dMimikSil);			//Dikey �izgi 4		Trist�r'den A�a��	
	Line(231,231,162,215,DikeyCizgiRenk[ MimikDurum.Dikey.Bit.Nesne_5 ],dMimikSil);			//Dikey �izgi 5		Ak� Anahtardan Yukar�	
}

void FonkNokta( unsigned int nMimikSil )
{
	unsigned long NoktaRenk[4] = { 0x888888,0x00ff00,0xffff00,0xff0000 };	
	
	Circle(36,118,5,1,5,NoktaRenk[ MimikDurum.Bag.Bit.Nesne_1 ],nMimikSil);					//Nokta 1			Giri� �st 
	Circle(36,167,5,1,5,NoktaRenk[ MimikDurum.Bag.Bit.Nesne_2 ],nMimikSil);					//Nokta 2			Giri� alt
	Circle(331,167,5,1,5,NoktaRenk[ MimikDurum.Bag.Bit.Nesne_3 ],nMimikSil);				//Nokta 3			Trist�r ile Inv_Anahtar aras�
	Circle(432,167,5,1,5,NoktaRenk[ MimikDurum.Bag.Bit.Nesne_4 ],nMimikSil);				//Nokta 4			��k��
	Circle(231,167,5,1,5,NoktaRenk[ MimikDurum.Bag.Bit.Nesne_5 ],nMimikSil);				//Nokta 5			Ak� Anahtar ile Inv_Pfc aras� 
}

void FonkSembol( unsigned int sMimikSil )
{
	unsigned long SembolRenk[4] = { 0x888888,0x00ff00,0xffff00,0xff0000 };	
	unsigned int AnahtarKonum[2] = { DefAnahtarPasif, DefAnahtarAktif };
	unsigned int TristorKonum[2] = { DefTrisorPasif, DefTrisorAktif };
	unsigned int PfcKonum[2] = { DefPfcPasif, DefPfcAktif };
	unsigned int InvKonum[2] = { DefInvPasif, DefInvAktif };
	unsigned int AkuKonum[4] = { DefAkuBos, DefAkuDolu1,DefAkuDolu2,DefAkuDolu3 };	
	unsigned int UyariKonum[2] = { 1,0 };
	
	if( sMimikSil == 1 )
	{
		MimikDurum.Sembol.Bit.Nesne_25 = 0;
		MimikDurum.Sembol.Bit.Nesne_26 = 0;
	}
	
	ExBigVariable(358,72,6,4,AnahtarKonum[ MimikDurum.Sembol.Bit.Nesne_17 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_1 ],sMimikSil);			//Sembol 1
	ExBigVariable(207,103,6,4,TristorKonum[ MimikDurum.Sembol.Bit.Nesne_18 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_2 ],sMimikSil);		//Sembol 2
	ExBigVariable(63,152,6,4,AnahtarKonum[ MimikDurum.Sembol.Bit.Nesne_19 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_3 ],sMimikSil);			//Sembol 3
	ExBigVariable(156,152,6,4,PfcKonum[ MimikDurum.Sembol.Bit.Nesne_20 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_4 ],sMimikSil);			//Sembol 4
	ExBigVariable(259,152,6,4,InvKonum[ MimikDurum.Sembol.Bit.Nesne_21 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_5 ],sMimikSil);			//Sembol 5
	ExBigVariable(358,152,6,4,AnahtarKonum[ MimikDurum.Sembol.Bit.Nesne_22 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_6 ],sMimikSil);		//Sembol 6
	ExBigVariable(259,200,6,4,AnahtarKonum[ MimikDurum.Sembol.Bit.Nesne_23 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_7 ],sMimikSil);		//Sembol 7
	ExBigVariable(330,200,6,4,AkuKonum[ MimikDurum.Sembol.Bit.Nesne_24 ],SembolRenk[ MimikDurum.Sembol.Bit.Nesne_8 ],sMimikSil); 			//Sembol 8	
	ExBigVariable(7,142,3,3,DefUyari,SembolRenk[ MimikDurum.Sembol.Bit.Nesne_9 ],UyariKonum[ MimikDurum.Sembol.Bit.Nesne_25 ]); 			//Sembol 9		//Split byp haricinde giri� ile byp ayn� o y�zden byp sorunu denmeli.
	ExBigVariable(117,90,3,3,DefUyari,SembolRenk[ MimikDurum.Sembol.Bit.Nesne_10 ],UyariKonum[ MimikDurum.Sembol.Bit.Nesne_26 ]); 			//Sembol 10		//Split bypass ta kullan�l�r.
	
}

/*
	G�nderilen paket[0] --> Wxxxx adres
	G�nderilen paket[1] --> Rxxxx adres
	G�nderilen paket[2] --> Set De�eri --> Menu.AyarAyar
	G�nderilen paket[3] --> 'R' veya 'W'
*/
void AyarAltMenuCanSorgu(unsigned int *AyarCanBuf)
{	
	unsigned int AyarCan_i;
	unsigned int *AyarRamAddr;
	unsigned int *AyarEeAddr;
	unsigned int AyarAraIslemAddr;
	unsigned int AyarAraIslemDeger;
		
	// Can.FromPfc.AyarDatasiGelmediSayac can den data gelince i�erisine 4 y�klenir.
	// 500 ms de bir buraya girdi�inden 4 x 500 ms sonra data gelmiyorsa data s�f�rlan�r.
	if((( *(AyarCanBuf + 1) / 1000 ) != 3) && (( *(AyarCanBuf + 4) / 1000 ) != 4) && (( *(AyarCanBuf + 4) / 1000 ) != 5) )		
	{
		//Kendi ram den data almak istedi�i zaman�n haricindeyken girer.
		if( Can.FromPfc.AyarDatasiGelmediSayac > 0 )
		{
			Can.FromPfc.AyarDatasiGelmediSayac--;
			if( Can.FromPfc.AyarDatasiGelmediSayac == 1 )
			{
				//Data gelmeyince ekran� s�f�rlar.
				Menu.Yenile = 1;
		//		Menu.AyarSonuc = 0;
			}
		}
	}
		
	if( *(AyarCanBuf + 3) == 'R')					
	{
		//Ayar men�s�nden sorgulananlar ise gir.
		if( (( *(AyarCanBuf + 4) / 1000 ) != 4) && (( *(AyarCanBuf + 4) / 1000 ) != 5) )
		{
			//Inverter e R1xxx sorgusu
			if( ( *(AyarCanBuf + 1) / 1000 ) == 1 )
				CanGonder(DefCanInv,30,'R',(*(AyarCanBuf + 1)-1000),(*AyarCanBuf - 1128) );
			//Pfc ye R2xxx sorgusu
			if(( *(AyarCanBuf + 1) / 1000 ) == 2)
				CanGonder(DefCanPfc,54,'R',(*(AyarCanBuf + 1)-2000),(*AyarCanBuf - 2128));
			//Ram den R3xxx sorgusuna gerek yok men�n�n i�erisinden hallediliyor.
		}
		else
		{
			//Ram den s�rekli sorgulanan de�erler ise gir.
			if(( *(AyarCanBuf + 4) / 1000 ) == 4)
				CanGonder(DefCanInv,28,'R',0,(*(AyarCanBuf + 4) - 4000) );
			if(( *(AyarCanBuf + 4) / 1000 ) == 5)
				CanGonder(DefCanPfc,55,'R',0,(*(AyarCanBuf + 4) - 5000) );
		}
	}
	//Adrese yazma
	if( *(AyarCanBuf + 3) == 'W')					
	{				
		if( Can.FromInv.LogInDurum == 1 )
		{
			//Ayar men�s�nden sorgulananlar ise gir.
			if( (( *(AyarCanBuf + 4) / 1000 ) != 4) && (( *(AyarCanBuf + 4) / 1000 ) != 5) )
			{				
				if(( *AyarCanBuf  / 1000 ) == 1)
				{
					Can.ToInv.AyarGonderilenData = *(AyarCanBuf + 2);
					CanGonder(DefCanInv,30,'W',(*(AyarCanBuf + 2)),(*AyarCanBuf - 1128));
				}
				if(( *AyarCanBuf  / 1000 ) == 2)
				{
					Can.ToPfc.AyarGonderilenData = *(AyarCanBuf + 2);
					CanGonder(DefCanPfc,54,'W',(*(AyarCanBuf + 2)),(*AyarCanBuf - 2128 ));
				}
				//Ram e W3xxx ile yazma
				if(( *AyarCanBuf  / 1000 ) == 3)
				{
					AyarRamAddr = ((*AyarCanBuf - 3000 ) << 1 ) + 2560;
					AyarAraIslemAddr = AyarRamAddr;
					AyarAraIslemAddr = (AyarAraIslemAddr-3302)/2;
					AyarAraIslemDeger = *(AyarCanBuf + 2);
					//Label lar haricindeki eeprom de�erleri min - max limitlerden ge�er.
					if((AyarRamAddr > 3300) && (AyarRamAddr < DefEepromDegiskenUstSinir))									
					{
						//Max - Min de�er kontrol�
						if( AyarAraIslemDeger > MinMax[AyarAraIslemAddr][MaxAddrKontrol] )
							AyarAraIslemDeger = MinMax[AyarAraIslemAddr][MaxAddrKontrol];
							
						if( ( AyarAraIslemDeger > MinMax[AyarAraIslemAddr][MinAddrKontrol] ) && ( AyarAraIslemDeger < MinMax[AyarAraIslemAddr][AraAddrKontrol] ) )
							AyarAraIslemDeger = MinMax[AyarAraIslemAddr][MinAddrKontrol];
										
						if( AyarAraIslemDeger < MinMax[AyarAraIslemAddr][MinAddrKontrol] )
							AyarAraIslemDeger = MinMax[AyarAraIslemAddr][MinAddrKontrol];	
					}	
					*AyarRamAddr = AyarAraIslemDeger;
					EeWordYaz( AyarRamAddr,*AyarRamAddr );
					
					if( (AyarRamAddr == 3396) || (AyarRamAddr == 3404) )
					{
						EeKayit.BeslemeIlk = Genel.Besleme;
						EeWordYaz( &EeKayit.BeslemeIlk , EeKayit.BeslemeIlk );								
					}
					
					
					//26.11.2014 te eklendi
					//Fan Bakim
					if( AyarRamAddr == 3316 )
					{
						//Datalar� ram den al�r ��nk� bir �nceki sat�rda ram e kay�t i�lemi ger�ekle�ir.
						EeKayit.Bakim[1].KalanSure = EeKayit.Bakim[1].AyarlananSure;
						EeKayit.Bakim[1].GecenSure = 0;
						//Alarm Varsa sil.
						Alarm.Word.Lcd1.Bit.FanBakimZamani = 0;
						EeKayit.Bakim[1].ServisSay++;
						
						if( EeKayit.Bakim[1].AyarlananSure == 0 )
							EeKayit.Bakim[1].Iptal = 1;
						else
							EeKayit.Bakim[1].Iptal = 0;
						//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
						EeWordYaz( &EeKayit.Bakim[1].Iptal , EeKayit.Bakim[1].Iptal );
						EeWordYaz( &EeKayit.Bakim[1].ServisSay , EeKayit.Bakim[1].ServisSay );
						EeWordYaz( &EeKayit.Bakim[1].GecenSure , EeKayit.Bakim[1].GecenSure );
						EeWordYaz( &EeKayit.Bakim[1].KalanSure , EeKayit.Bakim[1].KalanSure );
					}
					//Ak� Bakim
					if( AyarRamAddr == 3326 )
					{
						EeKayit.Bakim[2].KalanSure = EeKayit.Bakim[2].AyarlananSure;
						EeKayit.Bakim[2].GecenSure = 0;
						//Alarm Varsa sil.
						Alarm.Word.Lcd1.Bit.AkuBakimZamani = 0;
						EeKayit.Bakim[2].ServisSay++;
						
						if( EeKayit.Bakim[2].AyarlananSure == 0 )
							EeKayit.Bakim[2].Iptal = 1;
						else
							EeKayit.Bakim[2].Iptal = 0;
						//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
						EeWordYaz( &EeKayit.Bakim[2].Iptal , EeKayit.Bakim[2].Iptal );
						EeWordYaz( &EeKayit.Bakim[2].ServisSay , EeKayit.Bakim[2].ServisSay );
						EeWordYaz( &EeKayit.Bakim[2].GecenSure , EeKayit.Bakim[2].GecenSure );
						EeWordYaz( &EeKayit.Bakim[2].KalanSure , EeKayit.Bakim[2].KalanSure );
					}
					//Genel Bakim
					if( AyarRamAddr == 3336 )
					{
						EeKayit.Bakim[3].KalanSure = EeKayit.Bakim[3].AyarlananSure;
						EeKayit.Bakim[3].GecenSure = 0;
						//Alarm Varsa sil.
						Alarm.Word.Lcd1.Bit.GenelBakimZamani = 0;
						EeKayit.Bakim[3].ServisSay++;
						
						if( EeKayit.Bakim[3].AyarlananSure == 0 )
							EeKayit.Bakim[3].Iptal = 1;
						else
							EeKayit.Bakim[3].Iptal = 0;
						//Ayarlanan s�re zaten ilk kay�t i�leminde ger�ekle�ir.	
						EeWordYaz( &EeKayit.Bakim[3].Iptal , EeKayit.Bakim[3].Iptal );
						EeWordYaz( &EeKayit.Bakim[3].ServisSay , EeKayit.Bakim[3].ServisSay );
						EeWordYaz( &EeKayit.Bakim[3].GecenSure , EeKayit.Bakim[3].GecenSure );
						EeWordYaz( &EeKayit.Bakim[3].KalanSure , EeKayit.Bakim[3].KalanSure );
					}	
					
					Menu.BitIslemDatasiGeldi = 1;
					Menu.YenileGeriSayac = 10;
				}
			}
			else
			{
				//Ram den s�rekli sorgulanan de�erler ise gir.
				if(( *(AyarCanBuf + 4) / 1000 ) == 4)
					CanGonder(DefCanInv,28,'W',*(AyarCanBuf + 5),(*(AyarCanBuf + 4) - 4000) );
				if(( *(AyarCanBuf + 4) / 1000 ) == 5)
					CanGonder(DefCanPfc,55,'W',*(AyarCanBuf + 5),(*(AyarCanBuf + 4) - 5000) );
			}	
		}
	}
}




//--------------------------------------------------------------------



unsigned int HaneSifirSor(unsigned int HaneDeger,unsigned int Kacinci)
{
	unsigned int HaneSifirKontrol;
	
	switch(Kacinci)
	{
		case 4:
			HaneSifirKontrol = ((int)((HaneDeger % 10000) / 1000));
		break;
		case 3:								
			HaneSifirKontrol = ((int)(((HaneDeger % 10000) % 1000) / 100));	
		break;							
		case 2:
			HaneSifirKontrol = ((int)((((HaneDeger % 10000) % 1000) % 100) / 10));	
		break;						
		case 1:
			HaneSifirKontrol = ((int)((((HaneDeger % 10000) % 1000) % 100) % 10));
		break;
		default:
		break;
	}
	
	if(HaneSifirKontrol == 0)
		return(7);
	else
		return(HaneSifirKontrol);
}
void SifreAl(void)
{
	unsigned int Sifre_i;
	
	//Men�n�n i�erisinde de�i�tirilen �ifrenin i�eri�ini s�f�rla.
	for(Sifre_i = 0;Sifre_i < 8;Sifre_i++)
		Menu.GolgeSifre[Sifre_i] = 48;
	//Bu bit sadece Ayar men�s�ndeyken 1 olur. Ayar men�s�nde iken login olmaya �al��an pc buraya kod istemeye gelirken 
	//sen e�er password girmeye �al���rsan kitleme i�lmei olabiliyor.Engellemek i�in
	if( Genel.AlarmGosterilmesinBiti == 0 )
		Menu.HaneDegistir = 0;
	//Yeni Servis kodu al.
	Menu.ServisKodH = TMR1 & 9999;
	Menu.ServisKodL = TMR9 & 9999;
/*
	Menu.ServisKodH = XXXX
	Basamak -->	   4321
	�arpan	-->	   1234

	Menu.ServisKodL = YYYY
	Basamak -->	   4321
	�arpan	-->	   5678

	Toplam(Menu.SifreToplam) --> [ [ X(4) * 1 + X(3) * 2 + X(2) * 3 + X(1) * 4 ] + [ Y(4) * 1 + Y(3) * 2 + Y(2) * 3 + Y(1) * 4 ] ] % 127
*/
	Menu.SifreToplam = 0;
	for(Sifre_i=1;Sifre_i<5;Sifre_i++)      
	{
		Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodH,5-Sifre_i) * Sifre_i + HaneSifirSor(Menu.ServisKodL,5-Sifre_i) * (Sifre_i+4); 
	}
	Menu.SifreToplam = Menu.SifreToplam & 127;
							
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodH,4) * 1;
	Menu.Sifre[7] = SifreAnahtari[Menu.SifreToplam & 127];
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodH,3) * 2;
	Menu.Sifre[6] = SifreAnahtari[Menu.SifreToplam & 127]; 
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodH,2) * 3;
	Menu.Sifre[5] = SifreAnahtari[Menu.SifreToplam & 127]; 
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodH,1) * 4;
	Menu.Sifre[4] = SifreAnahtari[Menu.SifreToplam & 127];
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodL,4) * 5;
	Menu.Sifre[3] = SifreAnahtari[Menu.SifreToplam & 127];
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodL,3) * 6;
	Menu.Sifre[2] = SifreAnahtari[Menu.SifreToplam & 127]; 
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodL,2) * 7;
	Menu.Sifre[1] = SifreAnahtari[Menu.SifreToplam & 127]; 
	Menu.SifreToplam = Menu.SifreToplam + HaneSifirSor(Menu.ServisKodL,1) * 8;
	Menu.Sifre[0] = SifreAnahtari[Menu.SifreToplam & 127];	
	Menu.SifreH = Menu.Sifre[7] * 1000 + Menu.Sifre[6] * 100 + Menu.Sifre[5] * 10 + Menu.Sifre[4];
	Menu.SifreL = Menu.Sifre[3] * 1000 + Menu.Sifre[2] * 100 + Menu.Sifre[1] * 10 + Menu.Sifre[0];
}					
unsigned int BasitSifreDogrula(void)
{
	unsigned int BasitSifre_i;
	unsigned int BasitDogrula = 0;
	
	for(BasitSifre_i = 0;BasitSifre_i < 8;BasitSifre_i++)
	{
		if( EeKayit.BasitPassword[BasitSifre_i] == ( Menu.GolgeSifre[BasitSifre_i]))
			BasitDogrula++;
	}
	if(BasitDogrula > 7)
		return 1;
	else
		return 0;
}
unsigned int SifreDogrula(void)
{
	unsigned int Sifre_i;
	unsigned int Dogrula = 0;
	
	for(Sifre_i = 0;Sifre_i < 8;Sifre_i++)
	{
		if(Menu.Sifre[7-Sifre_i] == ( Menu.GolgeSifre[Sifre_i]-48 ))
			Dogrula++;
	}
	if(Dogrula > 7)
		return 1;
	else
		return 0;
}
unsigned int UserSifreDogrula(void)
{
	unsigned int UserSifre_i;
	unsigned int UserDogrula = 0;
	
	for(UserSifre_i = 0;UserSifre_i < 4;UserSifre_i++)
	{
		if( EeKayit.UserPassword [UserSifre_i] == ( Menu.UserGolgeSifre[UserSifre_i] ))
			UserDogrula++;
	}
	if(UserDogrula > 3)
		return 1;
	else
		return 0;
}
void RoleIslem(unsigned int KacinciRole,unsigned int SetReset)
{
	if(( Alarm.Word.Lcd1.Bit.PfcCommErr == 0 ) && ( Alarm.Word.Lcd1.Bit.InvCommErr == 0 ))
	{	
		switch(KacinciRole)
		{
			case 0:
					Relay1 = SetReset;
			break;
			case 1:
					Relay2 = SetReset;
			break;
			case 2:
					Relay3 = SetReset;
			break;
			case 3:
					Relay4 = SetReset;
			break;
			case 4:
					Relay5 = SetReset;
			break;
			case 5:
					Relay6 = SetReset;
			break;
			case 6:
					Relay7 = SetReset;
			break;
			case 7:
					Relay8 = SetReset;
			break;
			case 8:
					Relay9 = SetReset;
			break;
			case 9:
					Relay10 = SetReset;
			break;
			case 10:
					Relay11 = SetReset;
			break;
			case 11:
					Relay12 = SetReset;
			break;
			case 12:
					SnmpRelay = SetReset;
			break;
			default:
			break;
		}
	}
}

//IN1 , IN2 , IN3 , IN4 pinlerine ait fonksiyon
void InPinsTara(void)
{			
	Timer.Bit.Sn0_05__1 = 0;
	
//	Timer.Bit.Sn0_25 = 0; 					//22.07.14 silindi
	
	if( EeKayit.GENIN_NoNc > 1 )			//12.03.2014
		EeKayit.GENIN_NoNc = 0;
	if( EeKayit.GENIN_NoNc < 0 )
		EeKayit.GENIN_NoNc = 1;
	if( EeKayit.EPO_NoNc > 1 )
		EeKayit.EPO_NoNc = 0;
	if( EeKayit.EPO_NoNc < 0 )
		EeKayit.EPO_NoNc = 1;
	//Jenerat�r modu
	//if( ( GENIN1 == 0 ) && ( Menu.GenInSayac == 0 ) )	
	if( ( GENIN1 == EeKayit.GENIN_NoNc ) && ( Menu.GenInSayac == 0 ) )			//12.03.2014													
	{			
		if( ++Genel.GenInSayac > 30)											//22.07.14   5 idi 30 yap�ld�
		{	
	//		Timer.Bit.Sn0_25 = 0; 
			Genel.GenInSayac = 0;
			//10 sn i�in
			Menu.GenInSayac = 40;
			//Generat�re ge� emri ,ben bunu g�ndermezsem belli bir s�re sonra sistem Normal moda kendi ge�iyor.
			if( EeKayit.Konfig.Bit.JeneratorVarYok == 1 )						//22.07.14
				CanGonder(DefCanInv,28,'W',DefEmir_Jenerator,0);
			Basla[1]++;
		}
	}
	else
	{
		if( Genel.GenInSayac > 0 )												//22.07.14
			Genel.GenInSayac--;
	}	
	
	//if( (EMCSTOP == 0) && ( Menu.EmcStopSayac == 0 ) )
	if( (EMCSTOP == EeKayit.EPO_NoNc) && ( Menu.EmcStopSayac == 0 ) )			//12.03.2014
	{	
		if( EeKayit.REPO_OnOff )			//12.03.2014  repo adresi
		{
			if( ++Genel.EmcStopSayac > 30 )
			{
	//			Timer.Bit.Sn0_25 = 0; 
				Genel.EmcStopSayac = 0;
				//1 sn i�in
				Menu.EmcStopSayac = 4;
				//Acil kapatma emri (INV)
				if( EeKayit.Konfig.Bit.EpoVarYok == 1 )							//22.07.14
					CanGonder(DefCanInv,28,'W',DefEmir_AcilKapat,0);
			}
		}
	}	
	else
	{		
		if( Genel.EmcStopSayac > 0 )
			Genel.EmcStopSayac--;
	}
	Basla[0] = Genel.GenInSayac;
	//else oldu�undan dolay� kontrol burada
	if( Menu.BattSwSayac == 0 )
	{
		if( BATTSW == 0 )
		{	
			if( ++Genel.BattSwSayac > 30 )
			{
	//			Timer.Bit.Sn0_25 = 0; 
				Genel.BattSwSayac = 0;
				Genel.BattSwSayac2 = 0;
				//1 sn i�in
				Menu.BattSwSayac = 4;
				Alarm.Word.Lcd1.Bit.AkuKontaktorAcik = 0;	
			}
		}
		else
		{	
	//		if(EeKayit.Role[0] == 74)
			if( ++Genel.BattSwSayac2 > 30 )
			{
				Genel.BattSwSayac = 0;
				Genel.BattSwSayac2 = 0;
				Alarm.Word.Lcd1.Bit.AkuKontaktorAcik = 1;
			}
		}
	}
	//Opt kart� se�imine g�re
	if( EeKayit.Konfig.Bit.Opt03Secim )
	{
		if( (IN2_OPT == 0) && ( Menu.In2OptSayac == 0 ) )
		{	
			if( ++Genel.In2OptSayac > 30 )
			{
	//			Timer.Bit.Sn0_25 = 0; 
				Genel.In2OptSayac = 0;
				//1 sn i�in
				Menu.In2OptSayac = 4;
				Nop();	
			}			
		}	
		if( (IN3_OPT == 0) && ( Menu.In3OptSayac == 0 ) )
		{	
			if( ++Genel.In3OptSayac > 30 )
			{
	//			Timer.Bit.Sn0_25 = 0; 
				Genel.In3OptSayac = 0;
				//1 sn i�in
				Menu.In3OptSayac = 4;
				Nop();		
			}		
		}	
	}	
}
void DefaultDegerler(void)
{
	unsigned int Default_i;
	
	LogIslem(DefLogSil);
	
	//Default De�erleri y�kle
	EeKayit.Dil = 1;
	EeWordYaz( &EeKayit.Dil , EeKayit.Dil );
	
	EeKayit.LcdBacklight = 9;
	EeWordYaz( &EeKayit.LcdBacklight , EeKayit.LcdBacklight );
	
	EeKayit.AcikSure = 0; EeKayit.YarimAydinlikSure = 0;
	EeWordYaz( &EeKayit.AcikSure , EeKayit.AcikSure );
	EeWordYaz( &EeKayit.YarimAydinlikSure , EeKayit.YarimAydinlikSure );
	
	EeKayit.InvLogMaske = 65535;
	EeWordYaz( &EeKayit.InvLogMaske , EeKayit.InvLogMaske );
	EeKayit.PfcLogMaske = 65535;
	EeWordYaz( &EeKayit.PfcLogMaske , EeKayit.PfcLogMaske );
	//��nk� zaten kay�t i�lemi Alarmlcd nin 6,7,8,9, bitlerini kaydedemiyor. 
	EeKayit.LcdLogMaske = 64575;								//6.bit->OpsiyonBakimZamani,7.bit->TermalSensor1Ariza,8.bit->TermalSensor2Ariza,9.bit->HataResetle,
	EeWordYaz( &EeKayit.LcdLogMaske , EeKayit.LcdLogMaske );	

	EeKayit.InvUyari_1_BuzzerMaskesi = 32767;		//Servis login maskelendi
	EeWordYaz( &EeKayit.InvUyari_1_BuzzerMaskesi , EeKayit.InvUyari_1_BuzzerMaskesi );
	EeKayit.InvUyari_2_BuzzerMaskesi = 64511;		//User Loign maskelendi.
	EeWordYaz( &EeKayit.InvUyari_2_BuzzerMaskesi , EeKayit.InvUyari_2_BuzzerMaskesi );
	EeKayit.PfcUyari_1_BuzzerMaskesi = 65535;
	EeWordYaz( &EeKayit.PfcUyari_1_BuzzerMaskesi , EeKayit.PfcUyari_1_BuzzerMaskesi );
	EeKayit.LcdUyari_1_BuzzerMaskesi = 65535;
	EeWordYaz( &EeKayit.LcdUyari_1_BuzzerMaskesi , EeKayit.LcdUyari_1_BuzzerMaskesi );
	
	EeKayit.TermalSensor1.Kalibrator = 780;
	EeWordYaz( &EeKayit.TermalSensor1.Kalibrator , EeKayit.TermalSensor1.Kalibrator );
	EeKayit.TermalSensor1.AlrYuksek = 800;			//80 C
	EeWordYaz( &EeKayit.TermalSensor1.AlrYuksek , EeKayit.TermalSensor1.AlrYuksek );
	EeKayit.TermalSensor1.AlrDusuk = 80;			//8 C
	EeWordYaz( &EeKayit.TermalSensor1.AlrDusuk , EeKayit.TermalSensor1.AlrDusuk );
	EeKayit.TermalSensor2.Kalibrator = 780;
	EeWordYaz( &EeKayit.TermalSensor2.Kalibrator , EeKayit.TermalSensor2.Kalibrator );
	EeKayit.TermalSensor2.AlrYuksek = 800;			//80 C
	EeWordYaz( &EeKayit.TermalSensor2.AlrYuksek , EeKayit.TermalSensor2.AlrYuksek );
	EeKayit.TermalSensor2.AlrDusuk = 80;			//8 C
	EeWordYaz( &EeKayit.TermalSensor2.AlrDusuk , EeKayit.TermalSensor2.AlrDusuk );

	EeKayit.Bakim[DefFanBakim].AyarlananSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefFanBakim].AyarlananSure , EeKayit.Bakim[DefFanBakim].AyarlananSure );
	EeKayit.Bakim[DefFanBakim].KalanSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefFanBakim].KalanSure , EeKayit.Bakim[DefFanBakim].KalanSure );
	EeKayit.Bakim[DefFanBakim].GecenSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefFanBakim].GecenSure , EeKayit.Bakim[DefFanBakim].GecenSure );
	EeKayit.Bakim[DefFanBakim].ServisSay = 0;
	EeWordYaz( &EeKayit.Bakim[DefFanBakim].ServisSay , EeKayit.Bakim[DefFanBakim].ServisSay );
	EeKayit.Bakim[DefFanBakim].Iptal = 1;
	EeWordYaz( &EeKayit.Bakim[DefFanBakim].Iptal , EeKayit.Bakim[DefFanBakim].Iptal );
	EeKayit.Bakim[DefAkuBakim].AyarlananSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefAkuBakim].AyarlananSure , EeKayit.Bakim[DefAkuBakim].AyarlananSure );
	EeKayit.Bakim[DefAkuBakim].KalanSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefAkuBakim].KalanSure , EeKayit.Bakim[DefAkuBakim].KalanSure );
	EeKayit.Bakim[DefAkuBakim].GecenSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefAkuBakim].GecenSure , EeKayit.Bakim[DefAkuBakim].GecenSure );
	EeKayit.Bakim[DefAkuBakim].ServisSay = 0;
	EeWordYaz( &EeKayit.Bakim[DefAkuBakim].ServisSay , EeKayit.Bakim[DefAkuBakim].ServisSay );
	EeKayit.Bakim[DefAkuBakim].Iptal = 1;
	EeWordYaz( &EeKayit.Bakim[DefAkuBakim].Iptal , EeKayit.Bakim[DefAkuBakim].Iptal );
	EeKayit.Bakim[DefGenelBakim].AyarlananSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefGenelBakim].AyarlananSure , EeKayit.Bakim[DefGenelBakim].AyarlananSure );
	EeKayit.Bakim[DefGenelBakim].KalanSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefGenelBakim].KalanSure , EeKayit.Bakim[DefGenelBakim].KalanSure );
	EeKayit.Bakim[DefGenelBakim].GecenSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefGenelBakim].GecenSure , EeKayit.Bakim[DefGenelBakim].GecenSure );
	EeKayit.Bakim[DefGenelBakim].ServisSay = 0;
	EeWordYaz( &EeKayit.Bakim[DefGenelBakim].ServisSay , EeKayit.Bakim[DefGenelBakim].ServisSay );
	EeKayit.Bakim[DefGenelBakim].Iptal = 1;
	EeWordYaz( &EeKayit.Bakim[DefGenelBakim].Iptal , EeKayit.Bakim[DefGenelBakim].Iptal );
	EeKayit.Bakim[DefYedekBakim].AyarlananSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefYedekBakim].AyarlananSure , EeKayit.Bakim[DefYedekBakim].AyarlananSure );
	EeKayit.Bakim[DefYedekBakim].KalanSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefYedekBakim].KalanSure , EeKayit.Bakim[DefYedekBakim].KalanSure );
	EeKayit.Bakim[DefYedekBakim].GecenSure = 0;
	EeWordYaz( &EeKayit.Bakim[DefYedekBakim].GecenSure , EeKayit.Bakim[DefYedekBakim].GecenSure );
	EeKayit.Bakim[DefYedekBakim].ServisSay = 0;
	EeWordYaz( &EeKayit.Bakim[DefYedekBakim].ServisSay , EeKayit.Bakim[DefYedekBakim].ServisSay );
	EeKayit.Bakim[DefYedekBakim].Iptal = 1;
	EeWordYaz( &EeKayit.Bakim[DefYedekBakim].Iptal , EeKayit.Bakim[DefYedekBakim].Iptal );
	
	EeKayit.UyariSesAraligi = 10;
	EeWordYaz( &EeKayit.UyariSesAraligi , EeKayit.UyariSesAraligi );

	EeKayit.AkuSabitKalanSure = 60;
	EeWordYaz( &EeKayit.AkuSabitKalanSure , EeKayit.AkuSabitKalanSure );
	
	EeKayit.AkuAh = 7;
	EeWordYaz( &EeKayit.AkuAh , EeKayit.AkuAh );
	
	EeKayit.AkuKolSayisi = 1;
	EeWordYaz( &EeKayit.AkuKolSayisi , EeKayit.AkuKolSayisi );
	
	EeKayit.OnDakika = 0; EeKayit.ToplamSaat = 0;
	EeWordYaz( &EeKayit.OnDakika , EeKayit.OnDakika );
	EeWordYaz( &EeKayit.ToplamSaat , EeKayit.ToplamSaat );
	
	//EeKayit.Konfig.All = 64095;				//5.bit TH1 sens�r ilk a��l��ta iptal
	EeKayit.Konfig.All = 55903;                 //13.bit TouchScreen ilk a��l��ta iptal
	EeWordYaz( &EeKayit.Konfig.All , EeKayit.Konfig.All );
	
	EeKayit.Konfig2.All = 65119;
	EeWordYaz( &EeKayit.Konfig.All , EeKayit.Konfig.All );
		
	EeKayit.EPO_NoNc = 0;								//12.03.2014
	EeWordYaz(&EeKayit.EPO_NoNc,EeKayit.EPO_NoNc);		//12.03.2014
	EeKayit.GENIN_NoNc = 0;								//12.03.2014
	EeWordYaz(&EeKayit.GENIN_NoNc,EeKayit.GENIN_NoNc);	//12.03.2014		
	EeKayit.REPO_OnOff = 1;								//12.03.2014
	EeWordYaz(&EeKayit.REPO_OnOff,EeKayit.REPO_OnOff);	//12.03.2014
	EeKayit.Role_NoNc = 0;								//12.03.2014
	EeWordYaz(&EeKayit.Role_NoNc,EeKayit.Role_NoNc);	//12.03.2014
	
	EeKayit.MaxLogKapasitesi = DefMaxLogSayisi;
	EeWordYaz( &EeKayit.MaxLogKapasitesi , EeKayit.MaxLogKapasitesi );
	
	EeKayit.BeslemeIlk = Genel.Besleme;									//02.10.2013
	EeWordYaz( &EeKayit.BeslemeIlk , EeKayit.BeslemeIlk );				//02.10.2013
	
	for( Default_i = 0; Default_i < 12; Default_i++ )
	{
		EeKayit.Role[Default_i] = 63;
		EeWordYaz( &EeKayit.Role[Default_i] , EeKayit.Role[Default_i] );
	}
	for( Default_i = 0; Default_i < 8; Default_i++ )
	{
		EeKayit.UserPassword[Default_i] = 48;
		EeWordYaz( &EeKayit.UserPassword[Default_i] , EeKayit.UserPassword[Default_i] );
	}
	for( Default_i = 0; Default_i < 8; Default_i++ )
	{
		EeKayit.BasitPassword[0] = 48; EeKayit.BasitPassword[1] = 56; EeKayit.BasitPassword[2] = 51;
		EeKayit.BasitPassword[3] = 51; EeKayit.BasitPassword[4] = 51; EeKayit.BasitPassword[5] = 54;
		EeKayit.BasitPassword[6] = 48; EeKayit.BasitPassword[7] = 48;
		EeWordYaz( &EeKayit.BasitPassword[Default_i] , EeKayit.BasitPassword[Default_i] );
	}
	for( Default_i = 0; Default_i < 23; Default_i++ )
	{
		Label.NominalVoltage[Default_i] = '?';
		Label.NominalVoltage[7] = ' ';
		Label.NominalVoltage[15] = ' ';
		EeWordYaz( &Label.NominalVoltage[Default_i] , Label.NominalVoltage[Default_i] );
	}
	//Log sayac s�f�rlan�r ilk alarmla 1 de�erini al�r.Ka� alarm kay�tl�ysa de�eri o kadard�r.
	EeKayit.LogSayac = 0;
	EeWordYaz( &EeKayit.LogSayac,EeKayit.LogSayac );
	EeKayit.LogCounterPage = 0;
	EeWordYaz( &EeKayit.LogCounterPage,EeKayit.LogCounterPage );
	
	EeKayit.YeniTFT = 0;
	EeWordYaz( &EeKayit.YeniTFT , EeKayit.YeniTFT );			//23.12.2014 - 29.12.2014	eklendi.
	
	Date.Day = 1; Date.Hour = 1; Date.Min = 1; Date.Month = 1; Date.Sec = 0; Date.Year = 11;
	YazRTC(&Date);
	//Default de�erler y�klendi.
	EepromBosKontrol = 1;
	EeWordYaz( DefEepromBosKontrol , EepromBosKontrol );
	
	//Touch
	EeKayit.TouchOfsetX = 0; EeKayit.TouchOfsetY = 0;
	EeWordYaz( &EeKayit.TouchOfsetX ,EeKayit.TouchOfsetX );
	EeWordYaz( &EeKayit.TouchOfsetY ,EeKayit.TouchOfsetY );
	
}





//�ifreli izin verilen emirlerde kullan�l�r.
//Ayar men�s�ne aktar�l�r ve nereden ayar men�s�ne gitti�i Genel.EskiMenu ve Genel.EskiSekme ile tutulur.MenuYenile() i�erisinde �a�r�lan sekmeye geri gidilir.
void FonkAraSifreMenu( unsigned int HangiSifre,unsigned int AraSifreSil )
{
	if( Menu.Sekme.All == DefAnaMenu )
	{	
		Genel.EskiMenu = Menu.Sekme.All;
		switch(Menu.AnaSekme)
		{
			case DefEmirMenu:
				FonkEmirAnaMenu(Menu.EmirAnaSekme,1);
				Genel.EskiSekme = DefEmirMenu;
			break;
			case DefZamanMenu:
				TimeMenu(Menu.Buton.All,Menu.ZamanAyarIci,1);
				Genel.EskiSekme = DefZamanMenu;
			break;
			case DefServisMenu:
				FonkServisAnaMenu(Menu.ServisAnaSekme,1);
				Genel.EskiSekme = DefServisMenu;
			default:
			break;
		}
	}
	else if( Menu.Sekme.All == DefTercihAltMenu )
	{
		FonkTercihAltMenu(Menu.TercihAnaSekme,Menu.TercihAltSekme,Menu.TercihAltMenuIci,1);
		Genel.EskiMenu = DefTercihAltMenu;
		Genel.EskiSekme = DefTercihMenu;
	}
	if( HangiSifre == 1 )
		Menu.AyarOnSekme = 1;
	else if( HangiSifre == 2 )
		Menu.AyarOnSekme = 0;
		
	Menu.HaneDegistir = 0;
	Menu.Sekme.All = DefAnaMenu;
	Menu.AnaSekme = DefAyarMenu;
	MenuGraphic(Menu.AnaSekme);
	Genel.AraSifreMenuIci = 1;
	
	//Kullan�c� �ifresini giriniz yazs�n.
	ASendText(15,222+272,GenelTablo[16+HangiSifre][EeKayit.Dil],1,0xff0000,NOTGRADIENTCOLOR,AraSifreSil);
	Menu.YenileGeriSayac = 10;
	
	//Elipse(190,335,126+272,186+272,0xff0000,5,AraSifreSil);
	//Elipse(185,340,121+272,191+272,0xff0000,5,AraSifreSil);
}



void UPS_Durdu_Fonk(void)
{
//	LcdFonk_UPSDurdu("                    ",&Menu.aDummy,0,1,1);
//	LcdFonk_UPSDurdu(GenelTablo[16][EeKayit.Dil],&Menu.aDummy,0,1,2);
//	LcdFonk_UPSDurdu("                    ",&Menu.aDummy,0,1,3);
//	LcdFonk_UPSDurdu("                    ",&Menu.aDummy,0,1,4);
//	
//	Buzzer = 0;
//	LEDMainOk = 0;
//	LEDRectifier = 0;
//	LEDBatt = 0;
//	LEDMaint = 0;
//	LEDLoadInv = 0;	
//	LEDStaticByp = 1;
//	LEDOutSw = 0;


	//ASendText(90,136+544,GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,0);
	//PDC4 = 4 * 4500;
	Buzzer = 0;			
	if( Genel.UPSKapaliGeriSayac == 0 )																	//23.11.2012 de eklendi.
	{	
		ChangePage(2); 
		ASendText(90,136+544,GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,0);				//23.11.2012 de eklendi.
		PDC4 = 4 * 4500;																				//23.11.2012 de eklendi.
		Genel.UpsKapaliButonIlkBas = 0;
	}
	//UPS kapal� ama butona bas�l� oldu�undan ekran g�stermeli
	else																								//23.11.2012 de eklendi.
	{
						if( Menu.AnaSekme > 5 )
							ChangePage(1); 
						else
							ChangePage(0); 
		PDC4 = EeKayit.LcdBacklight * 4500;																//23.11.2012 de eklendi.
		ASendText(10,250+(272*0),GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,0);			//3.12.2012 de eklendi.
		ASendText(10,250+(272*1),GenelTablo[20][EeKayit.Dil],2,0xff0000,NOTGRADIENTCOLOR,0);			//3.12.2012 de eklendi.
//		Menu.Sekme.All = DefAnaMenu;
//		Menu.AnaSekme = DefDurumMenu;
	}
}



unsigned int UPS_IO_OPTIONS(unsigned char Etiket,unsigned int Sonuc_)
{
	if( UPS_I_O_Options == 1 )
	{
		if( Etiket == 2 )
			Sonuc_ = Sonuc_ >> 1;
	}	
	return Sonuc_;
}